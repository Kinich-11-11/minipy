(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else if(typeof exports === 'object')
		exports["ScratchSVGRenderer"] = factory();
	else
		root["ScratchSVGRenderer"] = factory();
})(window, function() {
return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@turbowarp/nanolog/index.js":
/*!**************************************************!*\
  !*** ./node_modules/@turbowarp/nanolog/index.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// only use colors in non-browser environments
const addColors = typeof document === 'undefined';

const RESET = addColors ? '\u001b[0m' : '';
const GRAY = addColors ? '\u001b[90m' : '';
const BLUE = addColors ? '\u001b[34m' : '';
const CYAN = addColors ? '\u001b[36m' : '';
const YELLOW = addColors ? '\u001b[33m' : '';
const RED = addColors ? '\u001b[31m' : '';

const DEBUG = `${BLUE}debug${RESET}`;
const INFO = `${CYAN}info${RESET}`;
const WARN = `${YELLOW}warn${RESET}`;
const ERROR = `${RED}error${RESET}`;

const createLog = (namespace = '') => {
    const log = (childNamespace) => createLog(namespace ? `${namespace} ${childNamespace}` : childNamespace);

    const formattedNamespace = namespace ? [`${GRAY}${namespace}${RESET}`] : [];

    log.debug = log.log = console.debug.bind(console, ...formattedNamespace, DEBUG);
    log.info = console.log.bind(console, ...formattedNamespace, INFO)
    log.warn = log.warning = console.warn.bind(console, ...formattedNamespace, WARN)
    log.error = console.error.bind(console, ...formattedNamespace, ERROR);

    return log;
};

/**
 * @deprecated does nothing
 */
createLog.enable = createLog.disable = () => {};

module.exports = createLog;


/***/ }),

/***/ "./node_modules/base64-js/index.js":
/*!*****************************************!*\
  !*** ./node_modules/base64-js/index.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.byteLength = byteLength
exports.toByteArray = toByteArray
exports.fromByteArray = fromByteArray

var lookup = []
var revLookup = []
var Arr = typeof Uint8Array !== 'undefined' ? Uint8Array : Array

var code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
for (var i = 0, len = code.length; i < len; ++i) {
  lookup[i] = code[i]
  revLookup[code.charCodeAt(i)] = i
}

revLookup['-'.charCodeAt(0)] = 62
revLookup['_'.charCodeAt(0)] = 63

function placeHoldersCount (b64) {
  var len = b64.length
  if (len % 4 > 0) {
    throw new Error('Invalid string. Length must be a multiple of 4')
  }

  // the number of equal signs (place holders)
  // if there are two placeholders, than the two characters before it
  // represent one byte
  // if there is only one, then the three characters before it represent 2 bytes
  // this is just a cheap hack to not do indexOf twice
  return b64[len - 2] === '=' ? 2 : b64[len - 1] === '=' ? 1 : 0
}

function byteLength (b64) {
  // base64 is 4/3 + up to two characters of the original data
  return (b64.length * 3 / 4) - placeHoldersCount(b64)
}

function toByteArray (b64) {
  var i, l, tmp, placeHolders, arr
  var len = b64.length
  placeHolders = placeHoldersCount(b64)

  arr = new Arr((len * 3 / 4) - placeHolders)

  // if there are placeholders, only get up to the last complete 4 chars
  l = placeHolders > 0 ? len - 4 : len

  var L = 0

  for (i = 0; i < l; i += 4) {
    tmp = (revLookup[b64.charCodeAt(i)] << 18) | (revLookup[b64.charCodeAt(i + 1)] << 12) | (revLookup[b64.charCodeAt(i + 2)] << 6) | revLookup[b64.charCodeAt(i + 3)]
    arr[L++] = (tmp >> 16) & 0xFF
    arr[L++] = (tmp >> 8) & 0xFF
    arr[L++] = tmp & 0xFF
  }

  if (placeHolders === 2) {
    tmp = (revLookup[b64.charCodeAt(i)] << 2) | (revLookup[b64.charCodeAt(i + 1)] >> 4)
    arr[L++] = tmp & 0xFF
  } else if (placeHolders === 1) {
    tmp = (revLookup[b64.charCodeAt(i)] << 10) | (revLookup[b64.charCodeAt(i + 1)] << 4) | (revLookup[b64.charCodeAt(i + 2)] >> 2)
    arr[L++] = (tmp >> 8) & 0xFF
    arr[L++] = tmp & 0xFF
  }

  return arr
}

function tripletToBase64 (num) {
  return lookup[num >> 18 & 0x3F] + lookup[num >> 12 & 0x3F] + lookup[num >> 6 & 0x3F] + lookup[num & 0x3F]
}

function encodeChunk (uint8, start, end) {
  var tmp
  var output = []
  for (var i = start; i < end; i += 3) {
    tmp = (uint8[i] << 16) + (uint8[i + 1] << 8) + (uint8[i + 2])
    output.push(tripletToBase64(tmp))
  }
  return output.join('')
}

function fromByteArray (uint8) {
  var tmp
  var len = uint8.length
  var extraBytes = len % 3 // if we have 1 byte left, pad 2 bytes
  var output = ''
  var parts = []
  var maxChunkLength = 16383 // must be multiple of 3

  // go through the array every three bytes, we'll deal with trailing stuff later
  for (var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength) {
    parts.push(encodeChunk(uint8, i, (i + maxChunkLength) > len2 ? len2 : (i + maxChunkLength)))
  }

  // pad the end with zeros, but make sure to not forget the extra bytes
  if (extraBytes === 1) {
    tmp = uint8[len - 1]
    output += lookup[tmp >> 2]
    output += lookup[(tmp << 4) & 0x3F]
    output += '=='
  } else if (extraBytes === 2) {
    tmp = (uint8[len - 2] << 8) + (uint8[len - 1])
    output += lookup[tmp >> 10]
    output += lookup[(tmp >> 4) & 0x3F]
    output += lookup[(tmp << 2) & 0x3F]
    output += '='
  }

  parts.push(output)

  return parts.join('')
}


/***/ }),

/***/ "./node_modules/base64-loader/index.js!./node_modules/scratch-render-fonts/src/Grand9K-Pixel.woff2":
/*!************************************************************************************************!*\
  !*** ./node_modules/base64-loader!./node_modules/scratch-render-fonts/src/Grand9K-Pixel.woff2 ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "d09GMgABAAAAAA68AAsAAAAAVlwAAA5qAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAABlYAiEYRCAqBiGjVPwuDNAABNgIkA4ZkBCAFiUUHhDMbODozA+WUzk0UNWFR+hVFyaJMyf4PCZrE1XCrh7ERVVf4UtU2dDhJ7VWrDLvaqcqJ5bNkbznPqQAhwDFGRMExarEdon/inbiwzx0hjRzhv9rv89ye6Z73PweIF2RoKgpofIA8gdpK+QgVGxUXxUJHp1YGhItd8B/G5Z0j+U76OHNSSEKbQ19eXlVOK2WHa5qOJAoVW/zWrVMFpNt/HtouGTAIQ8ZMSEQ9OR44pkvx0IHOKCKsu3/8KRp0xH/d9v27ppksjgJvojQLjCLLIL74LwBwAnL3IcWFhYXtthXBdSUIVVQaHM7hr5V9JQ9DT4G044Z0vf4Q89r8ufxmL3/3qqOXpcjqrwiDs/+9fQnJ28xe6aG04hiyS8nV8QhVukW25rCn8c3hu3EIg8NiNM6fERb7b1nTfVEeZKHW+EvCYNEYc6Hmk+aNIhuXJdTU//d6r3vDbFCg0KjzCI0wyTi22Cyo3nvV1tnCGjJ8yIX6uTdN2Aluu5crdpcPehEypSx5Go1GiBz/9l7XW6B+WntAddN7n8egzT82ffDVicHimjd8C2AC+ibliw+GYQLvKTtaxc8Fs5txrQgBJJDAdkaADsyEdGLJZgxcYNHMLDiVlJFXVNHW89BE22SSR3FlBSJiGtOMDtLCbi/CiANIIYcefuGIf7Dbp4S0nKKyup5Rhtoqk9yKKaOKBFGNaTp/RhDRuPsn8Orv8Wg46Pc6rXo6qOHWJCinw/6upeDW+trqymJ/5GsTkPkCRhkgS+ajYtIp/T+e6fT0DQyNjE1Mubh5ePn4BQSFhEVExcQlQFJKWkZWTl5BUUlZRRVhQtXUNTS1tHV09fQNDI2MTVjZ2Dk4ubh5ePn4BQSFhEVExcQlJKWkZWTl5BUUlZQh3hg3adoyLTMHOyc3Fw+fAL+gkIiwqJiElKS0rIyigpKyKwqRHjzkVR0ik7wrRMhoC0CGEFEIADDL4wAKZAPJgGfBkFHrBoYAdpfb4bQAWK3A5wc0tx4MZgybNWWelIyYihrAxMjEoAsAgK5FzhQqFUdXXGF7Re3faD8dDQZgEaCXdMP0OBtuAYDtAAwYY5IJJ0niREQBhoknSZYUmTGFKVwwSWJUoSOm0LTFeIEo5b17LH81k1xuFdmMMOuT8VyatCciKGeOgX4+sCnGkT6Xu9rmosREenxto+sPhR6/5Rhjw8QGrsiyQG6zoIjL3AmDkX1YGiTIbu50ksJAmVJ4xWC3xCtlpPHM/6YiM7Tc6xOJLSqckuCs7DlCel7pzKtnoKuOjbIKxOpUGq6JpDwOqrpXRaTOVII3Zis/bcXikxs5Wd6ZFw4jJlA8lJLhFr/N/IvnPCF4Ao1Q98rF0ZbuiuJ+cNkEstufzYx1Gc3FkaNSK+HqPW1pq4JYjy7tRzORxikdGq/ekaOtLdKVHS5qS68Vs0oK5xsyZbnE1v80qvJwZXeZ/O/RN+ZafCy+U5oHKO26Do/KGpU917QNgWaBQsmgpCRJSUhQyaG0QGmgwii1aKJaoSRAqWs4u1EW7lt14tQuMXtG4x7nNixucUYzJej4GNF2wugRs+p1cBpBLDrn2JYv2pL3KNA1lYTPYoUtMapMLqOjmVByXtaUBxrdDu7ZlSM33lD2JY3UBTZCVu50n8EB8mVQHmWpYEdcRy2AWd3oqfMmpzU30tdruHKjmd0awjkRazizp4JekHHzIUwW4WxgDcwk+/DUNcfuiE7gfsynCo13FSu3Aa/5MIJGgSWl/xrsmLQs0UcE19SyDolcUCd9aA79904zQ4IGetULx3jNCENaBZ2IUCMr5KAXH8hzCqmgVR90ZIWb/VfQJCVMSHeTRwRtHs119V+LXJMlnm4OtXRZE6JJaDcaMFqSprP0CaS1Ug3Evr95hVMtHZjQ6nF21X7REACWSnnqGS+H4o+wLGgkackC6UTXpLGnLzZVQ/AldRjZksus6bYzAGxLG1PTeDW6CLKpBnIE63hQ3Bk9ccaucsmoL+dkTVnD1xDnrksZcz6JDPJMqT6dThem9LGm5EmfUfkCZAA53CYt67JdJcgMA3U7QRbpLYph2sGzrGmjKQ+6kRT0tJBuVgJqc/knPjfLFRnrV3IWGiNLJxpuNfSjEY8aI1sZPMkg/wfCpIVgk66kh9X74lTPJMAZKcitciiOsigkaHpIuEavAIdnOAkE6EndquP9tEMyM2CqXr8OzqFUUA8QpbA6mmDnlI+s6TSeR35d3JrfnGCgw5YDDdHJVnQhaxta58EnJxy6HBDmgftJy13QN17FqxRxFlnB0NrjfZ7ijJ6KylbQ/80WnRrO0F5atbKS+toAp9c38UHC905yLbni6viTSSBR7WpDXEa2rDACHCt1XEG2jepitxAw7eWklNUWxOtodDrM0sDlomHblJq80GaXZeDqYtsenGPlHRhqdvsK5x6E28Ww8LktjKxqlDDqliGuzU9H0nvEFYRyKNV2XUkkzPcmpxf20RCadRQsV+xIOTaZFFDgpilsU7oh3Xa5jEkvrsAcuHgiPv9zFloLeDmjBcA/gRlVu2iCtLqYdWrCafcJkzkdYcsgtGeMRwwh1hiJP0Q0ErrEOYFssCaYCM2V16kJHNfdfwL0BcLhDqCeDTQ0ExwZHZtAFAu/dV5UddFEWpQsnT1+PSWb+Mzht8iiQOT+Eme3l56nw1FWlZKhK0z7qE2xTrknE3xTYGjahsXEF473NtLT2HcIDknJ292A5hrsGjGToTEv/brryB3qLYi0PNfcG9rbhaC+ZIvIEwUv6XH2KpJEi03hHAXTT8ROpVNQqLsAMzXYpeYi1PmnqSRm3a0I9BUOwjIpOisAKDhLx+ZaS8A4M8KM9EMEq1txVnvaBhSbDWn8D3ac9jgQcmcW9KmBxSWPCuv/tbSrFRQNKFatwgGwOjimmzyr9lquWPyzmwGmWX67iRW7d8+aV5e120v0Ts7vtuQ7DsKhWcvjgZnGdREo7qIrKKJEzke46pvRFR+yVLqKKc6c1nuY+m65TrP+SFM8FjueiOaSaveYDmteWkionJojHmSgQ2ymWsee2QT5eIsh2tKvhQChGeBeng/DMYvf6GLjOZ0dImtH/HDWJTdL8hFQ6N+JvFkiBVLMyw38cEVlVB1lfiZMU3zG7gyYCainf9cUri04UGzR5JbyFy0pQREeOo0QhvinWiAlYLO1IW4aWMTHU2VL2pLiP0KxdEhIa8BpiVqoM6fW0UG0VbC4/IOyXoUH7QJeD6usKHnVuN7V8lBhzPGDn3/ATcNMxpT6G7q9iRm+hruzRbJl/ywBD2QIbRgzbGnH/KnDVHcOv976Ve2LOTrY6uYyg4hWybwykdqKrtaYCUmIeoeLUgzzDMliN3iSgZRTUSmKwUgiSmPrhXuoxCXCeV102666pd4fwtUAoGsq3Y1Cvoq/yPXQhzzIrWYWLWFJNae8cn6u/41VLWK4ceFu4s3ujlgwN2dqmWmdQ+u3FNNHNm1LNdysIY2A8CqE6Uta1xB+nEcLicusD7NwYbrNxKXjMHuR3931N47BTJk7hZXMNmuoiNQk4uOsxmN1BT5e1FSxLqsLy6rRNW8CZlFtv5XwJJzb54tOR5FOprv9xWpOjjajLlh+MpV2NzMxCZO5qzqAqQ3tNnZeTjWzsGbcgt0WGsO1QkSgwKzNmRpmWn63kivSmpHQ1Pk1UvWON+MRrmdkusbu7iNgwikaxvsGSg4NP4UZq9QaZXF2XtZYFVuVvB+afUOuGA0gJPdnqZTRr/Bbj2VFJfgO6YsPPjqZhd0ETRY7eRvH+n2F2Ln8KkDUBu7AV56xKDDXcLU+gLp+z9KWW9j6Dfz8WwgI929+WMtt118GHQA/P+s+/H9pErGiMwAEARD6VkgPQAcBAACAxQAGDGRQQIAOxLfzdowMeBMbJRA14bbtoKMO51qc8+rCATlq9mW7n6dapYxmPC3ARFxFcDL+bTEl45ly2zOtB5I5d1qXKH5pNN6niSS4WRVZJwgZtBlL9aNSTuqukPmyXhVFE+Z5HM/N7WZuT37M9zP1AAKL7B/FYX73G9OKAMA1CAGQkWtUAExxkwpAsiEW5pC4TU6TsM5b0rPLe9J33k8ydMDfm8dOpo1EvQe8z9mQyNa8JWac/9uSo0OYTeJOlioJB4tLes5VMulbqMNk6HLrOGnsVst//B7cYSEefog0qnH9KzpeM5eBDX7JOTu4UDL9AqfydxOOxC7z9reppG+mTgunH6YkqKLJWueXpde4oc0jfTA+QgheGLCkS5zDQm1WryODVaEXrqzCxdt69RR9zt/BJrXWUsPnVWb9l8eGxV60fBXXqBn+xdrNsrL0M+Jugj9bYGDo/1tPLuBK11rRD5hGK8UmMMidjusfgKuTsOELTI0QXZWwsZLm2rz2u6+DtQGAEmBzMsAMwg4MYATDeEMUDDXIAI4xvQjsiEIiGzIIO0IMIgaMIASGss5su9yZijFEnTggGR4PgQGpHDtYYwDT6VECqqCJMXMGLiipbJE95APGMQCTF9iHlihIM+COpsB9QO0ksDLyJc6RIdhLxpIzA4gbQiZ+gp5CSXZFzO1pxwwwcKRViAek24Jt2Jfp7WAkCp7BWQLlfNaQPt0Yu8LLeevM5PZR5BwxQgE1BeRDJYbhpgC0UUQhQt6rLGAeknDuQZhEQNFfIOfUOL0HgFNHBDMBYPUQH+Z/9SLAerI1KyANfCCfHJw+GelkxGnJ2Bi4qM28yIoq2FgpQuPtwbqCc27rZO/g6Avek7OLEoJ/+57dPSH68keDTFHTq446wtCvz4BBw4aMGPVJaGJ122c25UyEyIw5Er/+dT2EmrJcwa8UdXxSSU99/nnLQEONNOaHdx+Sappa5uoaFqRUcoZGmfBufvlIMcrUaHM8hAFGW4SPsTMmcSimcSweiBPRUGdzcvVtZ/PwxjR9QwQAAA=="

/***/ }),

/***/ "./node_modules/base64-loader/index.js!./node_modules/scratch-render-fonts/src/Griffy-Regular.woff2":
/*!*************************************************************************************************!*\
  !*** ./node_modules/base64-loader!./node_modules/scratch-render-fonts/src/Griffy-Regular.woff2 ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "d09GMgABAAAAASY0AA4AAAADL4gAASXaAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAABmAAhkgIIAmCYREICoysaIjQaguIDAABNgIkA4gIBCAFjmgHhgAMB1uLPHJCVRg6CPbeztG2fQHh01WSguk2TwS6A27qjkplZQaI24Hcj3payP7//4QEOWRYoHqhYnXd/wYgRXZiEUEQERAKA8WkSLmc9rnvfCUc0OLYZ6BT0EtmkX/yug9ZOxCf8MTvrG1VYOKI7MhuV2Y7d0RX1504XAnZ0q4iubhVTE1P5pNZa6gJ7eDQ6uCkEULoCjYBWUYdHboH/0YfkSHO0v/vr36oz/cOOFas8P0e4pPMuPZbSa1PNjfJjOvYZUAZtx6MZOXIleT588/TNt+/wzgscLi1vajGrXXDZWJFsWqsRhcYxSqMwhW5NbpmfR+qfr9/e2bv+xBiSWiBWIXLE2sSJrHRicbyaIHKp74KSsAzP31T/dfMzoIkO9GZmd2VHSfRSruSbMepJe1KhqS12JC0lsV20hpkTnsNFGgboKa9vcWkcHuhfBEeIX4RD57bjS7CtapHFej//9dc/e99gqSqcjhHUrkadzMj2QYaJh3ZBrrzUdkmdFqSbbrzvZKJkyVjYCZXGSbkKgPdeb0q+6ZQZlIq090vxDLcFKAn/wGTPt/927Tv+6bdZ7NWty3tsm09yjdKCLz0AbgqrZsWXJDkmTcXBv5n2fonHwiShQYIMMht2nDGksxeXrMduv/M1UrGFB5h6tRJvOHnSVX7xz3l3jsFwJQ7M5gBQAEkCsEiAWIBi2QDItUo2SZVmu2YlBxHspNdUi6yU34o2U52u2g73mx9kp3yXpdTdvO7neSVbm//3fFvLeW3AhWd+AIPYUgAKz7VVneaPajlbNs6SewFPwEP5qGxjhWq5m571+7eAWDngcja3VcFQUnmz+NDpkP+EN1arXP4eTKn/3PvzOyuhIA5d+7uSmAnc2dnJQF2PHeLVsIlM9skhJ1omyTAdrTaVaHY2ZV2JYGbhAQCnOSp45b3JBBgO+UDBpf45X1j91fdU5rtlBf/aievleFJp/3/VEkgsOdIA9jO5u6ckcBOcsuckQA7ye4/Z2YAl1tmJAGxs3v/jCTATm6ZkQTYye5/EtXZ8h7VOFslwNjJbRTb8Wbv3o9rcju4JdnbjO1ky2t2yi31bzrfKzbM7/5UJekfmeq+ow2JA2kvBOfavSioGbrB7i+r1f9Sq6Wt0QEarA2STUK4NFK//7tb093a0Uhzc6y0dubOz5610uA0WBdRpMZFhM5luwQZZJBtkQQJl5Hi95ll6WbNYLGze3dU0qJHx9xbKm3RctERPyIwlZVVQKvhjcCSEBRCZmQ2cFXVA76Z3uV7WFAqSxoeDdvQyvBoWCbvf+p0u22Fo8qtKQXkX/I5jrXCWA7jcj9rMVURCo00COUqWc9jJFLzf8tq9ldV115VT6re2HMhBQ+5Jy0hZInaNJO7L+TZuRxm99KwxJTdzhBidOdWQpZZRnUoHM9jESoJhcJnfeDOEbK7h0PyPA+hTkmMROgTimAMkodQyJMEguVpJg+CUcBdHE8kwpmoNis+yXLamwv6WocVJkYMzWmNBcAwF7+j9znStti0Yt9Oc/1BzbaBhyRvPIdsVidUOP/89mz1fEsNSYjNxCaBcog5+/8BB+K22/7Vq7f0uOkBBBLHp2zJ1jXSjGSThzkrG3Amj+fEJQ3Sxt/8yr6x1x2W7G4bhhBEgkgQsdfPd38HkCqTAB2AeOHzAGRNDqCPzLwj8EBEnzX1AFhu55yfwN1mz4NluuAvQfa1PI5IWRZsaO4s1ykp/UjtAbH+xKFuyfAYV6TvFB0YRILReM3WPHG1RTt1UMGK1HHP9T2/nMoJdAaOBYKBcKA/MBTIWZZZWQex9bjgqPUB66OjH2pf/0swDu6XhGispmuuloqnbTogYcR33XXf1EEBf6ArEOjsbjA8IvCk/ADww0W0QH4LnR97+sVY0uKziaIEYLskUGTnr49TjJRHyIpkhOyEbEU+7dmf4szew6T1VnSCPh91yBiZ0pMngrUATdFIWT598p+wqi5EzjhLo8gg52S7rNQ1Vfpd8spp+UyxCRW7oNU7JspcZ8wIS6Ua3TrVChAoV5Bewbr0eEaqz1NIiJeee6FOKDN5FGTkwuihXBQhXKRoUWKUixUvToJEyZKkSEVIkyFdJoEst1Q47pgTTtLHdIfSJ59998Nf/5AY/qPVa4D99icoKh+99sZbH6i9J3FTm2Yt2p3yRDV8a0NGShs8+d31RmIEQ6YVjkS7e3pP9J18qD8WT9hOMjUwODR86vTDj4wsX7GSa7dq9Zq169Zv2GjvsGkzz3HL1m3bd+zctXvP3n37Dxw8dPjIUb6Ts4urm7uHp5e3j6+fPwRcDgoOCQ0Lj4iMio6JjYtPSExKTklNS8/IzBIcO37i5KnTZ86eO3/h4qXLV4TZObl5kF9QWFRcTm64pWVQXlEpqoLqq3Dt+g1xTW1dfUNjU3OLxA9CiDChjAuptLFRnKRZXpRV3YCXsn4Yp3lZt/04rxuYsZCpzGEWS+CyDgDzVoyejQCI/4AIJu0QUZsOVCGUebAG4YR73FFVFLn/2Ltkizglkt9K3GyRTBEn0CKdkkLaLFtLLuHFwVt4RV7nG1lzK69+wz2e6ghhZ+84f2+g9urh1Lv7sEXmRsiS0JUiH9vhR2LBv0U+Nft62lrbxljTKrXmEwHJ7K7PRDfBKkbfiJ7cLH/flYgKMzMm4C3Hyc4SjX3g8cWz9QTW7GA1Rn28m+77/jAnnjBYJ23mUuyuNce7CVWaJXjmVW5XWyxMzXaWtQq43ZsMCBSMSf2924AGRLcTV08YtR40ZqpE5Ns7iBsVAWEZIDM6py3XgIiWHTIUaz2hUWYDsQUZSKsgDZHIs8oIBl7WjW1te2M7O6TE0Lowq2vUiUW5ISI5HZMJ7RmSSST99Tsx/tIjRLcAvvibvZxIvGuNfc4q2dhQV41HOt2tiU35/78DD7ClEtcP4djMwLFX3mLL4+qLE44ff4VHXZiAR2GbdWv24Vkltvb2+OxKfC99R9O30t/YLVf9PMn8fZMlGPAkzKLTWlZCA+lm3h3HZZkb5IaD8YSJ0cHwj67ZJcIvF9IfIuj6BVx/M5WOz7JrtGuL/GeYtTd4Mj2c/objWjf9B5mIw3HMHfxgyKWnxdHxccdvGvvv/+1yA9pU3ixv4i/AQV54hhLPwqN+/NmVwjY5Ab+bL7TGe3H7I3opfv3wOY4MwWvCcCQ+n5jsxpuxLDmtBfOxaQWmgs7QL06nv3mkchq+8tzBCofSCN/ctAzr7D9Lpz7ggeX/PmIjurdw1vE/+0937ClyOYP99lXta9/XjP8mOQewef8sbujeVbS284CHw+qfT7fUlfyL+f9JZmdctsfvc1oyb2jg9Kl492zmzre4624uPQrXf7NdODzwOQ8Pe3ebtdah8+ZVDuH5IfvwXqxZtP17VPC2NqMp0RqxLdNyo7adNspiFhfZokqT9GYvKT3zqVIq1UL93UB5yBRrzEgt1PkxOalN2pvllgxWbJuMLrO0aumddUxRH+sWEYaEDqFomHMbHyddwaXDPB+YESg3A/2YhVEhqbEBoUOIBuuG8/63R9JQqpG1lGIhalZE5e7mp6VZSq3fup0L19MHhzkaqmVZo3mSjzeBS6tNu5ZcKXJORc53SIglmnqpEwOLmIYLqjdVa6J6mDoJyYJDIJYxaACdEkTcxtbbd8vEwqjynjQUluLxweUIQdK5+Uzg22bRi7e+PHHRoq2kz88XR6y2mhogY5Qe8Jg3kCDURAeCxBek8aplmejd86SsqQL7rHZeJFpKYXUAJm2DuOYkrBIEuGDsBDlPAPSd7PvMj5OUijTNnQaxZozOEAFjuKpFUGAmDPQsf/uNzORIXq3/W70VNLQqZrr1QkqTxh1+4XRADyNI5rpeJmUQPp+EaYGfCi51ho1Gh/b/vCeKeeXBJtIeBVfhMHYSakS22GADXqkMcMsxlADb0sZ2peq0BRQXk4wgM/Pkzp9pMvBTTbbwBZHk0F0d26DlsSAAB7lXQdAYoDfnCCN8T2nvoZxnk7+CgjmUwwMcLOetFt/xwshR6vVX4otpq4mEGf0vYFY7F3lr2ZO21PqRMq321qCb4MnRlMp0FZnlasN3rxUGcdiv0l1wq/R2LNTk3VhxK96KmOPitUUC+/SHe/LS8lcXC+6AkXU/fFkQBxCH1iX+M9k3pZkVDDcDZizHmR1ODltfwPBQXpyqsiiLvMUgxoV8Trzlqr4rDdpq7Fw6qbtNOar79m/g6UQbanS1+9Zv9L1qDQsDnq3a2d1NxccBeG02M8IEK4cx9yVaQOz2CqdBT28yiK10vP5/eYt5FceHUCkUNY07Sv1wpFoYRdItpftwOLhCoVYoHXsNxa47sddzU0BmqycQSul9G57rITj1fbEab4rr5ayB0ysGBeMHKpXgZXUGYJ0+z6jyzkUTvljFdFmdPi8F/RQB4V2hT0Er0BnQhwNZt4y7YQCya/RmVA7fqZeUItL4wAOCOQT0krSCuXa1TMDQ4ttGw9cTosx3FpZMIk3xnP3eDAalVdcvLzZbgRWuoK388ov+t0k2QAglkRdyiG9UbxnaIoduo19bBlA4f93DF2WpBzjkvV5ThK8+kHvkSACfHSZEKSpw4rEbRe9DOAw1Z50Rg5E9qXaZnoHzHGJjYjBUB1vFBkem49jbU0MrxchD1sLJE/lR3PCRpZP0qynaKaJJygFYkABiSlC/ePmUVlSDp8aJI5kyHIa5jcTuglu8hnTKhyHdJSem3uWHSfF+qk/+20zABN1bk3467uVFDGSKYO6BUFg9D99fZR2aXAZ94hTM5nknt+ndlGfm95yagajiacsPkoQv/XVBOfaW/x25zyI4/H4rcVCTUuh5DqKiocztyEe8qc8axbODcERYRBoWf9VGtaECv1pSCwN3KQkXjpy4nY5dC97WfKIwizx7M85yT8UYA0+Z1dcUQQigLE03WlJI2DHYx5rMSfY08LONzngacMoosrJmTU+Wp7luBrXCEhh9SmFuzU7fWxCkOEG0Z8bNVpyUA3jABG29F6RsX1rWHvYAU92LvRMkz/atMzfeeTxdaaitGWw62OLpRQxyYyfEByBSNIwohS5FfN+lJcL1rF6buKKIkC+I2l4B5sPUT76qI6lTgWgJdddzsqC/Vf33/33L8fpSzK7w5YQP2O//FjLf55t/QdaTKXOy14/uzeiz9d25JsDVVTvAuT4Ov7sYvwSuysw+5usvQePNUIl5SNkFWaXCCtC0KcJTH20uYP8pI+HG32g/vgydmXFndcq4M5gD3HC/6Df7djplcNwVRI0aKDpBPm6T4BFblboi+Y5j8Dk1p/B1ENTP9JaMk7kpjJI38YTZECCTbyKML5sd2yeTv8vLIwz1r9M1b9PxrWK2S87JB0zDHT0O/iC9j1IVfmEE4huX0kw8H+nktaKv+cgfFrdK+RdSqQbHkQEYrHP6yC9K+6zoQaDXDlTLfiHLh2F94g6TJ/QzHQ+jgFncfeZa5mfyC9vkQR73KSPYWjOmJnz8HXbhvXtPPtX5TjSR6yGm8RQLu+SEmeFpsrL+rgdi2mwf7zAXjv+29feEdxGmIpAVGodM6ZZ66J5GPiluafzoablTFbw2oxex+p3YLR93Uclgq56R1Zsrh7JQSWyuql4bbLhF06h5FOz1zAbm8aOd4X/XE/qlmZTZX3tvVqOAM5/seRcMNaF/Q3jdnOky1bG37AEz9Wd1NzpM6mGtCyovLw6qKmqsFhJ3QyBnYonwbqBEidHPPXDV2GOzUkqnTC8mzkmdWIOXsIM9ZPxcEZObnLpQbkw6I/LCoxYVHw883VrZWtEDH7gucQDPxchuuSCqOag47qvIKUHLV2/f4i1BO+X9QrT4T3ECzqIh5Dpi53IH0RPQO5f4q28Xs6srIXNyyWnYK9uSVBHvuwNkPnXln8/Cr74iZj9WnvBeq5++P/2TQR29H3q+qML6zNm4dxE9a1ks1jrG2bLS6wt0cWgZ+l2oCI1MbEiWK0mENAG2z1gXvsc9Muk6doyjXkR7ev2Dcn1FoGH2/Jbfvbs9zSOoQLNmnseO0Xs3lQBrOjyB6LvmOfRZjnL/7YrON9Kin/3zL+84P2wQRGm9ELMWUgjUD+5rjioudGm2v6kjTHkAomB0e9rlLN+ozO534FQiRNQr1Gx/h8cmWlbpDK5r2nmv2YVGoyQzzGruOF8c7OH8FLrVJjelWKGhAhYJMDBT5kAYmwWOAVGlX/auS/xhB3TD7dls8v1vLTUAplKGZJDQfpl+9du8HlXWNFFqGHT5GscZC2ZJQpe7IRzUZHozKw4rUPcFU4F9a1Q58SThYP0Kus9mfhsvVBHyUL1D2OFqblwiqhKxzdKkDCsN555Io598nc3gAZT+zl7uDs9S/iM6GBFeLF/g2meeNrXGzozUQtGCWe1Bg2ejsm4+hgPE4qCjelOk3PKz0na467MK4VEXNhbNHlSCJhHlBjVOvcQGsV0Im5k4L3zk74urRLsKLRU047f2pnKot/0GQrwSgfyQrqOqPtgZMX2KTXokNaTZCgnLjwiLiUtENX0gY5heaWXn/7bv/hWAiRE+BslN8hCiMcN7fQBDTBGLCOrkImJ8J3U5/QUTB1s3JAKA9f3BP5Koola+HVVBI46/cjs7elq4XJZP4qxUkQVoVBSJjyhJMBlnKaApVNh8bY2ld8FroIusUOBXMBOlWnrZRbBZa3GrjQdnwyc5N3X/Zuu6VAQ8waSTby3kcJBVC+AYwKarAB/liSWbHiQGmKfscBlBbjIUdBwB64RJJ9pLYxvDhYaCsRpH6/BqGci8cCv1p/xupYgBJjmSC9Iq9B5TcmXfpF6ja4NYQ8sqniXaBElv3Ktz2vpsgcprSs41hvGwq7pjn25UEyRCyWsZBG//CkG9doVy0yJMhphwz8L+ZDEzirKNzInULJSc8CaxE7lLAcLUlWp07qefZrVQf9IGUCsRiIApenpbc4OkjGudOvdPgi+nNLDIKeuH438sif5CPgBUZyuv1gIgR+NqN8tZDg2Pm2dMFIEpIkuL8EX5VP13IPEEjnbsNMneuNF/1FgXho0RR4s1rRpUxk3AspQLPKKIVx9YGRUgMwzoqwFLCs8WQdSocvxo26vXXNDDFE5iJCbwqp52uMqLNjMTFlkI1WCM5hS0zUsKsq3wVPNqECFSuPutUo9yeNQvuzAl4irLSE34QP183sW4u5CfoACjAP80pk740aVybof8+fhham+hnZ0sB5Ys3SxBqehvW087f0eaVrJvpdljjNuT/LQ02YBcMW4BdCU9TosQ/UZtLWlNK3C4sNyeHP4Qg8zK8a9wfGJ0jnFuMSCW8Xbuy7ffdsVEVzvIPOD3T+SHDX3BiI2hqGxw9If+UpPveI6Vd9kzcx6vdvv8bIDaI4dVOKmZ4DPzXhJB054tlD2Q7hYfvwQ5RoGGsn1HuqPYtawl9GawGokYzojgepGRS8Nu92QHp3sddbXN2KxtmQ1dJwx7uzGMsdEjNyudjEKxVXiWKBkFfaTZUAG8a0fJf8tf8AmF0vBm6YJO0yhZcOiL0Ji3AdenL6smvvmtPtFWiMoVL6CpY0J3ssRsbCFsOFjJY2rhx9LOoJL2+0qoGTr4bEd6dR8JM6Ao637Yfl5AYVElxsLSyLoH9ZKzzdQEfzo72nqwLaseFCPcL3HyND8taoF1emwtHzlD1LLLcmPlBZ+XqXqKCoV8Ucv26MVEt9snfiyVc5boHQjU4pCKIMln2HVFhUXPhaMUcc1vjefHLvEJslA0MqlMKRgySItyjAFWTCVUZR8zNZ8KGjuRDXmMPgtyHs8bbdU3dYRajqEc97Is6+u9zg/CPmFz9rXsUuLiaudo3//ULueN5bGKpgcN8C0yryuJuwC5RFzEVy4F3La0reFDyiMxdNsFnovRwwCgfmvmW6fN0T6c9vcy0QEYogoGolIefFneUnv6oL7o8as1Y2xsN2ZfcMzJG7VVr3oEKnPesnuyByQVYAEUkVnmWRqddqMrM/bhsbzMmAoSQdd8mOVFFKfQl717CQuXuljUfrNcAsO8hyAWcSI1M7k6iiznFt/0LV4tGQm86eDs1ekv/XqX2rsoy2j01Tq6OzZAA0NHnYayImovpTe4YVN5tstYndYz3rN7gOzQGxO0ST1F/Cx91oeUXF/dKMCVrFWWQYlyBYeGFYwJ77Es3soKeLP+Ua3M//zUmViP85ZLN5/eyn4iBEtZFZSnlVzxgWOBNE1o/WCGbRYo93bBYwTmaCtjBTUogdXPP6tcLkA9+yONIxuFxHnV9LWroWCz+fA4vMoiWRlZT3UTOR5AGDHUclfEjsyqVF7UBZuaKPsz4ozQkRfv1kviD9BbICp284VvHAXnl9+yqFlTk57ByfMohGjjDnw8Ugv7lChickmOvnA8WDv6UKOv/UHWnKc9dWVShU7JNLjjblJ8V5N974QeG/Ou87ixlIecfGl+s84VSXgeTCh6yW1bDpcz+XBlf9Eh52ov+uYkoJGJgEqtkzgLOLSVXBZ9wS78TXFMzJNfg/XPIpALSt9xXB1QV1kdW8y6rYLFGbCZ8zQFX191xfcIAD6znbLpXcd2vsdHXQKx5jhifkaa4zEk323eQYgQAxefkZSYnVjhvd0CY2j2PH0rh0FR7p9QSsvO9wcIyijNGL0c7lxTEAjJMrMQlrHsz6XDvaPMM2JnL4B848GIqIWvwVil3bfxWIA+Y0/7UEW9dfVCAFRybJS+wtCxxSQus7LoqhCZMCHaWe+/6w2C380HwUuXjcjpaKzUhwN8Ko/S4PuODfsqeGVGXMc4Ja5yAH86YbbKgSsvaD4sFcnfvQa2RPAc5s1+kDlVK3XfMYiSftmLUf8ztD1RE1NNfgRfRj54o44r3k9/5PieKBGptNOup2SKoao/YI6O9H26FSbHfjXr3+kGT5EmqUCVftBm5Z+4B5gFMZGM2vfkChMQfeFdo5xn3Y7DtuF4SuTM5Zl5t7BBZSZuh3L3ghWd2V9AszgGHH9UnnHRjQdRy5YTxnbD5id0CUx05mgpTCny+TKrJoCOaidSft1zHoIUw1tiiH8+/j18XIrHsh85hSEpMhsbBvC5rY9qTBFHuj2RuZgtf23t1Rop0PPqK3lWkK3obrAxJiHRwFFlAxqm0979If3WS9YwaSmzbJ5hUlkQLpXd1XQ8kOQO8JZ7cnKjK9pg1eKRD3LA0Zj8spsq8pssWWcpTFHsXUZZ3cX4PFZU2/FmCNLwdT7MvzMLrE3o60kPhG0fiLcJZv+Yc+stcXxfrOLlYm/2iL838BWq5EjrE2I57dvORYNp1LBt6UBJQti0H4+aBw465tZ2KQRlRRH1Y4JB4OHGRNixrwcItlWHHtVx5Fk6iq32gEKzB564KzpZdns4KJVBKmX+RHDYfWBkJQf3FuogDifRiTp0l6CqcfBZF6nzAGq0UDFBnhhz0iCUjWPv0+PQgvVjF6bHW6XqUcSMxr692at15Y5zdJbr1EPoKy5BaWDlCm5aDQpz9asZ5Kr7biYUr44Yq7uqm09O+Lv94bNbr+4f3z2yfpTClM77bcj5TYFVvDLv6nC78xrt1vPIjlnR15hCKAh0ZbamnxOdXqtbuOHq98IQvf0dWwgiNC4KbS0nzTjkPJTQTjRa+viXaq7+mFP9LctF6p62yX4mIP27lE1FDTC2vPvEXM51JK/yMbagtsYEeUxhjRMtwGVemLXMe/1DYkdbZ23nSSHcgic4OTttCfeQoVaKs1CT6N1KV0ZlKyRp0gBe37FDl5N5VZh/7A/7fGRDV8TGMeGpVO7TIBYK6BMstNdxU4x2sPdjtuyKPElMp4++TTCAgCH8ZvJPUUsawdlczNj8E2ttjxnpsA+mE56GjbfZ75hyaAXVbsKCPqfFDRUMvuJ4XBmKqEzRh2sVN1YerVU68y6FgwmmRmQ2b6XYajw8WsXjnB2dtmeu0C4a/ILviNJCQINtV1pAA3xlY2h5A4OYgN9/9quaMGWFEyWf4oIpuRPdDhgE1WIn22+d7cXUCyoTJwU52FkmTUIYSQxgD8NS5zbZhRwfgIsCvH02fJbLV9BpgdOYFB6L+KwzNzGlnftLsvg4cK2EB3Z1mbdtqSCZil2m68QT/s+XKnv2eefgZhdh+vt2++QRvT38ejuoSuomthPCE+36RTOvPataSGN3O8/XnvHnOqprP11AU4voSrQjM4M6pclsUmnVksEvg/DDukeHN3Oe9RPTXOYpXjWgRNBfc8yrSoEPjfmppZdmT/6e1yC9M1Ck37x+K6RZqdKf8K3WeuOR5FOGoFIIaAKNqfHcaMG2DS22k2XADI3rxBIL8RaCDEidX5QYYdVFm+cZGzIQQlhhQRIv0ZhqgNP5vnaeqal7Or7vwGD2fpuoE1He3bUnfNGkEmrTcpz9MyS8Egt7veQMXmypFYv0N+omeUGJ6lyXhWDob+mcuJWsPwMx7fRW3pbzYK6TiiqRN5YeixDoLryEe4IYmSLjZxuTvdSiZg92zGhWlzY4guUgTg8yw7YISwRoYTWP1PfyaVp8INoa74cbymGa5h+7uX/d+ua+BEBRJ9ceiM4FXZQnj2e+U090KGtUTaGg80514Rousmb6IIP7sxq69ObUZi9+H+bZwFTCTrFbCfibT8Tlvm1bMEQi0sunuR9rEdbH+bRBil5mwGNxHMgR7fC00NGf1g+/GZhC0qYdzlgfRiDQ76FNpoRICu2w8Bp5KyNO/x7Jc00RXyzCHiW1+ALHVReDaIVtW3qwTBlbIqLRyhV4Eo+fdej0gfNRCYNb7jx2CcDLueZI/XSXPGGHXxo0fF8YbpngNctRmmspMS012HO6CuGW0dE422eoaFVF/M9/FQI3/QzM81H8C+MFX27fSwbhmeDuQmbcdW+QTewdH88m1DmGcOjKDko+x7J15V0qTHpmfLQIKwbKy4L37K1vJbvOjH5q0xM6jQLYysTNWBChWegrkrjmtUcu1aTXuJJEf02w74M0BVcel/mZBFkGd/r0Lq+UpyHEjn+U2ehclljPqFNVZw2620igLrRLdcKvdejA/mt6EfZ0VsQ8kpiMocukbznR6MuBfQMB/9eKxyutXS8Xr/t/SvzqZ6bTEo/jUmzt2LEgITR9ydP08FUKK1LO55Qke7S117ZjDrtw05jubEfwvRIUjiW+Dcjqra7gOgTnvrbR1c7Q3XQoeGDazsFqCMA6YG8UgGTinbfO98UrnTzweCyllitL4Hk+CseRCLFcUQ2arLrXZNets2MsGqYToZGwlUzuDs4RU60Grqk7AC/XqmhTQrqBuPD1QuWs/5oCzOkUzL5ycSh+ocUPnX1dNc6NpEe0iyxQDOT6WkhM8ki9tPeBKJFYIUspyhSdjUeP7Gpp61shS+iOYSZNMLoYW/q7yGAInA+LQVPktwVzm4UMXiO/0o6xjlnOoBttCUbC6xMtrTPAPnVi6SZ6wj6ieTQwPFVS51dYuL8wIw8qlQYxhesdZcS+9iTtpYdMJODyBHtkpHaeejEz2PFgJ+ViUEX7exswCYZtzo6bVmDEHywsMDqfRedgMUGsHOcw3qNCzKLSItbFau0UAYaE5dngVWOt8v4Qc2zLOCdX/Pn8cxYcM7MPbuX0vL7DK2J1E6YTU5skxWSqEPT6+oUsndPF/uNOZteVxxHUFbI3+Z6gn9eJSC/q0SkblpfzbVnIRGU1ulyCN+lhptMQkLjss7nu5ObbwBQjA+W8roP1AxoqTK+JquPjlruR8Z6C6kRVIAGyhRI7s8t8vSkY2RPvi+63Daecw3u1N0EAzP3UkZgm1fCDwZMTY4ypkKcHDWjUUZivagbTx71t6TlemnBM4bdGjpXvvZl6Unbl6+m1fmal71ZZCNPb8o68B2Ex8azzPZIo30S8QFxyAJrwH9sxngb4rFqnjMbXjppNn5KNDS3HbwkScGdP/QTEkkKZsUzXbghayxw3FDYIJuds4A+Qa7GYnD75Dee53C1CZuIsDwQIzLZlT70OipapvecrS1piM1XTu9tCVa5AV7OJyYle20NNn3BXKU11WAM87tkRKXAxOl0ai6IFWcIoF94/xGW31fDYp/Tloai3wuxkfY+E1GTyECnjGl7BoLLD2jbcCndM1c53T1xsZOP/ccjwszl8UaBKxoXiTzEAAS6mZjIII/R1plK4aVCiPeHgJ75AcD6BWlYrBGZ9Or2fQcNlwk5mPV3U35fwGlXIcwvmIZRn6tHh4cQvsMkGo5uEvK8EfQ09jvY05wLUgEcOPYRcvmMKMspg+HM8bYYUKCh4j/9EOs/0tEWevaPiXBLUz1f4RBQCQLLg46iQoMi+5DLWrCpJE7R/voMxZO/QBvp1OtGYJEVfz4OKUH4/xZFeGnGQNO+Q+dT/XbVU+RKNdHnJXe/9Y7VvbQV4yubfDRj7+Hur6MYC/CsSEJzK3utcdWOX2yaZHMoIlSdxYljryjsp4EeulWT4IHoxOE1mg8zMBu7QK8XthH99sWHRgVVQ2uksTLhg1pCOGr0WDsby5eOuen8FT8rs9BgjH9gcx/rpvV95eGM/wypIyo1vLIdbgZwGt+vwxEtFVCnkqdeh+Ued/615lAxQKPQQ0IMHn6INTaYvjheLFygLv7LLHL1/685vNiBWvbNySRyHIQJOffALlHLBCNnS1CNFj1F5RDGBuQcUK7n/CRrUfLp7HLASy9BXP767RNlMvXA4ankRdu6D/e9cPOqOV58SXpZZGpS7rQ1XZf9NOz2qassnnzU/MqCYHknFQzzdKpDT49gK6PPgRm2W/8VQg6cb9AYgUF/ntLOZ23tbzAhOqfEUgfcrZGg6WhGnrgNOsaDeDQ515BdYMwvg1J0Rt788tTodlkUpH3BZHe3M33mzuc23FPWZFKQqcTqcxF2Nt0ukzts5MEdDcv20TEdf8EwZ9dMOskBU/KSneqExYzLneyzKYshGUqyGQ1PL4znjYvHetL2GCimYqdjmV5E3/7SnLNKWXnBZLxaJz5d17//39O6nMycd5F9ZxPJfNCPN07yIgN8esP1udAnDIDMhb9H9pWHoxhHkguZaoxUINJeaaei+xQYaRWUZ5fxj5C7VRm81fBEYYJmxuhYKoJ6EC0SZYHzrvfDvQ0OegPojSIQfhmc9G++E+9jop4UO4zXveotXUHTWM03NhWQenmOgB9NT0Ymd8xPgSB7Xme0B8OhHMx4KamXUK7iZfTJ13LVaxnNEbEStSmT0b+cTfRpPdnY0Rrggz+aZq9buzkbEdoLwABDNY+S94OGJux0il9AsCJdvzTekQuARAiGmeEJFABG+KON2gurAOqzx4oiMK133bs77mwyr8/nix4S+Xt+37E9mAdELdJhz61y8hEgikiAx29Oqc5jP4R5EeoV2CMq+f7DwnCmvF84WL+8NnFArojIk6gPDJ3Eg1m3FTYtOId2afrJYMO0zAQvw1JLod8dKbGkV7D9fE+uuhgA02Kb+qFOzKTw92jzQNEZtjb60y4JXy8F2k/mMJoQhMFePvBX+YGpFkIMpJQ9K1TTKJ0oTMhiHWEiSF6zpjIs5UWhSASQQNq6zsliMPdX2DNPzORV2AC7r9p1NhxT4v0H6jxxysuOPt9HYNSq2yT5wOfqugwCGxQ21zJFo40+mtxjm3HmmSDobixNhqhH8uxNT4u5kkmpMUsWtnDAPTARGadIn+iPZjS0opcmmTxcfaTXVyAG2ITv59y+aLYb5g0+qMkVJ7Z2C1fWdejMht30wVpBHRipEmbhHG/OsbG3XpU895kxDf+xdG/XsiiYcTfZ5rquU1ISEP+I5a+Is30c5sNUkzSKLVEOI707vu0k6HdXD6N+MAb+l6ipxHfBuax6QV+V/bSeTFF6uw7Rj+VxpiPY+kW8b5ESzjZRZnR8g2gE3UldD882H4nGMcGJkw708SK0L8N0IygURB5Q00hvsPo0GQQ7UX7DXzTqV7IDBUMj5LnOeGoQDGFjSB5Y9P90uu67SI5+up+/1hQyC4xIUE17eIz6q8eYtD4U5+JrujCG44mopW1ZRf8fLTEW0EE5uKV2y29X+O1V7xP1mM1c9mqC5Jf0XHxpUSVRPWe81A8itbhZ17KPo8QfsEYEu7QG1Vs8vUJyPuR7MLFbPowTQLf1GKDN3KhbPbhkVnkxvtUk7Z7WI077iUYUKoIwSaErvkPA7p5NDW1gpSmXqQ2/8FLaNUX+2SGaWvMr4XXUzx7eevmO+J11zq4icj3w+pD66nwDisquVHRb2rerDWBsrcRP60oJhFIDYMGZN5Di+oMm1jjnICUKQvBvyKl6LhuPDPJvkZzrWSuECmCwXv6I7LCoJc5CJkAADYD/FwrUFzvsKiBp6lY/TwBmLZAbjngJdC+5GnOkeaA1fRGBfYSnkdguHK+pQgU8ktVJpcVPNmR1YX/502eSH+dpfCSjfDjxxUiYMSoM30aB2eijWoos6YbGHTgsmBHBCAEJMUgCXxEB5DdVykieDuRkuzcXPrK4fsO6tDjYwu4cOQJo7XYW4cQ0sQMDKVYk75iD03c1yC/PYbTsIZr8hJ39xgC+53pmYAHMxcRpDKJnQOGBBFEzXNh6n2pz4Q/EXviNiQblz+5+E3Fdv3uCWyhWCaRVIpdcFuwG8BHwEHpuSM1zM6rgdV3/RG9/Sd9Pp+8H3lbLvGDpmedieY+UQ6gelvFw/mFXi+/U2IdlrDGauktntAMYjD+0iQhNWaA34aVdnmEMa0vcEHsMKZMY2Gq5DNTxVFTPfW/suRJOvkptPb5QmSieXx7gvfh3Yc1vdFHwcE8omKIO9Th0YREx/0fOQ6sS0IC9c/p2zqSCvvBYwZhJEomvV2k0F4nMpqRJGbATbOv6UvxDvEWr8bLU5DlaKlMuYiQ65Ljf/rc9zExlhpAGIHSOGOXc9ksdt04icxJGqB4/tJGUQ7C6LLHJWD80zEhgQMn3l3wqqn/4g09Q0xbhF38Hhl6CEcazjNCMkpCkKqwbRAEvM+aST23jZ111dcfGpnQCa9tBHUY4zhfwg3MZJ3g7zVwU07ltThnqQ+ZALlm4XAlPVyGifuxoxMdPHHEJFxDzCKBsjmuRJXazOYqmD4MErRkwkJ64ccAuiHg6POA4Oa9QxxX8qbj72oiCxgCIfzu85NhrEq6Vs20f1g2KuQiOe0F7HJaF+81AWctbpbqA7mdEzeNZ6XdfHrOOwBR0gAnk+Dt6PLxq9x89XzGJ3xImVYbnObyeSJJ/sqdfLur+1p7AxtXfvrl2J3WHBT+sSht5tbP6Csh+Eb1TPQYYpam65Plg/GBsBKPWlAsL3NUOkoLLVzj7OzlLqkG78xXiLKVa+nW86IeVqEDd14TGQXwuoYit2PH5Gzb33/U8AabYQCg53EGN8lGJOKM1n5HDT8MEIdCFB9CH4blNKFHNPdEKaYDnA0fbHA7qw1krbBbHXmTsJBxTfHrkhtlMpvOkO9wMPihiV/enIl09Asq+KPk4uOHWExqpu7x4bBZ7Cp0AhML3VVWYa5InKcPnFLDH1iicfxvsSoW32NbfkIq1Ambxsfvh+VCZADvtd+wm+4kc4CJrbUdSMLwPL9zTr40VGZBVtm1MgjFRlbnouFIZ6ZTJXVtZUvnBbFBBjKzecwpqmZfwtjqDM4+DsqvW6BsQxKPdqdWreivOVKvm7to/ofSmHRmLzeHbzts8PMonCeTI6LL1A5mH7Uzgkn7mRuMp6SMOrXvIIBxTYeEMULDem4bLYEWYXw4x763oY9JOV+TnqUAHfk2U4ONbC1SrNRmg4i9rra3hbXP5J1S+1/BLtx/i23fD1Qo+iNIn0LtE2xe6ryVcJAVrZsZRCTfJY1P/PudLslmjDn9yiubF6sHNoR99K50KsCZNHxRikQWTAuNUtIezE9t/UYfuTO2BEHjWc8A6CIhWRJYpyetVgG9UEWP0+jxRqBOe5BX/7sodxh6agrFeBQLXYmUNU2bnQ2VKrrKp38v3/OdGqOfo82CuX3numaY/PH4cngeA22JaGWYyhuBhdDcPFPynPn/0v5N6aNMJIPWxs6tlq8zevl7gZfTpOrUczLpli0DsL9QcT+BrD/1NRLgTdztoUjORwyVoA2jhSrV/RZcQZWrUISBv3zReCHNDq/fXSPZwxagjnAjpgR/d00BQ4FGgqTnh7A2u065BKlbRKEK3wKV8lNwPr/EQ4vZCzjjVpQIP6slNXyRztWfPKn8VJ8/82EGXeFSM08ewIyP5gXpvi2Jo4+S6zUSFyo7awwvZJuaDlKF7Qy0MmAnrDMyJxy11LPVw6+5KnpI11DXQBcVXoYZGlpq7tzNvYUGdNStvb84cnRJOp62Ai0Bjp3BseQfDIZBLvQIepDOXl0RLW8Y1G3xL/sVcSL5uV5V0Brs+n5k0Q4RbKOCAi8j0oCYSKg5DsSV1BexZ4BNNn4Kk4Ramaz1uZxHMeBchh7GqKunePqLYsTP2S+VQZUCBdlHru9xGlmIrarxzFhqngiopr8HmJ2dfHISinEyQ2XTrkS2GXKwtVu8sk3YZg1YPkVbnodIomSMQ/q1RH5v9mo2Kp+Z9QVq0MHvmbjzt/lbN6/O5u/236ipuRGG7i3ey+S/uXXpvZ8BYDz+wXBuOdHA30YLMQHueuHOmYDQN2jUax60FxtWM8wa42yxbX32k0D4kGenWgzKf3R36VG+e5NATxNvYl/Vz/SM2Z4ggiySe8ilqSTWwvO4c4Xwe0lGEBiYdozd8R0OCR5mMxnli2kEo5//Mp5yA6WOoaK4UKW3OkHeo5t41tptBrGSUZVCrizpyAdC8AHHjGkbsaPKF32tDYh4t+4kF1hJcu9vv6KExdXzriNqmHiFywQ5pt+tEQJcqHwIx/XetlSGagH8ByeEoY2nXN4c8Gp6ECOAXfTk4d15GYCSb0dXx9VS+XoVq4p6xV2yMvgXatlI0GYJexnp2TUlp0Qg6XdTr7mll/cNsk6FF7vDBU7qeYK+LoSmnorS7g5BUjClNMg4W4WO8aHJEwzRxpM+YTWZsHlDmAVjBioUhwBHnFGQ/8zkpPf6bE8QE6rGTzSz7n9r015ckZZoB71c1+rvb1+ot4O/o7tw+JjKjUhbAzNzEpRQTlY0RA4EL19biHj6QhWCDpX7w/k6KXFuYtgeQBtXqq0r4pfRAvV7X6W0RInB5Z12Cy/5zv3GNzfZVf5M8ns4uxSFnRJoj0DwXsP/qlagUZoFj1u5nTvwuJUhb4OiMXsyjHZvs2JX4VX06OZzWthbffR0oaIktm1ch4P2MegcyfDe8oTE+kV6GOvnmHFPsX7S2FXzuw0pHUOujAVQzz3GFC367OhhUneMGGgJRXw+203DSYAD4rtdA83pPnTHyaukwX40vW6q00a5yIeLgr8d+5zDjd954Rf7tzWlCtQGyIO9y0BPqJDeB0suUPP9geZ0F64mCQzNGAVyuaIVzJ+VQQ3lGde5de2nTOXr3miCE0cZQPZgzZwwCEgseE/ikbEo2cz4YC6iLBXp8pSesmaJqFfU4F2fIyFUai1Gd5Hnh73W33gzqWBZM1+CvrMmuZzgvN4zybxQ3wOUxuDDrX2GjBbE60jp5J2Ts45orVKp18vc9foUuRPlAnCafHv3fkwI4IsGdxjFMXgAkuzDttN6bv0LnSnZRtmbL1kpZ/Y3QnSvU16fpdA9Dlb01sH7KYJ3VcrJZ0G6e3KlExKrfrIWKJAV480NJuJtniPQfu3GzJkgJurSPefLCN0oRj4mW1tDIc9LTjdhSRfhncIQH63BvXK9sj3tNo/VB18sNTa6ddgqLuRnpI2vTm0kX2jNYRpSrIPEO0QA8kx8zt/Ae6nMXaUAjoWOuNAPdFAC3EVAwyaAdAjeUNlBL3E8XEsIgxk5pf2avZSYWdYktQfMst+vHbccLhVbMxNryIif30JEy2O7PUU2Fnef9w5lcjjmIekj4RUI+ziO86NOwvuodEX9N5pHYJLya2SbvsSsJOuW7H4n0XML3icS8mm6kmaEVD4zELCiy35BY3Onefk0MsiZHBst0Xw0rb9GJIuBEqw03YlY4/u72aVWQUYHUi/vW8aJdKkD1vhyrCGDCNEzlhWWCtTsWhXfCNsGfovQLJFJUe+o7i8pqU1mu1Goa8qVhlLFz39cGZpqi/Edmtp6DO1S7eyKY+BcgRvQ4X7PHSmhYuSnyZJHWPw4KDqr6so5GbOPUWnsgNIqg76x+inwRuRonKaSo69TKkZs5zIDOJWa22EcLoMuutO6UCTVOJJuQYbS2vGp0eZX4bLYmSLsyG0Wu6JcVq10QnzCJ7NMOByxHr1vQ+ODYsZ0JBNhxjduSYiWGtJPiZZoAHFKbL/hg/C8KygTpKJu3Xzy9fRp+yPGwUJ96FJleXTNXbIBOMIq4Q0kNs26qJvs5MT1yUJy1RMPO3z0OOrhkkNywqIgqnOi1t4pSPIm0cCt6AM2GuPhmi6EQtDjyY9wX8MuhkZws1UAuWc1qL/lWyHprWG1FY/pNqZLhF/JVd7tM2Pfj0vMg1S6UHVIA2FoNUn3bOz0XnPyvWUCVRKyMsAwjRG0+Zys30epyKHG7NNJVfzTwsUoSyia7mZD6maJmWCZvRQsVUNWoRF4KZDpMUyk2OjF12Y3QQObokmw1j5QwmPWckVl1haEI+DMUieA0pOSu5oI8QSWGmBFsbcSj5kn0IkFjXxO0lchbRp2IIg3dgfr+2Ad/vkw8/34APJFx1XIFxj+PwrqjgTfSuXy17TQp3eYeDVk7FDqPHxCZ+sOEGS7dEpFtGgzEkWe+0HXAmsNy/QQjAASu596yoVSl6Ue2NGT2ZQ17ksFm/AgzNuhjvtUSZCx5lxGfXUa/tGkY7rMZopiSSmZm0gN001w2KOicy7+lydYqra+PyXvZbfq/9hUzixuK9a8m33LbsczH2FK9FJVdgGxi/J6KH4akqKE8Ry9COpTjrtWZoGb8pASEYnVtOXCd6bjlxuwEj/iLil+Q4CECOsq/q65+r77h4If/8upjt1/lW1QWyPzfb08yu6Vcw91d4G/ArE/uVAP2518fF3bv2ZveMRdO/gS7+i2j+P4nkz9WpF9hVsuP8si1/Fa9Hn7kYGksRYy6yfTXEdfA6k5YMJF5kc1wuTGvx1VOVtxBLu8HDlu3oiDT5pyPTZaNGSopcfHyUkPCbZx/xS8mTIsDbFBgttR7dIW6NspCe99fc2qkHDQhvR6zKOtM628MIpExwMS+87ZtAmb+Mm/emNLyuIESgi8Urc8I8E2ejVbsQ/Zp2QMAh7YO+lO02B+bggffabAWS3B1KdBTgZHI5vxItaiuvcjHaKk010qMCU1pf64UG/hh5lSTYt3ZRDTFUtWFk5B9o/4z8WovFdd4/NFdFSNvnMNjq3qhm0Ajsgn0aLVUajwlWxj3N6NjK8epPpsDCEZzMFO58pwgVvfn51Jcr0Zg/GQnEX8orTBNj6hf439iBLV6D/1V/ygmIRWFRNk54qUXS2ZaS3Jvb1vtK8Oy1kcclrFEKYB8aX43NNUc3v7kROdCUERfMkHmo3mKEOBzJ0T03M5UVf3VeL2fGz5PHM7fCC7oMoWPTlmpxa+BUeyAoO13cFONDdipFzWXTk84dDQyYh6IikPZeFXCVywgDtYo18BU4aHpiSRXOlzzC2dEtirgsx3aZTA5tEBCVbmM1cwFHuE+esQH7fnATjzJKaMSZKFSOssC/JCho1zjGbIRq6jRWkQX3AU1GX9XI3oUU2aD1kV3EUVa6Vg4FE2ZWDdmvVZt3ellKtBvG3mVaie3zcdSUxAZkMxMFmZSigqfqcsuUy991NJ74P+r0gsZcekY++jqFHN9R43fUnokpm+dGB+u7MqXmmQ+9II4qL43jlxCvVzwDQm3M6RxZEUU5PEtxWnzLt0JVP7AhxmdWlKNz0qvCd3vwXjTtsHthxaS/QlMs36oUXglVOKMTqMJfjSeNzD4RdyBKBTCkHzuINOyUllL/aEZN1UU80SIVnn+YHZf/MDOXyutOv4mmKJ37R+gUJXc5qkjdntm1JV5sA52fPIvtmbuhIlfNQvXW8257NJWOl0U820c30TFGoh04BKHKUeUHnVfCOt0ZM0zGinp7W1kkdAwG9f+Q3/yVArLubTQn3/VTNn03OyQFApe9IghgDyv+ZOA0lUmVvSTnkAf0iqpcfUfa3Bqe21Vp4S7UkTYOB1imx/fHWLJSt/HpJQbXLJrStLUDs2mJfStPSSLrGSuHxPs4qz7LrnDXPDhgrVmNwbwb7dSQ1NPMEvAZ5R1h3/dG22egLetzRqHEs7RqAHZNcCL98tiKPTMiLJUn/56w0rot1LJycJmDB8KZTfqqMTw+s7pbZfdPkQCCsRrJyN9FgNH1vwlBBrrJuMZtNjK+ErKbreOJjpcSaGkEUhR+TrPDADDNZtNOtX5YKRfYJ7R3mnRCpqXrpDmz0epRNJgGMbVTUSoPOKrZH9ky2RR1Xmn5nklO4r6dvERSvldrwWgESGGldIkVCvLcChwy5Cv+OMJVm3h1LnpPAXGpuEnsYH0wcXqXl9lnot4Q3Q/+BnvFumQqJX8wkWoYMs45FbI4HPp0zKJyw+2YygsL66r4EvZct/MqNpN4jbU7DIPqt9MqlNhq/PSBwnkyL/Gwx4peuEg0XNxo84VnXhB7XgjJoeDgFvAOnr0QwV83zgAF4n7p5XuI1Zcfef+TYhJqddyP0cJzNyZPEXo9Fd9gf7Pm0imynFTba5zDGQ30GdIHcgIzv4wCAJ7rgRaepZXqJ4hxPLiv3xeePxvALXeFRXZU1B8oijU4w6iwiEGvvmXWJgeEPZKV3orf1fEzOlzKBfL+FhoSionnDi0I8uLfb3s+dPCFaYrL0QB88r80UEEl375ICfEKJJEEARj8xDR2BRcfQEGNSHWRLqlZyYvFGdZCUYaS+LTh2Ulvex5bPikBpRxfq2MSSf4A2gORBufZ/liKkovDo18jJmf/vekEXHG26lc7lMzxmDTePNhGicMuWHS5qrbi1vFkGfeiTHiXo2Mosq2+7cQebruGZJlMmz9yS1zj3aU68z3bwGBf/1/0vjrJ+tFWiZi6pQ7uDbyZeBgmB3G1eY1czQJZlxG8YLfxs3oNtesIYg8hbxSYSgGzQx7Wf0GXUm0pW+wRzcGuhtLMSCfgARDhIWSUs4GjQprL3l8bcpqk/2LvEr3i+prTQwjRCz1nRTJgdsQ963vFRg1dQT6WFphGfyZBO+I8+Y6/deOEeyf54/8jyReIMqgvbXWI2gJ/9iFHw1uZgJVfw+HScjxVl0fk4CRd55LPG9VoHxLHIkX7cssCCbHw+vtAgquka55ukhqv+FbVZGfk1g5TCc6YoWAKLUTMgFiIuaW42HCQKzD+HoTnTmn9KBg5RbnZtAIWtNtnBa40hzHBnxk7H3LE3PsPXwi6IejJacKyiDGOOs3TozeEclxu/JYmvMCCYW7UlcuPtaVA+Ck5ZmpTfie+6wSJzG3ouzbk/4g/mjkE1AiqCpXwHgGEH4hf/xTLy3W1b0wLbiTlzW0eJ6aGQWUz4ChPq26788mBsP7SGjkcHXuuE7qtQl3gzWMmLYFy6Hpd/ArPj90UC+svfFwWF0Z1txOy8oAC00pQuEltVkx12n4ZlZOfiqcG2DoDuWqsNtIPYMl6kvZYnzqk8MvU7Ca7l1g4fAsdNTVi/bFJptqCBEA0Fb4NW1KbiZPVaP88OtZorTaYcVU6MX20tlwfmjxaHxmeJnim1rDIREu2YzXSWYgtG8v0P5ffK+x1UfBnPHJiSCtHAZ7uOU0YdtwNEfWur3IRgojYyoNlC6Uk5eBxmF3ta6IBRiJenIUFgC1OLLBsOI8Q7eklXF4qVLHvE83VgO6v3CmKq8tFPp5cTLx+1yfg2yNEuia3ldsRelYshVSxR0d0K1nO4htIx4u7iSbs4VpiIg5ublYvjeyWNub9De3t8HqKbjN9sBJ+DDcVFwRHX9GjQUtyXo84rS280D6F60wBHS6sUwlRcZqW/sJTA7+7nx6Nm9d1eRJQs433R4Ucl/dd0KR8bp0lyPT+BBG5PY1qrnGoCR+j3bZwx4+jwXVvg34VhO2+Yg1qNPFWU1ZxPNmOjOZzNT02/VbvIuCYvo89To7Z0giOXu/S9qXARH1IHPosSJmCBsg9J+GlKxYNBIPkOU23X9niw/Dsf2Z0WIjUKrEPVs/GXoigCezdcW+b9iZ9DnnhiGs0MJObCaImWrKihy75L3eqb60ABrrVY2A2bDZGSvhGsiU92p1ZbDr0aO+tW9MPcumd5vq+5SMwypuMvHQ1B9uvMAxrx9vaZpdLZMXMUNGqcUcm5fEY9AVl99pbhL9qHowvoyGm3/y6KgcaeB3nfVQ2elmExN3gS17lJzWr49cXnx2/aG+/s3NPpehe7sxORzV05SJzH4qi5rG1+ZjsmWIdTMcv8O/Q5bbTZI5FHRIOczUosI9u9xNwPnw+JYls3o+UL1DxmGD2lOs18qxU+TEtQPONxTL2UiBbvIpLWiz+0TZuIgsjDoPSOMsIFmwBJMVhQMxy5GHLNR69+xGTI41z6TTeyYlWB5QVochy8LYrAHhHyjlDgIQxdf5BPw1qAFRlJsSPcd4uT9rHEI7wMqpJnreCxopiz5BCkv9N4ySP6rLKq3suKqjlmx2wJh5e9qEWCAErYevEAXguowrxGIK5dv9H91plg6/WbtyA+6GFBPGVIC/q8whpN7yt274m8TotF9j0S9cBTzZWnD7Y7tgbj9FU49aKLAvur9V/6PGVB+ya1ar0Ht71wNnE8SMb8uxaME7GcUr25vmNTNZIxmtnlNNmGzLYEj4Y6/j1m8vBdzcejK27LNiV8jcHWJN+qqCFj4gMvW/gu7x+xzIijy10PLId15wnpu4zOFHE8arUk8J22KtAmmEJ48Mm1UOrW5vGPSmO11Tbe0jcUMOQyPjnhBH4/Q0ifm+vhbREp0kw0xi25S2/QjjRS0Avwe3zsRn41bCbbzrfpHgobdZ5MyxdERFd52H9/UlG9SoCCiRPl9KVvoA1o7YyHIp4Lr5/N1b9g74xp4l1baVBmgo+AqXZMHKoDYdWe91K6lWT5jgHkNqa0Nh5pOfVA7BrDXn0rA9fuiOh+bxNEf1BXPbhLCF9s+uUXCp5vEwbHbhFsdMWrbxyXF23lMX7jqhDlMZZb19+EWkjxtpyCNMf2tkf8bw8Lo9/xhmFwnX7lSVBUredTe/Xd3iVUe8aWypvC/Gee6C5CSbvASrrj3q9L8y5feEXr03Lnlp/MKw+hktFnrWsrHwklsuhulYuq6p9WS9kjnFAcqVTJG4IvjwHYMfhhdIbIpzI0Jic684Mgi1bwf358Y84PYghRnC9jHb1pbslxp9oEPeVXXbo8DYTis7t1HJrPswPXsWWeiDjeeHCyLZzcctsSsbaOA46WMNMy+tqcIr3QNZ40jidEwGv7bdHtIz5OdbRLSZQGZcMhi3ebLj4stOyJ1ipM4kezcgp78VRYZRdcmzuAl0+l+PlQQz+ONuwwofFCSMCNccwjZKJkMVItW2h3KE3I+WeMGft0nS3Q5kJwtMRn5VZYSHCpFsmy/Eo4LcDNiunydm+kTMaqQh5ckmYsrRvvIfM92r2O5kUj9zn/odTTLIMEHMliZsf7Mwk+F5oBfMBmBhSoiRywatU3dSavj9Llt+L6tFmANOfUrTPM/OfraTjibT7uk9TR45FjwGCtHLPyPzERgFmcDJbdwjee2VWOVQdhsVKdDtn6UV6uqkpvN34lqhqjVPXD5S9xjc12g0v4uGtfW8Mffy/Ng6wyiR3YlvFDiZHdwj94MkFH2bezm6I+NbSkTkTD2O8sGcJlyiKUKI+vUzXySZDGyU6qyWQ2lmqKzjLReJS+pkZJ+bj3lk19PphNdagO03mX17EOH4QA1QAFikOcvGR2Tqs67lK0D1AWyAWqrGVFwyEqlqCNeyMq4U+Fl3RKmlsdLLZKFefx3uEhX56Xy/KuvbBVnmkgvE4Qnt3D0zRWdee/RRgy1iIHtLIWPlaDbMM9favckkZZNDPnjWl0zBebRIXk/cyU1bqWHkn0QmuXTv1l9ftotcONuCy8vxUKfXFqG73f3dnqmC6NoYvO2shWRldWrHre3j4fmzNRJ8vKBDR57z5TeX/Z46kPmXtrczDf0DdzlvK+ah3RILDDGpKJHKR9PY8EC2ewp8wUpSbu+NJX6RMEYZPfmgC9+blHLJ9WO8cPfO8e24h/HVk4WfmBxa8pfieZSvKU9L/Uy8BR5ziT9bz8j7g1I/wpfr97rjyHtMN4CbRdd2wFRCRx+gJ+/P49affbjIFrCy6BijlJME652HYxBbDXR1sYdR09MmLngwNl9h63hIcY6ug/kgU4Ma7kE1+hn+Hb85K4NvNHhWTgV50GJ+1gnoMIo/713b1qYYG79cX76LHxleFqzgMg3jVcwSm7DJYsDvt4/RVcbHsU0S4/I33irWio+oKPpIfKbh3qOX4sW9Jl9eb67kXAXvLw3j5Q01k5Rha6l1q4/INros+qf5Ot3NKax+vMXsq/pP7HSCHec2mPkJ6t9eSissDtXMz6NzWagMbblTUA7wWdOC5e05jGL59jOtgmb4f/5PxH/VL+KBtqXLVqtK1+mNUZqzF/jwPtzC5+m3iLOOHqx4mjX9t93O+0oRoGccEzLOvRLFOJVafDY3voXf52CrJkYJ4c0XPBXgUbVg0Hl/jnfEQxbBicgnye862PrvykLViAzEyIAy1EtSb5SKGlRw1TWf6HWzl2z5pPU26nbT0szevmIPo3E39q8APhKrrFzIvEl3egowACtzuhtpbTZ8Y2haxKNqz5yF1M2uwmF2QOTuoioKtc3Kr2V5n7BdWMp+Omy7H5ULkou5VQGd8aOXnpWdfOOczkzXYryy6MZnD1ba4cPpQJpfVzmeYhYVHMe+TQSdbbQ6tzL1zOXX7RRjFj9YjN8RZDrzyHricLQ6HB5265y9C7uJaeWa/jOxYlOeK/Ryf1yd2vYr2PrTJrPka1KW/DMd9gTTrYkH0lspsPQTuRGhhii72ojYLqyRZVAflO2RmvnKau+KTtyXiI021HA4rbF9Xr/OSj3xlMvcbNc4XdFaNNLM4K6Qqk8lKBeJbMY76EkDW+NJ6dHgc5ZPLQkg8lESiyanStbVUbgPsOx17rdxpEbf4YRH961V8cVOwtQ8HShG28mxCe1T04n2C6WsjszrtE6hi/+8Nn3XejXRAJWKo8tVOObHhW+qFKtrTpj96a79GMWijAlevp986RysKBH3x57jZDQtruCL+WqFYFlD1L36Szj2UR9xJvllQcbQkf7J6u4q0XhJu6gnVDU3sRZ9TKfRx3YPVsd8rLd5yj64EVr173lcsDfLE4H1bTDi/ftWwbMe5e9RZ5izwEwvAbzFwx2kpjaBesOkiBFXH8BdMTrG2WqUCv2JBpl7K+geC9owLaZwKkJ+dhE6Y5OIPod7fpv/6+2KdV60X1Km3YgxwWZPRU7p6G8jGVJMXPA/DVyVdoxarUcFqNm2OH9iUG50FrAeY9d6L8WXl8vOno3s06AUxDbV3dMJ7EKd1dk2rpYmEBBWE40HSR3PFTu301zn3ynUTyOcjRFAfPFkx/z4INVhmr/1uYsi2Y7lN1xvHRsNKl3ZaMzN3RCSUk6ETbO8QIzEhO9l87PLZ76jpjfmSYl9QPAzunq7q6WU3oBfl5W7nH3g1THS9IR3Vh+3WvwO7zndVVGlS+O6wW6VPVvfLHsNFOVBH0NICEJDNA1+y+OEO0RR7/rs/xrW3GnSxuPubmZU5cpn/rHQUEm3sP4NLQ6F1OHo9BZXXsEBWnHFhm28Be/BDKkrXi6wcfoPn02W+6WyEjCX6Mz1FW6YcpWhDKm4CXc48Go8WbOgWRXh2w7ZMnSF8WFogTXoWqGAQQIuDC0yftddjObFOwe7mSXnULXWbuPQbsKKJea31mO/lk5QkNyM48X5hnkidjsLm+KUXXU1wov7RxVn7iFKgKFp96P0mhlWPauABB/OQPYf3gc15VAwcGXQQBuMFPkypiUuKBlP08R/XSDrdROU4cMrkxEG9o59hLrcxDd7m8PVf4qpLGy66KckUDiR//tXjnKjn9ZIZVOIqF8cJjd+8qMm2i9lhFg9c72X6x08NThu1tUEP5FDhRrMS5qwt87Bor/KYAMamrzpl7NVvTxj/JvyUDHULqvLvIuXapkQM7VH1u39SvNL5OtgsTmKHrsXNx+UuTJrXQ8ImvuBX1U/HKfC3wxMprUTknj1wVakVtcHVwaC72ebs2RgWzaNlEOiDvuONM49Z60q3iLtlW0SizptSdTXxpnJR7JuzKHFI2gMGdZd7oDlGUJsdDz+IF4Z0riSO3IPoQN5Xby59xtZFD/fyoCqOXCiT2F5cSxlnc2OPRiQNLZCGIuHsPS+OwMA3/yfszwyo/yxJ4Rv0zlgA90SLfe1aE87u41N1brqeqBDr4ENQ7Pfwy1FM7XTaQjAT15R5uPJaF8bb4aM92budmLwTBD5uuoLAESQQA7ZBu/Z56zfTEjrxvCUcqUi3TmV1ob4BNG2Bz7BCdx1U3c5oUhdQeAt18UzE13Y9RBTZS1y9k8+zr7xtrLptjz/SaH3yaFlt6tAUUX8BNrvAS8EP8XM5ex4A0sD5gWbOa19DWvkZIe9M1L8gwzhwm2MJ/siOe+ZBEmH3IQat007yo1+TgIdB1M/PdTf3e29o2/etVQ5kj8dm+wVgRs6yGtr7Ag+u1sTnOitUfDT2Qs9vtqczQ32+7AVkPqs9z9nixfwTqE9/1byqJ+6yPc1nhdPN13ogegcEP6Ldaa7Fxn7qKw0vh5n884NaHWW7QS99O3yKUMRHdwZZae4Nw7L+aPdzKMp5LmWbJGbyiuxu8SGv3sIrvTKZeQs4s1slfM9QGIuKsEdDNNVPWObccXFe+9Cv0BUbp5/0Xc5CPoh1OjxfrmsQZl7QPjrWiFFAJi+mv/icCduaHO+/qe2MjT+dfTa+4/yEz119E9xO57AWlbT0OhSzv7huh/nvdooKA/8OZtOzGvxrxsccnersv7y0Q7ghvZ8XZfzsMKNe/gIIgIswdFrcl+MYNwtI1lvmWcMzEf3tr1/Y1N/+0vPxuj6+vU82JXZKmXjq4cwg4dRtvM6l+6NEoekQkj2AWsWc8wEZllAGBGy8LCeu6TTxkXu5oa3rrtU3d0tgIu7lyDWyF1weR0YtYsekhX9T19rjVxRzSOCk6sOqpHuRPARAwQDbSQq49Yj+04afIQEDJQB/EH7dBkG7SlmnThHijslPIbnnw9SlZZg/jLBxFW61be2PKiF1W2taHZxM7mvwkv4w2lo0WI3M9jaJIEtnvseJsijdF6h7FMq87xhEsEDjPybD/kVy9dmXxn+Sfs+E9OfN/OZfsmNsuPWpLMe0o1yn8gE+fkINWVyvPnNyr7zIl6VkV1LTPv/E6owVB9pxU76ksqmN9/7qs51EC6j87vHYMz/uTpyrvxF+SHpz5y4lLQOqMJjAUDpSaDTiT3P38bIu1joLxezHVUTqfl2KUEkJdDvFCRiEBiwmXeO+AzSWNtnoRP7UTNYPv5QSE72U334qCHv1i/ZtDLc3iC+/nCt9+uRiz7Oeij/SpOzybWE7/faflLe7bZbflZVF0jV8/p1uzGpW3h3IXWL27Mlumn3Mxn7T2mv7Y9DQIOb9yYodt5DC8xKdDgYE59paurm1sjyI3phdYawFVhwVnThTPSdkN89xzqFYd5T69RV+9658DZyOKwrUEcapDEeyflEVqzy2/Hj7zJCDy/Ky0bxXnHJKrv55WT+SS7Et2BwzZP4N9SGluVl1W6h0fvkRnCpYrxdkfvWLcYuK7cfimMbTGEo0J3O2o6qvzm95fS1RV1/U8sUv2krL9mMD3/xuOf2WPWHBz9pcm/Y6Y474ZdCXL/s52mEH+2vYDH2tnKJVm8UsmLf6S1pBcnvyglvZpBT0b1rnePa0nGA0LkKEnJKu7VNytUpoXVBV4+q6ZNvLzuXh9SBVj5ZmOzy/H3Epax2ulY3jBspUNRMiQAJihBaNx52iQxPsR/shyLLj3PwFLZ5mA+LRBQjzUvku5hOtTJp4xeYXtOcFbtTJCste9/eurG+s35PKHN/jxYOOu7XhPS55fdz+3NGSWQm+gOI6MY3gnPfNrmMMPuuQK8Kh2P6OqJ6jrTobXd2tdvBzd9WheZHyzG0r1IjBCvpYCBPwp8IH9R5VdVJLRltDT0C7gn7t43JMH8aQC5we0Maps1XEypyX+GA/HDThdQaPnNOGfcuzy8tDyhSpVLR1xTtTTW8yPRCVurli1dBPuDXQk5ZZo9eu8W++kALz/ka7St8o8QXvMvP0P/kG1LK2Yd475kbpxGwb/B2RD81fiXm//ig9LyvfSaLn3tXzDDyrVMWP/o9UKSPEWSwAlTdFSc0d+h87do7ecNDJEuKYDjEceOyuoNv3wzmVppi5TokFoTxRI3xFluHrse8PGMnMpfz5Kexx+ZaU8JGSTzWeUGZNYQkLUISEw0n2HZyFHphEgYMR5gOn4OTz5amfuL7FZ5pfDj/nQSscL+HV1RXsYXM9IfYKbzBKOaw1liRQyZx2tY25pDDHKOG0eTgOGkCWhInXuG9EcrConV2zUL/ovYf5BQ/v1Zk8nE54txKpaQILDOLGoiKAYXzczGgOQIQxw5OiOLcl1IWVkPUkmr/J62melPFzz7Ue8ZN6NkxSAJMwwE58aTDP1suvrywQwXyZV+uirpOhxik/iz/b5DnbGDkX3kf8Mf1u/NTtwZMEFP16MG5kxvROdPxAi+qml/mc/3wevTbQj6IX5JXj+9rf6oqPYbxG4RtPt4ZJbhzLsxIeK+8Jq+vNlNaEzocaVNHE59xewy8whQk5ZTCybQC3xZnD7NKRAZuDCR+a6HXzM3Rbku+F1H2jBfmBCjfQFcncYiO/xViRnF7970ebh1w4J4klef/ds8mT+vuREetChGnGoa9+UX7Ppy/Xc+VytMTafcmeajg+7yb82+kkHxtNjn9zRj9vFXhvx1ImBSULFQwRFS6sPduA/YnCdrWg7ko/RbtJVNAwHcqPsWmjcko4LcrXsuDpvsgYxtGXAsE9lpgRQpJ3Tg4vY/eiHV4CBQPN3QrtSoT9SaAmpAy0ABVfYVs6jqdI5YI/D1nM/SCJqva3jhvjnFx177vZPcRwOURCistlGhGRpo0fFG9FSY2pM4N7/y9sGWlBSaW8/AO1Gk29lSzQ+M1Rt5elS/pIZTsSCxg2ZCQLiLoH2unS2E6cmx01UcwuxZRNTSixVb6l+ZSRdcq2uKepu20t66M//0Z4OEQ0I1lU4UnpLAJJeNTJqGVCC00SmUeUGWqV29HbWZW1rVjmJSZkgZYVySnLlDiT7JpFJz5cdLhqJgtgxtXsqrVIWfGYIfe6JdOel/Jm6bNi3Vmk7WBDmLMCvHtG6nj4rr1WklbpavDIKOLbnC0FV2hI50CMhCq1LEJnIughEENU1iRL2PyiXwnAFhZ/9XdDh2mAALWHzezVhNoFPG+/+24q+U+dEUFk4DZanuIlIjD5EqmcJEEB6aARB7AoZEG3ATYhOEU2/s4RzntTOmdyzoZ5VEBTA5cWVl0Gaa1k1m5dS5eVPqTXeYd2wf5WpQQrWo4Rf/n3Pcfvuksln01VxKp9ybc0vbi9RKSJ0oQJTlbQFZcqSrthcFP70z98W4rJI3tZAq1LmEs5HbLOhcd4CNsr2s6AJ6O8X8jVy2XmEipX/rfH5ndyse/rbWe/dbJ/NntWx7dmq4hMQrJeW0FTTpzClGzSbBclRqgKJvr9rH4pNcCgPiPFd7oJQVpX8n1epk0ehYI2KRaP8VPVEQa/hqCkYNbYIZbIy8eP1cslKRPMeyq3+qX/bH09vh+L+ZpqJmPpGe0CUiqaEsvyBWr6NWJrkqYgX+U3wPtlUzI37S0PlsH1Z+HZm/oND75JH5uHbAE6cuKuJnq5XaQzUnlEtiVLNy4TJE1V8rhEyaDBcqsqm5btwKYW4xcNolFeNxIDsfbZeI+C/uS4Xoi/52y5G58vneHlcATZddOrDZeust6OPPl0tCCfbZeP/tkwt6XaTf/gxHMG7veEn3xrs7yj7l62XO0/4zh8Lna6Tr08FKYTHiIBNAU5BC3QmM54nViBzdxmXbTyD1fFmIxnyV8s0ojUfi0DwkiQKzOgw0UhgZQJFKKlpnk4voVgBombSfBBhlyHcNO+oMwoyvVZDS7UjcYUa40ndjCsicLYJL/Co/7IaGlfm3dChm0y/o6mkCh9OxXO+f4iRxvQRbY5AXo4sQiU/vhfHsc7kzFIACtAh4CaY64zX2H3Ju1qP2m8RO1ZQpfp7VkXjgEZixMsXcYIURIpDBoUR7RxnGgEVpR8l8Cr/OV5glKmOSvfws3AZM+4iC/qc5cSq0kEJRb/hhHKEhIeEaekkTdImJ0XiSSUZBoC28qrEEiw7Ki3yUcD8Hz38AVPcNRe3WbdBf31DtTugCMP7mpoSxzqLuVCqbzHZbym+Tp3Nohoi674DIc3reSDWF0v3cHwhMPPa2tZq3PMupoSoBaGKjx4A02FVhnvm5w4mzpzZB9DYZtpGY90whl0yNYtohYCJTn2SuwfSGUj49x0iENIkeR+SmWc5eedYY88Oh1vy0ncHv3S/+6BRR9UCW+xMRFGMUCKmFMa30zNOEzivaQpmlK78JW5gUjCDXHbTPlcRzxgUXQJAToIbhguyhpVW4eVZsx5WxR4+u92H2js5Oj4/zZStwkMGL4F9kqGkKowLHCtUBDfqj501JnP8hkBva3hc0nwk++nff2KxpkUO7URUiFrUmkBkwHGNmelTtkga5ocPzPT+Jwht/NHi/zE+37z/YSvc7UhRpexu93atctM7t7xq+EM2ReC2wmQY9CC7AMZZndghlIEY0Ulu67VpGKHkUm6JcvPlKP6iAahTaFFtOqq0Jd55fiKbeYYMUJgJFeBzQ7BIckZu5lEVdGEjDmrzPNKYFmIsoVOtA4UUGo7mYwiBjPkXNfGJXOZwd2uSZD12da21vL/lA6PxZ9oj4ENr5nCNC0+2PDzTU/7CTROi+d1gCmIVvXXCdiPxS0MJ77/hCaArHAadChhjD+D7i3SIngzS77xjaf8GI8+S+7eUs77Lyvhg1PwuRWyP8yS/OlJtdNy9jSd62e5R/AwDyu4jv0iGaf2kr1sAqgUTKPuureOa+tW8Zni699ae8uVaFATkFow+vJ05EpxVLLr4zycY0lW5FAkcl84tjunX06an4ikgqhRK3nTHGiwx3/oXEv3+IAwhhx33P1D22ddVRC2ZCoB5Dxd4RXsavSyFuvcTI3N1h5OFUTbvEsL1PUckihFm9Pm2pXkIEph9OwDFtUoL7BGiq0IbpXxNTNpWUFgg7yuNlTDfzVCVRYOoFSOPjs78HrlgOg4IppwyF0Et8A7Fs0YfYw4Ij/5l7lP3AnB5em9ulAaNL7dfrjV4n7BmGTTWRg6zp8WrJxtbzM/7CpFwnaislQ2XTlcniFZYzB4Oez72sibvXJ0OH6alRd+1qG2Zd0PRPzRIUDVSCPPuKOq/FaYAF1iTK2n684V43/PxuWZqOcoD+1GMyp8ozeFeoKNdEBaoeEfu8C/yJ++q60l27sYKqEsERlO4lNk/IWa8DePfFfIBQIjWM4kQ1WMTQu1R86SDkRTXKey8aXdzDaMBbasaFumNYfNkiKui9oHkb1BpHDmr8FuSAZQLKF9YeP2MtHYFx3IGXuMCQw9ClxE+JneYCfaI+KxSShqxne4AlHCUmIqrWIJIgpDpaLtFLGJxalYGin1Qf63k2kDcKX7mhn+lye3dd+47NIDzqjEg71EOpqzFW2Hr0tw98k6K1djhcAJ2cxgMXG039voNQxSUcNVFarshVDbqiL0RgFROTjCBSH4sX/18K75A6EGM24o0s1tXSrPbDhHbwuc4CJCzSs/qNuYP9jxW4OjqgVQPoVlDN27Uw0HW0JPaP9cxy4kne5ry+sJR/h4s7gGENfpNhL1Bg3imJgdYf/nJXOh4yuhLd4HHLfNH2wu2dEe3is0DiGFO0SLhGissSuTN9qFDx2f5Ot9+3/DPQB/TZhfheifzMXHMURl5yyJ1xgZI6EMNGvikJC3o4qSlma3yhxIqybk93jNqzmYwwx4Y2SJFv/ljoIcUbaCda9c8KvaluF8fupk2BG2tl139Hs+nwr2in1bytywPVA2RyQl67EMh5UJ22VvW+Ovk7GQcvMbeTFOAzWfr8jd04bRoKqf4wiTBqK0cRUr5lALgtBQhLDo93N7G6FC7Vs/OyilzE+80vZOXuceUqUp5rw8+0Tkr5edV5m1Xw1P+IblWZhLcQ7c0bWJI8bCkWG/PbX/lTeUNMbPgVW8v+MFg36/xty3Wr1fXZKXQfZVfayptTyso1V9/GcCTVL91bP/7cOLdMF7jSH82li9z5W4JyXGF+e6wcS11jbkXo/RgnOHMfrEtgng40Z7kjV6etIwUxSKqnHQwi1tZzn46O9nzUiGEtjAgSpM+Ur6Dw4bP3NJB59X5jFbDewa78wwefamLtE1J532lSi9Z44aVR2yLO4dXfZ7W+84maKipC029YqmcCLKeKtQzII73QcP8c42Y1Nm4JaxVjtkloNV/fU6VXpRMak76Hd9fzdlvNDxu3va9GMumiRkh3YNBlYEfr6hHGPFSgpDD1lqMjplA4vFnHKYIKTZ2vv7e9rUCJfDx9/4SDtu9NL4t/Z1h1tsFpT8X5HRhR/0ykNdxhGeH2csGj0qW1pyNbm3ny74JFJhZpmh9vsWeEET4tFwI84FU3DCJ2sZpVzbGMd4x5us8n5soQ+PjXAFYxtQUZISgtVHjOMMkCLpycZfWtdhVE2YAaJGJnGaq75LKMuDH19+UdspWsgCXxmZkT/Ym5Uixmb8a8JUqul1t0IedNwc32ijplss7WilD/crLSlIXDzU21X4LbQC82tfaSHoS6XdnTSkCoyKhIpaO1AHOYOfdjX8B8fb3k3rZUt+y5RXnqA+mjV7B1KPnPWOMtbVO2tNtRm/38wXxHOXZHSGdhe4rJ+GlvINEdqJ3CLLCO2g36Gx65EM/0X/m31SdL8+zskLf9kd67TrD0VUjc8kHCdhaSK/HqYpi+v5PpM7N/X/NQfk4AnkVk2uF3JGupRNdUbifjIoniXQirtif/suuWYAuWggBAUoxQmCJ0nwwuTP5RB5fUSUB1PBGsKWZi0QiYlwmc0xOfsWyuZZJt3PildtTBjiS7st2621Cw5lfAM+sGjScHkcgXFYN50jUUOD/DYWjSu+sA89y/Ai+Yve8U4GeoXxEClqwtFfPvkrEzWuKpU8YBAT9J7wSR6UAhip0YsQb697HEgcSIhQuJLLRmgSj0tusxrRJVlpU3yS/aQ86T5qPsVave51MuqFb/9qyLVoFazAssku7EuZwDpGT02p4XmfeZ+b30nE7RJPKnJUvlb0RwTpgOuEFXcd1vYIjxe+8oSLdbDiStYw3zY6h9exx9NNQrZJC5NFtv/9jru+5r8RTJgrJpcxtsXTsK5OUtsEbPHdhfXlZC3f5aW6zXcN+yafozPzWhSQcgfJG5tU6GbzySEsg2cR+hG2ajpspcHOm86nI83P119baCdDtRbwfmtPyzTSRYw1WVYDaLklRmy66nJ550i/GdvB8GEs27xdEquSnDJgKvhqTyAT8C0vxJdiP3hiL5SoVzEUkHjr4dxj9CCA8hXe7xjB3dxzOVI2ltGpJ3OsDPFqLPg9g9+KfXs/ls0ZIxY8fypHd3nBh1aSv7wtezn/n4vbg7l9G0yD2qyG5f60Y/BasKZCMwirJu4x0ACGecmPVeMwCRf7oWBDcFcM0pCup40sHqmll+NChcPFwOj/34a8+N5isGFA7sstUmXm/fgQOjEUhAo0983GN5YHgyxYX0ET8yC+lgtaW/fKMG+IaaGNadGAqzkRpDYFnY7Bz1KGk/JhrxRXiIqqVtxn2WRrdBwpId9xrWKpA4ISJoWWr5WbZELYLElPxcMNnf+2Ut2pGjcHhQqgpKxi67yVb+6L+s2UKWOPMi48NaxDgepO5nmL0oOjabsbRGBRZvZAB+2zyOoORLUlKz2gIfU3xMNCwVukoRl+b2bz1/tgk+jfEuXvsOIf+pqaP8z3oAhbUKzt78+xwY9fn6acfhTaFoxqPaZXEktJEUIhALZty3UsMR4f3qkzmTZCNxHZUCSxCaCKulgoUsZOzplB5aSK12zxz28FWbH43WmW/mhwgBywjhO7w9AqGVa5DZxRsVDURaVrAiWphqQDQa7LZuokHmpGluNats0QFAAjkswsncaERlEhF/jzoCMeNzE8Clvmd4lWXHUMVwOtWlVxQ7gGDVCOf84jjAe4KFoEpzjiKrkjDEthT6nRgJBNSt+bCkpxnKJZCo9hGebdajdnljj8ut/6We7e94oTiiMo7+xQxXCvzOee8z1dFRM+pHoFoxpzt7WZy2a5PTK96nj1c7Ww0/Cx/6LnFsMjZFg9MLLBpJ7jT2tsVVcheO/zfFN9ZeO7OwgV4fSBk0KSVySJLZRmU/VyVWWyKbkQVqon0DzAghNPVLeQWbEPx3hXitsS3xYl8GJUCBGSpOzsdu+j3rs2uJQyJZHwfJCUPs7sz9XTM30N9Ah/+BNftsqK9Jdfd5Wpf8xz+907a9z4RLgyf03/9cmqsOI5xbnOe3rVV8iKkjLxuifvCMcgDKjudky0pPfhE1TeEj1FY3YdgrGXSEB3mDpbutcJUyMnBOfS7W7FPNEM9qJcrAPf5/xO+T03zQx+gEPTuv7Q/yy61XE9Muq+hfFuFMfC+5srOIcrDWf37+uVGMqlKO29g36lxk1LW15yqN+8rauRKBlj4IUGKN7TnxYKP/ZwiWQpOGyg5hPp54Pyu9Ud6W1es7sjGAkTCtoC6ORhDSf7hzavl6D2n4LIoMmXKC8zNqfLO+GyjB8krPiH/8jl+1h5S8ZHCpxt6cSpYGA5RAF7QRmH84pdo5umMHl76vPv4IrVU/8+gZnqCzK6fs+GCGNcqgsxUCLLiUBQPrGThtl4+BByPk32SHL297Kv58mUVGZrT7gKxvn+N4IWkyYgoIRWovTlSexw+lvWNTFSpN94EaoskUaE2uzEkIBOoOTjwAhRIGYkFM6EHi4xpUdchf6w/RVWnveovEbb/3QwlFWTM3CIf2Bj2yxVzT0/I0eH4vHxprAME3lkTA5IiV+MiOIkYnCebgtWo0wqJ9mUMz1Yp1cSptfAvtwv2unUbBssRrh9QwcGXFTQpR0khUxHpIQoJpxDlIgRpjRD4rKDTs7IAzHQr0efSa+tKilxs82eT3z9YSJiFHAPyR7s8JUEw79GZcRrrKChsode2GXjBrAUawqy0I8K2Obwld3JmSvmzEVzxnVxPInRquKCMNMCaFQD6qcNgnGNOiF4ZN16kRRChSeLaxhpMhZ5tlB8uxCQYNRZeaYqvtcNMtOejfAZHtWzL4ff1UqCzot0K8jr8QbGVfReLItBvm0WfQjCMVYwCy8W1RRjVTYOAHrQHoiLak7At8aMN7EdSfNV05wx7aZlTpggw2ockkVG7FWEKdrsR0UkUyH6fIKMxWhA7ScWKmBYFpIN1kD7Q5RFeXSadVMMXQzvZEZGWX/1jOzwe/Oc/yYauXxNrFbkyuVM1YZU63zjsPjnT0R64mOMWH2qre+oBtNQlf3epk0czLciLtJeLAjBnL33hVR9QDzqtJGjBbaoyCJOWc+kUky6LvY/4WlG3qMeyhp0AsNAUs5OlYWXFDwiTVKsks3kKx6yuG3yChZ+3Oj6bblBWPELcbTEi96WvMb9+udJ2u/d1BRfy7rRIQcWKC/ocY8ttSfmVyyY5XyLjT4/WJNrs5jQ1EAlCYZg+PqY49GK16eoEWUFyrm8S9Tw8hiBJYQ33lSGqcRhEAqBE4IvQzcsH2AqsMrlDQ85t9NNXKk7kaqEIMUsJw/pm//+wlWo8eGUKmJXeh/OY6tMpDRfEpS4GSBnbTcKLnqJFJh9Nz2m6TOSecCyIMFWiCUcJ5iadS8ZEOYDF2QhPmG8jtgIM68r/abVT4oAD4phY4PkwVCiq6nDSZL1erHKtiM5ZTtJxVNlz4Q78VAXjRf+2ggFC18qihC4nxtBtLmznrk1WrykuMPgilrd21jkPB8DRbBNc+47rU2CWGV284pHlUNKqDAi85ZtI1hddYMTk7IDn4gfaYf6bY/RiYzn4r1Icg9Wbf94iFRD+0MTOrrhdPjAgjxG/yw5WATZAM1TrLBP6EQpYIjRDpPjB6UlRjyTvsgFG3xKQXc8BRKk97qutXeGkt/rnmMmn1FxcogLhQItVdVI8TCPfxsO136rgSsdqytFn05YnROlz1pw2L7cNtm1AXjJvDdUYCe6gdh1XJliTa+3ZT88k5iOLcrKTVm5xYhvt8UnBOSvkNYOoaUQpOASoUJlqcIax0cfrWsaisyECS0E9P1A8CZc84dvGPO86l0na0z5/0+9Qh+3YR/jqsG+tN37MB1WRqMTylcFOi8Dgn8hBsgoUfW0VcWf3UumZXndpy5h58Vov5acjpoZHi2wuuPXG7yu+yvfvwXjcIs7A4KL6jryJ23qSpOeqUQM4s/ehuNCNZMZTt8lpDa+ctPdUfLSiLle6z5hIEF4istxPvSI5l8rS3m574PIvKL7TofaApEzNX9/cgGNZiY1X+5MrWRizcj3bChnj9IQ0XN+dVCkmMqU/YFoWnQf/s+ABo53noWwJIqvIV7mazTxVG29RvNEXTS5DeE4Y69PO2sKM7T8Jr1wJ6lXQ3ff2UhqKhFDiCDlxVJczGhcIkTAFrNDnNBJJi+H9T03LLXHB+PJcDImL+s9ggAhuA/FuyewS6aDOhwixEFmKAtRMCZom0ML3YKUwgQLaIR8hX4zRjhN92hjg7qRBPABgXnOp+yLSThqlvM+MXfDw4US5Av2Yjr2Quv8TyYWwBBSo8ZuJhPjR35/T9/w7Te/k+OpWjhiF+OyHqJahvrgG30vR/c5x1McYTyi6YdVUpWC39g2mChqcynwyxNRd69fn22oR6bM9Sea1TArSHi5DBCiVA4XNtqjPWpr0L63o7yGsWSN6eEgCQJGD/o6WvcZRodNjo+pRTUhTUgI2Dd1qkazTV8lULqZLSRUraa+2yKylK9lRZEkVU+xDWyZZQ47Ko2CCtNBNJDA+jMpi+BpxTXabr78nxbkMg/sHKWhN0LBncTFbNrl2inpRPCLxYB9Vz1w+ewD86Dx/4M/tqcXo01cF+7VwwJqCCiPiWJbLUXhITuCvjdZT2xSFaWFsghjKEiSSRlgMgkfu7MDIhQMCxaawzoXKYhBIAV9HwovqjRFVgtjjXV6oK8lrhJK/LkyWxasroqz40ioXfXVYS3R0IhnfFDRDYaXtquPWeJWrpF021s/3K32yDrQlKBKVPxF4qgmckHF+zUhglDW1eNj+8YPn4ig80OExWmuPU4cWL3OQzqU+9ongfqBcDttctggPnnw16uT6hhpA0UsV+TJH4DwiDgrjxPwg9cNENPmfxgRB+zgZKKJSZ/fHiHipDniBzmVwj4JD37TX1uskAr2Nh04Sc63zz35Z22UArdBVl2h56v6bNy04TojnteEAIefHEFG7wixGStAcC8eS0MS4Qml3+/ExvON1rT74dnmR+uYDfd85Lm/Ix2iGmaJwygaMN9i0y6GKdIExWPS71zSlhJG6Y0EjGpcGVZ98t9EWH6v2svCsUEUXLJTBOY43FEhsftcTP/1F8iyqTjqPzI5tYvNZftqwNv5refc8HyBTSlJAeqAQha8wPXxtDljXcyQeQUyv04srhEnlk/JdnQn/ftf4hSWn955s8Of8Oa0NeeaN7/77XUK6PWW3KebidIUngomJZ1/6NXdIlMiCfAXfnl5xcfvWvyuZlpY9OBOxJMtptsE+ARyGCIABTKWU195pvCRW/5okZu1BnVRqYIudv1SxOv2d7SUxuXazu+8eA09WjDsuJ4exbhsr286fEdXx561avP9g0R1JQUJTBQhEmpSvVz9F9CrVypFgGvrMLTZ4T4honaUyYhGsnm/S2zn7ED4t70uBlq2SJsoPmkmQQOwCR9zPfQwGglChqxu7Bz5vYOt7BA5CG2M23zg8StCHveuYUw7rbobGP3pXFtjGIs8qkYg+f4Sm+lBUytClsXy8T0P/3/MZHCbRW9b6xfi6GSVCz1FDYjbE1sLkmsZtWCSjHtNUww+5ajEwso3nfR9/RmKTMq7e8XIMrcOfOHG7WZvhGGGJoo1s3LEKyoQTXBDSgxTzLwoFqgtICOxYIWOODMkDa41Vxno3IxEpNBE+QmGJs40eB733hbh+lmv51Gv97Rf7eXcE2PHaCc19ZTGe3Anpme/1ML7+JAENGG6ZVyaVNUT2jCu/V1L6x22a/KTU1nywRgvX1OVW/TcLIi5pkcj9kqI2GiNYuvJpps5VUHXqb+DuVegNrDNWFBT8FGLXrEdEHDw5V1hEh7in50+0EprCFhRDTs16dXzemtRFc9I2P5dYvHirQ+D0fWH1srddNYCx6Gy51Nud8n/552OH7Z/63spBj9zfxNOTrlxh0H7YhKU3xcFVRMpHVcFu8x2w5I21Y1iAjEIT6iCPmgKmHEYmDzFwuPB2CEjeigOshAOQs0HeciJ4pnqD1RWZizDp2lRLzGWZelzCWtkasgWeCvA5+7ULg7KY2RPLNQj3fU3xYDoL8CMkNgn7sLQMfU01TgrUs9JXffpQoSsyTQ75BGtRQIGhAxOYvhaS9loF9CnmfyNzpia08ezvXCsT3ptS8mnwOsumGbFM6L4dBAeKLD3H4Nd7F2eiyThrqSYc+AX8P5lOD9TzSySGVu5zU0bGmjaRJVyN0/IhNH3j3tZufKJG2GR1iXsj1ZEeebs85eKAruhw+GgsNuHUJHfOb+THGjsDrGuVAfdQvQkDToykcmp6P+jV0+IJXnnVGg8DSbhc3z0x+Z3fnVPou72izCI4HxLvmqxkShZsRkGXwT0zAy4HaXzwe2EEWOMboGWU5Pr/8oQn7O2lBzfZkrZ8pQW2tTy2lVEjEyqa+lqkhBmkm12Rk9qH/KPlYbLbgjSNY+4LuR3beSFoz0AZqFaQL4Rsfa7NOrn7Cr32RpWLgeMD6KacNDd0ja90QmMON5tjJ2I/LR/zjdyk78gTIfQkUDZC5JGNoTOE0LYLcYdATNGTpgUW55FbSaLySKetAAp84dCWB5QVTtTvvAoVZagplvZf+gFhEfDYzvPWKvmRJ6nm7ImDhzBt0Kw6/C+xXZeT6JjXXEljEbnDP+ndro7zNmPi1zGZmslLhRdwrU55JIppST+nmF9bOWaTZi6aUuqyHeNRB1V8DdSiU9CpluO+771cj2SIKRIRiM9gwIkoKv2/YqMidF9/g4kHnubt0MTchs1a5Y2QQsrUNq9mr6+lR3Rcm6ueURe1nymSqvO/dpcWdbUuZWSVpJSpn3J2pWsK1p2LrCTMqr2WkNYRAuMcp6SwMyxUBIuIby+OzYaguvqCcqRwO//IBVKkxO/MQ5z+pBAjst6gegtFcRgds84LOL8GFPMWj2NCN2HeYdYij9OGXOGdTadeMuqKMrVLa/E5lOmYE6ZTKm/yk+F4MIZFuwZchZCueXRZgYXGut5Nz/jIomVoobos5HdO+mvt77r60R8U69LgYNvkBmSZQ/Nyd26vub2driDDhvj7NddMu/fqGoNFKj/h98NjL9F+KWgkCm878KPRd8jQ7U9EmO+yS66mNii6kVuF0nhz3OsizOXjSYwuWw1AFj8W3j0cX3OOKUo5aruFZ3teTrcFh0L7VeTP++OxAFJ/9MIZ1UQiGJifUOx5tK8gHCJR3AYhFG7yfARCSrAFOQMBossx6Yla33dM/B9pq6UkRqt01zcNsXPNkyppNlSb1mxL+LzMjwAsPevbR20HH2GxjzhIZ2kRAWtJ1M1SE0iTnE0i2KP/TBHDjSYEbqioN/AMwiwPzgjsx12nlr1eieMsxla/PW/9I+zW7/7Qecfd3V8t5u3iFooJbmN7Ig82nlcwP/5DkfxCk2My+ELs1Z+uDBqnUppciCdUtir9GXTr80pqVKArdNCb091DWd9l2LJniToCilgYA/KZ754rtAR03eIdA45Wq6iCnHMyKjcNTLpV5seb7XH9HN/36kPRMmCVuhy8mdUfT+B2tbUCYokLEgzLjxi0fEA+1BJpNgyoab2pN0crCrZz+F1BvIAxjZbCiu+WW3969fICpGimiLXN9bMyU9Ll9EEPbbHnubTGbiA4K7JNr5UPWPse4U/JOlDWo+I6rDDijDGyDEY+ZITfQML1oi8qVxUFU2uWZBQNAMjywYk8fXrRg8nVxcRs41vJQhZs7Rl27qvTa+QmVvWcBEpaXaWgrgA3GbGXon48tjmAJUxZ+s3BJD4snpYsW3MavC0MCiK/3IEyb3apB2ItdSnXRp+4Ix6A+8+yR0fw2d8SyvzAjtGIfNrJFWuP4+sYZDV2W2xyfvijVTQ+HkuOD3fW3/+gfbP5TewfkjzRF9U9QJIX3XdKOgfExMQXWcWFnKhc9Hys553J5DNa2ga+JaI84Sjyo2jPRMzHIxKL9604CLnnndXSgujH0U6WuVk/L+Vz5Xy/NdDocgC+9G35SM+uMxvJSDZkW7hhPI+1uTREvcJWLmgfzZcXfJ7b1lYcdQGaybos4YDqxMFvqzA/TdTh06d4Cvw+ESYcT/nUc7T9MkdNYJsX2ACWcmDKbthQxRkc4MhVUEDcCBJMkVCC5Fb+W3jL4r73aqsSLbY8m2SzHmpi0rmxB5DjNpTOlSmxP68ggPe8wUwwcOMX3I3SsHJm2k3w+zbd9UdTmax9COvD15VthHmMZaZYravPsSGjtVMq7IMLPC7UIP89nzTwJRZsRo2aXYS015QesSoreCwOP504AQDRUF5diLy8ZEF/xhpGlnJ+0oDGhO1KYsNke9qvsl1i/cG2kWEP2ybkrP2zhRrjwaF7ounv/pW6m86Olm8sX+X09U2WORwlkP5UL8ztDpJl25bfbc7Aee2W2aawKrLiUPqbWqi8u4v/K4156TOHBaVqFQ9nIXVZTuPJCTFUvbu5HeKyaftpgFggakCq/EzedZ0rQrMoQTGwva5HBGkss+ho6bZNFky9PaGM/t8iGox4qafG7A/L4r0jf65w41XELmKv159QrAIGRR1QN4CLvkkhcgPyaqKNYxV3N7j9whnKO4QiuMIRhGunir6Qnm6zmB01H5hJ49ciZij/OKMZQnoQi8fWsOYUFBDcA2q7JnquIGcM6qD/FJoDTpwr2fWVqXydV/pSJOr5LQMqm7D3c4hSpwIQCJPsCxI6lCSl3FeCoPAgFOboVqmhOz40S1UWjTcYz7ldXNNdeYrmcUSnvQ8q0o38LpZ5iJWqInBAnHWS9YVT/F6lcNsMUl0XLalM0/cISHh0KTIkm3odC16OxUq6vaCoKTZq9L0ApEctdqc0iV01YkHQ3zHHmVpCxdxoWr9eUa8TsOyKI80crIcRYg4aTlxo4ZZrA5bhSUpA3qiWF5kkLTQZTiShglFSBMwyjq0eCU9hni5n5AlK3HNSlgwqqxZOLdifbjhmVs83aStLB2zFFa0mENjkbB1cUrbH6catzA8ouqrWkBh0hSXFZeDoEMcZ+VqqihSDCkhAbkbS4pLJY0ZL44xtmdyHmB5dReGZDY8/cc5MoEVl1ffdPDbPPmJ61FTC9RmOXiHzFyHBLLf7vgSjc0w9dW9t4ZFtMkKkhOqsKwxO7PNtxzTxrQcDZUCIRk//05srROSJ2hKhTllRRDikvz2gMriADbcbEflTzyPtt8ZciTzL+GXvuovsA0abHSiPHOZQaLta1mR1lOlHXlH2sJ1UYGGei8rLrTmCaMjlu/mtwRum7EN2kKCW8xbF9t1zNQS9nWZxo1moBFhpc/MTlVwlaIzLBf5Aqa0USO5yVR5qZfZgpJ6KGlPpJokSojLIdl3TM4Vl1AJiFodHB9zCKdn9oVJhYDoz71tLNWnLxjQ5qPkTMKDWZMucMjbxp1UPyMOltksCLRoUhpZJSAFJqwiDhcn3NTP9fP1ni516LhOIAKUYlITxUgWHc4bbIZs8PyLv64/3xgeDifEcCmvtvv0y92cfUkdblJcEQ1aDxTgNJkFiqH0bnP15aIibdEMre3B2OvndhlqCcOYg9iE9dRfd4Qc4ae8Lpq44diq6qooyTHLwolRtCj9EkW//LUjzSokAFSwq+p9G08fFQQoBgawqE/xaFEbvjcp9WOtFfN1smgLqQkiOOF+8ex5FpY57FqAVHSosmO0OBvXR+P7ET5DZx5JhcOM96rqI/qE+E6URK5KfEyOcrQqV0hMIGnSOVWujWRiojyJBZxwwcQ8KsxadD/ndRqRsPhic+A0kGf9XAUdo+F3XGjbw4illwnK2LdXEov+cKHWG5jztnBCUe4oECwEXlgfEuw90TbhMxSPMzzYp+YAm3s+ytAX9qqfeKgx/eA27jA7jIys8ctfzf55j5b/zMP34NAQIf3omT7EbJgPFk/oB3/U/ERdL8ZmW1fblRUkj+5onhrqbedmzgpvYcLUJH6nKfW/ZiUWEZsXKgwRNJZcaz/jKZZ8oYVqQCd45IniRYxrlGoGGnyhMR4JRQLoU1ciTQQrXro+wCAJIYkO2cBEKGA0x60i2YfRbOiWgM45XR4maqfKwyQlYVNFEj0fZoztUS60Ke8Y2mRqDCCDAwMg1YdRMk2wrLxHLe8loSjV0iJb5/QmpRvU2xCND6J1Kehsvt21ucqXcNvou8N1U2cn/Gs0fp1ANiUEXtM+eGWAlitO2SLREscSiIURConorJOqDTL/fJIPpv2zxRlTU8es6TFOJbYiuSkWvhqJlsYGfYgTXhCw4QfPlXDKh8xzZqrBWcp0AeMvb60sKtc+3PTOWBNwLbdZWlnpXiQjKNqtdVT2d4gAQ/SSoMt+60kv7eBv+vFE/9u4zLLMHGOUMNGhMkCegLLZSABtfVUfY+VwWDs1p0Caj5qWtRHIb00KPMgnrPLHIJBou2vDJln0cG2gSbuq711PcXZvasrIjOkwOSxUQkfhmF5dR3yenx8YoeHZv+nrU9AXnxYp0TySkBjjTDvTSPYd8qIIpKjrBYAWKybQUlj5GZ2TL5twU4afldA1QoLxKk3wXuJv8EK43XfTcy67FbMgyN3aq7o4AseXBkJJLP8o8LRfH1S95hjGx42yJZGDxBoS/ecO1qmyOeHA6z76/cNEhvt5MmYRcobkHmT7hegVi6w5CYtc1c5SKxl7jTmNd60ZxEZmUmU6SY7WSxatMnzykLhn6XDHb8cfM77W8mkCVFhllFdDHPZF0YqVxHyb4yeMbywISv+IVv6NdW3UDY3w4z9qB2EUHuZFGflRbhQS0+lMhLYQm5IvOE//n4F354aN9/+3EGtddfqXybzL65xLlLTLovOK+ONXl54chR4sZidiDQ9Fmiou1lGsDknLi2bJhWkSk+t3bHB2itwYqpvzpJSZukxg0PcRFgYqcAxD9AiqhjRyYXRwJ20rKZo2GCNQBQ6ro9SI/CAq/8s7OeuOgc8Ta55MXyU5OCrefe3ThJqGT8fYiYCTCi3Vjiqc5zUDP8/wJDzcqjt/n82+n/bCk+sTeMpSaobLpmAfs9KMSP4zOReHix2cWywFoUPWSGviG8ZrBZLiZqAzmwere83iBD27LEVTwoYHTcZTuHM5Z44smcIFDFZoYP0sZ8H//ao8pJ+q1w+yoV0abo0i0+ep2ea9O4wiFdUkLbo0bbG2zZfq6TitRpco1so7SZhgmfSXnpW+gWrT7LvmlIQ1NqTeJlZnTLs2VJMwh6GKQB/Q42Niak98COPfuSO0KsAXiVkkGKHGUkvKJ02GFiwzca3KS2iiaMRbuP7dtv4UjGbUAft8winp80O2ZJUR+adQTe/NYb/o7dpkCI0pym0Gzovib+XBHrR9LM4A1uleHUX7NW2GSrZJ8CN9ZtLrHnf2yzzHAEBIFi0T/NIw5b2caWSNwL3bw9MIuiPtf9LR0Rt7YgmOFzOwEHg0CXzGw/8ObMU+ZwnOWi2j2Jctskgk1yCfDFq31dRaOj9NVqlTu0TawCyNDPcV2x+CSzkIVXaerh6FFSS+LbBNm3iSleLUtnTJM6dkeZMt7Ru3DVD0Q3CP3P/nvU+dfRpFsIBxGqVACBIfYYzxiKbOuCUFuOo80hOJv5bij4ZXHOlcxVieWZUc3jlLKFqC3YXs0XzDKJ8G6QNAH1MJCbEPGFOpKYAkVSYzQ0A3X/FEDxvXXtlyhzRPDvt8dgsGPONuGiFpq7MoTj4dc1NWKN1496rk9Ff+SEAJ8zf9ojPRAfmPk8CTpXWhwHH4omD7q57SZbmXbbr5OsUa0AOLqj9HAqCG5DqYE+pwk7FvGEvG6HOeVL4ipVZ9BQH2tTB2Lh3Gs1VX+93A6H/vcF0CO9j0sfT9PVjqRPMrQpzH8tH99/1O6JoxbL5wFfjdF/u0ZlH8vQUGjiKxI+tMks8a22porIWOD18/3ajeUwu6+OZl8hvx4H//9W6hmYhbVH6VE9/3t5V81txWQ+F812uOtYePRP9PO+sfFyCILZ3XQZlN0+TptbtDS2iaxiMLgm0L9u600MXYUTQWR1U02RQWvdeyRD2GjFtoq/wtqZQetd66kEldy45xkNUUX4WdM2FGkq8y8vuq+RrFugQ8aRjlzGjx1/pRgdsZlHkumSggXubL9DnIr5DkxXQe8fTrCbkfis+l+72JKHImpDuH/rp2dYqg/Ah7mIpvMPC+I7RTSlFTPpCU98/M6jOnINuyqe98v67ZI5mcORqO+rKrfNQ1VwjjHfh82LHLrfV2DuJBf1IKS5YHP7SKcueq983/58ut1xtqP6hSn7XQLVCyt726acq1f+jUcuHA0XTMSmEmok1A7/Q2RHNDw5vcfgUA2B99+EDewanKsaKKMt9h8TuXeP4eb70lsBtxoMHLnqtme9lUXF06Q9UZafP8Njs3aRnUr8YN5eF5tHIGTVO9+ZLy0xlYMNcZuCKKtyqwf4HM2LQzJxQmMG3ErpnUG2JNT8vp8xay2fpSHlXsOU6+CgsZVOEzZzMow9kNWOy/kIJLF0H3mrRIvZs2CtYBm4RzWWE9ryqtK9nkheT110lBEP6eWjqVTM2G7CI8KjZbpMN4eBRN12Ob6UPWNO3dFKYRPj/3UcK39EdyGWLlWSS82HzuVJar80++w8Et+MLYFN/iPfGwahcsGAjjQIWnb8QRICNrRZq1iOgYc7NMqguyGouq5itlc0pZnZhuGHzOmFOB1mzg9D//RCPRkZEh9A87VLDp8KQkuxJ2PhbqZfw7STgave45rKi3Dbx+0dvUzLRW4pNcygq5AM2Mcv7VgRYgQSZEj3hpUoxUA8YCKw7OzUIOpUqw5i+61QT4iNyvCMTDijubBiRaNM+3QT1nWlOkOOz9ZLf8yUBr1Dlxu/WEoQ9aC4rymho94beKyYHEfgpjlzgXbe9hQo2FenqOhokYhH2iqppuQOZKYJfQIx5CYGUbFszyx1V8W/MrvPRueoFMl4mQYYF5sh/jr71P9B5WznHAGqGJoQz6+93qTAQ+7CHDgr3mWFMB4yMr2vD5P713D3sc21JrFHHTw7UNLVXW9FUY5/ALRihCl9HYDI2wGacTJPl5P3GP2nYOYYRKABeIW5TUdMeuJyMJLGb3YtnXcnARI1e3Nide92u2lLzOmK7hBmVbPLsV/KcRNvTjgshQVqOnTyXJMMlfM9fvDLx1PPJQe/O4zc7Zum3nxPV1m3LLXxWwmo32YBm0fIYDKxpAwghW7Z/85q3VlTLfupkfVWBfeLonSgbVdaoOuOoBj7a7RYn5XJsf8wQbaXA8bAtB1TMmXXaJxsFh05kQjQkw468oAFV+7jQZosXVfrgGlW9CJd2PXhkqTiTWH99ICpAVMTyvftc/U2vfVUyvRHkZT0nlKUqJGKZsopSjijIlAoaGYjqs1GG53vGirhMcb5gTQeN4+NyYl+BiO7Q8iJwIIup0s5GNAi/xvvKihBa4N8jtRWiuuFtqcS0M1UeTi4z4dj/4R5S009ez/Hyozita2r4WCL0RzZrEkz62p13JmhKc3foIjGAx/G2in8DlLNRvyMyGdByQ22rvgHx1cG9pG41w7jHGYXmx7ErpkPLSXO07eDrBEQklyKBy2WoJE4z7UED+3L327hDc6QSJUbXH6lTPJUEmvTiWnqbDGmJXrSuWsHT+puAdTfBHKbCYwmdZLJU9s05v97CIgqWcHGkR47uJOUE4XtFQln84JU5KcndPUT5HlD5rdbrfhKnT+q9veyAHQQALqjokAMLQ2+9q/C09JH7tbgOifIDzUUpNMWTTjvnVEC5JEdhUjjBlcuQQiRgUWDV4Yi+91BkHk65GiL1ajFVzrxud6Kdvp+QlTTNgNfVTpC1rAo+VLWHh2IKTJ0Tou0Tjvd6K73J2v2I7QwT0aVemFg8sRKqh4iyM4XMfBQZ8ekCPdcf2QxSeNHav/Orube2qWxJKSC0CgxMeEi7zKVck6M9E1B7pEkPT55GN9sNhNWqyi6pejmla4aMNX3HQuJgeSUMoc+JwzuTkkBTZz4zmvtvZqlcwnh9Hv/9MvF1B28WXK8PSoxyjvLJC2yYkG0/RhyQMCLluLgz8xt/554szQLnFSr8Kg+KJz7bBF749dzQUlfHyE4Lg9SGQEJ2QdiaKzFPSVK1pSkXfN2G/RXdNyOLav3gltKZ1UDf/4Umf39gJne75g4KY0De0gFI1pSLXPFlPTylGJI8ldtiRukmjdps9Y54QfrS8U2047bjZ1FxqjYSp7C+Nu1s7mcnH2v3OMQcJ59hMT/ibqfxxrRB6HfVKYvgqIQ5WJmMzDMEdXpsq29uzwQ2LDcWqOeFbN3qNdV8nmghN8imn67Q34m6++LCF+n+bx9MXPTJKoMP/lqQsGCCuyqouH1KXEectmmRh1uiOKF+65qxWG5uX/WSbwUuc4HpStiT0s0vZdlO/l7gfmzuKGygTt4yyMOVmlWtRL8X0z5I9GPY3FFlJuphyuhCyBZ6NC7W9u2V1jks522IlIQZ13vqhwe9y7z7/nRp4jioQkn9LziQQm2OZw5mGw6F2QWDvkr78qYatgBYvdYrb9F5bCGO2TgzKdb7upXxYXg1bSVCkxPAImW/S8KjazJsy9r8coTrjSRLKECJ4t/Zi3e2i+0O1YkzN/4Lg8rbn68uS8TYRX21hQ7SNFNKTLmm15nxxf+Y9i3jTPaAAIPqP/U1qKQ3NDLxWQq61E/SpFLL+tJkyV+8VWn9Y7QW0FVeHAk/S58bhNi9WHFrxdN8cMYbl7r/paLrH46UeO1cvtgkVNP6ZAaixeIaQLNl6YOIyT7fUR0Kt/tgqBG53XbRyrvzHm1KZc9/3FGsOr6QWlJJlFiOXvvKvIzu+1oQjEZe5MHcodUYYzg9HkL8KRDIHL6qPpZkPPNAo10UgARQ8+24fjaCXvvW74h5KlRDnTYQq7y6uuLdtm66Zm6Z53+R3ed92d/NhQbxEGFM8XmBiAlSbkmLjVyJJ3XEdtjWY+0F33mj0k9lSx7Ezaj3wfphG8tdDywLctuAKFs7mFVe3m7Gs2qzvCstYtun6umHtRhpQg3nfJuspod3T+fdbxSme7eqqAHGd0jdoO2SiddMD6Uq1jOaovb9J1fhYjw9fKcMlCVuYUwOMRpGZVDo+HjzXujPJUlDv6RKExiJhTjC+Ex1gYejluPEJuV6wUIVeCcEiUTTwFxxEspgd1XolULiojRmjNGUXft4/AAIVgIRRrmrnPmpWspzJ9eECgTUb2g04Axu75UR5JXKxRHm7Nk17FGZfyWmn5L/8ets3nm4DhArNokyaTCoWlgpyWlFM1pz97w6c+c69gaaNO3VJmN4cFy0XGVEi29KJbc5FNTrCC67QK2ibbmulxK2SZPfyI0e5dE4SJ3hhISQ/3FoS/1MG/otM++J2fUb6xDf46Ati6ETGqgr0YxWY0rnZv/kHrDkoKsojGy2eRLaY1nar8VAum7vuKlaKozva1w69V//1eJlC3T1cEs44TBhvqxXZJqEbrOFh/YB3Iqa3jEvoErUyCK1P9YFzjSD6VzCZH9eZ20+EdowVtiJBkU4a1HH1PimyLIMc+z18jz8a5GHVKJcbNvwsCG4h3cO0xOzRu02We5utSxFk0RExY1Ki7ZDKq/1+UOluqPdYaczlCm+wRGBcp+uGv7PmQVs3r9qTgWgFozIvv5ac2beUYbH+K6Bnj6imKI/w8evdJ3qOdJxI1iQYVOAPYjDLin9vcFVR5srnEH7DFD+ekMpve2ZtGl3x0U1mvW+wdSzVgD9Q9He0jepyd7hrjSaL0/NJ5Mo1vedL+1n+IUc5xBllZU8lRihRmCAd3HKCoIjgNKdUijziFYgm5WwweEstppmTIwsZgkT5xqqUZjDHlqiemW0QR5KDBcUETIiqBDtmTMLVj6rFQYl/3rrpzT+42xr1ahiPCwFQenRm47knpUJr0AI0y9xBsLOjMc44V2TeNCchnr/8TgrttMduFhOwICe2qfV4orEpf/ip3/DBNb4iQazC4o8YHdF7GmjU6SadwPpSZ9vvGSBGYIr9/s+S2oh2fVSt+d4VyREbGa8zSxhhW9xvhcMqazE9L7tbNlOVYEJiJRR5siVGauAEEUq0HZKZJb1ymyDer0iRsi2yNUWoptV4DtkltgfvgObhBPtxIYEDA4tSKXiZom8TeU4EiEI0qubsGThFHMtxF9ILV+vmOjFy9Xrb9kf/NLIkKD/bo3WrwVsxAuFgSxF8KdjdIe4DZ72XZ/Oy9/kW/7nwwTePHOmOd6we+O3fa8/+bWHmlHYmoAZRyZS7t1PBk5tDqGBaLv2zj65OzxQ++L8DvT9uX6DFFoHvdUWSd4hgYjPBmQjTSkwEaMJHqJEU7VNCFRkNKofypUjorGz3LmxpVgXIDA/zSAgHCk6RgwKPjxYwNr7YNPvcRKlnhjrzYZ7MqKwCLM/6prXR+BJatfmUGx8m62nO3Fsn7LGAzWpFLF7QBPBDWT+pgVgGrpzk+AX99OLBAwC1DOvMq6oSrMjw4LW4b9uISOn9KCnTikfH+YefoL1YGK5g+hcvZUnvcn393zjDLCcJZVJOx32dXf6yV0owGz8qu9FAum8LBra017dqOJSITYQSNpmWfOrg4X5Z3/EdjY5y+J1lLKWU/Dwu22W+odVksAxr85jcnjWYFIdnPDnti4JBkKgcLhsswE3c1ZslsXa7trC1aH2Q7QvjSwb5VNG9XBM8gcgiSDiGGD1iEBOKgpR8zuv1KaqgKq1eTwCoyQbXilC5SiqdLxSnCy/uFesRHbsRq2DJS+yatRCxK7ElGnt/YeEJ3zu7IxfZbSDzkiaZEqIfjfZhuVqeNcG/LPgpppUszhywlOnLftEKbLxkV3CBbBonWhlO4PguN5oDY5k+9gOLeUbVMYeI4Q2MjYVuE/0jF4hzgcYGUVSQXGbpEJbZy3mlCFogOuNc88Z8KMqdcQW28VKlpHRZfItH4iM+Yt6GyO8ntQn37itJtKmLfB2jtBQwN2jSMc2K490bXvCJDxz0BXx9Ptw7FgeLQYWErYaKDohszK0NVe2iHQo9qaquzTbpXubHid6wiuTYY3l2JZWJXFJ5Y+oGHSOhXXosDR4xweuj5BNEFuqSpPTRx5vb+lQxN2WaI/M0wQ1yvsmqd7mCgB8FePscUvqVwTLPd7lxl9N1El6pYE578xSiTe1rc7pO+W6krGE2ZTdTktLU6dDFLOTeXPXT+hrpcKl8eaPpoq5qiFBIJDfyhYLlCQcALQIl/i2/gTzMpLh8/YYv9aqdqH9iw5nlnVUe05jcXX+3Kpd4d9T14PXHZsXc/hZP1FGGravyu56zRYAzgCaCQiSSLSKbXFA4AWRJtkk9apVi1J6+dquqm2OTjS/7sk1XGTFTNf7W99pAFPLeu7y3RfnAtae9wmFrI6xlZbaVUKQICBOjY01QZLBJLklyWPlOsQASeEmSRRgjSEEjW1YVSTaaPGN+pwegTYupnea63ep+u9E6i6W8Jg2J2ra4jGc3i/IPHrNolaQsKMpIAZWMwEusvDa55BIdST+ohVSbQTC2X/AER/0fXU/CaZL0wn/JLJ7H7LKW3gsV7z3eLoW//VkxqZ0Ny7ZZ41/AMNYFn6ROadCXz/YAdhD01YK5zYNE6CSICtV+xSlFFCMy6tBxjJYAGCNKojbb6Ym9Dn3PiMiKnNlMmVYUC9IEUdg9NPhk8RTtb7BuQUFvhj8l6LK6I9tXpLV20VR4Xsqbym+sba71l5+aZCyvqD82OpldlpSNVUyvoA7woD9vGxXJ0sw5W/NJOAs3Bv0FmVQlOQsVIULlliYI6ppmi3WKjI4P7ErUwEgJkYV2rgkr3yftIwuNJKGzi4f2KCiQ/nmM5orRmrLuNk8QCDVCp08kDLlb1xfUI//XfjcN+7hZtqRJrJSt8o66uwIPOmRliszgc4lvxXy0cezwKz5njAT90JkdHdc5lhPVGzkenDhQQ6RwEZloQkauMd1cPx22znhUnbOC7K/y2Eg/K+tZBlL95t/nyLz50dX3nXlCVpNkhpBhzdRH+/v/o7czspXketVvM45lskbduy+fSVRcWCvfs3TG2x+u3S9xy29I188lR9iTI2C+2Sb3BqAa5XfkArWfIaHLGet9Om+ZO3Xv4AbmbV4TO5/cn0f++j0rde1BZtJe70dxB3l8m1sfuo8UKeEBz7cgQkmEmlJWnpWvFtxcmHmiKgrFoptXBe3ChFlrBjOw+oLxyuHlfwXYhpcE5RYS67J2RhQbz6XJtJVumnYeeJ4wSaFhJrrWL5nWulm+hlfMzIcFbUEWykrsyeRMCG5QCQTuNwLkYH+W1fuOjRwUPZzK4WGFJABGjBoOl3OkqINqVI/FyedDMeLcC2r+eIFI60cj8XNh0FlR3hlgbLH8G09Exn0Jxt4nhNW8oZV+xks8ahpffwb1kU+MdVShXrWEkmb1k/Ov+pg+U+B13R2+bMlFdbdT8fERIg/eWnNypJvs/P4hcb87diDxVDUqyNvBnHvze6+coCnSsVmuYniK6Uf1oUv7D9Kjr8d//nY+M7ywSOY9q0SxTGWYWZK4q7mE1UZWcY1xV85ffZRYgUr6rG4NYbOMcVrhcn1jJnd+XJ2lPz8KUICQII7voWfQY88EzExKKYBSKkgtJ5aRCI6pRCTHgHv8jocPxxPpWBAgA2DDx5lMBOaQ+NZ1qNmCs/6m76em7MHIJdMMRtlVyVQuA2V+jvRLSlYWb1CWUXaVDJORF0dhjBXjMPBc/LAsbwmC9VcM467YFtf1w+15CZHp6B2iRLeekEkjSAQp2h5KaJb9YwijJ2hSlsEQZybqH0RNH1Q6mgy3+9hrUUjAHQpmcZiqYlnZDa5dLZurVLWCBx1ctmpKOyeZ2A8ovT1F22DKFKRfTQsxyX1XH2SP7QNXUVTrfqsXGP1Tx9pEHWrtkXOvioSaFMXCbwKTTcfAoTI4npP+1WunxPIhA2SBOIHoDz+13XDdKbrLPndhJLc5X6zmBCtql14OsDu6CFzDWUV+T7OR+MTj2Z5y/dwy3jOyzQDZoN6mqM6aLwsfk1UXB4QCjSICiIESucxs0y+jY+GUbaYHWFjlsun4EI+KziPJlgDkRClxZTao24n14oZduRws/YTXeYV3lMuD7cH8Xrb9+5x2XO9hyOctl8YZNfMUrwdeAgbViFVYKiiXeVJSKovWIYkSrRG2Jon76ByjfafdO2q4ZmJYtLCU9/FgkAoIB8/HTulzJig8s2vO1wMQ2GVXqi28sVmKTUmOgPZILEcR9CMxXNT+qTvqStiJJ2XUozYjka90UcF4IDvq4G1cCdfcbfI1rDWVDe/nPH/figYiljK+zdztz4vZZsD8Scaavq+QDRojIsn6oXZqgA8ck2SHSJlTGNfu0isJYywWtcGWN2FOj64Hqn2c73H/L9bYmNRluczW2woia6gCQm1dTH5T4i9M9bLHPme1LRkwAb0K6Nf3dWDWDDBVZFRl7gh0kZWJlQBsNwrSGixopYsOvpnQ/F6vZonjlHqp2vJMDMXxQk/EuCrCacdIYNGbMfY9wNB9oo/JU+8aem/7K1+UFMRizr/3F573sfFd//5Syk20x86uHegUY25VbD5fO3N2zyrdVzvSAhakkDhRpu5RW4BLvA+1wPMjehX0WRv1a5MA4U5nnTc/yvy9ZGvqcv1eQhFDgqqu2ZGVyXZbgHyIpS/2lSDiZRHB0dei3zGOI9gXuAlwHfqmfJ8MXx227U0bp3HFrblBBvidMMFC3X92+n1y5vUEXOxh5bdO06hxkxHpsKxIZbFmzWWmBdJHhyWH2OYglqd1Ne9U0ZBxSYeAOqSEHE5G0SUqL/Dxc68nMypMnY33vZ5wbjX5cvHypqfkzWv2ZS5WqwDjXabrWHK9o5nNZcwm+uaEj20x3faxXRZdraa7Dt2y0QiPa0pFU2JTdjqE/vpIFrI43KW20WENla0q5yUwxj7GFmUTIkrghDAmjoA1pRIbCHZSItc5SyibcetlpfJK+xZpUiOWnitFRREc1fUlnn2zTQnAG7x39B3f5Bs8v81r5UllnmVb6uL0FuNBd88FgiBbeHKUShbYUXi+J94OQKNZhl2VgJPmsyPVYjhKZWJHZq0ySWKH6DAnI1aln3cdJv97DE2AhgApwnNkFwB1KK2o9hiZ6VHTCtuwZiWF/IIk110uZbqFTKOfbDPVo982BW3bVgNQgZYchEKXk1G1TmmED2XbUARCghknpbSTKMAIUcIEALTDsX31tE5p0bfrL/adqj5SReU+JbVWuTz5sERmbSGuKZA0PmqG5zR+/j63OyOLjGOuyPis3CN04BNCmEVQzQupZ7yMT70p4PWL/PEyGf3yF498Yui1MNy39Mu6cbqh3IHphhxCskFt3Z119qqxcn7AABn49Ff04ZQcvBMnRbaiKrFXY5PyGSnDi4MdLeGqJAOLMsVgIxyKqjaXKcKs1IEZ5lMqtMxWzwWxnVo5xLZ8tQ2bNnnSCviye5vkXKJkRj4shGIExKBNVglefFaMHrkSF2hJZU3Xr/tsGzrJuEXGDi1VVeQwa5nPa1o2rICB++Cs+lx+HwofTUZ+o969lDi4JxxcmdQ+XCRW3ZwyqWgbMt+muq9uVVvmOsbzpru9YUqP/XqVXp9aV1yLzzSXcxDkb/cyN8PzxLrtobydVcxASVMm2WK/hixgTggq5EQvhw/kbF+I5FoeGzB+9MP+5jcNWGSswFgFfswt/jygzpjlPwRK7funmbH/ITX4vSa/IFYN+Ux9ML9NjXAcAZaIFEJL7AcNwHWrlpzqwzGYVOtZvjkiGB3SfMiHZffWPbSDJxnyGU4/HN2XY5f+qVMp2zDHjOv+4NXavDly7d2T3Tw+exhsIeFLWKZsJMiMDf3dz4/7HuJkKnC+mbSbkAnGt3bJRWaLyA6jhXLlDEnD0zz5lFE209RAK883K+VyOm+vv3schKEeIo2u3W0YO2ZQFOE84xF442V4JUWC0bl6eVvjKjbIlK4a/RnuH7+dnZXBkDy/BuPoHIE0UTIhaLaodRHNFf8Bp/u4mzJPVG2AKJESym32VswbCC5IjCZV7jeZ20CEXI2Pbk90MNgA/1cJ8E2xTRc35jsXR95LDlow2O/bTxDQBQO2HNiPjsXiY2F6SBdgcdmHQCHGyBZRRNLT+lBktVg5hxI2LOg3yti1B02sTGE+0b71yF4xLw+tb3grdm2kF3Tf7iOD1LEkrAQAMgAZzfPHbSDM1C6FJqQ2NvbZCS0uMTpMmpJ9XveXecGz8kWMiVIuTFdFiyhGtggiI6iwuXAiGk+B2IQOytT9E6YosLfdK26g+NPe5r2JSsht3JTOaMKzg+pKZ+xE5Ov4YQdF+RgiQEang0UpHUmarByWrXD8a/Inb4EC2/48v1v6q3yWeXHqpPE3ay98/Q0j2Xyadt1GmAuyHXNvRG1QUpAxMKG6bDcuyffk9goVwl5LdOz+nNfnFdewUOtN1Fwxtnqu8zGh9VeaxuzNatk6ymKpb2cjMfC/D1YUrxM5ucAio1RzSKDEjtPiiA41jP5s/1ODoI2HPUBQqOfq8qnNklkzxshlzjk86ZpoUWanreHEI8uJX1WKHJPJ4wWETAtsA/I3IDaLFKn2v64t3Fry1wN+ndd1nt/lDaJVia8Kc0Hf/nANSLcnaIkHxfoPLqZRmR8FyrezqBCHwYyPiAE0Idkvs83WvpIUJJ1+rx3b7EiVt0djyW4UEh9Lh3VB4QWi76WsSFvnW0fcnmCqEYEmlZaYLru0g698lTVES4hlCdkLDb6pBPuuqhewiHh40MsyjdRHFZoZf+fRI3v9+LM//vLv/s1vHOKJUOFV8OPjB0QaNflq4+7dje4+NRwMG+jw860g+qeEfSrKAGgxedIq/6r/NnQj2/JFKTqm+MI+lIevUPeA3veQgtZY4GZpMTvcc2bDebP1iOqn6FBT/LWlORleM4Gyzch7zt3MyVZT8Exb4acgYKvBqOPfTJxtGb9sRKn02Lx05bVFY7zei8WheUpYWxCjynOSQ44i0qhDUL4SrYqQEMVaBY6OUVlSks5rR40oXc2ElmF+CC0lH+fBRaL0m5eAEtug3n43b7KcdawbsfcooC09MK55SzmLm638sr9r8fc0G9FmsMYmdkI/Sovn7V9pQ2bgo/KgosrhMYR3vv8Kd/cawv7BCItw6ufjjsrpJnpK06ea3T12UDZYotOP1HtOaI8YOtcJKQx7YQlLm/Vbu3EntxMJahuizXERHyf3P6SL579/2LrghobrYj2JnU08hSfr1+5POPNFBW/f8pSyFb/+65a1PYW/7iJfbuMsVH1iaKuMWvw2QDCdPdESXCCQy4XJbuAcBbEmNzIMSqI6y8uYvCBGEcwjsjmKuz8FQpotzlsra9dGLdQHQXfvdeuSUHkrz87ZkFUhQkM12nLqcadrtcmKHEvYPmkSjbBLrjpTSeyjcI2vXSuaE+orQxq4TBbhhY5vpnwfq2AJ0TknP+EOiUtHKiMRWBTl5yOdlp0M+GdesHYY7Py5hFf2JKf3VRr2tcock3p7/z6cOxkNct7VfKrsEnwD7Q57rUkCq67KPiIL+y3q4FxPnHnBUT6KaPgjbS5jd9W0ly11wArnKuEhTUgGgUYYukiNnIgxJHU3acaYidFXOVdeanKQsXCFsyrkHxOiQiR0HHawTZ8x6aUKuQTQ0o+/PfqvBTJCRicITrOLY/1vpM+MaKiYaoewi+FT68Ew24vDk5eMtu9wJCZNJUyEwo6HRAfrcMCN5KG4fY0xSRgjSrRsBRHKgs6bZBBoWQyOs/E3UrvdgQ0JasKBOUXcZVPK20TFNRsGKSZF6e2FTe/j3DdPZS8YaiSYHYsDCebeFBuE9vSR9rovxqbz+CEN13ix1BA1JuuurRWfXFCWp5xB+UaVqTj1kJnnlMbz/zR8tm5kuv5oePMWb9Kh3sbcrg2l3NZN93rVuNvQCcU/xw7PthjdonogPG8rZ8uETBMP8RLPKsprivKf/qVggK0z8nUIrzFQGYrl/rJ3/LTBn5XDKrBpgw5w61O7v2TppCqKybTaKyhQEzFmFBECQ7LZXF2IDsdfGYznMMQUCFZZcHeAxr/+Ex1m+EJIWFletGDZngnqrLj92huW0mdJztrOq94ETb4bhZSrNNZ23jt3PXExqY5ehcF5yEIsAUkGgvXYICODKHN0xgveBiG0TcAFo00rLEw55NVBUHBxy/aQJCaE9gUqFBEk3EIxFz6KSDMY76RILsfiM/QjgI59uWeM/uwXDSciX/ALAXidIberI/Vrpa2B5pEPKlvwtpKG9e61NkUYVgQWZ8f7KcHusfgfvrQv3RF4P+sHXaaKct3xvLOcRIgwbc4kf/RD2I7x1lE5O6512iB6Qa2KLx2SYL8CecXsVYRoAhUzIMNhQ4FJ7cp6VabZ8DdkdZr0Q3RzCVZE/IcS5VmWCSczcK9KVsVDFGcVxcu8LuETRXeCI7AIJKiiohhdB6xlqUaSx2vdpgBrptze236YxktC2C9Kv6ic+L2247T5afG+2Nj+EV5X/l6txK2SZK9osIvFm7xuN7FPV3oJPvIxDQ6Y+nY/Gg2cF+wCNDpVqRoJF52DeW/Rgg5/scPmPxRvuFrMUEkQ2jfeZTrovRDk1h0yTC6YoIp3D+GI+5bs1U5soH9eSxN3AsXOSjHbZrB4fpSseVFF0gTLjPdNNDCu+Aj/rd84n7qToXlxkno90NAExjkmNUOqQXitsQMNNXHzEedRigtv8Re64xkVynomBViVsRKcV5RAiU+Byly0hnb4errpKwy9frYIWYaxKXVIQ8EFX+9LHYcikNJoeL2xUH89biEoJKL4kMQZsyT7FCuEoc2ou4dtPOWqfIg7FxLdYZLAvp+HJ7+tJqLq81p2pEBQ/qxDXGSPKNYm855XfrdhNC9nOL9GiEWSpnBFGDumzrbLvorueGpvTQCmmFDH4CQIVf9+q5DpPTRNGLMLm6R23XOuOM62dH1wUwrQTssj6ya3OFFP/Fv6ALApyP4iJyYOUHs3GSovtac5JXYljAmJWo0wGkhyKHtlS8sx0VVsk0aVAJWINYqn+LvYXxBKNRxwMEbEn9zKTWNBekNLJXbLT7psTG8FNK4TUd+wKv5a7vGbrf+/vWrPfaFP+SCPKu7K0mlWvETgdaik//I0mhhv9nOH66QBQDgJYv+0goq5TFzVMm9+vzcSn9VBKHCnJcrhl/4xD0f4eqFKq37zEl3ge3praRZVeS4q/NXJOCn4gkuIKEhx9Q71FgDJn29TGMNI/xApSkUEBBXTeVQb96FTHEfP+oYorKILjvJSVHibpH0z4MEIo6qmDWvatLst05bAQI/Ev35SXdIT48jW5pWMjUo8dT45msqudrQ37aQrh3cj2JVFTRiFx1OHmcLFM379BbkXrVe8TPRnf90V8trIdEv7phJZFC+r0hHBpdpgDVvr5oa0OkvDUzMRLAFj4oeVM9h3GJxOggEsz47phYidnhImabQhN5me/KQ07b6VeCt6qtswouwpksTvf6e/KdoWfWEYT57bEz0S5w8raYPpOn483Td0fFTJf+zAqDaKxG2g7Lww2PXj/p4XjR9+s6OLwUf2evq09RqWHJakL+KOt5y29R3lKFlQpf9r4YPfOVpHDtzoFcNu1gpv7e36oZqC05TjIuzjwann/MF6wVqznFtWTlKMKcWUYbPj8bH2qLLpqr2ldsHbvhVVIOYCZ9ssFwNZGJwNdQ7GJP8PfytEKR3i9oRBBzTtlB7Z2e6aOFNfZ9ds6CBosopJ8pi3yYdOMbwiW3CuU0Mn3hcnFenETCRk7qvEuRiPnDZig9HTMdjbePEzDkkqyuzNY1j4b+1WXPcfPOrzxOwj1P+ecVhjyssaboJJtYdky1PzBsVuTB3hxuSRZJnJwr6RzpPao7cZfDEUBvQbL4SGKGyL4rWwbV+0POxMB3RBXF0grpIyp8ldztuypA+ALssjvRoq23P0d4+o+j46AR0YL0s0xuFll5M9W78l5SENlibWVM28rmMVx3S91MXVTv54C6Up3B6DCx2iljTMxw2PD135mIrW/4jkfR7Vhn/8XzAGd3qioYK6ci36Uj9MLB8o1O8CV4hz6AgRlfk+vTax4SquQUMobFl/1unBSW9w7SfU6X9il4LAjqkuBJZoIFW9imEElEyPIfuAKiE0QGgsFHTmUkwHEp9fnnB0QZLNwHAgDFu/m/PCb1cBWk9Yi3q/s/gW1L8nUoFkQzb7saks+u2lM3s6jykp8woR1ulDI/BGRBM31KVE081Jft5Jjzr3PQ/fMM0tb/OTgVM0nEy2+SS0GF1im+jXx9rvvkCuEVS2nUBxnUZdrOS1KWntFC/OzWr6tzJ6mzxuNJaJMeqiMNbFBiNPhlFfiBEYld1akBY/Ex/MFn483P5n7ZvLG0xEN6Vn1+hWcsXvpOeFaDNe8kMcEt/S1Hg0WyKjiviyId5duxoWrnE1XXnyHS5lmcL3wqn5tOz9jjH+d4URGs6N/PQvnhJIGahvqjdKDaIDbLmxHWQ4BrZIeRYw8iRRjGmAVRKE6BGvoklKwRopH+3BQCVDbAxWAaaI1U9IRuFtG29Iwvsf8cFdl0052+b8/cjXNfre6nptZdNdn1x3Q6X8JJ91qxJw8Z4OxgJvKSsvVfpAFcNsrpVb/T6wAGwWKEn2EeKxgWtxMmuef6rFTRgjtZnLJCOyQjEOuZ27vbe7Rp/dQvXLfqJRmiQvfLyt++cAxbYDbM6huteUkvDzJTcbvU+uOt5EoN8f/VcyhD8thY4vdkcYSEFg4kkQJR+YHCxKkDWFhB2O/eOaj0sRF0g0gx4smqcM43/ifXnn4SO3/MToWjCpf1raLK57bHvNk2tQNAAtfAVcZOsuZQF2isWAHTpdVqa81y8JX3wGpHZHYEMF6TpTvBSRa9IwI4cpNelMtkQelwiZUCEqQJem84YPcZpXtwEyOhwT/X87OU4Q/20S61LsJUwCauMygf2KmcZ6A9deyd33Ul0XY/t31bWLGDbRfmVIsfJhufCwE0IYUMk39Rxjn/BBTsq/nR33y5WSkuHg27CUNas8nxaUwCy8F/A2lagM1iSKa0rOId6qr7613vEyfXcdhzapoqME0FTUa/Hxake7DE0RXynDc4IArcE9TUhwuH03dfe8RUas5O0ciZYuLVyWqu63hUKJoBG7gIUhWfp5xkaIWU8y+BKVs5rFaCpYUNAFB6wQzmYiLMzCz3iDe6HgagxOy3o5UCx490dYsSlGwn4z/LWucLcHll0ORhhUu0V4diyuZ4NCTuMb2hIjXkIwW0OZTNC0r5+pGvp0VF9oaPjmNBlCVuTW03l59A7y3eT50xfytPjHx2KB1WAhrKI+gkJtjY+Tc1zO78VO/mF2lN/M68vWgoNqNtIHVXNXkzDPru46L0b4tFttSHxckubA7drqsR3hAH6WwrLUlvh7a9ZNk+gB8QbE34G4l5wp33lNXHTVQwP8GVrUs7Y6RmfPRu2mg26DgxIEftaNxOmDoqhJ6jg6paX9dIAXcaU5/Z1OGerR0Diw7El05owztWwq/bKu8XxLOXZUSXsfk2tkcVLofzZDVD6VRr7P3S9aQ99O7n7KCIWCS1RzRT4Td1iCoCQR2ZGyKuWkZIfr0taeUr625Gs6SOShhNgUt0+fVns4yiL05LEDB1uv5B6VdJozf5p4a5a4hRNFqsDsmobMtmXVVclTmMg9VJHyCU3LGa/T32bTPtuhEpFDMAfRpMm9jePOs0sXNi4E2DEudj4qCUW5mSw74op6KTNfaV/xP19961zizdjTSTXMPrurwbUpzUtDyGDmGfdEE36xQTZbOZcGrbSCmfBY3+loW/PpTQ9u/dENbGbB8d3gpWVxPH8xG73/e00PfO2F54jORiVaGthVnOZJTsU4xl4/7b1e6wGMkiABfVDYrn/HkGr7wzFtFs1k0I8odsDwSbU/v2cXAcatEWuO1x3/rg/L98q7LnIxa/KBkQ99q0Ym5oKV27c+G6pCbVZJx0GLa/Or1PynRyK5GZUlPtRH4gAfhNoMvBAg0AIJyObMxykBUzQpZk2PnToFScgkp6UGWwc2pSzLipV0qrI8Nha5t71dRBcHPhcklGkEgbZhOmUvlzfdFYd9yzC2eTuszIdH98Lru7GwXdtN3ELZyed9SAR3WHaQ28TjrCdbg/LEYpeMkJfkBgAxcimJLhlDALL/sjMPyja52TAE1tiQ9nuyxu/oilmdIRF/voHLuCy/VLzlzE8RscJeEZb8S5/j5fLds6+88lSsmbiVq0Qv1Q8rtijlku9x5h2MiCSr0ErbnRZgyxOoyLMDlAQRKltZORTYYYKTlslE/1i1ew5eIKQANal2sShfK62A3xNz07PnrU8heBX+1ffajGzsCYgin1rBVNx1j9GWdz49RBXW5SqJmRSJFlIIKudSNiGTiNDplTqxZWNHUXTawWxWB7Q7wVnU06Mztmmzu3vGnO77QO/JEZgLgA1jtZTvqjlldVKa5OtcZ3gyPD9pMbqgV2kx9ufUl+/iMKyMLL66lLWF0zqsYNi7m6WEVjEBQlCCJiLi0GTG3WN6rISbAjVSR0ofksitC0lyZVLsMdopqapqlFvTjfe4Jigx5RvcuBlYww5u+tL80sU4u9ufcchVjOHcGsIbQtiuopPVcCOjDqN+RnuV2Zcbnw5tA7TU4IPkpOFO8UEiTkH9rbLpkEAKc9iNHZj4tK+bQ4n0nbdIkbyWC6/ByWUJ/YLLLVyvkhEbTXH+j/ira7zxkzoT0SRmlebbnN/jZEOp/XIYKVC/yV8VSAZUEbCUnTcyUPmgXRs/Ec+K6K9AkyAu4/veOPLiV9uPhOTg2SNi+ErySBhoUY24UMBhwzEn/J3PHgrLwViKF9va7z0APJSqNHV1n3tYpabQXAsnMTYfd+/zkoHNZDuLl/ZSKvmjC8FmzlKce4k6lOzXB27uP9SoRsPoeLy3daNVjPAEs5dOjX075BChCuYFsdAmh7WZ0/gn8rtxqY6kMEdpszdaaxD7YJ7zjP5ssD+2FAeYhVH5iFBycXAsBOPzyscTtnvFfPQLk+7NgK7xOlEmrzl8i2eAP1GBI9bAFtz2yb9Wb7+6TvmKpCa7vZI907dYuJPJX/caOxuNq9Xz7/LYxF9EuTuf+pXYdeFkrCjNuEQMAPGk5bSQWCVofsmzfbeTYSAakKhsdftdN1CluXLgSe+hJOE6iZzooNMte0i2OZvbl9Ed+XhZoVLQcTR/gyNt4QhtEHFZe+S4nl3PiS1cT0QHgGi0uomf+odkXzBGRn8sCSLn/uo3gRw0hzvIcaeJ86LkKtNXgmddtKdDmA2ZbLAfRB5toirrARQ9ElYdP0WHpA8RjHv4ce6GoIH82SHPEWvI1eDBcWH+tu2BJKrU9Ilb3OPO2zmVUqP3uS+LmkIjQZPK3YekkZIe6uxWeH/ip50kMUQzZTQRYWEwsUqLon8dw/N9pv5UbJqGtA6ZRS3JyH8UCF5lYLSC9nPp4F37w7KnzPm8Tc2x14K1d7v+bMPmMm9Bwd0die9oPuf8PWYcHL7tcfyFUCyzimfm0o7K1Tn94rudWh85lPqVDeGUiGophc6TyDS51qcNsXCXeihZUFRh9XEfhi0iJMBRh7ZHSz5NwRP8fZYz3EmHosNCJJK1RjVCeZ5s55FP7vYPhQuAj7zLvhmVyA8SFMRwIZWT7TEK4qoU54LeIsZjBOT59lwDk8IgwqgcAHdNk946u+tYmMWk8PrGZyvU3+N+pNLV5O7SeiUQZJNoQhIKEmjJ9FR30iGutavYjpLuTu1M/a3+nqu/Xufp08Q5SEOdz20eWqt57rFfa2pTwrXWIIko8TFGCBpnJZKitM0EFZzc6Snd5sUY2kzBBpumbFz17nb+imPd9BaqebhuahvKJEC0RcOe6d4LFrd5rmo+SZ3yo+WQsT42epGNXWwjuEa1vvN/M9P6nYVOpOfVfblwj0uGi6TeYs6lEG3Q1gR8+lh0f8i4Z0Q7Q8auEdsTH2jiRgJWbF4GZdpC/PNYvjIU06u+uPtXbZLQK5zaE26nAGFIWPBwUunP/8xUOl26knwQHD3etcx3TH6fN/xVXDQfb6BFrYxLeEKsu5ttTPLONcbm+KuLBOa5vmVftGZiLNMHXqfnAii9og0z2PvV6PdebFYLbrsnAkUGJsASCR0YvoKv++n4UL0N9f3SlUkyTpNEQY3A2zfZnvjhxOG2428YvQz651UQ/WcZ1NB4spYTI0vUJ/ov90bvi//OpdYlVv7ja4SY6EyWOBA+TMBiXhhUhHRaqP1A8fe5TeuUrNPC6L0itKxJU4zOk0k0p+Cr4pVJchTib9w9G/PviwA5tUUKbrRHjXsNLSo+T/DlT4V7Gom5kehrD5NltR2DL+cO0ItCBcuger6JxAvkvncPH4Lo/Y+3iv6qO/x0++5utRfdPR+EKK0fbr3pprCsvCfBKT7yeV0qyL9e4ugm5ffjirXhT7oBa3R3a4IyqHnCGc9UaM/Hb5Z0fjvHT8mKJF5jRD2rzQOltE6QzXlaZ2m2XnBgMA0srw/AkIKenaKfOmMcO93Zx8gL3+kwIuEV3xEDQIN4DH0Rav/of/5Z52/++Bt7/7bjCAPBbjU+HB3GMKHCbmvAgstDDH71/7R3cVPbyT4Wt56Mg+j/Wjf38lfOVfYs3Zom0DH8u5/qaZbtiTLKjFsGuc/NPzX5d3hrNpjW+RLfM3Z0PStpgrr6b42875cUyIAm+S+K+FW4XkCnC2BYQfbW3r2N4AvDCsbwJI3EIQXM4a4eUNkqhok74qHF0Psn5dlo6DkDhMHeJo0xfPxQrPt73T3f7foLtSWNnxxROlhxY/45EE9osVdhf1z0voclYxJH3ssVXtxndIb5hFk/sRq/TpAg7z7g+RaLNNdafRhO26hkz3DiLaDENvnI73KobOd+nIddrPCXvVmZt3xw6OIovH0iTkL0QIUEHPx3EBiwe2d3e7gJi8UFsR5SWlWbTGuW3mc9lGdKiCTJSWmmmBeZXMmaMJpTS3FK3q6J4lsp9Nrdh0NIu06xb5hSnL1BPy7ny9URoVeZUYPt64Fua5NNqU6U1LJFaqOowrcAwU32p3Na1oQXVH6doEzmQhiatVCOaJXvhw0UDlXKqk6K8ml12QdTQbQII0IdN/BCyOF1UdJqEBJwF+6L8p6a4zTcovb5wnKczrQoLdCxBLAVc8xXwwgVuo8g+GqKLx6z7SU9VXt3zEKlQEEWf17L6WaxRkkJnU3et8O6cIxNMbkOBIOC0ve2zSaUbhK9oNhzlDGz/48wmqU9gDbXx4lGU3N1YRvDEqoRXwEh5TRsoDGMay9ewEPo6XJRwDoCayJcFOX6+bAjsa2Xip15/pkL42oS4BpL50B1q+rjlunwolkQEKvckZklhzVsg/I9PrDb4UJhTmJ+3zT2In7FSNCg7ch2y+Yqdioo3roXkGlzyuHgwejenTTMb/zuy/ts2ilXyG7arNkKbNtXctKccDW4yrwUbSKycYEI/UrqneRnU6Zu2pLrOzHmmwPdXlFYW6C9ddMql8rY3XS9bVl20+XNQdtbcdddl8kSl2O74+eSzNDnWeisWcDosCRFLBnKY7QxKmJc7rT5jG3uqfvfXjNmIuPvrXVgFKo3fn/v3WEqMabyscXxQUZtRsOsMGMyk1ERYROYzkJudn6Ug4S1JyPIZD0zVvfMR1bt63hF0ObZ0ftVy4S82sBKii9wpHeOv7GonfXJmafCCRqnNBr3P+G1voV/M+Tic96N4jipvOSYSu0jAqMeSfrO3yhqSApxvOLOpOgDAvkRPL+oBhZ96/5VPSldtLhk02W16vq8eG3F20wHij9P+ExNea5rVig9XZP3efe22tpPeX4PDLDaOEoc9ntfxzir2CVSginTUI5jGbAUTmqSk6wqihTFhIyoAy6rarWgCyVV1bqoxifBYa3RAkvnrLBlVCFJEQq97BPKbrJk1Rd1VDcHejz44w2dYaabWDdxO7In2tpRTAnKSQ0WuZ52XO3udwvjrk0U0UixADE5Afgmb09KF4RMkCekUyIV66pDNsYIEXpl6TAWEskO6r+x7cT7vg2zeAVtcC32hgr+iSBo52z3ozd7jmnDOD6kimVaVHBqF8UMp99Fkw/r5+QtE/zcDZ6TGu8WYtuYI6r/rNf7qMd71ksjPH2bJzfyrMM3fs6k4O3EIZqc7GG+UlsIEubGeRK2gAl/QLpsUZOQcRbQhEBhclDvZUgLDxiwHZxe8MYOfOHuBrc4GfS6zZIoVt5KOxf0neJ4jNc4LtgmDHMmG9KGjrkldnaZiL3akGLAqusqFFvYiv1PCsm6v3v16e832q7IFJcjKJZlnhFjzCLXtoqc8DjlJxgS8rhMaFILRLWFheJIKqTCfKngjuSVS/mcsi3Qk5IUsSLPMnuxvRnzCyHL5Lbuuk/eya7xDz4Q9uaxtkALW1ipK43wcEFjK7Ry2go1lVg7EHVIFZSuqlIhzbt5VWbQQAypECQ5riiaZLKwrMQEiViqlbBGvKe76+/DZfTkdO6ad8EOoD0aBQ0XMfAGL3bzpEmnkR1GKkH8t3QQKf0JH8iB65a4Mi+uoaeTPD4aio/T4ucaLQhNn7QurOfzp4oNjBMJdkmSSYwGDDTjo+eOoM1IymEOm0lSlgwxh6bWHavGaCo0ANOu1Ci31pLREOOXrRQvXErW/e6M2HpP7B1WQGRnIpwzNOBCYYSnMZ71UyayApFrAjb3TptP1mmBH+oRrounODSpm/Xo8xuyq3Zg04Q/frZX/GybkXuUDNUqPMOJ2j+Vhahpg9baG+6W62txvsfxvXJdzPNmJOT4xVsUdLECD8z++wPGh+bwmbVlZ71K7AZzcx3Jn45TD30YbK38VByHb53LdvywU83pejH4m86Q/CMdL9ftGd05xpMz7L/5Z9k5SFPIZdQYF48wfsO9QC3yzKPHd5vk2OgRuIkTi/+tF+vTj+ffP50aR8E02DPIPobeT+CK4zklbbYL/iBWIPegj23TO989KO6iOAwih8CglauxuUPiNITF3GymJSMuvJyaw2A5AndysEb1XkVrTqkCIXadZB2B7URH/qIf5uztz9EKL2sUEbYENBgYaJ6uTKrZSDUGW19nxavEUy5i/mooRRVN8nqva6mzbUe7Y00WFqXpoprKj6xo1y15AIuVI7oSflfJy+U9vvyx1bplf1kLXNFVop4yo9wRhX+WgU3nTxM29eNvl4u11cWrOxiNyrMuPBDZE+XFNxZBCn67PVaxrs0kQ+9pPmPmn+aeEuWvw3gw+PGRjkTHsSbKhtVBzC4Xhe9KR3nae+zL3tMKKtaFBCKfzvMZ7sIiKjD0jz223R0RtZJ2NXnQUO0/eRsvHzuroyrP5nLHYFXv5k8flyOGq1mOSYOYg+YjblXyG388MJdUx0uIZdk6wL2b2pQgnRWi9L0MqyiB74f36zA6IRp9unpGZi6zQ9gOzz78YsuBcBJDNaDEJtm1alh7+PN3eb3tCSaHA4dlvgTn2HDkUfu0O04ignM2QDK0aHSI8vff6GHgEQ3zQv2m8OMxsloieUG5Bi5XdlbG6EPeEEAeyV/tFOnlUIySDq5yPYGmQrkpfFupimKbKSUNIA8kgsZB+EwL1WidCaQRWiEiPj0ePWZ5TQsLH/u9DcnKle0bjpXRFvoWmdGXQuMdx+tsvUss6o1l3/BGvmqqy6WMb3hxa1zOBPXthXFDHiDEa8hiUpgJyMreUtyeICFJkAZGSvqMg0rEiPK8JCkie86xA8uePV73AVdNL9ErlvfdOzeVqrq/SaVrWlp1b634SpsdxTkoqkG/gszGz7ltyv5Kvj4DokOh3fidlrj8JzB0XRJfFWdmUGFHsnM3JYbVV8vbssHHIlF9WX7jZ+mIBe9PK+KmkAZEnYVRJJ9HYqWgt59o2u1yA4cihYlW7qJlP8SE9fyyFGokikri8VPhdjivQOYS8XufSFpvvF9/KqUGFuACiBLlARVAnxzX5WKgG8Euh1V09nHi8/uiWT5tgXSVeDTY77lCmrMtiD4WBTE4cXv9TbrnB/PZrhV8g5ClOpQwK7gyCoY2YjhzfzMm0MHK2o23dYmdmp57NnOwanuILHlQmxPbqf5YK+Wq38SgACIcTVixW+wccFaKnlIpMuKFNIQsSzzdHupWD6KnyyqVzJdzzzWXtng09YzHc1SLiMcIXn6HYdbADTRHgAQzeT2wU76KN1x72W+5m8m6OW0inuZ8PjDwZ9n6+0JNAEUpKoZ8R1CX2VKoWkniH3ui+ygBCdb2mxWo9G9YqGSuVR5PitqPRhbOyjAJUGVPdB35us/xLUY1OuDaHaHDLq+Km4AS2wKgASKGlYNBMTl999OUNYyrbf8dZvjzWWSXCeo3F6SyfcG+fGd66vpUeEaFb13XTinKTzxuD3eoEyo6HQhe0F3ti75mGD6K2AI/z4lrNWcXrjfVnot+uy4mYAAssJMKZQabZDXyDruccjQpKSHNWSxEdbJaCavZNOxY71ZHFNh5eajERCNK+uUov+nhqyRaNq3Q2tYUnQHrtRqybni6ParWjEEUTO9hiF1BZXuEV/8buTeBS7xed3JX0ugZovbBwOnI4afbju/sxriYqceevH5DlnlKLCVNkKASskZqGWKbNTc2lxyTrySOyo3w3U4Q19mr5MziiHWbkDXyuKqd83F600Kj9qIAXcZd0G01NHkK+9bUpAEmzHzHiI85p7/uT7p+633D+plVU6XPrQrXiy6Dg0due863o//jaTqjyr8nx0RRnxetH4d539wpWFWEKjv3H0f21yH9G05jgjaC33/L6BGU7D9ps4ryr76i7tY+EJZjoQOf3wcsTKlJk2eaiMmadssh9w6LRae21ATCYeCU9ZTpwPElSt2haARUgytj4AQt/spB5suMDgWXGMafkqQDq90x35KaG4v0VuOk5oOi74AiiQhdOcHl5HBRYdPchrCHYGXL+ns3cTXne1o5K8yz8r99cVfDMVVbjkQSUSJG37QuFSssveYUJuIJmd+aVsfthkeoMz8PXM6lvFbelLWVufXhy1zCvp4I1pQiL9HkSuezLWhuihcwJDFAEJxgxQd1QC9dxSuXA4PrOof4JESXtGkVpuCppbYXdFDUlR+Qw7p6fOfJLu2dXjXQiqKKfSdDrt6bDLvuXZhCznqvJm37dj3b9oXfCO9RoShi/zwZZsI2gVDKNB4pbHHkamic5YjSOa/3E64PngpTxVyW0H+a6PWBMARrnC1gexWgjPO/yqW3Uvxa6GWCyZu3Xdiv669CHjNWWBHJvzt0IITNY9tqM8/DFSKJvD/qdPKtd9QxJAAmKkvVi0P7dko+y/w3sf0/T70SOtcGY2PaifbQLqFFzLVIYv0RXvax6Ie8R5RNUxLDDh95GNcp3aBKdT+e2vJvmFt+CnLCnTbX1SHbWfqAm/95jgn8KOO6hEuEeUz3WoU0wbZAj51DkSdJHnfJPnMYXfSF43RR/DwV3z6byu4eyMv2UQJs3VS6M5Nq32XiDcyepV+aCYEJT+6gfEJC3yeURSRPT/3h7n1Ci4KeQ/tiBR0jZ/ZJOz/Lq10wKAimx0VfU1VPKnhq6CB5uLlwVYdmumzLy4Z+kqURgvJX+0OXzr7Y/gvJtddze8OsIPIua1888wIRat5MkfJRbM+dLJFwuEVUXnGJ2SLSUPqc81SIXN1hFVepOw72vTQ1dir+ML1tNdxU1ITdXgh3+NPbqWTEQ0EHbj9Zf2tuK7nK6nxj63EZcUO9xPI97m2IfEs5rmbsusntrXBCsTPKSzXWrsDDnSHeLTKbI/oWMaE08j9ypA11KEJtkme9t56jt2g9CbR3skbXeX5bVy+3Pi1Okk24zhWlsL7fOCfeuXd3n+f64+2KLKIFSvYpalqqLHaF/5saDXeco2FhlIAYr4yCNMsu1mMFSMBlzZqLuc1WzhVln/uCi9Kgfb8n2sTjTA6xotEOIYud0OGY6ItjvRkANiT2YyAI2XPGu8NaYbxEFrTpJVSwydUEKlmWkJ9yw1Pew/z7qWwzWRQAMtAMaO5xL+0Y2dS/lGdF9s5wdrH/QoZcm8Tmiu33160PtYsbx154QVS7CPXndQQN/14YKtCuHx9FZbFa/XcRHBWcmfagEQT3QHukPd4jFrrDJplOjKeGRfU4oevjj/7r6T0J+l2OViovzMKjWuaERSq2chFbc/axfaLEKJPth5AkKSc57GnOET9o+MY0Jd9PFqvUzmceTkjWRq7cgc6jkQycHo/Ffpz6G5XAoN9/NGxKybFaa5+TICWsMiVjsNmx0YpKQm2eXmpVHRa8cBgEIVIFix2jWDP96B+j61Vv5PcfEFCCZQS36HOPy4FKYOC7+XC3L7fdaPpw5mOZcxQDm1qMErMuVuJwTIDh8SGfg/2LSP6z8NmMCsYkVBSltEKgo+elzVFTK2mS7g7OeEzIWL77t9Aoh2AOun2kqMMb3dGOqLhDAovQACgACby29NbUcuC6ZbwXubVJtGrbG7/cNDvPGA9CqZ/xa3CFOa6E/XD7N1uIzpgjGIcsYRXzWlWVcoiaRrAIY0KLTt42QT7TQS8Z1deyK4Gtw/ylhcrUd+OVjzPP/XBNT4UasXqRFV4Mr/iZhxzp6hREIh3TSJHyBt95sfZiYjlYw8CKLPeaDbY434XZK1YFc3M83/BM2wzM1qtj2ljguxtG9dRwPaGmBDKAjBgJjFlHjh06tnQHB2R9kY4+bZBZQoaifQtW3l98Xps3WbLJjQ8T67q3lMZ97IwPkKD0UBL3cslR6aiXylzCzPHBYea8Cq08GtTj6ORgE+mCtmPHVmWIAJS45MCXF4U0g/f45L/qp34EbhHFhX2h7G+zUR1n9/P+z8aNOUKhRVK2HiZi6IfxY/eX3rY//LQNOMKoU8EIuaIWUfRfV8E2ctUJLtZKn2mWtLwEWpalTTDycLWZFLnzq0POJ1yH5JzTRoczzqYloZz8msFdVauTFrFtGoesQqIerdw4pEGZswXTrkt/7fDX8I+CgYBe4Nt/dX/LQy13uhjEuDJwm5pW1doxQYGD6hg1of0EbV+JyvcZW9eB2ZL5k9RrrNu+Hmghbm/mvvkgqRRHaPEWd/o0BCuA2j76cqB6jUZGbJOMkAWNk4woKaZQToP+rkinyMCK+OEWNcnKH2u9gpLJWkKK2+9JDg4zAna6Rg7Dd7G1TlASYujuk1I8d/plT3K9E0kfLZHG272yVJW/Fe1Gwt+057htrKYlawoKkT1rO74tC0l2xOskmfakf6fPFQnSPBivG8c1Rme4hPo2Zcs0+dO5ydKWJ6SV/DXnxRg0h5Dzmcl7Gvfe6FQjmiusPMUxO4sbu31jX8yJznLkZc1sM7TDk/un/hRmmJ0V+Cy/YjL8hfFn69wvl0oUkjXALa4TaQ7iex2+9A6EPBhKsX859FWHm5Q/oPXqyuXRjsbGDk7GfmsuCUDq8q76E34LOb9UcR8ROWNttPbBSUhapKYVa2pWj1uBw4lMSZJfULogKSKQmKuLlMvUJrYJmgAqfNyjmkYoGUC36Ivf0gsfLOQ+vczmr/84L8Ot9nHeOSfbX3RaHRAQAUqY42C2OvSDBHR2ayXTARu+60/wwl5whFhFT+KxWTZ305y7O0qctar8jTNdvHnDyWmui7KeFg7tkF+e0F8lzlYu99f7WxUMmtlGaIeWs3J9tXzbs64YiQJiVaiqRA6pjRozSshGq8AnDSaJI2RbVoWblo+Ioqkhfk7eAzk8BiixkBBL6CBgG7nD+mGLJbNFalLm25ZMLb+s1I4zdduuSX86QXwtd45Bf4ed8TjrZ3VmDbJw6bc7qDNPNexu2n3hC7fwbtlOXJVX3kg7Medn94kxaaFUUffmwKgCz8EyuPD2kn5OP2e8ZhRouXq4vS6AxEGM+vN2AvFZVbIHqoZrWxjY5+xCR3Z+aPB7VfFoIpG4tm+GDGvJtvyf/cAAMZNW9b+gj/9Fz9+0c1PyOFCddwb5qYPxbh952kujXLj4zEFtYJCdfirM66SV12V5Y7tRENAthv1/sD/USIsS3tpDggc2miO4oFh13P75ZN+XGtz5f+zC2G/XkRHyjz0Day+BGBAx8FUAE4cUNMaNJp+rVXHdFaGDhqvzzuiBALrB5fGIAZohzPlUg7CJJYQX1Dvf+tYpyj96Q9KutG3bOo0jqrCjKgdhFtIVwV7U0pmcrLTyKIz9rct+uiVqvbvV3r3LXM6u33HfVftEM6BNH6a0XBbZ07F/PtyK4rIQWhgX5b5P5anEorF4RHFGFmgn9XRBcs6imFhz0fKVmlSYshUKyWs1le628L+9kZtqTNzuKn3vlKS8qDYk/l19eb4idBFtSmIb8Gff2BnwtOJiTnXWxbD0wpyb75dRKCahp57PF2tqAE1IdmflKaOGsZnkoZJOaaL+C8eNb78QG2MrkvKBJdlrVttqbp6GriDsQGg6yw1RX/IhyQlZB5SuaZ1z6a7Svgo2mFyOu/qIou4+PXDcXdqKdIpyVR+3pf41KYXZHT2xQNKEDIEBf48oTa9Zeeuwyfz9atTzb0N+08WOxrD5jzA5IKGTu7cLJ1zjlq43VdZt5RUspXyrj95K55LDo6hpyRNDydh2aNmRY4NmxZ6bZ4xRBVoVFMdETHaalwKkK13KKAy1gm3Wv+2kG/q1AmcLEO2OxZdDoLMZbFIYYdTcL+xDhVZgad+Ke1zYlMuWcM5/vibSktOoQ3cXV0aWVyrrZbRwkQBIxMxroIJxWE32ttxVZ1BM1qitxiy2iEukytLN57MsdNmo0q6KZckjownwL1t9x7+ZYsVRhwxCuLGcMNq6IiJXl0fI38JpBX/0TwNZBqCmyx9qLuet5saEMFkFLr6tg7rOTdv+G8CeI+T93NUsub79zEScqodJeSrfHCGKMKZMOsSgDigtlH26yp2xK/qKrBgbUZhm/CpStom0Teg24deUuMHYNmOb1PhR5hew039Eqzb48ZnAdX4qpNd/dYJ5XAjDxa7YB1mC5osJUEf6XnUqCQLVAVb4liFdciWbqJ2r8esF0thXHKJxuIR4ya6OZPXRG+LTnKSkzReMtnT5oePc1oUkhBydt1vKjaERDiIxdiuYE8W30yWhT7lIUX+aLyY0rcd4LdQro2gaZglmv/hUHCy2HGlxAgRWUVlV6TAarJRFFejqoXY1okiS3bSCUfLS/783THWj9XiSWOe9Dcbv5FaScaNKD0KQBVqtVSkBthiqf6PoPQZweSghVqTTir/NQq27cYdOZt5NyBnu8M+Nsp+dgMrHfqXp45rwkVVtecC3rdZlg6/JaXZtvsd7j/nmaVmy2G3kcIzqEF8pDFqEFGMWHLZIR7Fa2uWTZok+n9X0zIAYP1jh+DbXEc8H6aaf7+gJUhbDgrFogoBiYoswMR2gdBtgvxlPKAAFfej/Hz0GoATBQjwD2X1WDMeQMqlZtYR2mNqWvGtmoSt9PVUcpbaw7Mk4CanTLjcaozUElUPtKueKrjsLAphJVxQpgghJMSsqconZkTIvUaIfymMxbgZMZf8SWb47wB10kcLmL3Vq+Q3qlQ6+gZmHuimVeIhJ/mt98eCebnTQYiNlEd7D0NvxE75AezXjfeb4LrHe993ZRigkaF6SYw+Mk7xLphUMzjo63qANkAo6gEl550vOl7ze5UEjG1JPHzmu/tPZF3uLNtfpeBhsTxgKhQE6F3JPHR9eo+42Ht5bv1j2bccPRvd4R8s47q0gvApc4fJz/7Ygc9jtX/mCk4Phh7CiCFmMnydkPLtSwpkafs65LVcLm/dzf/RLf9cDK27ACCPToCEbWf3FLmFtTK49c9vpMRLs9idBnPPWkTOvOrv3gPiBkSWg9nsZZNeiBnyjlqUufZaBb8GFufHpbMahglLoJDyADyGHLbhkF1zbI1CTtLw7iio0X1OTtv3ZlrmwHcdhLiOdilBhfxKRwW2/NjszNKMrcXLtTfWoDyCAi/D53e1iovHXbtZ2ln8+drg34S50ExhYh238DfJq5+JpCfpQaUKQ9ki6BRa+OJukYNHX4SoPXMpYghf4Cxa1zFvYP7GLav9ft5ndZAAKvscvif4jYlSRytnh/LKjq6rkdxKy3bw95eIIh75yQI856BSKFaVL3CJjBxAGWApzSe1d7eASdql+eWvP420nxx0bAVRktmIPIrwhhPiH7aEIj/hQoKnke8Hz2wC4FYiKdZAKBtECTtA6s0P1tf8tWK0IYIDrsDB7w8+Nf8rnO1aHY2uBi+Gn2k/nVFaW8AKVrZf2Ep0OAgplGFqAFfYNRxyOtjlh5kFqExJaMR2IWU1168DpC4dF457xRqwiyTNa6h0v/amNV/zehsS2POfYbZxA9nsO0SL7c3ESgroORQV4CNQEjNbc3sIQNKkatRsMdXak9XhC+cjlBtd53TD/fOlD39uUtY/x4mTv33WckNDfOoT4DfB84HDoeesKcvd6m3aag2OynPqbN7gx0T9K23l9xr1NoBI5yWUnRiWCOjiJ8eJdvtE/JFZWzXVh2cWrAf+b3ukEyPJRVvymoY2FD+hQCA5jPLZNpRxFVs7elx2r29Gs+e8z39sXSxTuzuWUx6O+SwalqPbUFjkBKa4T6GkmoTDE/927mSeodhj2k+Q0LPyw7wQrfQsSHIWnjH3WU+6mNNz22gJKMBiSbJZu0J6snM1rMHq14crwY3eryGaU7yjnRzEbe3ZNsBMsB5JwzAErhjzTHisy2I3oLCpCBNhCiljmFUrkcdKhQZLy08yu5BJNnLoOJ+nJKO9hkA1AFl5NkinyUzDHs9DuHlSguyWzHV0d2LhJ2W3GthhZp9xbcd4rbbZVIYEiXxToB9LAJ9gX9/ho3Tc0HDk+FH8tPaJopX9Y0W8l4Cjvg6fOxiqfxoHo39CcVc4miIAGoITwgtqYlU5+PmUgFpi06ETNY6lL+WCCYI04u1Uq0b6qYBHMQdtD0YvVdGW5qAxw2FLr10PEAgi7vtPo+uwQ9fMCRjjhgDvAKBwobWuSsA8asIXRRM6MgDay4QCvjHYmf6oMEqSH9CNx0xbSNeyO0RsegsVoDysOZuBPUw2RwxYyqumSpwlBhPynfcdCAjsKr94iswrsc9xTveEZSyqbR8lKSPkbW4frs/STQ2R6A48mJJXX+PJjRvz+XHg8UPDBq7z8gTlNk48svqdrX1jz/mlkpBrV41DXfaNRs0mDBFwO+/Z9LRBOGpMRU8QEpPHjUkyZSUaS2qOPVZ6I0UJQw//SUJIPxcl00xwPw3Z4BdD+eNCZs8iWvenesd7Kw2lZdzcuC84WomaLgJcIS6Ss2a8guD1XmV9YXfXJbplrSrf3kuOtZVUtFpd8rwxjr6ltWFw/JEbO1Zh5ZUdPuMOiOPqMxh1y/RnfKeud6YiWNq1BdBkpgUltuuK3xB59vC2g2qatJ0I9WMws9ys5feDIMfrAJOSahcfe4u5jVCEqUkLJctQZ6ZLL0o7GXYyPdCl8hEg3w5wwP1m1eX3Le1A59Pxm5SVHRNLkFLMSSWjstP/6DvVwBM2ASiI4o1e6EbuK+JSmSLXB2x5Ph9X+ZP2g/ERZtAyVSI9p/qIbWrHTjxIpRpyP0nZKI7gE+swy7JfZW/ZukR2V7CY/6dJ7MhbwnrivP+ToJgkXES/Zz2IxUSY8Ts5WUa2Y5jU++6m7OYIOx+daAOQw7vXIspJO3OuOFB9qsotknxEQ67WSYpVwMIC7ftnitX8M5UzB56fL7h4RJ24RY91FU7ZzrkSHbkIqr5QnKeaQc66qstJwR52Xypolik3tEUdiV7lFzWRhuaVOW7maPLU4EapyfmyYBvm10LVIzpJKqdsTUXzNG9GQzpXxHPU07o1u3O64ZaolW7lIyQYaFzQYZzMhYXi87uF6z8RNXuIoSlk6SvuWruiCssEpOMbsGySv9+iwxcc0JSeK/+plP1W1s78hiWQPC4MYIMfAgS8d2KugQNETnPVQK9uxfZGSzCuV126U4Ri1AAWgqzFZHevQ0PWX+KWwwi1QXVDbnwU6hyvPuuO6gTh41k2bHqzDwISkxYYCfbq77Bztl+pwUii1DH9j51L6gjN0/4ov/Ew1+++2brPC3Ssms/7XG889KZmYhJGQQnzINPwsf3/b3/9FNxqxtVnvarXOPwvUdpdNh+dPafa6NoyU8o9SOXk/Q6N9Q9mvHLDJC+UoEduUuFI/JFnhtBN2QFeHM9n8Jd4/wvn1iHzTZwtytc7TdaLrpn15ogiUSZB+WgP117dnrdsOIecTCzH9zS81+qSZRYXiSTFyY2FQ+wARqnCO+J0UMdoYP++ea8724SNi5NlIyye6Gx6KRJ5oDzfxITH0xTD0M1537261m8wN1ct7kmdPeyiLRd2O/Y70YhcjQN/VDFvn/bd7VfZt02L1Op/5eNCuq91z+jiv2sOILwUGR0GMsTthVTFmxejsOcgwmLjeKXa6w4KZMhsEzV2O0CRvONgrB1jc+dtoq+0wekCNtfB+DPsDcCiiL0W7sTCPupEEo00848atAGuYU+GCTLkWsXHSaPa5wOnDTBAZyXG7zCDjZ920SHcEXB6nCEN1kBjHmO8ZvYoQd4rjEltX+H0nwPd5ds31D26qvGVumPaKybe1WaZuUaeIHM6Qgg5iC9osVG7+Sw+cV7CEhZNbJIvmGfd97jZ6Qu154wlRmWVVSGiO5xVSTMaNomFVO+2kPXIow4Uw1c576Bh1zMMcmLKqP14vdsyZPb90Q+9pHCMomFeURMrAtAMpQIXRcx6rc18Tf/j5L7/UQlmRtn+9ldZVGmH5h8U79cbgAPZfEWVQtLnb/O/t+spboQYUgdwfk6+7kUB0UDJNRjSV52U6f3/z7K7dd1bQTBLOkGQycSEJ+0Rzl26GjF63y1Y5cDNfBqVJ+Vq1D98x5Mi7oaK/Eupn5yRnqEkSJWQHuhPgvkPUIpIIEsAASkie8FAxeOrq/3s0hBaEGGO4UVGXMV4sJxxOaDOmMxamkcea2gAbbZInmrZT1H8oMrzX+Qwgo2nJR6EK55ShrmLlrFc773X366JD8UO63qfrffr0FsrEcHK0c/B595mwrGBpGisxD8JMqoISy68/Uz+1bWfmi1Ke9zt4YUQvByDLCgn4SIAcp6Lmho9WttFNZnwQba3cYyNibFC6A8q/Nl5w7rxytsCIv/pGIhSDag72+OyJOAsZtuD/5u+39wKFVtXWODRUEH3zfJ33y8Y4AycDAEvEt5T9k27jzdQ4O/0947/4JVSRxPAZx4nE33xcYZd5UYifJCsBb1PKSMOS21YJK0cjRyxh+ReWwm429p+DfX83CHIBklfjWP5dcFKFB/MvHQ3HZRlUiE+HZNja76xLV2lYwvi1CQ6eu5qraS7RdE/u8gS3zQXMhdp8FDALEenanafXRvsWZ13EqzbMcjYCJMK+eCLec+bgKy2UpqBAQue8noOQ0TR2EXT0K83td7VXn9y/+y6j/cXs0TAso5FVtvLIWrfSxZWXTOdKmfd2rAl7uYIDG9z4KCnveHsitMomjG8Fjv98YXEUja4bncwuH/EX9+7zR8xIAD37QLyHk7//ndQsJ19JxA9jgChrqe/u624PJ7/XGcr5uh/si15OkyHHI8dLkjmrlD4PWP5dnGYzS21e8uumXS6XpZKAfzF9yRhnD1H5e3/wjSMxoQE+Gfsz0lFqOukWQ3vMkkRcYTt2VVnJlEgzpIgxc4VkyvvtCCNI0VFT2o0xyeJA6T7/iohXmB3maTvGf7XnDcoPw7RwZkAtxDXSj+xaHeY4sk4begKXsJ2znJHkIlAyS2TplN5j/Ghxf3tULWB5skmE04/UUxWTpKIqkFlSn3v79KggPMcvLWBXTL3fXJIcfm2BXR6IWzBLsUYBEi2qVCB+uAUsDBKJEBvhkCvUyIoYx76pgSD8njK9RLGOC0IRww/vDonh0Ye//ZI1qSifoy/ifoHWTpB9aWByI2h0DYGBzo6du2jaWOsqB/5hiVmwkQ5/21chC04f6adGfbCrjv5uGI1ye9zkigOeM+p4vUuh4aOSc8esPLWNKOGj+/YzuFohNQSzHdOowAPvI/abxLtdEEY4ZIDNAq/Z2gc6SOi+lZC2hoZ89WE/TggTlAp1SXuT7dImVbSFEuUqzsmTcXobbQDyR2t8JqxsHc01TClHLewLZYmthMZF/wKQCnRiOELkgC8/GmrQuiSKGCOSf+CKeZZlO38KJM3V3/81sZOBXN8440lO722Azl8l85jRNeWSjAcW2+65ExO8vf6ML7lmVy14sjMMarpBHg7nQsO67Ecv1tNDCbUoizs9M7YqKIrZwRPP1AxV9IQEzd9tj/Uw9H1hfYYdoccXo+1NuNHVSAtQCu5wWveL05TFXrvkUFkrAcRUyJacFtm9Et/6E37dwvbVgPmdHNuuNck3AP2iDjVnCp+OvJ+EYfF4fBfBvJ++PfsVboDVguYdc+U3Aw8Gn38gcUm039llfMNomOYez3G0If/7YMfH/N1Y6sKXLKX2VN60SvjRQ2tBH3+5Bed2tUfbMYZ9nnLJpiP69iAOclZUODQiT0pWRIq0r63hlowYii5mLthXayeHr5pK7YNUEX7Ntt627WCiusxJZY4MYTJBSIksEMwoB2H2VGo0hFJvZqO3E/vlULxe+ULulPpWAoHdyJgrdj0EwCkkoGnCXwxg5EyP+qCO5aW6TZ0YyRNYosvgWedfssFtjHM8f0fjYbzq8wYbdP4wd7vhq2GPo5pzTTuXO0Uvf1BNYRxQkVNMSBUaNmmyOY2b7SjLYh9OfpzeeBDkYe9zE2jeXA56f6pMoik+46Uu0BZrTsxv1hixE+Xq/myr+GX/pDMzu8XTL6TelU/U0xscMwAxQgQQIyo4MUz5qtsYVsMXvCCapiB0gPl9Jw2Cxl6J9/3l7OEOwt1l+AHFFpEmjMyoofaY2DgRd4hdkg7vG2m3i8q6NA1mtXceOcMcpMKufzldvO8gV81PGMYs8EJsCcCbX4/v6Hh0mxNj4EmNEWtTklxugyhBNMWdQzE1zUM4D7EwMYsvhwaxGJuFja3xdB86nxwThMEwIy+6viNCgqaNvjAjdoQ80ZMnVm+SUkMsMiU2IaE/AzlJHixyuh/07fqsEmSVwMJ7VNavDtWJyNzykSxLnauhisx7Cj1Jik1TMuOqV7mpJwu7aGeVLrFimFtOaVIHkiWyxuaUrFNqDcRIIJgSWBEyZrl6grgiqbhWGAWMiRuWvdpfKSTFjLmA4NoGyGZkcGMoWCxt5hKhwULCyGCDUrae0Q7GKAusxcGP6VsaBkFQOTxWffU9Mp1C/OVYNejbpzwFK/EYdLvQ+Dghy1CH95285UtRzWbNMPnkzjaxnPUtSv6ccfcCesMmexvb/G1lAMHYkOzTiN/CGcASC2oa7dCc6VIVD6bYlSVKOEI9KUWMumOyO0L5U8YgBsEagw3GsqAova1PivFfBCbPTIXwFthvDoJsb5VZtPMjxTRPDlGHI9tAI+jldMgSSBNZYK7Tjm12u3zoF33xw74INL+40YJZFAvst881uoe51aR0CC8oXCRgxBhsgY88s4ccMPjDP02gfpLbMG3+ADyPhE++eoRn3w+KPtsc5Pw74cl+h3iOUnZ2WjniEDJHKvS8BrzCF2hR/3GS+yxPBqxLkv4NkTgMLfrRDuO3DKp47qKCv0XOce81xv/Qwt3Euuh5MSWQ16ZGYNSaZ1D8KS2NvIcG+LET1A/+ZaRjPuGedkiwvcteI7RGJ7dhLF9/U1FtVdnd6Dj6kxNWhlIueoq1iit6fO0Ve0f1u3mxexE1gdVt280x3hobP0ItTqWAiilHJF+Qrevte30MQ3KLNbSght2bZx8MP6RTtmQvk/MaGJFkxq5Atk0TDRZfduaDhR7wdsON3YrC6qKW1VzTnQOJTzzUcGtaUcuxh27GUO0XyTf+B67hAEn4C6/UMi6mJd7sJKy5/CRVsVoT1sXYzr5u4QK8dtF5sKXZvv5hX3x3Tm9X9QqydUgt4iYZadqTVTigKOLwsqS8y/M9bVbp8Kw2UthbyEnsc5ive+U74k0+NK/l7K861g2e/efx9A/aAg+UXHcMLefmhx5kuwR1Rq2Pe5LDeAGCS2qzsjrxXuK8i02pNDdHLvjE0+NGmwDP/aGPfidY1EGxjHDg9xtTpq9BPRimS3zcDbNr2BTKU45S29V7yozJq+Y9OSyOIusAnme6a+MFKT7ygfPGB/7MFZQdYGlha0+7NtGespRCueB8rSoBoQURPr3QJeYBTmXds/2zSpdH+EiPM7KxDbsKDOZ4rPR5gm8eRjYtJDsV7OGRLRIsBOyasv0vafcgp2lzoubskSyf3Kmxxw4TCjh82wti5avucaLVyqYzi+wM3IJEBIuoPYHqi1cax13+40+UNHS6II6tifGZDq85xz+jVPNCeA6WheAOgXxI/mjgT7OwDX7M2cHZb4iowGYIXdp1j7XzSynWzdnd6Cz9p8dJ6FpAUuRoENgCODlqeqxg1afkJJ/paWdsh4ROpc3eTXtEl3MvLaWTMHsBkaB99c9opioXqEyuOcgjeaa4sWf78jnNX8bcnqlFL6nF2SzaUMIcmhdhOw1VPsLhm3AbquFUlZG9/QNVFr2pL4Cl/opl3b3AP4t9f1l4QOfk2vvp+ckHKajnVG8GPSLCS+Tyzc78VeKjov350upJkmfXgGUP6Z1S+94f+uk7UCF/FFa0Q0GwvxaFyTVzLSNpZUMX73mKFYHE3CQTQOfpbKCMU/3xo4oKAQfEVg8kmZq+ZxelzdByZ3IaeG7JpqbvDJl8w8d1EwpiyFt0glc3PJI/83qqkEPomb0qnoi+E5uvyOw02gjugpCNDFU0zpU9SwKDT+pNT+P3vn6Iuloo1UPLsYMRsM0yY06ZY5KOtnq6vokt6a1/11pQYsfbuhnEV5KsXV7Z3qxJsrS1byLvG4/b+7Wy65YdWLavySZMUBWUKsTLNpll/b2GXNPrzkXWZEMG09hRrlIAUgCnJC2SrrTcrq05AEhQk4Pjyftxd6KvtodIZaXp53kYP1RkfnvrqUIhJ1QOUKK5olB6XBPoaKiktODLlPT6TnOAD6rCr05GAi5D8g/ux97LV4SUWMhh+jjuL5F5NZuUg1UArzGOyPOGWGE/cwFmmTLJzvrDSz5+X5vVYXw2MTpyONcJzTY5yJX5Xzd2aKiv1R9cSHyGuZ/Gax+0Vz1g51qv4n3m1obJH65K5jX+v79687dCvUYHXi1w2y/5ysioxB6RtjqVmEot8lvPtbQKYp5FuGCCTQdxQIFZdngtduZYdCrQvEQRm+LysFnkmqboVYOJ7ubW0XBnlh2DORCndj/7XKPegw2Qy9cJ9Hoc190tqpAaymrqwVw4dCk+GAJzUeVWLBoPzvKKmNp9cqZHWFGfYqMi8BA5/2o3zAWG8bw1ThfG2YJMLttDwjAG3/HYf/xHv96vgxQ8aUNz3rRqTX1Pd7C7oCVIj/auY1IM4xaQba5fT/cz3GEsrVkpdI56aTNg7Mc49vXoCVYeC5NlBPd9VWxVySFyk6xDYs7Y2IYkgcGJHBYR+JGhP+bZWfUwkIOXMAzJciYRz6fDS/JIFPW/bHloJDPhXzPGHAMNBE08a49uvGrys0r4zTVexOvFEHoduEE9UfTVNlJvKXN5JcEdRokqZc2Jtk2G0h2+6l62A46nvObSKuNbbI3+Bglze/t5vrVy3ONmEKGxTeHEgWv7G2+2rbv1Yz2x0xAWpCPTEKR67X3EsvZNu+goeKdlBH/R/NP8YhtgWSYvMDmsHFmCRBCjKjAvhnLwii8aWM95klbCumWyIWsDtZHYWmJQF1v4ulcGRaqNsom9uWCrsNi/iAWWgMRu/snWiY4pyTpu6OONmRMW9PWH+07lLG8w5o8zap8+4iuiPQG6KBeVvjV0ucBI7xpgVoI0gm7qAZuwSaiRNGsfrg0Prw9sWeRhVg3s8J/+xd995Tuq7mFbsss6b5NDNJro7/q7ljcQk/7IqI/vR8t1yVGrpbWpLa9pfvFp0QUCUoQWuLrMFYUMYDDJJd+ZxHz/RuRhXMM/7qDSx55QZv/SOc7uJ0DreUxueNlFrdrYz8Wq8sAnC6eRx+ntQ/Av/3lYpOBlFU7G5jKKXVJLo+66axKmKO4L9MMaxjmMPd56PRactS0y9aDuE8nSNKnWfZeyaLvF4VKIY+SUuZBMd+mDFjDNyJ1GqxDXv9FjA0hA5emO+ANNuITt3EaVH7s+epQAHod5JFTdz3K2z6ua0sLiagKeAIlDbbEBXzt6kjjznLsjMIGYc2I/snqeabwTSIW1Y5gVgUWBv2ywh33IQ9C53B0iFUJDUHTe2RQ4JetJl04YgyK+fCJKKkAW1PfTxM0lfOEqv8YFrHhMqvkZ7Qw/FZzwy4sifnqfua3AZAA1syJKSPpcRoiAJCkAOe2C7G1sI5GRVu9T9ZLC9rr31N9+NvPLsRZYE4c62rC3GagCLxk/zbvcMEkun4oFq77Bnw287v+LM4y4Lp4g9nWqW+JEi4AGYlpE8Zsv1ENGDmegXRBP66EBDKGV5g6M8x5aHA+JfZOSnZC0JKcmQAd4ztlRkOQsPKD4WL5Ng76uyjdVakNcv1dVk3F5KZjpiwf2bLLXSHwUO9FNHRsXbzuUmFPWEBHPpQ27NxjUDplsgJ99D3yP/YaAvQScQHAwwaEke4Kii7RdXvpAZ7gH9JDxg9k3r7G29I+q2PmnBZJGHtM5neLr6v4ONflUvd1OnT/19Ke7aQXsaEcdn2GhIsKx7sTM34ZnEavIwLKBTLGl5d4X8ZWx/WhsJrEsXqzCwKtWcnPYH3xnXBX+92/fUeuPTkSNYVs8FOsBLzlKVlR+oqJMKZRAYwd6DksHoDBRdHPOKZ13R/JuXhakchVEiDrsXy6CEXb7D9F0eKsBc01M+gln28m9smDN8Y2ElVPpi6G8lo4d8Mu/6NdBDM5301IhNAFicialr/YpGUouEyfEGUuH/A9h6qIr5U1Nrn3nAjmr/dOS8bFp0XLf59+XCz8Xv71R7eA8KVLM1bRTXI74uKGmWB7j3XGWJcH54s9ybz+oCUnSM3FOmdImuS4vDPySxcaErnsjKWWpRq+cn+qxnVf3533+XBrqfTpzjndJJWeU2SAoRIJK86g0rTTonGxsz47K6uADbgdTCctHNw6W2BFg2xy2WVe466SMap+Wnio325DIFmOcqwsm7vuX2Eq4BvQ5eCRGqIkXREoTzJrJlmZSExSdut09oXrVceoZ4nnJOU/2aOg8If46hyntEmGawdROZGkJjDxOXJFOLKoOTYaG57AqR5gT1vuVKoCoVv/5Keq+CfYjj3bG70+ExwOFILvByR/Y0/StzSq+p2teWPP8S36cRWMG6CHPsExoQsi4x0uSYlo1ix6WGs1f82MVpXifB5uomJ6BiywOAjVFaQPx2rDVzyYHzgqZti9wU0rmeQtZLaE6/VrVqvdg6O2FCHDN5h4P0EXaGHAFj9i7P+IqJ52sRGGU+DcPi1FenscfYNuiPdyF84U8hEVuGzvnaq5aOdszWK2gD96LZirIUOQ2Z5M4Fa2jTegl/Mi/05CMJAX1Nr/AKA/rk9twwL7f8lWJwI/Cq1etUQzGOarr4fnVq/OkIitTRx95GjnD4lyLWCZ+kzB3z8fQ25Kv34aWHiVkmDcFYaYBNfUAlteFcDBe0+PjsdjxpDaje//kXbMJdvD8smDNYaVsmu738vufTDNxDYthhaBpxHfsJAaQY+cL6H//nlzRkznuKR99xvzsGJ12hziKHtbOOMlkSdIuZc0jCi2KR4PGyAv+ExMkRG0KF1W4iD4yHqQfG1ohlnk+uYiuCNPC+4XKcP0ZXMErQWNQpLSuA5sJv6xJmn8a5S3hwH4QAROSWTKBMbjkS3aLLUlo1qNPHRAbETxe2SvSuROB741Z/62bw8WYNjHsBf9lY7gj1HO8kdd8M8lrfjGUdMfH7yd8J/JfyRRnt1ayJGe9u71oorO9JFSATM4I89sE9vOuGKPuY5dpGaGqYW97A9eDVU+d+lRNHAk3hDFYtnByIjbFQpuxZPwD6vbxkZziW9DzDbLFKKlJcMgKoyNWHS+hGLrYD+fh7U4ax5rOvlMABhHOjnTWL+HPXJyj77QgOgegwX2KdUaFuz3hW4cxJjj9eC91wYIg9jZTrDcQvTNSN0pmVJWGeHu1wNqllMDtBynIQbQL2f2YrPj4Dje+G24P9vkPH3WKRK+BPq8uyzjYNucgxi1PusmUNWi7tlpeMgCx6YoPeJKpFFOeUJIGwJgSZacMDilCHidjEarMYLcJx2xoSmjWgrOCsF94uPnAEHuiojInxHQ+KpPjCNuRmNp3giwYfogpgcMcQBvaR0mn+DkCnEKoGj8unVSDUO6BGZ5NLdG/uapdZKsRro26hLleVep60P73tVNkQAexXCywSHLioafizl//zB6x9NMfRZrCp+Ta6iSiXnL7LrW4NOafvGhP0bi3FLDfhFFTMTKgzCmHGXIQUjr6LX76DR5+JI32h2a/fuQbf9D19f1hkiUHO+J+BlzjPMzGETQ38aEQLkN8IiNuV7vxGtxK6Cm22tyUZdFuGDUEPSIJr9KMKD+tHB9IaDPx8j+tOoqHp0y14WQcNsjNj2diFHX4f3w+iQo2zDM1BrHdooC+HsDtbjmN5LHcS3UTR45EI+jY3RTLICZNEutPUnGoKu+PBsQwPsHR77gDIHfrwZEw1DEUseiaUH200EstY1jxKaUytNl009qkMs+oLTHqWO7VFenS5B3rSsKd1EMRMNLZ6TXgRu8lE1L5c7NiZ/z+IK+8b0nRQRwuQDQBYirQ1tKQYrVVbQrD4vEKna3MzxieGN4MJ3y90GhtX5N/btsu/BE85EI+iWIhZZng8LVQLIGO37ASKPWqlibS+y7m67wFaF2xdJ6QEbJG4ztTsAtmFbTyR7Ex4YVZQ38p3tM6fLOHDeFQGtNNfCBUFrPNXGK2OVABxLj6Ns+6gHX4xM7QqCiDFCSRGJuBJjpun4AGtBRU33riV+TUqEd1pMCUOdG0lCPO7hmHA/OhI/p+Fg5g+Yw0ehDuxuCNEoQt3h/cL5AwYxMUE5hGXcJjDA8/dMzvDR1JpLnItkkmQkf8wCrkpMDT/Yza0FYpxhk/NaKN0WMrj+ihQRWWMc62WAHQJR+//N6QhwS/9Z1Um8wKQT1hHiTlHIZZYcYYZ2kGG3yG9XZY3s5Zw+zsNMrBT1Ot3Qr61EF2G5gOKe/zaNsH6QPlxbIowWQuLPs3ZFz00WUIiwSRuC6HBOE/Jj7220OBG9XM26kUUNJzKFcAgYJNlT4jNZQs0vs0xfjKCKFMOGoHqXNLjZ33bq57KGOjIr1Vxzxh9rJhWNFnEbvNyHoidiNHJEe9VtIUzZiEN3J7aJvKeWmUd8Y7xYxYkVVPBYkH3BD/IKwg1x4veHsf4AOG/w9Ns6r0oWBkxJrhxEviWFO8+luj6k/EH8lfXzrmt9/GwjnubAMrjvrwMGHHaF+jjzjhZXE/wW9NXGj+2Gdv4gUWtbCVPM7ArMuh0VDLbGlON0Trt4plJolo0N53fMi63X7s2G/Xt2W/fOvEF2rzDtkQvwkn68Rddc02beC6F3UdeyHWXJEPMiqRO0wuc4fd0sQZJ51F/z/+6PiLT/sxLDKkAJyXMnXLnjsxHxsgRh47U13z0YOU2Qzced54Nw7nIKOOPRV35lxqv2aLOWVkQAOjpQ3mqPEuyZDWdnCW1Po6gBaInDDc0zZ98dEfpXb0SfJPt8waY72jNVVJ6FLk7kP81hCIIse4zjOlsOs3PkjYlDVFOb8QVTs4TzIkwzXJV8iVuPP4YX3BuXLdIRcsklNqfLFneu9W89yrn8tZTQ0tGpCBOyEuKR96eoyD6z97jyPR3HBLB7G3EsjEjwmC4Cj+qf8GN0v46+PFlq534/g9npxPftAh69VA7sWO7Lns2Lj4+6kytejwT1G/W7w/itb9H4SdaalIWuBDxHbmlK65C5Fg8OJGZp38tn/mHwvWBJn97HgNrwY1JD/dB0cWpkgoAAuk3Qmr/1rlmsoxzT8PVMk5sO1uYQvvO3W3Wp467PiTA/mxYQrmoqXnO4NZyU/VQY+DgLeHX1M+Rdv6rMGtnbI1KMaV1izdyq3kc62h1NqpQ8/hFiyP+gIu9SOK8SfumR8P6+u8v6tdguNiYpXZ9m9Orkm+Zzi3clKSCl2VzwxdLvLH4Klh2cj8AMuI6pd3+lAqZYxkM1lmuS3i5CHXDU5zyPUKg/bTdjWtUCJprJ66MfRTOUcjCYI3cG59YzmoM4BuJ4RUJTwyaqkAJXPpk0JnPfV5JkskkWXtKMIq27b2rBgxAlaoHla/yIi7LTEuheuIvX3DeIWRa8KfBmv51nykJ6C5B9n9ykTqaPO+eq8n3rNSkU3rSQ3lLHB+l9zzrGS/pd6LzEe3t6u9BBIfJ9Q8jInCK0lqU8q6OWgzOx0qYHn9wdKuLf3jtJ6Ff3DHMaD89WLgeYFuIn7jVC8DOXiSRHeIcpE0UZIOpTJD+ntZrLgGLGX8G6nQxfrlM+Pkcli2Tpe3GX9VZfpfz7Ofr2G+5k0/L+0EfIOf6ThP/rYxJAcmimvCzCZafegDW7FSiunu3oV4J6G1PcdlvKYWqscdNyLqcK5xg44d/3+ZPKuYG5az6khO74FYJx/wwln10bK/9/hUrNWc/XLjtIGMNhuereqogliFX8JuQbLLcsrKh4dV28OSrESfHnIx6ExmcYdY4n9Y5q5+19Cz6AJltWL6nU0XbpcC565X++HyOi4qGxg2mLoq8U1WwO2+/h3hxOF5bU8YMgam+dAZ927zioe0Gom4T+QypwF2ywoiknn5k1t0TildZbnEg7xYo5v5A9a+DhmvuDCAcs+1yv7fL+9vUWmxjsdmghr7xtRTZ6fvEWvRf6RrVqm7eIinVzndEOIGoVu0VZ7z5X2zJcvfrvP2yomYdH7kuSyB/SxzIfX6NaDrkDC+O81uLO/f1+mqhT/ZaySD9MW25oQPUSfUcDHNXEU4qqMBhbH7xpJVxP9LQ0csJAmHPpmXbWqi4u3F6QnOp63ROhs9c8Kpi35n4Xh9oq7GPxqzg8E/kNY78xVcE6u82ImFNTdYixi+rfnVhNVKGnJ1l7De+pxd5HUN1xbOUG8g6mVslzi9gnFANxunkKP3/CR5/7stOHcYQyKkLmEZ2NQ5V9z52I5AkUQM9IqrdofGFPQs4uPPtrQ86S1pfZNkoolee+A8ubWdHfIbTPGVqiiSOc8mVT8mfKG/j9n9nNFR2tde2r+v1Nb0ZJN/OPm9van21nvbz/zq/vC30kejX/fvJc6wea7xoFdd305/kT5rwLdSRU8xR7pVAWMYEuBZdEguN6z2lzvtCctF/p/v9r8U9rNUkcqa8JKtprf0z7MYMp8oPVmH0vED/6zbt03fYhvKPUcuvvQ7f/PV699aCjkCXwXrDN39oOidaSQWnXj+y8NqfNFiE1YLZwLhTF34t3/jPXwkxLsz+RjeSmQWu9e6uPeqIB7UE19p3EVuu+5doNV/OOTws1po8InvTX51IkqHOZ8w6DL1n8p3hqPLmt7jHqcyBlptf+l5g8x9YO0JC1bucRwa7XAIMtsqo4v54sXvput2+YclexH1QzQRolM+MvZsvWynn3Csg+H0RNBfv/rS4VZqrvmJFAScsrr6jEmtztpnOk4U9tUup/PoZh7zSfzIitHhZ+a5JcOFMxHDKffUHuuMeWZPfdJCFuxjPC7d1iSozdIg+9AVd4oYEeaQN+2BfKBw25f2jeT39JNbD6HmNU7I0MTtPfnNWevDxe3PmSXpbLFTOgvVUqivRm5rKfE79W9c1YlrjKmoPjKSNVS7meBlvirVJfMqRbZ0IijkHIfchB15Z7NSEvxoz4iukzgPnkVhTKqSJjWxnBp/PvRHf7xIQc6iMC+tS0p6wVm8TIYIOkv5HGXilIlf8aQSN3vA6wnHFzgnjqH6cd6Wr5DYWbK4fyGN/uFsyv/0cIE9+Q1WXDOVwDYrc+3lPO+9FUKDZSmqnaFQ7SfCa0iZU+wCEfoUu5+go4TkSO7DXGaYkDTxpHSXAFN43+JHQ/ND1kceKrOjH+VmTemdGJOekIpnJWxoiZeJtyKULWaBiDdNwSoTVLLXlEV6RSjXkfLNuwvXUObaxPq9gPra2ysZ+Cpau02mqTxJfM8UFj2Fb1rzdB3FfWFE+qnIXSNX/VIcoX0LQSQU+xf2d/9gJW008pqDbP7enRyZx0u8uFrOFdA0nrmTm0qSEuIL9sMcehU5evEluIp4rD/Wv9BFf10ogVnQNtmoskaLH8HcP+bT13MPL1oz3O93LKIzMLOuWjPwEgPNftw3qCV9kdViL3uvkVW0ICzSkLelxRUU3j5Lz9aF39ZRjh+8iOHob/PTardD/q2uxmYszGIi12ZLGzpAm0lurtr5lHUmVYywsA+9+Eyy8E4xy10VSSntbAQTge/lYWmX/qRXrGmorne8NcbTtTOapnTvROZ/6aZjZJubG6om2BZTdn3DChXh6uOb4R2CmyBpQ22iEi6XGLOp+ZKq30B2VC3D8rjNJXVF2mFkk7B11qqsXZ65GeJuj9fa/lmmzCojOXTudeOkKOWlrpWIQYyQHGZN98IJLmV0i2TddNZH/rrtmIoSGBFfj9eqVK1kCo0gPjA7qWKV+KJn6w8zaTLU7PMtfN6SPDNJ15B0N8z8S9bJX/QITuMEPg5o/ivRpmXfw6nInhwDHRPdzHYP33iSft8IOmbYxrFHMV4Y8cfJEXZ8AUAG7BFCcpwvB5HG5Jd9dIt6G+Idmx8n5r1yYDNnZ2kdycQYGqwQh0n/aydHY+gjMqhHh3YACihshKOUwqjaisRv7etiIIHhhaV8PXeWMP7BXhpCsydDviXqv9TYIaE5QY2UdQrw6SFx1UmdifW9T24VkXadZ5vSKvHqiKgv++Jr5kYJf97alJRShXmX8zcgiYmM0maNAi1d0JmdUbnBFJ7QpKbUMTEv9CnvBAI4ExhhQkzASI5WArjCkF+wAgCJFgdkyemkXZN0hSOtXI2o+JKnEoKck+1SXbSBkAt08c0ctBjb9slv+mlpfI/fyLG5HqghGQipWn8tuoAy4QvdveJhr6f7tGQcNiXRtvU+SzpyRudq8nZoWrQx9ygtr7IKFl9j8N2HfER5K+8RoQAV+EIseSlEoj4XVuGa7DzMZGlZtidSlBWpXOmINBK1ACmAqxLP2e1IXDzJn5RzUl5UqjvyklbcIYqDCYzHDx0UsQoui0+wO52pRO30rPRVYulwlLgS6lWT3kr0vDW1Oo/Rksv9SyNY8HcumcLayxvPPCGiJDCoQ9PDY3J4bm/b7/9Z+1CKjDqrAZ1fdQPOlibXvAw7OpOHrCw8kAC1vlGMaRrGOHsEoG++CF+/OIym4SeBjNepzjEORmuWJN/WAe+T2RFZ+QiySWazQLzMqySXAwcOtexFsFUwaqIFF5qKBVMijekuL4BTUW7pcn2h3uNN1tzI2Ca64m56qHB/lD4NoKKV7ej6COzFXkO+NMwyUPBB/KamD8TYJPvXWIX7ec+2MLvArnnV6xpPWagiCCcn5n1qHhyHTd27U7KJEPYhozemIAMuRfwRND9G7bMGZElL0JU4qBnH22I9ehLDRHUE2SOEJBHItcufu/5uxKW0Beh7Zy2Bl1NnyB2AdvD7s2quFbsu74tEQa2QS2byXFNDcgLjiSoYdsNfxLoCM7w41yXEmPIz0k0uUDX1fsLlrD3Zx+EmmqUgLXWgQpvfs28iR0bh5ruJ6z1oynEmfWYdnO0/siLj/pP8ZDMlCAnFIztIIlhXfcuhFwtYWLLWbexTyh5OM/aiJgiGR+frXgQhw7eZIhkSm+SdLcX6sREus7XnPema/uFJvTfup6xHU3SrE0Ctmg+m2Aks2K7lv3Pfa/u60XCq2S2ZFTftFClGNDguEWM8vYPBmGKXlRTOvbIU0YYU97Bk324bk9YH2QvjuPNSV2TM2JsIqbKJL3gaH47gNtjCEhYI1FSDid0d8Uea9xYHGVBC/VXj6H2TaxFJW8oUh7qAAjtsDB2bPN6lnqbl6KLuqwGEAUxwbXk3ywe3or3s+JolRW2ioSIPxKGVSmNmtcsl33BWNMhmbWbKbjRQKENsYJRPIAZZlhwTZ6yPVNoCnYTbUa8cHrUvHtGbrtkBtT0ZW6jXPK8FSvbNjD6m5QTlG8QMiPtXgcagDFWfTi2TndaFqlSnzKcmiMm64+jgrxo9BCqedTVqBTle9cQzVDQ9jbKk95WIhXiMBEftElRi7zFkk+q2Lzhvxyo6UQNkLkTxKJXFKzDMoT/Yn7/OKx6OeIf4Nx7WhRQH9cF5c8W69e3WpO4NiDAuLt/FXgXvHM0Rzt9YJ3larN0sGkTJYsEiSghkd+vtb27savS8A9PervBknfJdzu/xTJiBf7p8E6Wli0M4Ahpn9YllvBcFetYmNfxtlClxi7JNZn2cuULppQmqtT3DiOHzmRz4cLxT3h/SRw3Sp+lHOmsufiiR8tGTt1Hzl7vkahTC61S+NvLH3C2f959Xs91OomDB2ABJaf2dqbPRfTo6vp9283E0IbsuSZe5xFnO673f1t0IFQahn0nEJO+FEVT7qv+uWVy+3FhdvwMyGzOviylZYA8AnISnb/N4YiVEDI5nhE5AwzQfgq/IPUi+TQOL8WlJ+YsipuMgy2JvhoEY3HBUMKYRr/3tR75F8XWlWWQfp1+YZb95QuyWKvlo5SWf8aFp/Syj02BSduV/ssHGHmv/yqBFE+HkO3wn4ek65bd50vEP1O4Fwsx3JWE19XLWSx4Twi9ekwWzLDh3DL6jXB9azpEyHuL5LuObnD/QeB7jZeuZhnanlHUlKZOD1r2m4x14keicqs3a1McG7UxZ50WvxdLL+mCrtYe2AA4xOxIYv+7yMp+R8bBh1fe6GzhfpkCC+3+/N/9UNsWK3l87FVKb5VnX1DKj/MvyTiUM5gU6PhYl9zrelKuJDFwm51XcUzU8Q9obvoZWXN4ZxZSHq+aYEIIMls/4wPHz83LZHscs6dS9R4fvjYxnwakRlJWEn2UZSQzfz3kADTKlLNV5YfB1Rnz3fmbxK0u7NhRUme2xYxkL8Cmf4/WQOAS96/JnNa7WufTBeWsKnNdBToFgNRT+kwD7QhXYLMeUVxETt5oj7S/QED8UUvtwc8vuzxX88uzWmPGJ8Tv3eqg3F1hvuu5nHnEhDxueYhJHeKRQAf28/0c2m7CB7fKUN3xNkJcRhHu9fg2dYHiS4xf2hj691LTUNs/ga6sazPEzDywhr5gbljLv70VcXc+H8H/5zX7tTBbGxtrkplRxu+chpavERC4WUZOi/4qg5nrkuN/ulk8rkBPFt/OqfFNFta7N5vYCl/e8+Z/Mgixc/br4oBY/MhdxFOVj9lYxIm4/9SfbPnRvWxBdhnVl5h7fNuIV1xjTYgn2XKdMWvouBgM4N4yeZBg0UXPNCBNxjGD732i4NrnMLyr5NqebtAXEIMD2x5m5PaEpy+3R+kTgy/GtNKqO8P6wH7FZOE8Fu8S34LS2hM6dMkLdkk1EdakOKYuQ8v61+7oY+ceSnees7yfZeD8fYfZTep6WLykC+IyyDrmn2S0S+pqy2CsJCNh1/hvmOL8wHJ4OawOcRzhLcWvY4uucpyCqsuZZm42bo5LkET4t7uXoLhpJtzMQkWrJmJMyNpRK6KN2Lmk9lQoX9CreNaoFg7/FRxJTD993+Vt19zZi6b/F4Dvxqg7uVRl9LdXQp+Rf3mxqeXbjpx+JqBofGGTRgVf2vZJO6F3yjOKA2lBDDwb6RG1b35lXVcmEYUYtakaZQ3xn9VQUof2grLOSnmr1ovitwcxB/HS2SEUpm7LJqvXVPWoEcOKjtodCNXuP7g72Q/dBeAtDxz/U0UJZvXE3QSrwQ1HMTpkhQZz++C9fRzHQgHYphEqwOtn0BvWDPSnhbLzW3t/uaNa21sq2dD6O2rdiwdGdcdqpKwWTr1jZypVs8z1vw6moA8XjYNWmtPnyYFgmwccirr/5Tvq/UZ/kRgLwKsVdSaXE3AcemfB7RyR5z/aaK1VaXO/Zz0CTy5huYguvSEYa4zZfeengCQbP+7qT+edF7z3rig4tOJEKGxGGyxJOT+7C+GuTmXPUCqaN5H32i8HgsviIIVdTodXxl4xf9H/+uCf2kITIptnKdQ8p77Lo8bfHeztDcuO00FYnCZmch0455cF+I8d4XOwOtNLitherAyORU/ToefBDQUNrQ2Ar/ccid+OtwYTqYUISKq8RzJXOMGQ7570HLL/L6QZVG7KOXa7Fmd7SkwqfYhsfWN46NgUIyZpURXOJw8c3lwu5ehTTvr/VLFci0jbcYwIThzJ4rlE1jYQT8O2L//ZfR95f8B5eDs9m84w8mwTjDnlUsj/rrCxgAQaMErNcn0nQ5RecmLQ3Tox+bVYY8YIkfMkPbIGPDe1VQwk2Z075K28f6Tqldwd6fbQfsrwoXpN1jeYfqGKfmfB929nwcv+no4PCgSJOKW7jpl/8zx73jmddNpJ5kjT6ZVXnLJwJJmGHxikNSiyBFyOSiFPANZK+WGKqJIySLIT2OKlxxTEnskiSSKG1Rzzl/JC3PvF00Ctcs8wN+gX2aPQs3UlAn3NpITZpFH9O1qtBkl6q2DwGrj8ds72n8yUEqSr5HIYVBb2w3/3D1VydFkKuH7ng1IFXYR87udrztd4Yxk20JxSsYzhA+zGu+AOoLom11Qp9641CZkOizuIWhBZpvhV8O7wvmX7SdoRjMUruwPJ+CPLwXLdvFX2+AFUDpuOQa9r5e8khCrsxYZe4EneCe+hofNROV4PmIg9W2ZvJyBe5ErxUCd7BexKVAKzEVu6YCy/kfFWWj7vqpPp2NbaU2P/LxOqNPuZGZkQRFcz/WB1D/5NdiL31V852E+5jUfPBWxauQnW1uyUIVqb5mVyNuEGoYAkJ/lZ7PLTAwjS/l9sXAOL0rrhdIR1E6suQfZDAvJmj/5kPz9kMmktsDx1KwlvD5A6ACD94MENGmOud+W/neoYYzKlf2h7N5d7MzQYT+9k30Ynj8NlT+dBqboklDagWgs+pNFTjtxNAK6E/D0hRsVNvI36yFczng6s7RnIxBBas1iDHPnojNVihV/Icij5IOssYcnoqQRM8NIafBFR7vBAPLQJUeZyD86XEhFOsxw9+uKZX6VqmKMDlAVbnkO7sLH7XH+TZ9dwdUe657JXQtJ9l54aVJdbI1V9wvtEbZ2v/koACqd4okQ7Bj2cCgDPwQvx4fpeLLTC7nruUgAUkloRQh9xMnmZZHonu1SpMYZXa8bmWRPFgl21/MT5eWTBqAbjr/2WOFVGJcJcbo9Pst/9y8P8dfbw64XI9ELDFUO6FBWM/txisB6AiyMZIshVa9cdcI4t0+ylOUw7jCisQmx727OWMU95NTg+Y1cvXyw412v6SSw1ciK1QD6GprsmiKMbmcnhcRrNIfv2F+LwlpTWrhNlFgd/X9iNf8ZOmNCJGkWAfjfU6Hx18OyqyY1e5kiuS3XiY1+Ak38o2KPQzvUCwpzwJYBmhxNMmjaWWatavQfwHTjHNaX2BjGAwGGfLiyy8c42vK8u8FCV3VR6Qa700bvzaO/zek9ycUQeypzPKcUGIyd4PK2ZxI21dSeR/7tFlMAtuqrIap1BB2BKMDsxbYKRf4df1Zv5aLBNMPiKSU2L4tag/BGBDXZJfE2BeSX3suluYX/ehjklBoUGq+u/Ta2t86Sv86bHRAqZX5PrOpjHuGHDc+NM4mv3lyL5GqfxyXM3m55c3+XXOH2hcdvxKdSOoehWFYiLb6IoMKDCzn1zbnIyseXqwJkvXkpVlhO8vzB/l7KMedSAck5+qtAKyRiGqqNoF7w0nBWu48qxMHRXKirJN2t3OpWIy6w+Q5UgnLXydRLqM1yj9f3TVOs/fnKooBXtSKwfFtSl5qhrFsMNrS0cr9rKjWHX8o8v3Qhy+RMWNzZ8fyXFe4dExY/TD5OI5KG4wuk7o0J8awsvTjqD4tnm6ove3Qbao/vA1I9kUP2CcaH+hmYwh7J9u6VBwoMOTPnEZhZnWxhGJgSICCew2Qp04ScEG2G8Z9JVH02Qftf3YyHDZxgslPlbjHBehJ6xWI6TweFvXrE5SePB37pBhgtJ8KglqBjpNvE+GhGOQK6v+wW22HFqr+g+/Zah+ePDtZFSyLxi2xNpAWyvihTK+sZBG+OeXSNyzg0mLjShdZ+Sqmtu5YSy/5cnbStph2U1zsmbtcGztmRk0Ggh+8uuvGiDJYJPzBdOq1THXXjelsmmW7FxjNJqGWc4qMI4gdio2IeJJfO8QWcQAXhgG1I6k+VQIGzjz0YmxrbIrZV6qfcrNa3KDqJscOC0PtbhOzDg27IeinzwZ9iWhbkAoBZ2/TNpQbkayNJbWptQN3/rALTEHAxi6gxB0yvpwMCtCi5gzGPzW3ZfqFaINkmIucSLtslVVebtQphZKV6mCgaO26tDUJY9g9r1TCq/6e5abM6Vtxu9z431r4IebXETZQEla+hhhMqIxOTC1EFn0/bkxmBC6WOp9j7DSK6XebFvuzSvOQZdy3PDm+0KUNvHYHG/8Xj/5zjR95xs4GHpTRHENg0UypZ67TQrkDCP/n3CWhKpUjXJ7SMX9/tPtLWPxSHu0P68OsBlTWAywjyuV0lSaWGpsAOo7vvjzhn7SEo/HQulYa/fedhUtBciLoeK0jcO5Ki0rqs61q0mpXQMGomUNM8yRWNtxqzld9Z8uL/1Fl1mYxrffYC4t0Wyv6eRIPzrPya9Q7EEdKmR/DHhfgZRm3RBq+UI1/cm/zo7PFCLWKEqvBxoefmfZ5VfCW7YjpXhakl8RhPNloNR1sAGKKh0y664hjDAppqlo+wAGc19oiGAhK0pNnmxxHTUGQ8vVNitajsJvNlX+ehFOkvOYa6M+MhIrZAzjtXaju/FQW49LftZD9WcbJIdMQoxLnNH31zb9avNyoDVVwUV879NJXTWeHH3t5xcBVHlyMDIhyQviDMHZPh+MdQttIEdqwcSCHaZEFyQpOBwLnV5POmJk2xIJvVM7hYSRi461RqZjH0qjzEsXQ7CH5TPad3/YCGLPOqDCJvVEJbGNIOG57KuNB6jPCe3p3x6PBRLpmX+a0ooRFFMqGjGm7/EnXNaKorbwp01uWPAPLPMav8tu9hwDsMCxbS0Iq4JpSYpp4f6G+9jl2wbf02DNXrGhdLDvNx8/Ymx/rYG9AfN9+VJ56np3wnXLtPgIUT9979wy/iQouzcWr7hSqL/4ZIOUkhbnKb6MZ8fhZgqbLsfOqFQOFBGqQLSAitIW8Wc7xFPl70921qPP3uvyvtR4Z8suBZ2YArH33Zmf7YpsBr5xKZD/xptlxdsRYUO+AsdH1SYUFNv2WdZ/C7wu55bxh0/A1S/8QWqOjV5okFK04DyR55G8E4Nf8EybY2c8a/ZkD8+xicaTLIw+2y4+nN1x99TqQ/3IekurDz0+l7zlDv/safl67OFz/vy33ilWfEtElutif4YmFYfxPzf0f8H6T52rGxzTSo+UPE9gUWevKbZj5u2TbEUz9shFitcxvAVv1hx9skFOiqAzFtMpnK1MoM4wrRwd4oaigrIgvmfVnSpTT3TE70Ths4Ay/Q0dNWhYC+bufPu3UfcnhD2EmxkjmEX3IIRVQZXYRYRJ0bgh7jHqC/J7ZWOID+waWZ9vNlb6lpL0p99Fp8Sx8+JtX28aqad/s7s8ufTOi8+622QPa0nJ+sLI+5aUESFVFK+rJ5k1S8vKxjX5ZvzlrsuQswWrHD+SlYe0gDPyfmJVFbhWOegZma/lwRt9fyEmN1z3yd+Ebebb85umkxhTB7lUAA3GaIQulSmoYE+99PdjT39rddxhYMFXhkkIGnGwmzZk4NJXnRx7q9mkFbh7Zr++rL2T3jhZELAwkRsIuAaDNEwf5ECl+fSnvpF68Oqu+AM+VjFBhPzbdjeQCVP3qa9YefbF5hAt04vv3vdXtAwqP/Dfe+G5oAP3svCWCbk1p2L63rQATHjDH+D1tPpdXy4RCusQih3+QfP5pQNWgHs5uGvS3BVnB4+ACR8k4K7Rz0fT0pGgnWWaDu8rLiUl13Hs5Rwgi2BcvWwVn0LvFqaZS5bQKL5SujjOmQMvskRQi5i4B63jC5Kfe77UlZBL5hqxy5rrfY88D4Wgc5BMXETTRJAs3CjmeUZSotgsqkSvQgo/iwY7T2MAIIe/eiLBwM/N6NAdI51c9RDeqRI3r7jLbKCHd6Tjfs6SNKyCs2pfrq1W4L4NoxHSPx97VfzET4d//xer7y3SQRblp1wFhHxGsxHeY/rnpZpNMOUulO4puLspZ95kle6uVIDzznQwplph5e3e97zHnrvluo9ct+JPei4bUbOrPrRch8ll7ETpVZ6v6zKF1E+ze5IgfZSYE366ySz/nmAHS+w3yyYbkf4tovt5fYMJ76N3HejzZ9sP2u8AzGIOMXzFuV23nQbEzY0sdo5lteOCEH9Kz1403uyOxYca22TxzT4jc1qOE1t6RLIk0L2rTvkZqpfV8fdvLGa0pcT1UXSOFu8QeJYONrW+i/b63jNn5N8tUeK0PKOCkYDlHr2vrikHXjho7PnFs72R7SOfuWym1ynT4nXSXAC/hZm3F3p3sH8zcreNaS+BWU2yVGM567nZWm+hDR0dvzeK5+VwrhVuo3Fq5vWZWHU0LysZNoLhrGk/kycWFtYp4o5SiO5uf+zOc+f1x9eSc6Y0pViOYKjWu9ngciJUETwHXEf/Ie2yL7WCy0jmBHlfCOYrd/jCp3NqlVWDLjMBxcTt4P5vBlb7XMzt4hGFKJj/sfUIOoWksWAshSpftNNNuI3FHfTyCMlAtTnYEoBlaXWi8oYrGMFOkL/VEw+VWYKAczu0z1zPzYBhvyDpcl9G3AeJfzHHKnS6bucv5JZpc4ktoaMt8MVhUoshUOGLBzM8KLj+6AHyskstuseyRFYCUM8c7Fln0wmLtBB0mSFQ3grZ/yJp6RbVxaPyPQSpv2JWBXyA/AVjOZ77gjMyDg9EWOT3bDwLtdVoSwCWhcJMbkkYSld9kAv9yZraYu/M5gZFeGMGcD3UIaQk9w+lGRn6l+gL8dDBnmj4+bbmcGMwNIS/P/JYX3iIfysvGeJPE3822H+br2PSX6tTxEfVivvI4zrZt+TEgIqPysBasHeLzJmkErHLGGP+2hc6j3UCuWTamEiRaAQ9oUT8uxnYz3hZsfqUd9ar1es2fQ6tl3/2gvdn6dzUNci3jUaA73Yy4769Adog7hCnVfDUw1pVNNlRYnQJEnOjcQLAN3V/xR99S4N7PLAaJZhGfklOEpdIFZSqKlmWyMgK7Z5bKLHD+HAa2aQpHMEIVd40AbPfTyUvGWNqO2vYSUvipvcQ+I7reH18icVvUjwrBUyycklnQT7HuDRYkkJ6UsWMCvn9v+4PVjiv8vL8FBGPH0+UsXa1cpHl920XgSEntJHFMRK11var7caWxXbacbY92m10gvCdzj1wJH3ZLU0o8ne4bijlZ0j0eoklpYQbvYD101rv1Kq4QVsRaZG+t2mumeYE39o36XeS78/7MoVqG9pm7+dFE76KnyDzW12Oyuuy0ynLD0eCBIyCmHsYzpIqW9S2TXsJ198ikl0ybbKqnDHbCSzkFUJrjYDgHlb0UNLWv0MqBFWjWPQvMEw7SntJEdLvVRHH5uzjrY8vZwnxU2yRPWrXNgBaa0xMk7fsXV6vE9sTPi7FxBt1LYqk9mO76vzuHSFMCWbzRxVfWcXcRNOT+YIovjcCk/ADNrdCiUb4PXW0ClWm6SP7UkL61vx7xh98Trn6/B+OidmFHYNRw40j8V43M4S8R7X+KoeoQDa3Fr0H8sPurSl8eTvUNh+6ArfRz7PVh98QYWQPhnkxBvBPb2j/J1T/yuLus619/W8UPxkTUEOghKG28SE/YJhL8fMMnEPf2s1+JhOrEtjJyT4j/qHBXbu2Km8vNwEsQPx4OpQNVPH8L/JnUloCwAMWWBri1vU39fe6BgRh3ARIwn0GfBfMljcy4wyQmHDPGpux9HNEW0yoCfvqvxX1PdtddDRbWkajyzAUm0dLsmjPPLl3RJ7E/J8dDsOt0Ge/JLeiY/RJG27TqTOXk5T3zmOS6CeAxeEWLVV3a8758EoS9LFzBZVVTVnXb2GgIVfni/G6iE9w/iASzDntYnG5tnKPS6m3Lqkd08qzakPKAH/iebiZqIx6SM0kies82RJdL/vNDyMmpuy+lS2WKE6l4SS162+4J9327kjYAKeCXjykRnWALMC2tn5jy31cNFoap5FdQnaRnDbgC7LPCkEy1MSYRLF5mf9ZiEIlcED/C8m2Ez2xac9c57O2k/ssO01//1w4FM3K7lDtt0LarLIh97sgnhyYhK6/p2JxLHkSbyS4X9/5yxHWwdkb0cfoi8fJe+mhVZq4D+JCiThRk0z6IjRJ60JKVZQFZZIf5UX3XR+pVcHWct/CnpEYc3BLGwHUt3j261aScOFPjcCDOvemZYKS96Na3FM6BO58MV23006HmAy+aLjQ2dvFwBsBw/8ODDArH4Va+oDt8qLzwuSrfIHyVfyHY9e4PSH79He/Sv3gw5NINJfl/FAkGr2Ff8+xEWdN5ULWKwpHo93yiyYK51JnEK18v6M8Wv2RloYGYEEnmX+t67sG8D/tUP68I8vnxA+KZep8g/HoN1+h7xYmJZMgFl6YydPhrMKMEc0u98AYe2ZNcvyD6n6JHIxbundtZm2aGcyl7Krgv3oQMWp34g0HHyfvSr0zCc8dp78k9J/78DJl/sa54iejE6ebob7xoB8wRk8vMPgqwT/Zzf6j/201GwTbiH9gcL3By6O7hTNr2k3IjqUjx/uZX/3DmR7tlLaUBIGpV98wbvQOMOuY4gRvt3zean4z3UVDy123sr863UGVIHDozNcNTKSL50n40rpwf3NQUbY/LSzQ0JV5ToFlr2z3XW5mbBhtG0XmqS6zTTvFCH+Ksfej85dy7Dwfv8bJTnRpPGn4pG9CfCcwwaEeBPtC2IjpWpc08qWtzm7qxwk0oXXEX/+xoVYDgb24/tOWpp819imQf7yQ7cSklSSc/P/sip6ODuLPrmhwOjN/+6EC93PpNVx+XHi/oJ3KjCloMESqSDbKHbR9VHQielHG6z68TLRxXSiwooj1q/B2fM4XzkbSExk0yEMrURCCN1Srl4GE5Of2Cm7SoT/u9SRA+Qe5FU/pajTU/YVuEAR0QrauhR7Rwz25Ztl/aSHk+ovpSJIs/skonJHl5z99Q7uK+rVV7CK2w2I/CYUKwTM9u0TGrIxEhyAGFSfqw9RcVYe75W/2RhmHu4owgCA2qAl9CtuOLnsrjzNkQC1eFyf15ju7tpAlyrRtfmYJMWgURKuL/JnARSzelgQw4BdUeUEO99HrFAX/16j0qeRnq+IbIz7BjAeR8N5ycXmXK9Av1l/iU/Iz2xuC3vnjqsWhih22y0c+Y1kVb38v87bfz9vF9zh8knfVu5+yJ95G53hLLob2I9xI93hr4h25rA9ukb7u6PZHrIu3cJ63RUyfOvSQpfjTCztPUeUvt9wuJW5kbpATY9FDpmvxVOCol3PfefQvo98/0Kq3AxFEYvCpsxcsPlCgHWI2awHQ4yPw0dBokAvohmd2iQMSIi3xUoS8n8YmPuFRb6Qic2tlwy14YiwUKzWgjHApqKaimy3bsYz1pPggbb9dJ/Ch2bZVo1qck724P6Iek907EO6BZtt+SeWV4T1EyYT9fmi23d6BqpKU7Nt9+hEdvGeLRy1KR/Gq2R5NOxrYiFp3g+HzEcBs3dLckoAJsyXz88fOY80hiIm/BSPhz8qCQ6vXYAy2AIwNZd2AHpNFIIqx2zgP8ibgvg9EukUvi4ZDEKE13T3qwogpMRXcitFY2ESyovL2s4WgKaLYebhFXnWSoC9lMdwf2Oavwq0oGz/xSkzJ37Ld9C3b2TDsQKTGegTP3xQ1XhYJo+shrD1QQ8tkDQDZ3+AAWoCxanyT9ugVdcVHY9k0JRV69IGg8BVycIR2LBB9HwU7aU2noyMhOfMhVGSFPNaK2Kr6oaYLiGFwrfe9Ch1JU4R82ljTjcWAuvF+/yKBC+vOOKL5L72zvL5EY+RKfgHo1gddiEq0GtMCAFBRG5H3GBaFyvw8fPzKWdWXJy03STyNJt/sXPcYGVrNbsyjfKvlJUhjlA6uW8nLi2KQZzCP1j0lSGtULqzz2EQjpZ9W2klFay7BFoYq/LR3lTvbnqL8fgvJQiFx+qF1oIyJ+73zNyAu5FsOEI6WYA6ph6ON2mgnFcVL8iVvbYeNAu0Mi7y4RZL7d7RRIiZHYMYdlKy7sPNbZzm4ui7ZAisbZ7wyRN6tWwAzr833d9AGoxr0lpFY25WkJ/3aWrdoAxUYEg3jFmiDIfHaaIXUUDTroh6WjRX53RJV6qh0XPQ8n8ZdnEb6OjBqyIgUJS8pNNGZ5xlHLHE5Ed4Vu5fRhNQvo8l0VG9WtBkwjyb8jIHm+0LkxlXvdQW3W92ps0nqJF1Q0nXIgetvnTXh94bvN1n0Xd+AAbeTx7v1RtZv87yZifn0ZseuviSOINj8b2zJGOMHER6vn/Tdw8iI/69BvM+ANJibFy3PsMbGQKmMYaoJH73IE59Ijt7klj2ikZSR9oHjA3D4CRz7Mk6LGCcHLKiGeaqE0kM44gMgBkDDwNjD8kOZcOwN06OxIAxj+sCcfvzDemChbigKYJAsgfPHs2UMyEcZp3X56UlQtoTjCfng+czwViw8h5newHjbw0EAg5Bs5C3QDZjauCXJgms45v6UR+6K2AGYr/cdPp1GT4mqYN2TQ5F1eow+kgPA2t9Q06L0q+T5O/fbvCPzGybbPfe82JJZueW4tNo6GTUtKeYnzBv4cRKVMJY/daflY4X8YHp8sCJxlhQb/UyD5NiaCePVga18go3AVs9zFy3+jQrn6XSe8wx/dnHkNsHf9BZz/Y3Ul6oumhi2Yp8n1sNf9DAD9kinunMrFkTxq8hhHLdhDq+AoyTMVkYBaF21DqyTnacqsPc66gBZY9jWamzN2mCpgUOyYgi9JY7uoPe03Yon4+gCUxvBeEcEO5JhGNYojyTs3NjGlZ5yi5QfTduVRas/MD0dC9nD1EqYpQc2uols1EVsa3h5KtbekC+ccpTSOdi51j6I72d0g7Ct6bO7XnyhLRYyASYna0Q0aVVr88tTxPpN45jpOaH5DIOLpf7bKZH1L9ECOGSDOR9SZBrzyWdVUZCtBqDP4BgY7OuGIrFAYBKMCWyC9GB/un5v14wj28EiMnNC2aRHfTLk6BJZpwMtbswy+pJsdKZQkN+h6vL9qNbmM2JET/fxq/ADyAwzGLUExm/EK8F8CNAFyHZG6dBvR7jmB4Qurgj08EYyjqDLGNPBiCt0MaaMHvOoo485X1HoiMWASTJjyBAtZ4QA7WDMcL0rU80lQR11090EcSODMHQvAmOrkGzy58tgdBhey+gysnbRw7sC6bOo3qBgdtYM2NFNYsiULp6RLLvqz5hZvc72dxFV/itiHYDXGapKNJ2pWGjAKq+B2WQMB0FAfjxCYmjz24ORnGgP1aOxHRx4iotQmTLPHZNKCZ611ErKYqKQ5IMeey0hUeNDDKYcDolSUp7pELmuezMd2OezeVDsWsKSCchRPYOQvwSkt3nNcsUVQwcg2CB5E6oT0/apMq2w14lN161Z46wk2hKCxIb80fDFa8x1agDYlNf1DoVWGqp/QdxWM9ZxceCScjYHiiEsSDY+xzmcW9wMiQ759ap5QcBp88LjYqf5Dh9TiVRBU548FmhjOsA/1zCagCpw8RrFhuaM2qH4APsnuDZiGubEeIOHmyaRvojhK2ib/KB44hYXnI/IOZZ9A2EUqdJbgh7w0kdTCq8A1xcKSJgFcfpnaR3lW0TRCOntUy5kbupHZh2u4dr+GjHYtCB2hR50aigg7E8R942xIwYGeB/h1DQAQQuT4DyKOEsBkPjpen5IeHuVyRviuUA7MDHnrfTeQhGalD5tmUdyupjfEF9UI3Qa9XQnMzeNpnBhy26nN55bzA+8ngqS3rxN4aeY32DEukkOWBGrE2SLhNBc29XTo5THpoZ34rl9zbBFCYIprmkNF19EKn6kh7DIOBHN07Hzx2sW1nTl1GAunqasx2TmIHo0daXJR4Gf/gfD8D3w5/pReM1MEWYWsa28d5nMFqvb4/Uhc0No3Vz+hdY3X72D7WaRBLonly+kf5DSxno+k8XmcHl8AUFStFAklkhlcgARVihVao1Wp29uO3kwmswWq83ucLrcHi8QBIZAYXAEEoXGYHF4ApFEplBpdAaTxeZweXxBobi4clSZvCjvqdS9NuMR6cZitwvOOLFJ2+7pcnu8Pj9/MWLFiUcU574kyXenSY9NWipAE6c65TRUOX/tJZcJZcuRK0/KBQoVK1GalatQSaRKtauuue4GsRq16tRrqDSxP8/jR26DEIygGE6QFM2wYolUhltOEaOWY1vEcuT4d45y1khXSMdV2ljPByiGU2l0fh06YzdWriJdls910gKEJ2Vq4bOnFLUmjAuqRlqvSL0b4wpPLGI82/O/1psv5f94lOjS2qqQi5LavLa+QYBTo1b+6rp/1CqnmRPm7msbwZBA41HtqOI9rHHRbGty8s+OJ7YWfvM0Kx0209yKUsxvumgFLb8vLmlSVZycMgAAAA=="

/***/ }),

/***/ "./node_modules/base64-loader/index.js!./node_modules/scratch-render-fonts/src/Knewave.woff2":
/*!******************************************************************************************!*\
  !*** ./node_modules/base64-loader!./node_modules/scratch-render-fonts/src/Knewave.woff2 ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "d09GMgABAAAAAE5IAA0AAAAArnAAAE3tAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP0ZGVE0cBmAAhCoRCAqCuiSB7wgLgywAATYCJAOGVBODEgQgBYlRB4NZGz+GE24stseBIoz2EEW5IL3diGSLszH7vyRwMsbJxr2WR1gSQ4ghdGszM7RmZrRNJo4nHK6JD7zqCntYHvxGH2r1T6FQqfhgqbD0CI19kssdnp9b7/3/F9VsjI0cVQvYgBEDRkQpaSEGiNFYZ58ZaGNVn3f2eXqlPP//R6/7nJv1QeNZAcsMEgtoQKZOs3cWb0OdbRItUEFLj3/q79nZfQEF9KPMm4kTobDu//27VY/fqv2s96qknj5sog02vS0tGKa1s7M40cJihsnOWT7YlN34u/0LQutMFgXE0MkQ6WxIq8W7nOOGlODeAHADhtYeHeamaAlwhHRB0s4qV08Q09nPP8/997+pVgFX4AoCdLE7yyVt2/vcE70TNydVa1Oe4ONunkReyeN+AqBBm+oSKVKWuuUZy5aq5Fq5nyqkjoYLnY4bhBB8+7XLfyt4qaQoYq+Tt87UE7EKSa3a/E9NqeSLU1+3MiZrnrLYAZYc7CsqoCXE/vL6//uWbjzrK8tyhkeX5bu8s9zl9c85J7t7oYnygu4kZ+ky5YwxUOdEfX08sDSw3fheUSlu2ZgQFcBSNCEpooX//79vWvqjMCCcJgtsAsvit7a21n3nNlrAgUSa/eUJj+RpgH1wCzAMAwtbdCsibcET1MuwnLwcy2Vla0ZqHqVDDLEhpP3ZXfb0WrOaAHvJtfbqnwIYTsAEuduWmZEAABgDd5+mAzrzwsmXxddbNNYD0KpmJhyskzcXAM6N8eA5UywxBHEDtmQU2PTRtTQ/aW0DZrSdO+r/33NS9c8GQ8j2URBWPvIyYSnhANzFcFfCQjQwxuf5gJEDgGaUlVZbb6Mt+u20134/kzllM2xGzaw9vQ8vrlKslCvVSp0yQhmn3NSqVrN//oSVU1p+zrqae+xzOBlTynb1dmrvXBylUClVKoNJwz/inPXtL3/8x37kh3/wBz7wPd/9HS8rq9gi0/++/v/Sgs022WideabRPf70MQ2ii8GNYKthu8UKrwZwGwJqe/HbO5N766rUgJbtuOj5QRjFiVSVaq3eaLbanW6vPxiO4MwWqy0u3u5ISExyJqekprnSMzLdWdk5uXn5BYVFxSWlZeUVYOiwESPHTZoBAv+bKqn3c3Nw2C/evFkOq3rUvDV5e/pEdWNVNbho1kXd9aZaMPwNAADU2MHzyYKb1koA9gH1dy6BtocTd+w8fmJ75/mLStt/XL12dKyBC9enz2kdL9pHdY4Z2z16/ATQ+276VLD/Dzj48/DgY0fWAwCun/pq6OZFE/zIzEtH0J4ce6PRywVuGNnmoAh0IPTdFyPXQg1Q0/eoCrGjmZmvDKOb+a18QBlwGfn5MWb2jMV3T+iTO2OwzBzfdWZ5dzB3XsjKoN5HPjI5WhvqLvHVyt5j3zNfnaxSZ9Cfm54sPn8UviCfT49hUPlqbWKqHMFUPJ2BvXDJsDcgBy9QdkaPMwzyj7F521W595RRQ0ZHpr7o9p+NYNXanocI4maTs1LAe1HNWbwH9drRUFrcojXiNCDUmm0Yi7NOeqk/jExdUp88JGMVTptDucMXF+nhN5/BKt8lFxe4wFrHrt0QDOMC0887D1nbUblQ46HGQg1DTYYasEKNwzepNp6/YAtcAMvgBjPQAOoVmlIQLggTBAWRggBrULlOB/Iaq2ENaJ319A+Lcosyi6JFpUWBWpTDIJ3K5gH2YiY3mAnXaciuRtLUeckwBhnpTCSRzTi1P1dMoSr/5p6TGKDvJIqRHiZYBwi/8JQ7QkTg0FIsL6xS8f6sIC7Mh1Jp+SLOAQTG8T+u7V88/H0+xVI9zbKGnRNsxXH1IoDZBLHLB/DguqMOeuZYM/wNmSjErnP/qX+O3WHhr9EAsBvPaaYXmk5ngnAbtxHi0HKAfdwMn03YhOA/ahCVf039tZ5qaMT0fmc8RZiMS4Kvmx8KsOGbCT2Aks6FGbGKjhaoXkVEPWpatduFrLcSetRDnNxx4WmLqaLbM3TK0cnyO55+ynQg7/+KV+mpXoUyptdbMZoohxvSsOSTrot+6Us/GAN2xQeCoRbbTIpVOvI8kmrh5MJHfTFTz5YZlO/c+WnfKtGBAvtmrhDOKI9X7tvWAHBIilQ/cTRafe/QtiI+gCN46X/V5P8x4N+0vZ0OXSCcQ26gTwXHQz2+QNgt2IGkIsHfWO8jc9SMtn7RBZVT0ilgD0xxrJToMq/GJu4oNfhUgBGPkTf7nOER/Ueh+JdjEk+SCdaCbKN15o3g+6yJINC0noDVKn/IlqJrhai8zZsXkfHMdg8kmQK84UC+j627+kqEWaS/vmpSW2OqnqwlFdIBK9Lmf+BNqUF6hbpEs3OH31FjBGWGujraymi3KrRtM2qUdACivhZlUMesmItjV96aabrUim3b7QQtxdIErLhCAi5NbEM0pfPFeVMOucJPiSh+TRT2+QrTKmIHrhIp0Yju26/7PmiWnCNOLHM9+LXhLjeyff2x8dhSnY6cYOvN6BpRWYvfK+zFZfQ7zKqSBzwlYjUwYTUhAi5R1pAGv+2TNIqrO9XpZup1HZKP4fJ8xffSXIoacUGAJHn67yf1DoFYKX4tJqWc19tTLST5oEWclxyrPiQ4ec3j0lEDwQQP0UH8bHHxSJh420lSY701fq8z3SvAg0tiEQly2yogWnsTPdRHWq4ipY/vubA5uk1Pd5p1L5As9FRAwIqPBQbEZlAExSXJvXV0sbfKJZI5VlhVzlBG6eG1MAZaSyNs58/chfum61hK8PSDXXYbg0nShH6QbDyve9PPWUi6WrFtrULbth9NhNIYTbCFF5GTZ5uB2XK0BsgQrXJjiiMHBpKaK3Xc+4H4hQezKNMq0JydSiuawHFcFPIbCoIKZk63nj7gzTI0fznkxRsKwJqphwj3IKq22rvudlJ3WXEhOvcem71WIWyrAGM7/I+ocg7coCT+eLKPuBR9ibOLQkFw58vxQx6fWIV0IJfYVpZqulbr/ial2JdYli8syrseEN0J+0t+wIRB8JtUvwbsIxZmEdxFOSfNIhn3/9K2p4Yyc/ZzP2/df2KYU1h/ELyuJojUEEFMzzgCCEtHzCuhVTSqxIpWWEgwaFBGEMPlQAtb4YmlopBZJZ7ZciA/e+8rzlLjOFIf2TWd+cUz23c9ruAaRB/AS6Bijm32H5m6l3qFCtahKctQuonmlF6eyR8kxdPRRpJX1LppxaiG/Ts6EYuQTpLeM4/pc1M5Spda5THRB9gU3+fSVxOq/e/3KUfOKcf+njVqY6LTIZy0nfdt9+C6g0SSo53iaVVlLCQ656UsZLaRUn+5ju8rM/RW0PEd3KiOhLlA6xAeYl3UXwPRCw7VnBalAHZdY7hzwDTpemkZPZcLfv686I3FFiAMTvepYpXif7Zrc2kM2fVasRVd0KBeb0N6vSVtUbWoeREZBieyuX03E3DS5PknL+FldM4xQVcXC/tMT0XKydMNXyuUxFPkAWFzA/I7v/l1eWjIyvBI7u+LgWSqh8yxrxDvygWlYW4aE00Mz0ScJS//FlzSqO9yRMkE4j9TLVeIoXhkXIoCIGoFoGJP9PACsfliAcH3QQ0q+Iqld78b3yaqBGZ+WYdhRHIUkpy8vCFgwu5T0EI9Y/3Auaa7noDb2YiIVeJcufL6zaqILBFpm5OkO3uRIKRjUQhcvA817C0l+YY0YvXr9lL4BoGq2TaEr8lC5AbAXyyXW63yIZP1FhQQ/Ez+WbfnZI//kU7EY7zPSVw6Iv2sTyZd9FbdtEqkbZuVUuZ+lIZrPK2m6+V4GpgpwjPP6zZFF7WLv1svPZnnqnIdECO0f9Ug23vJVd3VF2O3EH0pDGoTVk6edz5QagPrZBf78Fm4iMIsRf/ahui7kEwjdjIirL40h1SssIl3hP30pd91kqzdxZPX9cIx63ahoH9Aq7Kfqxt3lwPs3PQrp+5ZC4kVFCYBylbDDBCZalFK5U01rSK9i6AfGdEoJA343UzJ9L7R60zPOtxTf/1yyY8AANRwgM4QY4SQHewZ1Ho9ZQEae6NrCRT0f94RQxPFNWcyF5blB1jggpeofV5OBYDlYUWuQo1Squss59gR1t0+Ro+7NZ2AKPNAv1Q3zQwZtSLJiUdXDyKKXNjF62iVZBzm1z9O6lJZMgzbf60Eip4AbbVg+9fENkJ5bfshwjLyBOD6eG0eTPsbTJ/AgCGqOsyJQGcMlIgcxOHmJgiHqqAgwmVioTjdMx9TzTpQaBjuWIKZtwRdRrzU1AtQkRLevXrryweaXiZd2/Ztd2woSm7bQAZOGgAaOal01M6ko8wkR0LQUjTQE5A+wyyDDaTZBeIh4QXyXQt7iTcrAAtJX3iXAD1k2WxWSD5ORpRIHq8IJTZTieCT9bLFSoQjOy4lnrKKv0HqBPpcgocp2l3tlegzT0H4BE8qZSGBP/c7Fw3lsSjtG9rQYlWJRSRxSpgDytQvu8JeDZs2DkzbEApbu0RreM+dyf8X/pvedv3zCxe6YgVuxUNLNz1JN9/nTuNqTdUKgtahE1Z95D0AcEd5/CN8rX5uhRfmUH8Asij8nOl1woX43AszaDRIfWyypb1is5bkbyAnjfMpwjjv/UCJ/quHVFNK2ypx7M7OWfjs7I3lFAItqzZwWq8zGzar8BKxefOZ07I9pkso29fWcma1E82LaJwQoDemTvw0clVAnWWuvGe7I+4g7rCXU9rseYmufl+cIfZdsHHnytQG05K4SIWSnXQPpKH6JsXTnkCnv+FrD1TzSQueka6BocxTPaWExp7J8cTUqoTZVTukVUPkeBCmJFeDF7Z0MygTVmQ4OLklAx0zH7T/F6xZf4hwgq/qYEeBMDpRDL7vN88Rq9fe+KaNUBKfc6lewoHK1nMtxeArBhCm66FxGN7VPzPvM2yO9uj72BHeqOOYWCB83tAyT6miJuPxautPHX1mW4WUDk4puSw7yEL08pxpCZOaVlwogkEFDqK3Si+yVIN3EeXey2wcJMSvujdYjRpEkYmTkCSXBXf4wX8OcFQiezD3IdxJJ28auXFP7CvLq/j+1OphYObHvygcDAkVvotYPDsKioSYkEqfW5Iq80flEosk/HXLhrZzYRtijj1gfTFEQGhvB0Xc/Us62vX480c0WfJ5kCpYWLhLROcHKKvrL7/5D5Fq+XFKb+Gfwy/IL/YPDzmVjhLf58WRqJysCXNor6MXUQ3LnXIqg/JcfIO9YfE4tD54N9HHSc1wXp0wT0AXACzugb+9lt+hDxFjMRAOuQk6OW0CuZ/Odp6SMIDYVeKK2RuxM5oQ+5euffBjUs36ev3L8AxhkPjf4mxVmKOodJTWqPW69o4dnRUcslZw9asEH5eOuf0TA32n3pRqIc5hRb9B9DZiVQjeKGwjBVwXXkIyma6VUb1CBFYxKN+gEO0Uw92ZbDuZtWTkhwVAVcO2rfC62HxgojW+Fpf8JVnrTVzjU+BqnJC+Z+qaB0plC82u1BvUaYvDF4bsfhdD0qLebjLhpdhTy59oUJ6WlIYSWkvKUEqcJhKD+2/nHG5TBpJeip3Z2QnmgMkjCFQkK4saeZ3STzsXN7N8YAMGKUKb2Kph5Q1DXhZfxQaonNrnJB4XZr5Nek5uXe4AXVtxahWrb6ckjzXbN1oTpciFE+6USqd3Dzy1R6tymiPbEB2rEJ0ef2wZo7tCjbfrrfV8kJ8nUOiaM+p7RZIUyuiCDHLTeHszT9PbEBsH0RZBpYtNLayGeh9x6OTqC1wLP1T9eTZmlC2CJlLTb6A3Pc5Y2ZgIDf8lNnvhXos/FsfrZcm01wMVkbRWYUc8iorZNOu58Do+xmp6xf9cPEQzZOTDYMPM21R0ayqd/MsCkyzn+4jD0fGdD03QOl5GEAKl+nd3OZqhRtCWXSahTlLvozbEc+L4PvR4uCuaQ+OOJlxYHFlFsPYXwE8g0WwjeDQmpYh47zMZ5dUY6ZH+ba4Qm2UhEX5KW6j+pTBrya2N2M7Iyas2MjJto19HESJpJhOJqJM8tUJ8i2hBkhrJFqofQ3Xi5ipZFBE9OetQ88YoamqF1ZGSlZIVYP/msgJDKFjJPTWzqJ1ijCNi2dYUg0kJW0AzNTwSg7OUghfQcxEuBBWrwooYsXh/9f6LDhK8RAmoGgtXVnqSUE8hvblurfZDedXW1LGKzBDntFpQgQViLnI2d5Q4TgxwFxwnCgEE1dBSWGCp7iDlC3Cr2hEsI/IEu1rJAC1NtPuDBzs7E8SJ20HCSbvdr5nGpnrTIywL2Riit44V08c3bDJpDgN8bM2LZqz3xT6gKkt2DytvrwrXbcFlmM0eArArkYe0+E8yCQzoUM6j6aOqYnq91bIephv9kC3ZcJcr6mQ8yWQlKOJkvtYWCqcsSn7eViOOh9LJVTBbB7PiCTy93vtVg0OyF4nEbCOEL7gcUb4FyynHiVYuA9T1pRcRNtJ0rwc+R0xmnEPS4RQDPCgVlZV/7ULoB+mhgiNa7Kuk53Gq5Y0YUpYRj2HS3QM5BaBqzQ6rC8zFRU3RMUVjkFYP8KvJg6mpFQnxGb0vXnnhjzpQgpLhwK+HS3AKwf2/XDvj6z+pLX2cktSF1mjWylwCBK96jqU10pIqOrfMkC2OS28jKJgtXN9a8y3+EHHoLsCKRrzaGsZ14MtW5A6GAKcUS0fXkIuy+DGVyefUPJVpFbOjCsLRKdMDtBWThVKBD44HUi2sMpb30wumN27d8YFgRp8izt+2eSEF2xoDN77Ypmov9K+FIL64GRRPM8XEVIxjkQG20gMwDOLjJIOSgoArmieJcfyz1N83ysdo4qy9cqu/4NGR6G0rSQxOxQ4AsEFlcIxfO5szUVxuB/VVvW72Q375ujtJXUt7aIl+hLpzcGXmtbSsHBEI7C+7nt6hh3zjCbY1a6/9v2icl2aD5/uIhJCGzIsxXyV/6pP5dRCJaYIwoq8W+p2AYom4Eo3SadoQb8pqnlkhFs1sqRklxjTzqGJhoWF/lBa9FVyeYOhSCa3Z9nrB9ysD8jErwhxaTZ0A4chxEbH4noyY1v5zPtL0foTFaCLVclEiWTdoPrb9Nx5gu/gtTa9/OTIw8dHHlvqLkHQgn8jZl3MPK0IFmUPexLqwlDMuRLsUiFqq7VqLhGyxSf7qXcfZ6pS13d3I5Rk0b6Sfv+nFO/L2vZ18RvF1a1gIIEsqZukPPszzgbVSxuJviUzhn8CUpvTIEaJT532l/AB9/B1EN2ZfQofu4aE4AyUv/kle5BSNZRwtuxtzS4de5F66WGu2nq7Kfki8SZh1lwEGJY10keaWRJX6q0XjYQ9vxfGuECk6Ely3yzzxhlc7yAjlSPyhKtmGUdNv47YHNNj4sClH7B7aLdGEiMZw7q2dEG5EKDtxLSg0egE0stWCyV1H+nG9SVeZ3N217ZZkwuCcUQwJBWuQWb4xpqRMYJeed+giNizRp8Iavi4PnXJu/1BEX4oyp1FNVSPGsCVj8tB6W36NeHewsk1c8BfJcsaBe2B3x1miqfLvoDLy86mOR0xHKJiSxAmXxjVgJ+laEY4sNmjgKw8RH917LleCedEYnopT7KmoKalPeZS85ntccPaDZbSOZlDIDgpdmZ1Kojd4QmeeIeozKFKPRqmyICAYpTlKFIkCJEoplIpteNK0QZ4mc00liCZwaWaZziakusLhQaxnkHjxdmA4Gp+6f2PCPOZX3q9UuVHG+iSjy7hJQrkaXCycUiUJp9zu6PYQlcARLT0S3fiR1KP07mvSfsIN70R7ODv66VsHDKrIz4+XPWymItG4cPIfr88/mdudUd0ExhCygs0G8EOEIStcUbEOSheCYYWiu+FLVynTV9CjZgRa4tfhXAWeBqW51bdCju9NMScBllvoCocp/WF8S11KicycUG8DqShDSN1FQfbmmXlYYCxl2pUxXUMYikbOax+IDablphFJx+JpvCNuTnvEVrHPFAEU5jQqvfYLsorwgoOLZUt/5IW4F/rmib0v59C1HTQLdeusU65ygc7CxUjGd4/rf+aNAJQKMcwuTADzoiwXrXmtrkhbWL7jW+V07s5F1sZkQERZ95Nh6BwniawEagKXwnqrl2wmVrWfOjsSRd/jTCQQx+HmFeyBeFr0OqVYIQ6cQTr200eed1r2N1/XQ2ylh5d114st8e467wfDpbDw+0E/hSzTvMG90u+qNe8/LpHSVt5tgUqw8bz/vqCpKT0RrxJf5QzgeeKkgi3AfIsEINy3k/fR3ksOZGG/PgltVyvU2JOgyHOwAPXRtD8UkME8IAoa/5ZjTii0CyEzOzQE9TuVLNCHi1uh72PNOVOJTJHO6leQNFoQg1niixnBWXIbMyelbQynBDK0jTHIzcue7tVLHKaSiOj8BqBh3asDzw+lXPcfAYKbPiQ+GhRKEHBhaZOXWfgT/Waqt2u0srQ0M20hJUbmnHpLwVVR/y8LMRx15LNUarpNVHUQf2yA7BS/i62loze7uqbYbo1duMuYZiuOtx0mrDqTxMA7RZF2F6Vrga6X6RUVIYDEB+dCX8Bbatka622TrfGgdTer4q3RgW9VL3uHCBfqAnribLqHO7qTxQX+cF7ESULpE3BHE0JNcUpi1Y8ZBF63F7ct4Pj1+FvoMldaR13EQvjOlf7oKF6piy/oSl1e4dfiHyOy3bWxNh4It/XJlyvWO9LBkHIubVr1g2RtPc97Uv0jlwiBA+n/GTmzorzCqVJ+XI8/rPD7XhRX8wU3QSTObLcw327Q+Wln27UCA+C587m60UkfecQjkvkWEKUOHZdOLVD6UnJc6bcUrtTFLsi7qwcg0QHM/dsmnFfLmI845FEwDyWB3/ewWm2JtDIypNdqF4KcdJZ/f1y/Opz5rKD9sUviZ04bkY7ckFB+8cwyt6tHj7xAQKO0DTTHWV9cfyf3N1AiPqG3L6C33aFAr62m6z9zksw8s5w4lrdjL1XnkyliQhVcvRBHLAdddDsPK0xZRI6WaktlZVOW2Y/VV+C2QYKoIcH2YCuCoD2S6f0YY4uSn2QEf8fqGclhRfDTRk+ZPvYMwYK3uE2owp1iiiCAgGQu0lP8a2cUpxoTigf/d3xwBhoZ3QTcXU2gaSw5eLAF7ktfLASqEkpcfqRLIFBI3umKLGSWupAUyOXO5ARiKLQJEzPEeU86YhAJ+ZMbruSWeiB23Nlxa3MuiNYL3c0erkCV+c9hm6JBYMW6cGwFWb+b5u0Y83kwz3Ztg/LdKbZhK3+a5dS74sfVFf0i38lIEmrx6l15KuKp+5XVmy8OmHfFN1wNUPiTHec4Vj7mThVYf1GpExzxUbLE4eheYdgKtOvM0OlJR8kvh2/yIpo0hQWUtW9cHrfREEg9R7jjMD8zn9uY3ib+jzcemPqc47o6zzZfNNTM/6K4lG4I1U84OofTTPB9rmxuVq52XW9+UEsQFH5AlpfrFT8cr9Zz9/y+X+CbDsbM32EWEAYta95YUV+gAIWOJPTGaovbRN+wIszTHtI0pblKqBy7FX8o05VAkjQGBdqrEFmmPb0NG7CkIVGgjkR/09EtRH3eUmzOojllsh+ZnZiuwEUrDZivSw8nI7+mlSLnJ/5oJO40ZoWMHj4troxfHTVrknoTv6Ir/wzFNqw4HyDXg5fofhT4ENXHG4q/xz7+g1TZIKHL7bYCf3tuoVIDLU1wE8MMlO8N7wdLNibbLrzyTe+1VjHlmIBlBtv5w81XDu59bEC04pGB9lZEDYg3WEsunha42UEUkloE+bFKzdQPpqPn/9w/VXqBlPVVSaXKgCIUbXpgtv70T4lQMye9FBZ+6CiMVjw9lo2Jb5bZ0hqWkV6mg/ZcPjg5vUaGBPdd4j5WYPor4ufYHoYcyEuee7E4lb+4JMBveCG9XDGst09Yi8VQN4CVyXqYeXtkDcEKev0sEpZA7zdpq0OboBiPhrGzqo9nIkVXPiGGdLXpnBcGi6VuREeqvuqFErx5NOV9wmJFEh0PMU8rorAVi7dP5ElHr/jyMHa2Ft1ESSM8+KEoxtSskSPnSP3LeJEkmEQc6aTjaHhSELbZI8mvMdg3Lkdcu6f4T4cbsWEvqhiB3JjdkMiGQKd9G+Z+0Cszt8z+IAMSfsaqYkdZ6gGe+oguUU9L6m/Zi8AGc0Idjj5sbPGpPfJOahalOuNJyzmL93c3b1VSOF4SttAs6EE1fbRyIjpIm0IHxCJCSSZ1FF7L/8TCEAsqavSVX1z/PLHbfhSaWhUpya9Z7PRSqJl6DmUSIALGUj+2zwWlQlGTSu4OJKDTGXiRVEX150ax2wdELSFyTZaMkUWiLUBqSYmmi6EtkO1eTGovd9k3CdXw0n/aRZPcJkc0/bBBOCI3D8w0iAlZU8gEqPYeEAqFpoolxuxIotczqoD4wDy5khX6WOEF56aXW47X/ylFugRHqRSQ8WjDQIW9919isOl+kpyvEb9AK6467UtqPnTUZ/b3cPNZkNka6xmz7pmxZoXMLydRY506sEymDPdgC3bIoSDVy+jhR6WPuX1f68nDUwHpMOyJC9MrBzi88tAdSQ1bWrQ+A2EB9K+jkD4emlLUHCB2Rcs+ZuiIDkgcreE6wdmg6wFHJ6l5rDiCYvJs/Bg8YQy1lMC76lu2RsQdGgqdRSwG89NHmUeq68FapWfQuYKbbf4f/anizQP6buTVbs+GHVJTF6w6DBM0LnakZ/mIi7lBBt3fbNF7EFNQKByAGXlw+pDoKP6XBDo7ZNwk9Ppv7zmn5WXnpbTiPRCC9H4aIRvO0XKTE8aU8W+XrgGqwNL8YpWv5hSmaEACp8tekLCoNWYwAV4gEbqST1JS7QxcOez/V079edV+E+uX21aZLFqa9VpDvmoOkEkvIjgoHHM70ibzMOtj5BjA6dfCejEdyyxN0Th9RFOfhKdtden8vp3wTwZfN47Nbp8x6ebYIPjA4FEfxCZGpM2+ixRcndcVtsNgckY0qbCynrYsKqpE4WoPxSbHPYJSfHmyxa6Ka3aC8SVGU1DXW/C0rD41zhKSEHU/Z53AERc5AdeQ0sqxtjA/X0OWI/et/pWKN0hjOFEXHLcI60MQdJ6KePrsyau73OtOlbrSJjJ/bEIhDGj0Sw1akhUEOkjlHSQKPrQx0Ud0IbVmdGo5eVsWNSsxVq1MhFNLi1LD9+BGjdiXYdiRHpEY4OHd2z/ehUpQykSGRTNBf5xLsJFD5XVEf2dMvTXc45X66qyseCqNKBbjEZaX6afPReEASehKsbIifvaNB/43YE9cuF65jsOZoFuR1NA/xsO4zi+cDtTnNMNKL5T2lBUle0pYB27GKu9AfmCLY/ncqc+8ZkqNihwDm9f62dPXSi3xQaygyAHzIubuLrsWc4NWRzFnpHlrX6rpfoojeQZRT39SdUvwoS30ts/vWodfFXPiGGHg7Db4RCEKHVAHZ3utWaHjF5WH5AgRpUgdPry+rU0P2fEXA03G/rgY0y8Xr7QxI8aG5w/sZDbnyoMpuGG/R3hZ/YYltRRU1svZFUpqJwxwLlp+Cgx2sqQ2b3uzxzbCfb7Ul8xnhu5m3zWbkUx+RfF3q/wwmWdpYSOrA2Z9immcIAzenOnREnT79ykwxAPSIuNeThFMgUegm6CG19oZihV96byf8MoGk0psZg3U0kmy36uTk2yqrNRd0BkKNw+HLJSfwuA6DIHdlhYAESD6G4P9X48zRLcCZOZOBmyxGcxcHitORVUcB7PD4f7jSYIGMVA1wgol4k4YWHUbYSKWajnLFjPlddtT8HViROZTwUAe/vPIIdo4Gyv109a8skU5zoxlJ5+wqirhRiqPR2FO90nqWOVudOSNWRLhArqlypmpVu2FTRsNRro3NxkbiWakXg1J0id1jM+zPVPzPGbaABN+nxjkYZEOkI2E29pFJWf/50fnt/1PKoE4/9begrWxQySC/fH2mVVvgPy5VHMM1FBxy8gEvSlhma38H/eK8hUqvm9FDrI7WOzAKMM/8N7C1CuNz6vmoqRt8dK1xVnuRD+wWgUf5Wn9Pd+SaHtgZuv6kS1Jg10xHG2GIzdpwcYN4wrHCZJsIorCx/Vn22JRxq96XAVG+kEVVxb5zi/MHjffHvnfALE60GCS3OWCL7JfuILHP4bm5WR8EaTwH9D89Jx115zjKDW6K0HxFi1iDkp7XRL5Jf5vKVZZMiLU/thVHh9nFGBmm5KymrKT6OtUy52JBKEHMxE0MmMuq8Ic2AM0az/ZI2R4fk4AqXKm3xIuISOrfeiqGZ3p9UEZI/R/cAFclefhapaYu/0JrNF4Il+GYceb2bzARm261zL0RdWhecFkKimBG3gosQ2s/Vx6kuMj1xEgDmIc3PCkoBSGnryDvuLG9svtl1M53r5m8f+XiPLQqpjml521QS5mP49l8mUk0VieNk8X8moPmalkjfCUC/FLifEjh60GLATrfMyGeF6yBmgruJBLF6dTER4sQCl/ExS7oRbfCcdG9O6tNgfYg5KyYsQTgqecmNMBC/B5+ajTqC7ZPY8Q9akwk0v+TiDltGDasioxD/TrYPdC2I/SULoqLukzu5JCKGO6Pr0iedc9mGWQsqDTuuHMqX9iHdXx5++E3WZqDFSkLlf/pcWZAnQcL1YGucCO9ZVCrcJcwl34sPu0KLtgILGmwJZjwGwEryOCbbxF64pgsj6iiBxPq7m/avCpRUXk1Lt3R5T6CTG518m/NAEscWJaQeRKJp38S5Edw7KQfJAkB7kJUo3cQeT8Dy/VTHBmJLKy9pjdPl4+8SNfLGsmI8tQS8vu+QeOU8mjh0Rt+B8lZoWtvJsY+3yJmIvw6usNoqCzGaGbwd75MN8lMxqSKcxuLXxU7r2VzLrW9Qj7VGcOTrMHWXzs/mHij4CDgRUgP11mMKZIaW9hcaoyexmFs6VrD5jtQeLYLQGpSTZuC4LlH56ijW9sxZE6J0MbiZ/lFcQ/Dwqy0Daqh91LRr/mbVHDbN3SwEYNxBjxfs22//D4yooXtax6fosuI/4g6iKRHbbtTl078Os1p3m0eoO6WdBFUsp52DK3dzYx45NlGJkpuwlQy9CnFsqaVGxFCvq+ukeaCk88waRJxhgZzoxd745JkJLoybokBvig+vn407g71qPk5T8+tRCZOWGgdRkMl0Rugr8cXhJDnlCIRyX/g8EO+Kieifgje8vdcYghlkidP4cbZzaXKcH9UXia1FKdn5fvslqUGneQJ/MJnS5J7ipszBnaw7KawyfeOfUNfhEJv3F5gSU7P2yxxQUme/DJy0i49wML9iTpVaI7eOqbZa8oSgEUgYPd0YEflSZ/CZaQVty5ojTEAACC08AuAvXEGgrvv8UcrPt09OAwNDm51ip/nywc6s7MRixdWkWo5fXzWJoIT/iAx+WownM63Wg2rv144viGvISjzty2ZMtrXBWaX/eotnlLuynI6yNdVFheOTbODGMXjTVmOgHhxaQ/BWpvAkP3OENTNGWmV93czeE0fxkeJYnMgY+CWiXGiBsdOSOSBT5UZkCD3+9jvx6fMTljUhGiHiywSjPaUv4H+/68DctGGLV/4JRvIA7vOXv6kg387nBz7H0EM7lFiGXilLxA9ceuLjQ9oraodJrFSaaXWYSlZbvvI/M1GEzl0M4rS+XWT68gVZC9ap0veQVK6iEOoUnAIQhboyryajKwEnz3VPKurS5ptj6Dkg7NxBgbL80nJdPtpRO3o/jjFCqvZc43r6JdmxsiRqKJ88Qyi07IaQKEfgJxOg4Lmzj0bO9bsCAyouufm23MioRI/UYRkVedur/3PYKeaH/8beK/qS2DJvyDpSO2M6IrXfNcfmWQpBSd5/7dktnknasv9uk4BAxfEDhzIkeUnT1/yZ+87KSvA54e38ksMhLqlZUogMc05Uct5pHRJQijUGwh3KQhMRgzkYUBR2wXzOfbUcJaiNpQnmTWaKRtdb+oqv5wXA0LzMCD90eVsggisZdydvlU/9KLHzanco6CJhZP8VMgL2u+CTu5zI2QnKSLN9QQcPwRkBfm+Xywy0H/qo0PSA9jtR8Cf10xIWadysIyq9WCq7T4l5KQzVPUFpWF6HlXH9JovqNx5LNd59z1G4jC3iBrPZYm8K94stAaUhU7xtMyuDAfy8Oa58vqS+xRdZHZvET/TMB/u9g5etCezrtWqUbuwOHSp/o0mOoU1vC6bNuwrhsXO8zBIRrSXBjfVTgHaYbcZCafXtqHsGDyNpveHjBR2a9B5DNe95uH+cxfEDhtNDyEmL5g0qLUnj90pwi3XgDP9TB73fXZM44fCcAxs8UElaV/3I/m89XFz2f8XWngrcFxwcCCUxmHHk5riPaVSyjcqx7xU3wKkiZEFWU3pSfVWNKnhFrNgT7GtKpIVb4f3c6sI1Jb1sCOljHAfNpXQOg2h1v0HkTO8rrqa7QcmJLZthXGOwKGuQpCeZTFPc9ZeM39lPQ5qTlsMmYdUlhWR0YcmoC8nKLs/vtUg/PzVo1kzMwc86R3/k15B9f6NKqsYJVgLvQkgQFXclNWdwJ4NMjPpMojK/hQltS8YePbsDyIoB6sCpGIG47gAB1HY/51qJzcQiV9EjKaWXIRuP6b5lAgp/MdFefnkdtOi3HWVNyDJl8pgUjGZuwYD+5Z5B6yIATgICsOwvDC0tZx7XPDZz8dq9fO+oLXUGJdbDK9O3ZeTmWSYiI+dnfz/YKpccEpixhsFFz4Cj2SB3cHCnzFo7A0pq5lRsUv2G8dVhNvCQXXNVS/r3D+bO6QG7lWlar5eAuxmzy6z8sdWpb8CaHZVSpOE4VUz8+YHAnGHEkwpcgXmL3MUUhDSDMfVzUUOMtX39jYUDYczcBPn/wYBjd18nPcmb0KynA8PWCVetoB6WDQqTozNj4i2ulbKs6D4TVVxglcVAQHfyxZpDP/IUoo+K8ww7Tr4vOaAIolNQ9NQpNdxx0m+wF3iUerH0JAojP11lungjLALcRekpvwK4JHlAlQCxmjqfQ+qVaJ7vv/f21OVw1W6CXLEOa4N/TOSxCXekfRXVnRTndqEZaF5hTcucuBnmdh1WJcqyyiL4pddkyf33oYsflOYtM19gBf42kJWIPzT9I1EY3W5ZG3Iz+55qq4lhi7GHXkrl4wJYu/BuaHVohtZBJfQJ6wk0sXyx/wk66F16zyYJpe+awM9st3P297soRLtJJI/TTBJQh+iaDbs8xy1jcNJ5fF5b8slXMJc2Uml4Y7UpRV2/GwLaRI+qr0xbi7me+YE56xCCeWi8qpLGqEQMdIOq2xC6TyJGtWnr3XF/xG3xqkmUwWahWJXuUBbR9CKsYksEjKegK7bMu2f61Z0usY5/Dt2lcfy1+/TDAVafLXhlbbR4B1P0R8ETF3ftkBopnPkJ8hl84k3/z2hEX/9tMnmE8gampOLUsInd2W6uulGC7DS8i2Sp0uvTAHTTEYp6UuiqwxOmLaQM4NZClmxhoEQ2excD5pq1+mNFr1Vo3AU+Is4HRFJNYWskdJI6fI+K3p5+lpTotOqQHm1mN6+3R4pXze0TO1i61ldaPTz0VI9w0l2a9nJFRAakoV71A2Q1UPJc70RC27koGJWoTVadh/ZDEB584+XCr08ImXIDSkdXmQBilFTW/fRmWBkCljcxJKlnDATQMvHoxkUmIHmOrA4Rt1IwpyM2zmvUwbJdlHTrZAPC0nXk260JkkInsTFJP6RDjltAyLZ5SU0g4CH5zMgn/Y0tR6r2dGCmf2FSfEkd/x2LhkMHWXLoBYPnFnffcbUCcVHMNxYsoGdU3ZNX1fzli9swPJDyDSHsLXbj+LB1mSsKpifE4HE5NGkYNpS1lpdTkpWjVoHjOIIl+JKBvsv8izFK6eycgRPCXFM+mS1fni8pT4AwvqjSL1PyNxkqFJv3hYRf1w/OGQL9dbpA4EL/sje1JVW3mVxcmgAPa+qX5OIe2VNkvuqOXI4v4K8D0oDikUZUj1i7gqyWc+zpigzHpE9Z+qrrZvyZV5ceqTmIRPFE05AyHetbAy1ENBABCuRKAaTSGGhEdz4CICXXxSIfTzGO1gM9MXCn/NWdM/GoaxuVenA6TNIyAzCBATUQEEh40sTTGila6S6Vc1X/vUegwbMsFIkE8GdkGeXt1K5KuYOHkKyUcGl3jdu31uGLxB2PsKWoWtQ3TQE482mEnbd2xLWQ/y38GRvugYrBkx9FBh9Pw543JYpkwm816QSQ088dzdRBktCVbSHVTU/G/kJUI+UbD4cS54h8CqPULxg/lHN7PxVyeZGcRuJKSTjkX+KsNJJoTqW3BpeISlHQqoPRogNBuM7uejDrdWK7giYys29pinBwSXnlmoc3gEMvkqVEBzc744ytOglGYwvNoN1R5mm90/TOQ9GoQl3hmXQHixgMSVnfs+9WfiZ/jBLmlOjabfA43+sJRifMOWvAmZ2xc4+4kXdmJfkf5XEikjeVcukV1mb7UNdZ/6Ky4wRobEF2+ePirW9yPBmXC2UpCe03e4vi/Tbc9UUzdQFOCf3+Jk0l2lo1cEqWupocN4GL5djQFUepVOe988McgaGp+GxKG2xGktrUsSXGIgngcOa6SjSf8QVUnKhLKNkkNRSxEVJMsJGMeraAnW/VyQUWf10BHU3JfjEDcekbAIS+fL7SkGrVRfaqurK6UEsXoo7EJHQ/kbuirEymGChpnw5BBBBuimsvMVXJ7CKynTH4PQFu9N5K/wzy92WnwjLBNeONKmZZcOwkrFa6A81RyX1kXkqMLNaZguOxV0IPr4j96szt43GPUKBflyFw5Wyd1VozD8RHPIEKSU5a8U5Pvk1C20qYZQefitxORdrJyD1okrW7yF73BSsOfEzu2zwjplHwPYCjseS2uie8dF2yq3dpT4jgBtS8UCopB4lSnjJy76687Y6I7zGdgVer8+TucZ2DUjZaw5UuWNQwj7ydqKUjzxDkluWJwBRs0N0qnsruZqqIGOGKvWFsFTyBOVSYhFolgTqD7fXkilE4V+C5NjnEe28E7D7vNensVQ6oxeeLrMmhZqw5E5Ti9f5R4s1z1+gn0auNcPT70xT8DwKOwTaBqVxWOuT9mhlrjo2EO2bQavxF8R75eQh+KM59MR8VEXmH7Cu/p2x6IdKgmdzJf+kGxN4oXHFUbJSMGJHowfcO1oB4/eN6S6W2eNbZBZvr6G9ggP1WMF/7DKYwTgB4rOu+bhIUafep2EQ+jhztpxeY678XSh6Fdx5BA7HJkWHC4gZMCOBfcF/QhRqOQsgL86qhyzQZp/uIj8Q5MoE4zlsg5W7z9qn3q5quYcmCNt3ccV4Mjrr+whEnoVzo2TDv+Ahzfbos8yaM8hBqnv6CgP/IrvC9wrT/gJ7m0rTz8ZtsQn1xytC7AEmhlWeA8+5iDxjfLEKwzsOUpNy9YrjpBo04M6ara3V9dPHX7ElGnxnA39cHJxshoXZEuD8WHlWbs9lftpCIfVS89pZM7esRePgIM9xRS0MkWgklAEczfGWCO0SjTFOhwunVS5tIF/kIYVhNcn0EedaexJSvHCcZmMJeG22ck1f26mNE+IKH2hpaz8lk5Rb00ET9a/ZuFNBFY0qYKYak9BrWhG/al0s9W3CEVwmrL/SR18NK/zwcUV7nlMPDs+7D8pjhBoGoPRUOM/kiRgWNTx1yBjUoSfRaPyfSHWpXFD7C3Jfr9GKaPHzTJkjvW06tt1yt+FVK07sETngNBgfwib9al7ojqm7DkwTDZiNAB+2uUhsL6/YGKaxb+lF5waVTHBzxRhSQ/mCk/hPRDHxM1ePjVcEfM9lVfcVA2/c8MTI8TKhl/8K6pjWRqsetiZoR8TtermeMJW228oXyoBY5VhXe5vUpEIn/6mNUDGohGnjZNIJ1PqFIMkhJIIg2gPgWhqTV8CyoVF1tH20mApWsdExiCcY1T1Ly8vpx94OYUuP0k0X6uq8bspJf4+InuYe96sxiw02zhDnuADSp7Crih73SYbc1iFGTEpaDxiaW86e8yQnad7y2t3B5dfE0AR1zBr8J+q/VeeekKBFp4r/fbcxLgcs8TiuHlX6FzMFN+lUgHbKlq54dJMo2IsiXvCkpS6vqjAtXKev7X7roHGnUkRpLKIIX6JqxOU8GOiaj5KGZFVbneF2E1MHg74HPLh7AnYbkoPjhssTC1wsxtppL4ensB6m/P88OgcX+GDeOJnyOfowzfP51jblrCM3jI9ULWK0uCMZDyCkEdOk5EwyDyv8Tv5G0QIvot50WlHinS+3bjZOMNYTXJva7KN+06TjPi3ezc7l7ZwPCRpEkIqwZ6kmjWhFHpQJUwuBiZPqx7kZotUJMLEvkQql0Kqo6jCUAtfo3jSGLjhvRrZV3wSrhMKWDRZYNrC/BzYku0iEcT5ISrt+DthoLodh6NFidUW7+3Skp2R4+2F9o68yGwZ8R2VYtrKEjkxJKS+fNbH2HyEufPyCMYQeXK0shsw70VM/ZMUn6fWDlKLIs7xWEBVpsdExhsAn8Y7raoDwaiEG56Z5kiLbaMiECKZNxP+PEiVjItfrk5BiRd4yEyEL1P4ZfCmDQPSHsaPbKWP4SaqOAcxzCwRpzEzPemfj53Co2tpBP9YKJHiUx47MUU+kgMpcVGf2PG1DG5gkoOdlOTtxHFFNJuUSvfgEs6oqIVkCL0QnA8OJBy7dbDu4YRrXB6RdPbjWYosHXLVpQv2DhgPsSP324bScRxEC1Ae7MHPmwooZexyndpwGpEuBWtaIogeJElgYqZ/muLefhold0srT1eMx5FH4Okj/4Gwt+x/MjF5KDOV8IV0NtTMdAiM3S9jClh8L6pDRpQUwcXS/d4chxYpw9s4YgmIYo799QETbanUY1Q+BZEFxg2DQ5KlIXE+X/sP9C1lCJjInnlmKQ2EpVA4P7RGRtvUrKrf55wg9P4ylUF8NqBO8F/hkuxnE0UcQkAp/8B1bkIB99VYHorvVeE+YtKjNNr7KGcbDxKR2OxAYvkpIplDH+aNH2KrwbJxZSsft/p6p4BBF8F2AUsy6ivE/FGibyuq9IAERhw6DxrbpySiQYaUbkDgg6PEQGnIHyFB2rVwlgASQDhO280uMW4JENGvQts1iqIZmIXlMq7Vf2jK2NzC4ZFxaS0paALhgT50LXEkZVh2Rn9Zl/ZbD1UB1CNcVFUtYE5Q5WPz1NsgNp5CTvacSJrMza7PSdFqDDp5VCI9kT1ek8TC7ThuTGnTqMm3K3LovHR1ON9kyQVWHNUmwyV7nylAA1yrxyW3/6M7vq9ouKjBTcem/TWFEATeliFAzC2M1UkOc5CsGA/s6m0K8pkpKU7R427cdEhEuUk6wgoQFlACq4pnEJYRcxeVNcF0JmpRNwotZVOleyurWmcbws1LkAw0HklAlqG2iZbqssTGCzauWpnbjgw5yfQjBdOK7xzh1cFePmLpcKVM3PkcQUX+i38ohd8MWKgWN4aC/JQqZc3mCzScJ3BMeK1nRmXFetAmQmnaqpHJ6sKEYAw0vrB3BLn9chgoCloDu7sJ7CdE5gryoZXVcM/boQJ6AcRohoJbSVF8V5+X2Qt5S0VIKKbPc0yK32c7B87VFz0qn/WFwNMyOHOo83O/JPx7ZnVDp6rum2E9BmfF2N6KNlxv+3jH4umd4AfLJpKEnnP+/K+y2rXYFQiCE+WvdP/CSxlzVjGP70N6S6lTd54irkDMoYq8vPp85zgYtdOzlFfe3VhTV64jd5TRCHYqKW5S+o8mdYIN+kXZ77/HIWD+qLq6X9FkxFkM3bszrFXSYJjEDsyAfpd8zbxktZ+xaQbhOUbsJzTF2eGlWlcOCy4h4JtgH8ZfyoL5yOKakS+oDqNCnKBTElj3AJKMAJ+cA1MTvIaDZyaup6101eKw7VANg2F1hP/moLSvd+GmFQTukNAzWEJODasDMI7HvdBcCMrbnKJHnFhqTnR8wKi6yd99ZDHFo/uHoYgnvu8afYKQNpip6AQ8ThF8JVCcwgRXumotagFzK6y+l50HCg8j7UxjY7IflQcANP0iFZcnehOfzVjnDwDNG4GJRPwwZK6oUkJ7D9l3lST8MwefTtrLls+JR9mnoWS2mMUiFWRnvbnZzo0KeVXawUAzJsbb1OUawEHD7u8Qy3fJfGztadRMqRJS0WXmbluVgwsTIuSy/L4JcFfIaARtCM8cy/VCOFx2KlB6DloSH+dACQp3qbdiAPZE9+vvM8hlENR6Xvv2Ze3dtApUgqOnf8pphcYG8HOCyZ0ujdTKSRrPZFypxwiMzBr+8tD38CGNHEfoQQvipt8AsYBvl6OuN2O7JSPqcrnLTF89y13enFX/uDc+IIpGIjIKJvQ0uVkVLGgL8aZOxP7tHEkRE1s8MPlDX3poxGDJ5PHD+jrrrtta2sHEWr72szEmOAYI08enb4NrJawSgOggypG4O3c6euFyAYkh6SgewiH3dzPrVtnQC2/e6PJebri1V5RDSWvA/PfuW6ShU2Dqju/Wx333QXWJnxJRB75vGx09grAGfj/i9gVmDQsuG8oVZmfPP3z9K2QfebGAwGF/J7PJUAe93Q4hvBaUftTf7B4E6QViCwEnx2JQvA0D9thpMFeQyJu9QCj/a3AXGCUTxVCYgYMl6wWTgjgyUubGmAZm3UDmpOJxvix6ovsAaICf8km4YXD3X1VSCh2+68Ohz+x8uvAOj/dZiNC5G56Zk1AnVpF1acTSSe07c/Tp5Bakm4U1J3u7Kt16mP/+VLsnwnuT2nQCckUXFb+NaP4oZO/NcMHpcNvTJdt2iN/RsIwJcVZ1hRa4vxlLjuy/ftjTMiF7R/bD5ubExe7RSx/Z2Q97z8Qz0h2kEmcRCBEVJAOF/p0Zk6ft0EZOKLdxSXhpqChtoCAqq+jhE4XoHdTsYohfqR6VmRJOw7BiZXyCqmggga8Y1DLhb8yNOHyqwrv+u9nGDgyL1i8lUdP9R/d58MuutIStX4+5RUYz54A06rUPqtgOyhLkn49IMg8UHD91uWDkAGIDTuC4mUaErZUHPp1/pJET/1sUiVczIj8DE7/pWb/5eXcey6BM2Myj/ZmDIcu7LJom4vrjqlSmry7vTxibXFyeVGKaZ1TekQXCL78RqXfAL3OKfLfgEg+5iynQvF8C4zWRnpWmzIcnRniSWB9KlUWBuuYSRQDiYGAej79ouG8BG4K2SQ/R2WK5BNbewsrwUyc9hfamztSpI1b4rmubcmj2kVJa97uqpi26wvYZB77HPOqhDqZOYk5vW3S8ZDvv9xXIN7Kv3c0XDKP53uTlUVkmTdHYB0gq+0P22HtYzILBOJ7/ZxeHEWGCEIUYTYVAdrjjxrZWcXVBGmLH3J2HqqJzTa38HIzHSK/a5GreyhN40CRM347R35ZJDZnwdFh7X2ElwMh36KffZznG1v+jxZ6SgrLy9HXgSBzLovtNSA2Mzk1Zp8v2LQhviuoApjBukwKem5ciVRGvatzV6Z53KajN1nN88gnUhWaW7VwzKt8Q6CPaAk42eO1aneFCs3Xx87wE3yAEMDnK+htWgyeHHYE4bUX1EAgXSuNCxs8jOQ4egzzjuTR6xWxepH5WpEZ4bUWbC5btyNFFdaZsZ/Lwe5uD7cKz/3DpcOjNo+HJIfwM2Efl5io4PBDZacZBaAv2IfKX+RXYS/wM7JEN+qg4u3+42GcUo9eBh+wBbnS/ownz3IGl/vs1sp0SZ5xDlM1NwrQHHtslg9Oi6Pee3Q7qw0UHtWC63FQh8IqDGgOKEyJw9qjEvRzSfw9aCK0vqIQ9HIOCKFgKDw8yOrlY/tA9p0Y0hH6nSneWzZgVpw6a2vLmDMQh+HEqDGDSo3Ta++ihgc/T+p3H4Cx7xHeIOIbFdBVIKbII2fadQos1t//2SjdO6cxXuivdn1oAd14QcX2Vgt+chPGoMGWYs5Y3bGmbQrlAIYiQ2CeS58Trefy8H946xJvKbbthGDnRmftPeVUuafsEMr9NjZVm0zsqJffaujsY9p6PvjgeI+wd91Oc3re/hbC8R65iO1c4x+FsJzby140vy7PffKzyKVWhtNvuHOO/+WFQkKw0VOEgE0CEZCiOMkqfUti5KmIxrQgrp9zPTXFaf7jLIe0lTf0BhqrQlLELcr2KdHkMWJqhKnHUVjNHUZZndFSoy4PikkX6/2DOeoFvYwB+BplEwfwP7hxLLzlG8qAvwhOuBVKkuTlmoZCNU3znIiK7yc60iTOgq0Yv6NSHQ5ZiOMJ9OnbMTPFc0xi3KDZdRuWk/lnGm6Adh8ho757DiwJFarCKsxHSEoMV1Py5rkAFao7RNMnkC3biR1hiEEzEO7FAonrv0y4IAWQi75m+d/Ax+z4oPUPG5w7vTZ+V464mEDeRad++DY1Gczvv/zMHpu47GzWic8IfgVlketGIkVOqVY9gkZ7mjFg2adVh8szoIy3WaH+/a5u4A9aH3PovIPEYpKq9MV9J6SYeRdAmBMfOVGeCMzyf6QASGXiYM5zBHAH14ZWykd0F9Xlvn86KwHbua9IvJXJ8LC2RpSmT3Lvt+qtnel4bcTUbF3bGmR6GUkLn/AdF1i2xcHKfuaktgrqBKh+5fmH5Vpm1tKFoEziYM+PIemy2nCm+2JiVoPM5uKV15oyoIoTOql/SRXzm/X1Nh7n8BERK7Yez+WEds9Ly9g/W3rhzQYF8gVkfXjnLL4954FDNpqXNM+HNoQIrs5vCKVBwuIqoTjM+onP7+T0tGNuciSr7dz1JvsL0S1xX12nEmwgwhpRJzM8tjqry/JXJUi1xk3wqh7Dw7CehVgXeM7APR3cRjVHDx98hWJB/zgLPnBQyqJM8q6HAaqBVRSZJq1HGUdhYmx+1d6RedRrwUGZaFq57G1e+Wt+L84BE3vys2op7h9XmKT57mfqOMG5Ucdu4nFUzD2SPuVzGb5nfclQHkyFhFtg8pJcxdlaMB3r1JgVViItSPZmvhlPEOYmeZDNoHtNEWSaQx9qmlHj2Bc1dfV3MMw7fnXjJOWlMY0UuEn9wYpJ3wHluMiL/R7Yx0C3uh0MOh6BBPzb3RzWVdUTbPIYHj+eQKCTG8Qtwbvmn0zj6NdhYVxA5Lx/qo/QlBNwG2wkovdUyHsEECOThtdcPDAPKMj23nuFPsUpwL9Spydl8Nj+xzBbZsDw7CslcZWpro3OvuQYFbyOR/EX5hKNXLzMU/hm87sGvOuC88k93MOpLWFVeZoN/Cz7x67UVUffiDpClJzP3QgkU4FDJ/MegF+HUPyuNC99BpjLXiLneFQ5s/mq+tX55z+0N7vCwNM5tColnGHd+/5p2DsqrV481kvB9Y2YNIGtCI1fVX02asLJJL58olgHRD2rpXhL3CI37ZUjiF2Xm3P1DREYaCiQeoynh+WsmWClgo4A9258el2t4uMIVFt9kssBFiB6sKypnCptdRlE1SVSe5I3jXAVUm2em9Sm4efHqNia4nuKDxY8gyKdxOd6xXzbAobehOlWX5VwkZMnpFrbTlpAovpsq/HeInjMN0sNcWiVy8papLaMDJExJBhYA8Js89xrCUtKK7Kp0BhIvDF/+1zSCg5P7pqL3j4wViJEC+28coPOThaRwQO7V2YqcLu8b3JXPvpJNawOCbVKi6NiOfwZX8XaR02E1siwfA7VntMYVFxekB6hiEKdqOrkyAJ6zWeeJUZKASAGT+CIzv5EDEXRRRpBGmkFjhKYlpo5n/L+IzpfVgPc27aqhAGM3/PExxUvNTYc02qZFACJLhpJFmV4h+jZTEQB+GsjTdm2YFa+TS79zsbSUxIcSuZCIVUs+usEJUsEK+GpAIQ5ECK1r0DW74hb+sYgmpSEGNgIB2KKHKdIaY5Q1VsoGmBQFQelg0jgLjP0bnlXQ/qCSjpgQoU1OhDgeCnUumU0Wj9K3IB77qsZ1rKcuElOpGMAFwZXWME/VOo7KmNrE5mb9vHON6GEg4ULxFV9nIn1cNKWwJSAGV0SGCASvFckcSBytZWgwEghzQ/UCRPZaZR7EwjXKXMev5dTzjOETyWeebP943XhVC3475mfTySTqlilwYzLO9aBhC6zw+aGF8lg8BFp6Ez8RmAQVaDVTFXIcmnRAoMqvFqbDmwag7ZH3Kssn8tPOjH63YCWXLxHdvrKB4qEf6rvw4/HPP3VKovGah0Pf1PE0lcKQ7AJie/ToO7qokR4WuBVG5AS/rqFSZiF/I7aVT8EuwXoOLwCMHoIafHB2YYCt0ltE5qC8uJ54J+UeBSgaYaZS2Jhm5N+6QjCUO7yxT99Zy6TshnijMgPHLY8x4j49JQmR+zyi00/JvcUg2X3lGBvsKljxBc8LZsDd1PlhGnxqB6mtLZHotR4DY2Pj/xHtu972P/3gK6XZs2LjFHSbQ/7rqE7bnGYCKs9BS7LT8l+CEobElNgLE1nq4cMyFvAkPJCCJx4Hb7eDOb/BvtMBZ4CICMda3nrIDmLeQsgKYiPDHiT9F0jsUlBvgjMDMgQ4/HEnL4V+Sz3mb9w0B+32k+uVN6MobM4omjcKykbNL04eEl8QgQNjSKrA7WTReUncX54pL3CcP3Gi6RBfP3DK/qL3Wbt5gv+4z55ldUMaDCVeHeN9hCMTrEgz0h5OgMtdsJVMjMdxDRTMycOhyEkWmm0IEgRLWeSZZHrLRU8kgTm55bMVwmer1QgE4L2Qw1IysF1n164MeAVL8Rh9DxHfZkyihOOqlTD9tJsDlZAcPy19AvUG6RkXQgg7ENHjHndxsIAROCcwa4yW8Bvxxp32ygQmz7bGoaD9hcPFjbAdRVVlo5oDwMB/i+6kp3aHBtoUy8t79poNqPgBXHoh0SWE3zDJ8nWy1Hl5PbjqsAZPPWDw5pM/ePt+SLywn3S2/qptmnXFfU/bD6njPoyoL5GCvvnJ0Wk/vv+YhjlvY7naEMDg+VnQ8O8FUwyOM+nomwnTCs+u6z6cPjue980bg0ed5M2Dm3tcvYYfDIpGgJ5dDdowi/IvQwx9LFujr/2TpYHW8s/CftZ4BEuw92aGVvVXLuz6AlxME1apTxFb787G0dVC2C+ip+9SZROO2pgel9m/OXi1EKF8WLb3rEmoze6yw3tfZJ9K6bkP+9mDvW5Mv7eNobW96JH4uvojU+8DILZ7hJQG3MMAYS3vvl/72UiEqjuSxYoae5HW8HG2RQ9nqkatFJLTBNXD8gdKDvGvvs3l9V1nH23+f4eveqt/n0f6+bR5fYhP3uymldQnf+lb2M/HHqJtLUYJQNXLYB72PjrQlVl2kEFAtqLVhZ57bBnJkK+oTemhXzvrD2emSWZfC5/b/K/H64zTMeaBWdI5U/wyVEBtHI68cp5rltPDHN2RXwZpTBFkkHCru0CYSdmJ1IXfQS+YLATIMG2cPetaf8sLrNjIOv09w3zX44+cvW33BgrhfPo28C/UR5uf+dQ+RAZyIg0VTFgqw4wVTAEirfQ6Yc7zmvjrjkm9j99j/faOK7PvXsLOXiOqyp+UBjp91Z0nOnO7w04xKjeGCJ/4UZC/lcPh646hz95QmXse5zQsc3qvtS1u19IL/e0ulrxCs/fkqU3JZJMPSADAknnfI3PGwAOAKhdcRW95THSo6xyeAXcXL3YDDFpCg0t/ilE4P97lrA/3EV/pN/yBu0oAHGhgzBFr4s4SBDcC503IBa+78dD1ieASHAIHQ5G9y+kIanpTCKdbVzmf9Yazrw1cwnrCJa67XNIa4JLXUZzyDKfWwpkEu0twPgMsRhzRLymC3is5EpVQFDS0o7QQR8PNJkHuIemecY7kKVnulJLHuuQpZJQwmaPXYtwTumWt38jiVpDNbSdH3kcuA5MXRpS/Ygu4qxTKRyka94TF0td3Stw/EX7MTRsRWATD5w1mwsszCJwaqvmehwj2soj9Co8ShcpjCAnhcWjJh/gj+zCeQJdLPBGlNEgCewBPFtrNPAV9UJZq9+dp0HEksBGmgEf1FmnqIIDwEN06FrEf4VEmd3gMPToeR5wYiCd7LU+QnDE8ET9feRJ+RTzZoEbzFNK+5Kmkw+Zp8BO7s2z0cbIZrNlwrerUqNVOSa+CVxc18RegUaVywxG6m2ijKq0TtPvCQT5SA18nWTRqsRIAtz2CVR1bBYdYWOlVBP7myqTCS/knywFrEtqxVWmvG1TR8J88cJ3Xt/2jdowAcBqkylBlMAgsjbOpbEgPMxbRGh0aD6e2Ar93ShHo5013mIhsEMURI8SgB8JWa4QSGkd0L8+WcTY42wYHOwAj+/LP6sBargRNvv6cJ3NmngtwndRgWQXbU1hmnYSbxgUbtnd3sGodAEDwN/3DZQtmA4thzJDu/IDGxaACha2vRMPBQ7O4rzYdqpIaDV+oKwzWBCy6orGtIxUbhy9kgmbFaBq75PZmniartxlBr/DnN0zwzcA2NxIEogBdkAhB5M7PHwoqGjoGJhY2Di4ePgEhETEJKRk5BSUVNQ0PWjqe9LwYGHnz4ctPE8QkMCp9rxAiVJhwESJFiRYjlpmFlU2ceHYOCRIlcUqWIlUal3QZMrllyZYjV558BQoVKVaiVJmVxuk1z3RTrDdZj2mOe2SpDVbY7KzTtihXYaZK51U545zLLrjokt9Uu+6Kq7aq8VGfW264qdbv3pmkXp0GTRoNssxgLZq1qkhqN4ReU28NM8JwnbqMtNdyo40yxlh/eG+fftu88NJ+r7y2xh1P3ffAQ0/c9dh2O+y2xwk77XJSt2Mm2OiQww4EA1N92Ep9Jycjthe2MFoA"

/***/ }),

/***/ "./node_modules/base64-loader/index.js!./node_modules/scratch-render-fonts/src/NotoSans-Medium.woff2":
/*!**************************************************************************************************!*\
  !*** ./node_modules/base64-loader!./node_modules/scratch-render-fonts/src/NotoSans-Medium.woff2 ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "d09GMgABAAAAApYYABIAAAAG6AAAApWrAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGotAG4PVRhytAAZgP1RURkGDfwCULgiCdAmabREICpOcUJDzVgvlPAABNgIkA+UcBCAFjRQHgpEVDIF9W40ftg+eN8b23v0hip5OD4RDVVetaLVmXyO82wBBr/o2T1kENmR+ItD0NhHQOR1jeGDAlFSzupYBVeN2a6a/UMBtA5apqd+tD8n+//////////////+bSX48udnM/N0388suLE1aExTRKHpisJ8l5i65QlBw8xoILKZCWak1r/WqURYxEpqsqcYitajd8UfUYh5ll1e9Ikh9VfIDpdYwGNloQJ48r40p+f4k9muBpr6BWRlo7hcNrSUdUr0TAy1ZD4GOi9ZqXfITOcpwT85LKlAbn1AMTaCclqcbMZmo6jyEMzYNdhY3W98778WLbzE5DFXQ7DykwC4lzK8g7KCQ4FEErnYt3ajYh/sfYgEIJRIkYxCQh5HYqbdtxJaZnSO7wZRCZMt+behD7ZbKPRgY9mvqTWkfRCBDXwlz1ROabRGoHiWlveudZr/odrtdNs9h87uwKehwv+RGZxBVrNOD8Jj58GlAod1mj+5Bhgz3ZzG21ltQ6WnnHtyj82p6r2uldH1DbVBFloKkN0JkkE69ErgnVUHXGSwWh6NywEJ+m5tVi84bNMh+LE/Eff8F9PpaBE8VJn5YfVs8BxaUFRtPsfaE3p9hP0otz5eF0QR6Fmjs2WSOa9qJ8fitoHrzkVL+bt+p5N8/6g/ben1VJTqKNWpTo0ElX5klL5iJQDTBTFD6fJGCtnr1VoofKVAvcnMoRUBEBhAXJy8UanR9noL0Q0VABETA+fZLujmOUkcrkzSQB1eIgAi4ngz5GV4hGy2U0qdnlx4/jV/b18zzpp/BqACmBCiUAaTN3ep9rvtFk8J55H/pW0GXbEQbAh9S+dFfsAnbOvTd/PjuxqsRTAADBCNVU1IzM/CNKkCgoQ/mVRHpxmw85PdUSa/dw252FVNyR36UtaQC0gf9Lf3Kwc71M2qsqtN3FnLzKVYoHouiHSnm93ZQpcR9jo2ivbPf7s8y5I57T4z9NJ7Vwi9qZVdkX8wP7Rr32R0yK2hNS650tVHuOTg4wBoUSNUBWT24q+uKQrZ3dHHxxmB0BmHb2DUETxiOuDV+qhnrO0D+kB6V/8PB/+Vw/+IvHLyVkbHiWLp7Ejw4yJPyY7KOSUrg4DFZVpeX0iHPKOOVk8/PQSx/PwhKll8ry7Is2X/5K+SUUkop0mV+kMFB/vEgqWpukV8rRBUNOTbx/7zMCwhDbi8cAEARQmqyldmpeoNRmIRZWIRViC3tjjytLrdHra/DV/xF6J/37/+/GjX31Xvnt6BUyrpDgCGAyAgt3bPG8Lzd3v//xnLurjPW3TmcdcadOTtrnKzsiIwVmrQoGiiiJI0lIVpqK4WMhpFKZEaFlopydwMw3YLX3vuiv6j8IvLbv+/7e3/z4ESkKLRItbSAksIvWISkAiqSUgqIIj9vW9WT/75VFW6N+IgIrI6yExVFH0Oz0c0FEQkEQXBQUV38R2bNPlg4+dMng9sDsE0bwaQEBAMxMCJAIiVSCRUTEAzsGT07FuryW3/VLtx06dz2xZf9xbd98f3/nzr/954jwVt7z1i3GUJubayQdkujplTqKaMZ22O5yTCX61ufCPqZ+ZVW/mQ1N4pk2ZZpwR2IU6An3YX+n7+H3+x17iuI+QsELJHGE3H4+XavFeIDPZA00EatWpSrcAADFPuZhc/37CueFBYOh6u9amwyEZvQx2oJW4g8c9Lb1f7/tvXe+2QMlV0GfGAWBtYQ+6zpX/miQrzCws8QTupU6Uyq1PEuVR+/8lf6XndPz4cREu0RrHQi2BPyr5WBuHKCLHASOLMj4ZUcPH7gp0hFnVmw5E0f1MkHeHTs+73ESDrgNo4kPrK3IBcgZ/7/TuSGlf5+d4hJkMzlS7ZpyP4gok+nh7oDbhsN/eM336o6Vy3Jec5kkJaAe5nhCwDQgTDP/h5/6IvKS3OX2pz+72xkYgbbzk8Arogn88Cny391NShpJC0Y1oQP1gFC/wC3qYqclHW6Mv5/bX7/+5RSJAQoxAJJsPgV7fZ6LsNvg9Fbf4C2mYtIcxkG2z7q2Fz7gcs2EsygJI4+QvAIEbA4QtnEfkW0MWvR6Kqhjy56q97s9fROH8rXgAXjGMCwBWwIaTcPuAsxw1ATHEmSPKpb+gn63/emVueca957/2fCEZ7GSUCSVSRLbaVSq40jmUMUpYpAYFwSYFOJz1W1xiwVuWAmhhFiYLGarXeaf936j3mMESBARG9y40oChOQyjD71FbVOvXT5NvObbk//m2rPFs1C/zpqM7+bV7jjT9cagWeVIih53FqikQQjt4v///f99pnu8IcZ8DcAZs20MwgsSosK7HPAgRW3Irv3vjno1/+nlyPp9dIdnV9v9bp7k7VWsvZ8rLXWSrpJkiRJkiRJxsjIyEqSJEnS6/WSjCRJRpIkSTKSJCtJkmRlJEmSpAjIBASAgTVbzqem2yMpEUpgYi1a+yRoIqs0n+6JTqKRSAxpzfVEMWnmIfJ0oIc/cLe/1f69A/eAA0wtSwOLY1dq+BXQGgzdDegbRCZcX+InDouxnWD7gbWIoRmiyQGcrpANZsiYwkSsJmmTJo01TdvUkjQ13dqtM2fAbZgdpxzjlLs3O9P9O/e82IlxnL15AfwHgZlqZPeeewcmAAtKOoQRr2gcEp3qq356h9bV//Zu/+06V9tOO+OdnvYODSENIQ3bFFlCCGus+TNYtWfCirl+KdHJ2r2cpMiApIbNmKdlbpOHUHqTOIVtwgiUxI+pxld4Fhh4IBkhhFKw5bQ/hdRfLJprr+pi15/5Dr+8u4TblrR/Jc2MUyoKK6V8tI/HKR3BQByAF+C8BfBQ4PnX1M+LwQsIM8OQBYn64ic3hVStA4636Hx6V25LGzI6SGCr4fPxcjjyMhypRCrRWv3Y/9t0Dx66gB+QbVzqGZUlY9dKXHtB8/XYXK+E4WLYIpVxqSaZtey2d/vx7hrPG2O9ImIIJiEmwri9v3RVvTJVLJWUL0nACYJScVfT9u5M3ieyiKyNcS/8i7POdKhn/Q/v+3tcgtltT++y9P14ghEYjSYISTAKoVACIeQoLOSmbdgLDw99l971P7ObFyBpnSSgXSUYcct7B6EV963p4/Mk7ME0u6EJXcjRJnwT2rLwLGyqiB0AKhamQpU/4c/nVhW2b9SKVY1ZyZgJKUbEbr1767n2XClBPYGgCVEgFEQM8v7/KwpuY7GTNSXr3ASXqZza7utmdktgoCQmiCOZEzZQeVdrW2mUjdvTTFUXyHPn1+feSEkJLnGBQ7I1d36vrqSiTHiaPzdhQ4AOHJK9u0GQgtJSUaeoVRVX5n05TKBuJcvtpwWlUQaMIPAPYzb429txmpeaCAabiTCQAEZOJtn2rWmFIssLx80gHPz0W9qb1md6PsrsOZbsiUb/T+wLClGOiFFzfn4rGhV262sVcTAYLi8zp9TsoczE99f8Op6Yw93n8Ft3ynbECLEkrBBbLNQCA/Rft+3Np6tTCriCmkQC2QQCjCjgrNz7ezuZUPaSj/AYj0PIX0pDqL72TjiacSAUQhMKcAN2V+L//1dn/3uuZWeuDKyRYYpgGsosZtnhFcwr31Pr5yv9c75ev3dflXvulczVlQEVw0jXQGQ5ZFQMka+AuJA8F8izYQptaqe8kjBNujJEsiCRZYqNU7BMGjDNpJIphkxlKiTTWuZNKe37v3Tyav34+X+fpTYe+va+s3nnpoBcN8I/9YWjWfF2k770oQwISRSlGxNpOchIJH7ftJKOVq+dAjOzEZxLkRux22r1/rerleZSYIf8DJChqqtKPaOZvbmUkFMECBnykZwjD/+/UqX/xppjDatZW2SxmMWAdaNgNJZjvfy8JGNl21HUZdnkk6O43VFRCdlwDEtbWv8/1V7buRw8EcNdHi0+lBIkp6TUp9Q0DqkogRkMgYfBkMtP0l80l6sQoZTX/j8rwiHFVkW367ySU+y+ffpYuy/M0/NLfzrZOfRREBmnkfa3t9RLLcIiFHgcyvL/96Vabd/7HwFEgKYMih5AydUma6TsrHPMzD7dywZAyKWsucdp18teRtz73r8R7/3/A/g/IkBEACAVAXAASIpEgJQEUNIfAtSPAOgKgFQ2SDmzKaezDu2aKMuVR65RBmjJSXpIU4Od6RzGVQ/zbpLdk93jfPY9L9bTsKplLbt71dte9nZarHqxXPVm1Tz8/5XyPy9712sRzHeb1CavO80CNKc4IlUvxarFFiuC1RYIAPH0eZCamUjx1h4QZktf70IFrvS0IFTARgbEv7/e2aZq76iy6vIRSrQOUOTwlS9Vm5XI9QpJahQeIUzh+dqbvfTde1blVbfD9IpoHDICkRAjpu03qv3qM89hWlvl2WdnFCL8cI1CZNgEmVADxALR5Ph3QC0wCxKJIf//11pd8wRzUStxmD0k8xSX99f+DKaSaJe2KdJpJFK0/5ta0pU1X75L7KSje+FHoArKERpC5D/zRzqNvrQ71tjbnOuVpVlK03qJ7aSjhB5A4Q2wsCDaaPx/zfRtB7h4DMCsyNXqcPgjj1Q5xKLjOo7z2rkquQ8AIS3mcXW0XCUmhxBaDZ1AOi1dyaVdlbkqTZQtlr5suHUgLEqWbCkB5AUIGo3j7ftzI4eHXxtWL9x/YPmxijUpqAaRjZULS31cqItrfUSTA9bb79lKKZT4f/iTiQdmnXdpP9o4CTCe//1kIT2s/XJq3V4agiAatFrs0r/7RVaFcCsgneQwd+0u1IrIIiIhpNLHq68+S/0/keJ/z73PLOzwRsVYMSIiIiLiioi8/qhatarW+Hfi911aurClq/erqhUVETHGGGOMGBH73h2FuvV+CRhM9TRozcHMSx3G4Yu6IdP3DsXYUvThstRlLpRzdi18jJxRYYSoijKxPbfsp/x/AwmolVbKodQqQmR47xv7d81RNgv8zjnlFhhaocwKE3vBPyvFkl9sqwgysq4Uryc1YOR7t38yzf6wYbMpey1lcxNvYoPAVNMkVNp7Evx6jGk2qfnvGCtRM51RFBSUgxu979esxWBm7uxcRzJeXCqKCirQTZ9VXSWT9/ZvD1nz///GYk+7v+3/9nR1AUErVQQUlCWBLDOTxOf9ufpzk6nW3ddiYxAlYgwhIsWGHSxvP34gqK6YHd1mODjWF75OTbjEZv2vjE1mk0l23r+S+pvJEJA5AgQIOBw+TtmS3K2WwO8k+v+cNPOg+/+/uzvGFWWUiN6IEiUiItsiWrQL6TT+y0jwu6vMoWIxDxNMfLf8eP6eCG/768LFUIZSpIhICSIhSJDg830Xq/nx5/y/AbSv+/P2ricVwrDY4UawMjJOknMCVXBi6E8SLlZ1ByK37YLlb599iYJuzFANhRD5PaIEGDJgpgBzM5iD1JVLx1k4iN2OgahyG8TduIG0JmKQgmoEYrkipZtVrHRr1Uu6bRov3fYlgOxYCsguZYLsWQ3IqS0GOftIDIoo47dWoHb2yQFqj9tjkPasdQC1560HqL1YqECLzCIDtMgvgUBL2KIAWtYt2UDL+kUDtCQtRUBL1lIKtOz78ICWynoO1Bf6AlD/MeSAhuLgAA37QQYaroMONMJGMdAo2GSQUbTzgMbT0Q803oxhoPFxfAQak2MKaHwec0BjYfwBGstj2UkDjsahwQQcESyFI4Mpl2CZy7DSbVgw1p5z7bfYASsdvNFh2x2x17FnveGis746979476XpP+RtgCIJWXkoC6BjCiNz2Hgj3rgEUhPGyzpR4iRJ0yXTmCx7tnpzUAYq1aFaG+pt4KodNDvAdSdocQN33cN9j9AmgjeqGDXFrAW+qrMaWudwaG+mQns7D9rEImhfVkH7tg5qZyloV1RCB6OhQ0kJnUmOzmUgdLsheKN5UGMF8CYKoT5VQn2thjdfA7VQC++briWAPA0DGsmNFgujZdJopSy1URNt1UXb6VI7wdE+SGo/Y9TCmurDRP3sqTouOsEbnRaIzhlL3ZKNbjuaegsevYOMPkIEFhgZLLPDjXGM48hOapDIf/zVn5d8My7lVgCDD+EzEAaCU9h0qwc6mywWPVKpOYDRnfgHPQ7hDz3T+27rgvIrIapOT+p2Zq6tDmarNYLBlgQmO1M42vOEHpztDy4OBVfHghufB7dO/jc8P9Thq5v/w6O0n4bgRZqy2qOd2xFRHds9Ycii01R1AUp0kem3LmFwXRZs97awVHeMqBaath052as+tNQbQFgfxNL7a/OWrdu4kVKabO1jMibMWLCa1OaDwxbGhF0w+pz2EUhf6N9B9f9dBHbgsARAGPJDEamhMThQduCQQOty+6pGuYbpEoWpcTlYWhUXa8N4sDGGZ9uLljd27/a8tTeDdw5k88HhfD45XskXzdXxYz8S3ImamFjaFl74xwFp5yisesOrznvL68g+9TZ/X3jP0X6MzctfzJy172GSZMlTTHkqUplSGpImk0EqW9jztacSUkakZYwaN2HStBlz5i1YtAQEgSFQWAw43ceV7H5aezHx9HHjEiY2xrMXMfFScOsKJsICuMH/6Nn/74bHjf5Pwo2JlyuxYekd/jW30zgT0juGdQ66fEFhUY2rwVk4zCp/8NjAon8/3P/pwd1vEe+/7tfsAoDBAUM47uVAFQgKYFtn2jrRCw2fTbf2CUjsgVCzYIJ+2PfiIzwsIjzuJeyLqRKTfSEqHdinDzArFSCyIfrzD9s3drXwxV1NwmjGguIGMPqSuw8BFh4vVf+gHvVDX4JCfGjSMuD0CoIYF7tXyEGImwqL+AAZUlFBGAC6IXh0OD1jK8ctlT1jt34cC/rKg/vx6LTzxo+ogp7FdIadbt6pudFMDfv1P+d/Me1H6FLsmzKmevXKNjatBJlK2kPa1dQLhTooEyjZBtce5UEWzGLIxlb2X+hUeugKZClCh1UMnqMunQs2pmLVfUrVSPVEggSdqHVIyzpuIB0oKZAUUlFnUAv2B3RReqGPGuUCuft2JAK3uxLnggdEo3b6Bmf+LmC2K0y4hoURqBDM8HLGfZu9SOzhUEXFJnU82fHih/ulPXiyu+ndAeMbOt7uhvvGcICLmHwtFoQ1b6bbc8A3WEsjEMQIdD3wQMQ876iolL7oL9DVbdW4Ot5362+JDdvU+S5DmwIDpIvQXfhbDaWhACIho6CioWPg4BIQEhGTkJJTUFIpp2YWIlSYCOukyLXLbnvkK7DXPoWK7HfAQYccUe6oCpWOqXLKaY889sRT7Tp16fHCK6/1GfDGW+998J2//GMFMRIIIENSkDRE3cQjddMu51W9WDbtEYwqpmW7nh9ESZZXddv1wzjNy7Y/n18wihGS43ppVpR10027/eF4Ol8+ofgoGYB6ZB9zGRaIiEoQlyi5FFLKKBRFB4EgUFY2dg5OLl5BYWnjpkybNW/BohUQBIZAYXB4AolCY7A4PJFYqdZojVY7B5/DETQGiyeSyFQanQHEhHJpcEAh51xyzQ1f8ICHPEaisXgiCaTSuXyhWCpXqiysrHVOWNg4uHh4+fgFBNV8hu1J7H/dQ0/nKHogiAEMYYTC4AikJQAQBIZgcXgCk8XmcHl8gVCkNxhNZovVxj8CoUgskcrkCqUQLoMsZZSVnOQsF7lq/y4WhycQSWQKlcZksTlcHl8gFIl1vsRJWVE13TAt23H9IGzarteAaYkH0OPTlx9++vbqvpe3gmmnK9lDiIfKFbVb6tLvabt5w1c7VENq0JybeGPNWi1iecV/IZpI/rN8+BGeFFUYWElxPOEiEro7dUuH4JZ+DDA08qmxP/1d/h3ruCNYiUIkHc57iCiSdkEQaFh4RFKkUcuqHX1ouliJUocdUabcURUqt491H3+ApReult+uJ2f8ED8n4ntnmGmW2WXOGYR5fpdlbWcSk8gCk0Lo6BkYderSrUevPv0GDBoybKSMHz0n7YCFK/i9WeV6ikIbTBDWbsKVK7zUssAClcSj2h11+XqlVfWFM3u51UZzDyIAAAFEBAAeAkXYR43bntcT4Vx50ZCjhsu8yw8tduDJCxB6jvhhk+lS1bdtD044xjVkVjevf32al+e3hgvjdGzQU8SOFSir6riSh0pRqdKky1BLXCTtBiBwQc7AYThZMb0kIiLykYKIz7/pEzfQ27xkWSF9I72jgqxKQao06TLUEhdJuwEIXJATUWa22ePO8qhsw5rj2F3CFzx3jWsesQ1Ga6wLS8IJpp1hMWOPjSuiZ90nFHPH3P689HT302pma/a0vYps+iEo2FXUDt+TchkRo7WXNPym5KBLL+vXO/no8i5nUrO6WuYp29KS7cXXeY79kw2Xbl63n4kWOyXyF6qDUYwSpXHYw47yWXkZ3TArCcHpeBG9I1MkDtwLsqNsadmx58CRE+e6ukmklFJ2xFY/tmG7XHl2TPZekZBloKCioWPj4OKB8AkIJ/Ktc8taVnUzrhD1qiAKoQ3kjGZcc90NN93SEq/isKFdh05duvXEKDGOCZOmTPu0LaaWpN0ABIZMiJLt+RZYaImlHDlx5pKualaNqh2IzaBr6eGPuJs+wNfoCPECDgKloCDgD3gB9S3MwK9Qemxl4WZBbM3kWlQ4F2xjjswFelpmShTCjrJl9Yc48eQUcuVB6NwvDw5BtXyGRRw3OHFdDJLv2onmZhlCNATq4IrQIPLDIrjVwlpNyNFFcGSW70OyMA7zHckAJ5Rn+/JZOQTTEeaBe5urTjkTF3DJjbjjhxll54aazNtwXHCxw+r1nAtd8pl4ebABVzW5Efe8uE88RJt2vTFA/UEUOkhH4B5BiJjEXm5HMnZFEZOjk0rH4wRxEnUaXXXHPQ8802EwhrLxDsMxjRnzvvnhp7/+l5XDjxxhvcs57Hlb7A11ATPhsrt1fh79DohePYteZpX5On+QWfS3Jl7JeDNw3pvyNLYxOzUjT0QmC7BghH1363aOTHQzbvRvIcw5h56AJkAnPvsaP6T+RLeZW5iuX28PPTJwd0CRqO7Ls771wux5W7bGNmIYY3VSMNL1iJKInbFeFOV+fqJColLq8anb1cSpXD0trG4664abRoz2hMaCxjfx3d/5kncVAdTZigdCpntvvFU3XPYhboDnkXMMHzAzGm1ocmFyMS7NWgu/USMf+IC3IOSu34aPfTDsuh5+VxGHeGmx348KektRFTXLaWf7yn3VvmJfbbnw+t7nS/ECuxbzgt7W2vTzdd1Y19cl0g+z+ktv6IOJs7Kek7UOR0u0fIUkirJecpCdfzjB0iV+PxNZhKS0U/x3g1lvdmPp1ejvBmcSMSh0ozycBpQFo1xdva98QOkUb+M9PtSFYpVCF+Yw70mq3tN17RTD54y9AzFOyWHtWezp7pk066J6tGpPfV+5p7+vbk9EE/vyarzhFRpBGnsvrZsBgU3HrVmqVsxsc5UyvNV5dXxDiLs+79oXsJRIai0aEZi35KzP/hNFyvkgmxGHsY7NEmwHpqkIraGr/aG1jyZHmdwtMtvqGo2oHVj1PjxtCy+14DBsxGbbF3ayuCOvzSIcfsTwCQ2WW+CwOn+hbRnItk2h1VheYXcgb0+IQmwRgWPA0JLtwUzWBxPggxDXpvhIVFsi+1NcbFL/pHsPwsiikLzQzon6KE7tZgsClrD56FNH4ZI722ABHs5bKOAvRmeGMAYv3zQ85Y7LAy/jCF6qVmur9UVJTu2rLFsgL7RInnkg+0zhrCPMdQJtD96UYwEtBNEQzbAsdF15FEBlVbg6vEsfwFN/VdwNtLOGPvQAMTCxsHFw8UD4IVDHk9D2cfDguE/rbVjEIv04xw6+f/Q7O46YN36c4KxTdpNeeV1+tK+DKaaatpqk9kWlTzcHXm9/9PASf6tLrh5HPHua9ijIVFVVVVUvlHoAMIlUHaE9P3Ibz8wfXjsJ2cfzUdqsQ44/r0tovAN4wlhAYM9u0+ynmohH/KjnjKsXZjAkLCJbbQkAAldEgz070nVYuILfq0T93VRyOKcXrvzYV/D2AgXQ9W3xtKR9AQgMmaAlvBhYuIIfcF7Wrwbj+4wf6mc7G8oWEctovyw/AQz4/6s+XOZj+z9QflzPjmELdwA4er/oK6dn9JaIki0Gs6q169J2cuHaF0w9/XiTuSToqlJ9UAKeVK9PD7m0nQDcqh4U66e+p+Po3wa09hslfT1Qv1rn9sTvzxlNll9NNn0buddFWGHZ/26pDE9oKA07pF1LId1fs5oZt6S5OfG27f302Dd4WLmlVDoiCqKLL2ZXma/X8cCvnmHsVXtVYJDc4FcsNOmZHH6a+g+9/54nvbHnGFPKX4vs1yb3Dl2oYkin9B0FEsxL4vK0g33EBqaF6RMJur9fb6/l+koKVVJwMRXjBULp4GrGMPmJ3y1HC4EY7O13y/KPD/m+Wux4yoZ3TQThGaSVU75xexPi7lVl9WXmRkROXbUNtBCON7i7d0DsmWFdgY5a6/rVPC90Pvv0knJwww+9cs/w9gQU7l19r2saeM/H2dupXdDcZHPV0YIoUq0mcXMODsTXrL6Tp+nSXo0H6DwHAqedUptiXq4cKMiQXABOeAX9eNdnw2xYnC2N8cB6wk0sapcr3VHpVGInGNvBL5g1RW1tpNthJ91A9tBJGUwFT5+cHFaSdu0lVypmtIJShpxQAUtpZmpfr0+xU5fTF+9IBXro+9sLy0uLWUaYp7CLe9uu+//JqycD9vT40vfWS2/d9Gq0j+vTb/Dlaj9h/cRFYeqa+4b7RwoO9P8n6ug1osWCGUGkh4YHmHd3eUzh7YpTP+X6SfLx4IEo/0f22XHy5Q8/8hOlwIUZToI4A2Etr++mB3jUo/cT++/3wHuhWEVyjKTJnvbfXA3fWzinHHlMOln98IZI/POp7za33ky2C/p5SrFEK7Ar3YRUXyQ2ploqpthyA0OCdZVlCXqlFdbAU+Z6Axpk6HLkadbLFUZYfPoRjVFP+k9c+2yMTQZ++xHsSW92PwL7zl7ckX+F3eLfMuSXJbRULz1P3L73aETxVENAVyLb9yFj0IeM1AMT4EiAeNC33yFz2vZPCnuX8XtSuppJB5Wt64LSRaTAhJSB9hPWVjL2wseX6bzLI+iV/4avrFYQTh8pEui7B7Yw2N9T0IdluDvszTewn6y8h2ZL6Bns3YBdc3eNnw/I6cbHS9EMeICYftyFUun/H2FpPy0aLezH5zkTgs3HfRrSwkd5UnJ03G391tplgIVHp95duPcV1GNmD8xOYP+/N3Kj00wVOA9tmgZwZoKQhnpSR3rjoMluFQHgt/n1fLkinK0mw8qNHIfWCryEFIUwRGqmqDAs7dSNqzVMdgjH4q/wfeQYIyucZu4ztexs00DgWqnd3XCbh7u1r0c6+emyVo8wL86Fe6VPhAEjos0USf7WyZb5R4qVwzRiAXj4TMIANs4cyJoFkD3LgJxZQ3QDQwwTI8+kKMbkqMXblOgOs6PHnBjgujqYOw7lGYpDaUlJvw6O9nuqEVQESKUyBw+u7pxpnEwdSc5Rj5oLDh2XX2cBdUdyhXrVNESrpLE4q7lW4v4AuFEybpaOWxHQUgZuR8Wd6LgbA/di434QHiT4Bx4mNotHKVTxxMtq6PCKBXR6VYRurw96bfnFC+9Yyssi8km//bWNQZ/ZwZDPfc57e3zJsP3ho0MY893NPGTcYT8y4U9NMuO0M3z2s1+Z84e/+ebfIGAxaBgLQTAeJkKoTPJFrA0s8SX6XkvYaafVJ7WFvcMRGt+IhCUwMlEJO3udEvEH6ZzoFOmS7NQYmB1pdH/2BPTnHAlH74xE6pGsj1rfbE6eZ7M9Ws9nVwxezL6YvJyDKfVqjqXcmzmRDuNyOR9Myf2MuS2PM2tuXmfRPfmYJQ/lS6lbvLaVgwcWukgu1uoSebWiSuWjMPLFKfsPe/msh3a5X3pir/Zb31mEzMUUFyuLe1UpsrxfrLy49Kaqinrv7C9j2t/2r7HtP/qv+Pfv/V/W9P8HFg4cdlhKogZsyCVmYId64ufyJiZo9jQ/wXNFZydmnpk92d2dczT7e3xO5Gjb50IqenKKUtk/8AK+8M7AS8F1R3mUMRzVUcV4Ck9hiugfWH3QoFGVBwFVxUhjrUQJJSAgFRKSEXBQMFFRZaKFJgt9HAYGuBgEBDIxIhRiTCQTM1IiMjLFWFCgUlIysKaCUv6KEYwbXx4tPEc/sIewLIZTKCJrhbMwRFJO3iq2vKZ9EAqBpmiua7ZD0DwCVVCNGsUJNaQ5Rcmn9RpnXQLzCJHHiDyB0AbmKYRnYNohdIDppGv4pGvmgm7RbUDxmp8+KAageQPNW2jeQ/Mh0YoCLk4Nzv6lDiTtlk6Jjg+PLzO64Gqcts6GN7zgA4AlBaAkDaBEJVOrrixaW7EVS3Egmju8eXTFM57BBx+veI23qxjbLt7Fu3gXr+ID6iLIlxmoRZEvC1CLucrt7fJVfoDICVjOoCW4UAgX/oCgUOQmh6wwKFNCUgR4RRE0FXjFIbdcCIoncOoL73PLrYCDoBVfZKIr8ICycgjaBFmbkdky6Kt+qAniSoYPOogPefKCySNZc8kfcIzvSWhY8wbPcyqPuQgKXrow6S6jA3zroWEDaF6Fgk0XvuGtsKQOCD0Enveg4X0wfQgFH4HmE9BsA8dnHd/tdiClejmewLAXVF9AxZcXRd5bcWMW5gDDD1B2BBhHoehHUJ0A1UmoO93x9cmZeD4HFb/A39cvGJ1wZX4Ffz9D0d9Q9i80XALDZWj6D0T/d2XFlYgURax4JLAgSj2jX+CsIRgBVhnxE6jaOxZYB4IJGiuYOLCDOziusJREgGwnYDuDeDWwXdCODjsGWjFhxUElHlL2wzwBHglRTwQvCUZJcS+lJLWpI4NbCtxKg58KjGOQ8jowjoVZDublluQ176e6GsppIeUkME4uSak+qS2YNJhXBK8yaJVDrQKPKlGvCmHLwHgbttXgWj1mNWBQI/yae6Sl+dMKhZajWFs17S1MR4vS2f3TBVrdUOvBtl4YDYJxGbxG0GgURmO4NI6giZLJVs0KmLUSg1ZBazXUpkqme3rWY3UbUGljyR+tnc1QaAuKbYfWDqjtKtnd69nXW9nfljkIow7h2OHyONL7n7/+g8oJlWaR8hMwbqvkaZ/OMyg0h2Jn4XcZKb8C49clfe1Lf/sz0IEMdjBv+maGwOwmyt0qud33udPh/N0Pcx8aPYDRY2x7gmtPMesZBj1HoRdlXsO0N+j3tuRdF+Y9aP0DtQ+Y9hH9PpV87uJ8g34/oPUTar9ALAa2ROEAgAGVgGAE3mbjnAsuJJeKK821xz3Djc/9BV8s+TLgwYqvQh5GprGZRSTIFIUyGZOKjlT4NMS0pGzA7KgZ6HNkwrnkKsytOPfSPMrzrJxXdlRbb9GVpWVWVmk0WVun1abTBdHOhk18ZRPfmOPUFGcl56y5YMt19tzgyE3O3OLKbe65w0R3beiPkvv8+UsgDwXnf6zwrteSkUxEHWcKyO3ZIVP2nQK2C3oy+KlUQ88sH6gn92JIPbNXQehbezXym5mPnBqyUwalHw9Api6W6qKgtjS+uspDviSnveLXygS2364KX2t/DH1F1UDOj0BNuRWsDZ1CxgrWns7lC/j+dQM0qqAX0BYBpIHCYgFhVwv5RRbykCsEdOZB7gaUrV6ABha+hewlKWp9prPBzWezHc/IfGA/52vsuuu0Dudnz+nft/MoOOAKi6efY/01RawyI7kF9LZ4wH0JeClgoi4c4DDhcPe5CCksm1pSY4f0ey68wQ18j0YHaPjQGENjho95krBNtrRLhdZe0u56LKup6QhwBcKNEu508JjT8cYHOrw9Bn9ACGEIALEGhkAWBNEiODFl7imEw4QodqTwJDc9HA58+CVa4EAHOki9AmflY4hzamG5rAEU6oDmEPc8hNG4p9Aq6DxG4Qk8bbA8hecZLO3wdMDSCc1zEF3QdIPogaYXxAtoXoJ4DaIfxCCIIRDvQAyDGAExCs1HOoxBM06HCWgm6TAFzTQdZtBZQmcZhv/oiNCR3KZCD08CutUwEwM1TKEl9xJA11ejSGlUqY0m7UTsC/pJILRhCqOywEJWYuE2Pi18Wvi0iqSOAKNuX78KV66eevrqG2hgqCFPHl++kUbGGtvvkBwbhQLKgcKFVa8xwbzT14nnF3Z1GaTDw5aflAKsggCtSwDpllhgTnoaSc5o+hrOaPrqPdXQplZEt2yi6zZaabtdAtONWF42SnT1Ritt9wpoFiY0w3kV0YMSN8abrcVFtFTg5kACY/450XJ5wJ6XtJUFsMe6144rGqpPJukLuRQwvi6TeQwnD3MM8mtVb2iEMcmSI/NmWPK2bsCyLWDanqga3lTshpBDKFlf+QgDX9sftAEHrgd9A4J5I/h2u+2974fnlOkjkC3Esf0NPcedACG9KTu1h2wCA2cSRHUE1oU4JyD4I5DzZ4LYzhpS+v6RIINgo2CjYKM8qWBfMCwbNwSWxY10CbjHc3ocNRh4WGgQEkwR4lOCHDKz0swaCfJ4U071QhJegpC+Vk1UMmAhI3BlxnUxu1THlxsUARkBGQGZ2aZlpHgMQnNakw5ZayYvdSDkya5VsztpGEzEcwhN1phTGfOJSF5ISjdAcjghP8J2W3m4g3Tej65MniwmZazSy5nTpZ2N/OK8myC23+vMmXzJpkGC8I5RcmmWICskNwSs3Ez0hIfgUcHbunjQTXjII3CiwokKebKlmk6BQXoCJC8SRHtkBGQEZASqDBjSZ0ifYelnRMDKaKCXsQDJRIKYPzXBJ0+WfMnmc4FjXiUE9jkicGDPgT3GlPtC8ruAnD8BIX8DZpYC5fxLCP5jkIOHZQx4WHhYeFh4WHhYeFh4WHhYeFj4wpasACr5Pm6QYilSLmWMYmAVC7vY1Ev97jp06XRcdEsXt7j0So9+6TMoA4ZliFc8/OIzKiPGZcykTJiWqY4jCtAgaBA0CBoEDSpSORZgyqlLcy7ySAMSDBIMEgwSDBIMBRQKKBRQ8JvW011qH7kSuTog/l2qe3cuuuXbhXAC8TmtwroKaiNoT+ltf2/f3usxrb1FB+5HSgi8IvbzG3DqQqKbiT3aJpDulxPtUnxO7PWlBY4F4pTa9utPT3oH1HrVh4C5nPAuJ0FcpN7PYpSJnmqL/ffYWnoQsWQAf2y7qYMGrLfRUdtKgwk89zYFpUD8KNPHWojPnGwibQmKF9yldrWmNrabbdptm09xn2dm/4eB+RHctUivQdG7yflJrmfmHIobC+b3mtOgPna4/w0gOKDbnReQgG5/H7gAmLjLYQGKjHlI9O/Zff8fXogXr4WNly6E5R/cyp28xKtiyOq7CrZq9Ot5jT9HURNqUtPUvLS8buolT9Nqeq3EE/HS9si5/1ve/txwAT0xiFi5ZW4oDfVl+VpY3VQHpoNYuTpKujrczxPlofLw0nvIR3jmg2E5PsLH+SSDDLfxeodJVrCK1UyzjvVDUxRo9JsUUlf6L26G5ygj26sRYXLKLTYJF7/Kq5ACFKQQhSpcWOEUoUhFKVpxihdeRJGrjGUgipGWwOtfxRBLnMS9MlW8Cro2zPitDwnxoxTYxCUE6mXVxSbKM6Qa91DX4rcz36le7kgfzjPZ+pLbJQtXwXeQDyGiJfLgDn5FS8QOQgccJVTQ/5HyPY4U3rk4d98LHFVWnaQm+dxR3qW7bZeTr8fg8oh2m8oIQUL0oPBcXeK/zURfK9wXP7i5uahuSmoEvRkis9kROuLcof79DNH3z5rQstolhLzdIkjWgPN/fDyniVvQAjl+0tk5ifH0/ZXy4CfcchpHTTxerTSk0A2FD4D3EJtTPXQwMbu9kYbRNbSWLrakTOe/Hymk+LWByo7gfViGHVIfuED5gDyEYNd4O8/nDXyrHCILisOHy+2yslfBl0J1JrI10JfSEVQZ9baFW0J104iM+EgN9HZpXDG/nBWV9yj9t0zFG+XKfzjz8mhMQfUF4AZV135tOJ+EsZ5joYX+AxFUxM1Eme6Efvz8vuF//+BHyi6MigmgGn3h/6yHjX4f+df9r1KFrB3jesN+tP7dDHzj1xD1Up36FEAdLYj8u/pQfz81C3POEbPhTx4GfpQb8OcH4WVZCPe5V61RrqQr3+QHGZFN5H/ysFuuK2fW6I/3MQn6mO/4+AgQ9dP3xtgpCa5fHTxVTz1aFfuG/8cLP1L+TSCuZfeSGnJ1xnoZZJPNKT0GV7ykgPnA5buPHaNc7CB+yjkJWP+jT2tSx2VS/E5qZjFIntFFrBp0upb3TNpk+tXBfRPtRzt2rv9SIgtTP9n+/MmxI7vkPjLv7Jrd6DzAN5+neMpaKEVtpKPsm0Wyt5ka/62G3TRN63QIBhc/B5Qct2Yvnsj0TP8MzehMzHTDtBIT+NJ6d2ZnQYapw2Z1kdyN2Z7VN7gKWD2KOkdzOhdzNTdznxUoQFHEPC3SsujlaY9oDnKYox3jlJ215sxpOd0lWfKlKk8PMW0EbSKhtkwWaoNCC51d+R2jKjA0NJQC9M12vHufLJLaoaVdhmVetqD3eIELXu7lTW15ZwPyhkrkE2s7J6zwiq1kRVdm5VYxwFVetfaSrebqrN4a5lAng61eUzLy7SHXehns0MMy5701W8tF5Fwng+0+utgwZGu7Duts5M67T6M6BT6GAUh0oR524+rDy9eePwTaWbrBuzd2JLsVVe5XKEU5ag/u7bXHVkq7ScsjAjh+Dj45f5uiTBK6f5nadEDNaBYuvjaY3RMGmWszVLO3q+BqGnXw+XHyU5YV83n77Cx4mVpEBotbyt5tYnNDLW8lq1jdWsJA0VBcveOkVqUlw4EOQJnGwK3P9gKkjwhWyTnom7FmDDBKaxyRRhlhsMFiTCDZ2nYjVdGOdnHKuXeaM0Pv62V6WdQAZMyys/nBMjvHjQZ3TbhAvHGePeRZv3NrbkMRVZIFf3Yx4i4DmgQCJNQ38PDwX8hx7IBMsKkL1qmuo2h525Xcuwb9Mu2gvD9Ua+N6xN2UdrdClimKO1hwZxdDHlEMcsTpcf9qJHgop6f0POoJUG9w9Lmv7GXlac/6DcZQTWNVz9wbP1L+aHs3WTnwEVCbsPCnIxvf+ylIIei9DZaqeEzPGU02hD0e8f9xjROv7FW9zGuRbeLlRoeglgiGJOTfvPr1lA142+E1tGEI8519/wBPOkqsk1Cd1b2dAtrEd4GAX6Hhj+6Uz6XGlgI54oFwC+ZoNU3Dn8VpeCPQByIRFhExT6TgEVXe87X54xT6kYOouP1ZO4VHvBfJyJ/N1kAwMi+tumKUoxalebFGJ3oxjDh8Fst20iwlgiGS0pYOlqczkzEVMzBQeust/oYBx/51fItTnOM/+An3TCFs3GfFX0fMilnNOrFmtoeRLWxniF3Cw4exj4PGx2dwnFOMcp5LXDn7XOfWvyt4zzjjZ+TMTycC9zf60jHh+U2yb3gt9/gPPl4rvgilEfcF44QJ/7Aq1pISqWSJNMi+8mx5EYtMlKIRvZjE+gTPiDjEKYh45CT+2eEkJSoJSUtWCoJJVRptLyNPSVcGMmpjSVb/DfQItDlcsMw8lU4nQFcDSqcshs6Kiy9UU0PLtEqzJbhFu5BAvqZIUEHbX8zVyCtrAwgY7v6QrlJnfAEuhxcBOMOITRASksg8jRomibV+vg5FlFFDE52PabSHIaAlyjHGbJVzEtiOaFigo2C2kOgB56fbJ/5zxdyF0GX3BdKdesC8501GPrGM3WNitFAXMHnlyb7ELGEpy3usFqj0PvH3z9eUpiLVqUujvEjwI4Vzxy9IS9oT+u6fcnM/UvbBNzBd+Za+DGakHz/2En8q45lKtLIfzmjmr4mWZT1biWc/b8gP8tCnogxCGb8mlI99nu85yXl+5LqQ3OWxjNiXohStmJzwiKu3qZtIJ+AVXgtu8E6JS5ZWHxWeIJ61NL2hPt4JWctRTtkKkYOZoe7E4seVyZ7S4Cls9jozfD2rEpVOhbPyjherajWqXd0a1KimtagVKrWBSN4Gkb5ED/yvOjWpNb1ZggktjCiL7Vqo/iLTn9UPVa6zOnWKXrctdbclLW9Va9vQ5rY1OMcI7g7TCHS4Y53sTOe62OWuqcubGxDPdE/jW3kPz3xzQn32WS+Fwm9DvW3CpUemhz6f/udTkM8dqGCQLT0p1B0zXMwfn/3OHTwFXyYy3dm2ufEKaSvGAhRQQ4ftVmGEhasvHgQX3uBDEDg5S4hsbiiGcwTUnN/y2FDf9uBWyPXvaX7D//tVTkV+gDk+sMYOR1xI8VqT+bCMPzFhmFIlPoKlghteu25DdShjxYg71e+tqSesFEKDTVzXSgen2IkPoUcgJPoZQr2I882rnLOYYJr7j6HZ7+1WVu2IBgvEXqhaq9cANk5b3anLwePqI07zFpmuuOF+p774xDmJJKKL5TO/PNVDNekvO1U/81t+VxLJpZJWBpll23GBguWWVwGFlZzi6RE9o5yKKqumps5kpJ6G3+WO8txrrJmWIo5JHLe2Qv4QeYysqe2cZ2hACw061olOda7bumdSU5jadGY0i9kNeh9ll72Zz4IWsbilDLW8laxS9gsg3RNjzOe1Fe+a2ibAwTFZ3wP/+059bEMfhcJqvn4G+xpKQkGRUdPjyWBQ/Gq+gOsBgLSfEsBAzaLZvvt2QPBieykplKJPI5X2BtSDXZ0KH6v3DvbJuUpt7vnPMqF/gKVIuWk4EwqOzal6L7ecI5IfMjIymmWQVx6f/NejMLupMFnzT5gmU6JDNs4PAwkmEiEMo6ZZJ7fp4eSepRrGTTd6qayGIheWp16MKnfMspGGoP0H3Mv+h3vZuNhw3AKs3MjYUESQ0dAinh/oRVkBrEpyXnw8SEn0j0w0eHjoqmqrAegSDDMXawFfMbtJJsAsYNHck2AwUWnO/S/EkGJsSEfvVQVghRFAXcvqMbqnAmKEqgRtHg+cozJgvpfXaY8CpIlqV8XgfnIutFI1LVUq857FFZZIVhZdSrG3ZvHDhra6NLwxm2qTURJVvci+q98kAHytTun1cu8aPdg3YSGnNe8ubRHtG/pjQcRJB52n1ep1UK6hGJMJ3lwDwnAcyaW46yhWQtWqg21hg20OK90omy8M0uSm5qa/+K61bQPMq8OFsEbvZdE2fyRQK5Jq0EkpnzLHLoygVo/PZBo9wbPYMNJopbu/6RnbGySihi3f8yKbI/spEaPT8cgVSg3GaOaL3Bi3bu7iLkOFb0eWAWViC7POcIvO25Ni38NEC6uZ2vHBtAWTGbdiOJRmaKDymo822ED4wcYDxM3C+ykHCSqTDNPiNwf63tMwsr/Syl3Oc6aFc55bPgO7DBHI0hiYUMcFVmxw+1PR0kLTaZ5Sx4oNItoOfmbLvU6R/0xfgsfKB88ucMerzEUSfJKm9ZJyv2EybUdirI6VfAPaXTSsAcHmwuewV3GFGqvQrvPVOu3T2DoOlKfVozNxHSoX8y4IgNXxpEnXxBEHBQrmHehtXGCLHZSOhgPAjfGerOksBWEb1n1cogsdPiHfiVgjV3UEwiCJGOYh85nDUUX+ZkVwhCLTfC5AIAyiIyLKxi8VcTNKEtmYR3CmV/U08hKtXr0G1EqWIbkfZfEWcL0Q7QmgrAeXsq4WAwWkJTtoZy0hxBoMYjKiepdhBrKvVirJWGGNK5G5afocbCAeO50BP31qCyOIHgZ4QGu21Y0yctziJtdo5jIa8OnkHFcozWNT/iSiZ4JY1ysclPO2kbeqNbi0x4XmqQbkeXGHDg/iRdkaNUeqjQ7Ba5GY8t6wsI14RjN3bSeZ69UYpbfua32dWrxr5JNZWXBXgNKKk2Rjvqcla+4w0XAKnKbaUyXRxv20ORZegrme3RUudPP+W7MzCmfy9Ma5WJRbSSxJZpQN1n9A/zS3Yn4o2tmLG6v5ohSfmoJdZ706rOJqzRZScisLMJL0zEG1+krW1tOgBlTeqEiuFd3CobxTMcLq1AJbIpbadeE3iqvPJHYKmJ01bR3VUZjqOJSntKrsgyAzu8HlM1OSLrRiqsfNmBppGprpQEpT1pSGNp5Z4u5beds8khoeB7mGT6ocWXUkN4Uj22Sr5l9ynNyKO8ektoRNVgI2kS02iXXIg7PwUwF+Ig0BxkMq0ZW//Gqhwr7jMyvSqWleJu1Z7Y1lfDOZpc6sjc1qMwE+Y+MMImjRsKGZoM7QhLFUCRrk5WeYk9huoicdq0b8dNCwlnWLcaMbdCpr29Spq3DJwgncc1Dw0m4K0wenYaQy0vocUXh3yqWNhn39HGXOiq22OnzRst5SGVw0q/QaUp41nKU/5ZdMd+fKIXcabUcWzl/a+pLzutN91eo/M5MRme5n/HCQbzscu1WTjki58zZGbw5LlPX7upVfuZnITq4uTXQHZGYzUDNc8MAHf4IcayJvuOmWFretatb0iRn+8Z8VRDY1hJgMUxA0rO5gk6OWwcrMNkedRXYpsFiTZnuyIevSmlfpjUrHBIWERUTFjIubIBAlJC27RkZOIZtSjkJaFhgcgcZgBUKRWKeXumFaAlGEdHuYPP+0/d8lhcERKLS2Uk6ZLVYbWzt7B0cn32GwODyBSCJT+AKhSCyRyowxoYwLO+F0ohCUokpSe8vb/iwgKCQsIip20kNnn7dwtaxl4Fynk75CIFFoDBZnzp34jx1kMtcXKNQfepC9iSaD5DroYc9yoJH0ghe6lSMf5ahHO9kNKzoTrtdkY9BrtrvHbNUG6NVbYImljhiYWk2dUeeJvP1yxK/7wp78rxevydoJGr/N9DikBcZFgreMzjXKF8ZtwAj2p9Fmz+SNJATn+x9o/Y0S8OJ5SL2LKQZ3JNmC+/n4jM1IkE2dgQKfMM/LAc2cIlBYApla6xjG3HKPw+tcIE5tzH2htYs1EZWmZ7JT3vSEYS96zowlTI+47AiaaKVzX3WbSr396Kss3TF7F2zypepIkiGrDGXU0PqfdNsY8tyPTzG0VQc0jkjRiOWV0A035zrb/UsnJ1WoVi+lS1xRpKqZNEnjynnUgi0K8ZgLVlq1JSEfWfA3v2hEQotdvraD3Ow5mmpOdtVEEMZa4jKmei9f16RgmVbVvuytSSaJBOIzstrNSzbxIRr6TBeOQ5FqYficCsfsdoEulGal/IrzNag8f1RbZvInExrH5VNfMYpSJxELjiuT6yFRknQLeDOao7PLfV/hIYfZ6s8Q5kibTbb502VLjPrzceETHb608ukVKRdtr2HTvlkBYMXaequtsVaYKOsk2CBRslQZNhoxZoVVVps2Y62N/oC4w4aD1QQ8JZNTSpMpi1qwUOGwIkSKEi1GrK1y5dmnyIEc7JFxSJlyFdpzXNx/Jfwvt5aN5Lr/b3L1UYEco0hspE7OG7hsuVcxsvcqCjv0ci39JDybsT6veIw/wQU3dkFpDvF7q/Ah3H//7v9vai/oBeVLgvkYLt1YXpvfUpLuX88J500AzmbgwQvy86ZotViPrUx5AUSkHyMuhajHqnWmWxJiHKvIpbeoSFDhPDTMoZTL00e4NQt1isEy9y8YjGgamMZqpmf2ohLLWMXmfmveIZGMz/N4TaGb61EBNSyvBQ7NR/voMltO3vt8fxYIH/Ckty9hKyY2x/56LUlIpE2kopBvBKwrrJxVtMr2RLjkNqmcN+aBUrOaw7B0hp7oIv2CSi+cyjAbV6ZVzBcUyixbTtkESSYickYUEoYI5WfGvOWD2AUSo1j8iT12JsX1cqUE0tk5eyyFJ90YazMa50KMb/4XWVGt7b7reVxS5XzIJCiR33nh0pZo6YaN16q7LJe9Um0GlABb2GDHdmKnSSBa9PoTNnty7LZfsXse8f36a/RVIVxQ1TZPiXT+yydUNUJdQ7LcPYPVYw0Kx4Jr/e+bbdVqqfYKVdfqpDwNUV1EfbNw9a1HehMLZ/7STg1urEY2lpK4UId17KUEnR5w7fNqqqI1X0vSgYrXygLDE+laX+7aEv4h79f3ut5cmJcTeW9EBxrTr87rx72g9Ly5kYHk27ut3jP10igOzWE6xFHFw65+44V7NgG9oN2ZWWlr983L2m+no+ElXypk6Xb8Dk3/kyMGj3WbTGsbW1dGe+80ZTQUXC9+bE1zNr3a0v2Cmqk7rM1xyJHmaf4WalGpGXJmW0HyjI7EgmG6oFZtjc0N99yhjdUkqyJtbVG07vMeldHGbdBGbdoWSLRV29xTnNq+nTqpA0en+7s7i43+DEJ6vQoy2GpmPpAuRJlKUQt115ZZ7Iou6XJ/QtutXLS7thuC0/+7j4H27GVkAyGlHnTh3dbBV4X3Vk0Ggm8MPEQlSf9zAKCR77o3K+iYw6xaD/RwNyPdYz15bzTcMwn33L3foV7s5ZF3UQBBtmtb35u9E2x2Qu/1oe9i0Md91ped6Nt+sFneoH8H2aW6DOkd30oRBjC3yAU3dhPy/xC5udt2e0M6FD/Zh3rohhH2YXlvlGUPCn0+wDbD9QPHPWyBaR6+ERyRER8pNR+jgUZiEfdg5KWNGKVRGfXRWlLhoz/ex0R+krb72fj4CF6P3TiOS9dDN8clikfzmB7xlBdRcMmreDWv0eUSPZO4iyHXCJKRkjSk52ATWclBzq4pJ4Q8UPJTiKKUCNm9r20EpSlLBcKgVKUGtalLAxrJrOB9RAta0Yb2XeuXQvJQ6Ec73t9MiudP2Mx0cBj9yjzGLOis3AXxF3+cipc70nyFDS7jKs7gJgvv0LcDfsRdCEDhjdPNclbBwVo2bIaBfXdji/BgdG0mP2VZwXteULTZ9l6OQYbZzV4OcJhjP5w4yZnvI5zjolAS2QGmwmCAKHKZa9zkzsVQwDOAezzmYQ+e8ZKJtR2FkmzJrkAwuBT4LGRCJQwCWCUSk2SwQUSQGySFYQrRYUhCAhh1MNokeRNfMhhfkqCSH6oppS4twaV/QdGVd5kMYNdcjov3Q9aym1lwBrnki8KgUFr42ARYCSZcsxmhO7pgsyvMu0ZRVQEcM3pBHlnbYQpVEMI9F2VpQRDsre4U0vtigMIiVjM/4ffO+zsEaNMmjDvqpp31KBSt0UY4H88Qg0w42pJsDDIo9UU9VvMCkdCr08y51yBrfhoOKxw5ltQVHXUuXQwkuvBUw0ofeTrnRwhRJFYTaWRfEArAULU6umhr4gFGmGKBFTbYP2n0JDGUpGbSSmesQv1IrJkRlx2aA9EbVg1Z/5NkgWWspRbqi0o2FvqU/GRXuapU+6Qxg5o39uabOonaFHQohbDyXimcYjkfpZSXxtr6UwBspF4NaDhv4JEnjUVnMU1qRnNa1HL8Zg9gY+8hWlM7CWtPDzEqdAYPxTHTZeT/Q3TzC/vtpZvuPMmcGoXBAS44FGNeiic85Tlv814i6VRM9dRN47RM+/SVagePL5yu+bbSCc6PGTnEMz5TEz0Sh2PmR8Aszcqsv9uHJ3afrYnP/nyfkzmfH7Ga6xeD7+ZxXlx9UAQthA+mIEKZVmjMatH5MKMI4ajyAn2Z3rp2daxL3S+S1Eo0LZmUjaucDr1MEIlYVjnkFCKP/JsjpOigQpzVtgrCVFVjKrb3EyYIUoMF6A+y8aGpFlq1MAD6QFGndUyQAHSwJJsiJFxJ8wQGkiCUWXfBFzB8XRsSyBWhgval1QuPcgjzzUh22OBTb7gbXgQQRkwDkEEROeXL84SrhuZz8gxLSBhi/CqBwHYwGRcXDpgvYKzBEGhXCQUqVolKw7LKVbtRFFWPUiqopo7GCQP6FZYkL9fo4ht9DDIirOZVUYN8n5tEnccUUeZZYoX1ktsiX4ZjEP8Qe+uFfa1K3gbtO8D3neGE8zfv1Tdcc8djyb2QWEJJAPPQgGAyy2CpkP4fgiD2Lsdcco8YGcqSp0F6eV4xYcXh//Qtm0D7/pnwCXJyE/6LnxBR2yBJkI6pSRNZVCDDr7O8fUqb7qmXASOmzrEoIxqn9rmMZDRds/QfmPW60gboTLd094kmMbmpTGsGM7/C6qjVQIkNm9u8m6tPsJiFYZOI8dzLMSxjOSta2WoITcvG7tnQxjazpRG2hTgkPzs5oAaMAIBt/FsQB2A4IVYa5EE76LnUFSW62nVuzMdgb7cniKJDwQmW+5v7Vq0ZYX3ZCI943C+ectTzix6UvMKXoK4F1/fef5uY+7BOaupdFPzol6AADZhAsitmmQoelKCyMr+HBnRCHLJQhmaBdyP0YQrrKlJ5ZHdoe+JyhPPb3/dSRCEQlx4d8YR/IxGK6ObCBZH+nQfXvHYsPzVFqEYj2tGNQYxeKbQwjUXIxmIVmzsmGd531ylJr6H0kBWysPvlBPNqi0Ob4yasijnb+Ihp3vwwY4aD79VSnqrUpsHDttABvyAIouveDGQ4Y5nMTOaymOWsZTM72cthznKcy0HXwsQ0/M/f/Oe3sD+Pu0Pvwx2tYe/znYDMm6NXYPCuSEQQxVESpTOVKI/25inqIUWBGh0ujKXCjg9oYdfEb8AjPEiEOTjxQcOnOBClQp6SOOq09sA+78+Zie/d8cFaCj0HjlzgRt4U/TfoGH/6z8dMNIp3tkO3dL27Pe5l7yuurMpqqq+p1jrqLFJPEXTNPNF0sy0Ua7WNttvtoKNOu5ntoYbUR/ds7HvSvyTv++n6U/p1DTPaGFM2VZOZlukqUTvL0+/t+X6DZm2Cwrr1GjBszKQZcxYt/45b+/42j9mx59CxM5fttwm3HjyX/Nf8df/rKooiFONiUkyLebFd7FVaRdXV1VhL7Z96obr6Vl+DjTT+lA9FbeM8VyN+pCvzdRZxHjAGZqaxLTOP4njPwzaNBLloW41Ryazk2sawwpPlTpZN+RKP+pnXwT/ySnOaVwrjbSmcL7VudAfH2pEVjDI6UrgBFWOTGVZd57M1u6EWVlm4DkdES8215lLHZCrb0G7nu57laUnZuXNgP/CvhvLU1Ku0WRYbxXSfHMAw9T2ymKWrXkSLn+8Cg3GXG13VxuMOyjQryebYjqRxO2uTXbOteso9rAkxnXCnKgNqpJJejeQW9jgPA5qCGrqPEA4/W+UfZA42VsbGR5kmhQVYT95TWhWprIjiomJ/pVYEbTo3HSrjqSzumtIYVd1mt3LaYSHjdXBMy0xpMcrFM5wMVQNn1OxS1XHgVshPkdRYjNt8ONsKtMYL6QfBwOOqFS65wnzlFqCJr/6sDHkehhmpOdnn5U1b7p0sgywFyP/Vvd6umEUJ3AI2GuQwWitwKxAFpoaGrADzbDC8rSlKg4rEwj4Irw6YnVvRIshDOlT+aeurrdeGM2zgEBtt2yxqvihNb3CWTj3ylaekOGyXg5pcLN6ZAdpXYDcBTxbaS827s8yZxeTWZk08aLPdfMATGKmgYqOG8YLVKY/WTOfrNTaGsDBM1oXmsErhKKKPyeuARxE8ipI3LRYOG4uBjcXpsTHThpUVvkRQQQQVRFghFhGqu8GhDk5L0XX00kS3bSUwlZRSrWk5ak3Kd7AHvYYizaDg9QRGkatoqGJyPzs5sLURP1AZ/bBmSfkaw2xK+EKR16X+FFaqe1ZoAk+P/nGML1WqH5zXo8vBf8Oda3OIxCeB19n3VdV9WBMehdRbZMBTQ8oF3RPXdKHU87LckfrF6We9VrnVpoCC2SnmNaQn1tEbIgtWoih4HSnumCwaYdd19yITKzLT6lnln8NXod0U1aLVzJxcbM7UCB0GPS/GnE3mJ9WNG15MyJNG3Jo5umtSnU6VM6XKMsSl1KyGWNnutgUEOwybVRQ/wKA3tYVy2Apb04g7huh/X+iMxI8+pKJLLa1aSp2gvNc2lssiLoyUzJb0zLBjO2AbZbokcHo5R/OVSGHaUgvJ89abL+3UXXc/5d0iplJP0yj1mnLjeTWGm5F7Kt+25XUgxMJeOtu2FVF67m5RSJHE7eRUJil2gkHl+DQT2DGKQrNSSj4w3Up1HMv0yQwhPgyku+hUGWSOZ151gGEjkXwkCh1WkDDpK/CSlvxe5csQ0Xei20jeA7csB+Ej1FG1ZlfrtZV3h5RsqVzmgoM1pMH2Oc6fREs7ZfKDy6N7FZNW7U/KlnttAZM+Xy8KZBd7h7lqewIueol4aihMhsEl5ZGqCW9oz8VKjcHB5pbBczrsJa5YRVynzqctqGtPu21koGKysSX3ruMjieN+0VR3qOO1Q8iZMcclG4cLY9Zq+rP8gT7UyluzjlqDxlDs71M2l6TOZVTGrPkUVn3dw80MzYwMLIu5ZkoRPO1KwlvvYO3y2hY14dE4VLxe8qujNHSpwNWXXypiv7SLg5V+x8BITq/ZYUUmVhq5QWskq0MlUaahviFTGmOqMzjVsmNhqAV/kks7e1n7aVUHZslPhqvhwwQ+IS5S286t7Vy8UyzSgjWr7iVUFLtqIghjbYsrn4z5FAc2n1nLxak2c9dhMGB3msGj4r3i65oUkrAMq75FkcRgR9jB3JKFkoVSPiVdK7DDWX526fNJFSPqqPIw1TI2lmk5i7ZiK0UcYCObc+vUPQB33OnP3tlSQDIbSDAqjDLKKOMDn8kjlBhc8NktMw8aEcX0naBWhnKV5rkUcnwkfnUvXzq2TRtCX3IWzs3VPIxLozlepVkWo6FpekybaRHOvPqUTK9QPRfU8870uLIMlFGWH6YNYMhr2VHlvTFqO9HELdtjSPKVTzJX+3EJz+4zVrBLafYkwEqzkb1bVhIsKttAPGUopjem3MPEna5Ni2EiM+XpeFYzp2gbNjSDRzsbR3TNhtZe5OldAMV0kDTMcCkMF/4VT5asrm5Dhc9NFYDC2XDUrsiyYv5kNmUzzLJcuZVQLlQZkCSLa30PHYJNe+aNvjDJNVmRaWFhZsPdkfiNC96ioVmREuG0l/sTuAhdW6TtAaitJdhkqmRNCsOw8he9WxW72s6iM9RkzyxSypX0PXqxlrrAmwfTg5XSWNxYwA5RaPeVQWpiFwm56POb71mgakESV0OLX/Id8mPsVVtOLMn15d7Wzc9Va9So6kbMMTeecniVW/BVOx7VrerOsXCA0n4VIhw70nPmxlwpwRBOYeOeSIhw3LEIHcnpfMunjp5AnjsMOyV1TROGHcku6Xv0Ym3gxRjnQ1TX8ly/BnNIdLLzX6pFT3bJ4qP0ww616LAlteZy96dZMSvT047aaUU6HcguWVhhvCILLJtJoHuL6+lQGkGomhyUCsgoL24+42uPNrC5T1ssjWj7OYi7r7UKN3TZkwaTqd6yDadBowuysHLEHm6U/Nu85vohKnUCmi8KNQjIoGrNKMqiaFi1zOXJu+zscbRRsO0zkIrQzN1CVBuqMnhqPQ7sBe+oaSn6+Wtmx4xDuXO6I7tzwU7hBUivxlBXE+Pj2s1W4VXNEPyW9blwdlv19nd16jhM7L5Onqf5k53HtcsZ2790xluhQ4AZPg4Y+5IeWOQwS8qeUCdOOMXtehXe+1zpggCudyyEex6J5DGviWWAGbL50gqKzBXst1D8gO/85KDffVniL0uU+icEjjQdIoCqFkA0zrRCDpfaqh13OiKD1wcQUX8nlTNghOm8M8Y8ht2glvGTiPnJS0H4qYuVVNOJZsyxglnzrOeL+U3LnAe0zFumZcFjWr55IoLvnlLOj7OA+d+Xdtj/2Cgp+OtNTSx5RzP/z/zlxSf8OiR+JgUA+kZxCHrne2HoQwEKGi1AQ5+LY6B5F8RC3wvw0G+KyuUAaO8AJb/quKQdHk/Vioq3qMM2WnTtaa2iTmetunXOZW1Hl9xOqa55lErVD7WLcs4kFdU6jVRU+xxSUZ2zRHugbkSlIbc0y9Q1RSyyOcUtkZrLi+yFVdS0FldfVsXW5pUvrravMqPqZD1372qtVxavjhqxdI3UR0+ssZqz+ui729r1jt3euvWhoaArz1wUGbrzLG90Hz4rm5yPHqfG8nHTalq2N/2mb0fjN76dzaSZ+LxZN2u7mqBRPd8CmsgLLbBJvNhCmtxLLa7luNiSWr5XW26rdantaI12tvyHYE879yjta+2t3Q9nIEZxpL1vw462cbSOtU+sXzqz7asTTdTEflrwaBI0u5DRQnOL/Nno/KK4aLmw6CyGis5j3Cvb9bbowEfToa82zA9SoT+sYrdYK/G4aDvkpbYq79FW7UOyanxUutqjqO6afBttD/r+k/9vPeSH+B72O2GP+ZOsx/3dL530Fh67dUI7tSfnaPn21JzpMV2T8z2zt6bjwqjnxwf0k+cn9L/m5VVRN7/7zHdR/9P/FXzifhDs9VBVxK1qUYb9IBX0eOuvhRgxI6uQI27klcN417qUx8eUCroY44tiKrbSUDoQXQi3EP2ZWoZV/IVVxpNHl+W0SFkdde2Km14qQREVSZFT1EOuKRp3sXq3pUwwfx7fuUTJ3E6RQkjKioRmqlxKlVHerTnBB3Vk+bRhbQ8afZRcx6t9cUbn5LvzHfRfOSYbmwdkf7B7py5Kv9utdd8r0XP4tfXeJ/QzwGAMH3hlhNEYO+rawvOG6Cpt1VeN+sRGGgZlOJfGMTnYGu+PtF4ZH9g0907O8972qjhVVBlKr8lYkpWOQKGti+bo5i1WZCArUk1N2OoxUi65VjI9oolqiuWjeKLRdQr1bXvSVGnTLZ4FWY3V0UzDTvhh3uKUH1wA0hgxJMjtsRkJyb16QHwjBmdBP2hGJYwLJVS2FgUUXZU4L+vCt1CZ6uFQ8p+POZZBoGGt15qvBi3f13ntjm7brz1vaX9LrHSHyorTtlSEBYqppjFsza7W0xDCFG9HK26XofgJpVoCTncOKOdrAZPJKlmRaabNAhNsBuoM7fyMzrHHibVAEfoQKpkPRbu3yCRGTKvlTk6zPLVEunWkqDRkgYvMZnyYN6ogKggGKMEWCUzLBsVDFXLmVLDqhUJbhqgGRG+JLAEhV4tA6vTBxgRJwCPMVnqoPtTaigavWGPpCuURWW0rDjRPRT3P6PwUu0WxGZW0n+ALAlFefTIRDIfq8BoXBAvMHYsFHl04c477+R1wnhUb8chGORpJkhu9CeUrJVQoplqlDoxCHmHl4ITwPPSukJyzUQlpWQWYqoY2Ek9lC+VaY2EDJNGDSCj6FUtfdKVr3Sgsoed41EuUuRyPVNLKIDPPstV3gqSVa6X7rTSWA5b70hEIeOMfU1IZnSPDYuq/OlF/P04uHlEf1kn6jgQ2kgEmQIsCDL1pQt1VcGpIA4Sf2441dW0trvcurYgsTF3jbKoDqGqtTvakWDzgZs1EmftcilC3tjoMq9Wt+2SP7778zVx/mO+5by3yTz/5NUlLrYhFnfM3kfcy2uLhgOwi9M0+Bx2xdSzeyZUy6rxLrrjulnH3Ed6Nc+6P1LZrrXy7vfVxrEBTd3iCxgM27F4VDjwE3PHMPb8luMCo+ChK7ocYGcoPHpQwI9unQY+J3VO0DLHOW9cHxYqjgcV+MOiFCSRHn9U9+AkRpdFgzeAT6wUlZdlWVhAKMVhLURNWEZHBiKJcui748/yJBSs27B89TzG4SckgqetLO69zwuPKrQpeD/QmD1rI+CPML35JcjlU0cIQs99WAwaO+8sF4k3g6EY4MRH/YSSTSS7FI5osp5ZmOullmHFmWYbINoecl7yz973223KXPyJ2RPtzT3Kaq7a/l+++7Tble0mLSG+mCTsWLaeZ4w/O/NjWAv8fPf1etjH+vzNQxlT0pk6srxKV7pODtlSdHv6ZbTfb7DSFsN4dkLedC/1opz3RBqq0/lw0VaN4STgCuvPdC2wyKM4f1S5+Bb/5yS5KiLbflyADMjWFjC9gbNDVrm6l2N1/5owrh03BH2HNRTeHaT8/GKCNVg0LJsnG7V1a8rnTWyx37CJTcZip1MytIFup2Kik8OxdNFeqtO441jie3tVEdMYtqrHK/7Ysnz6myGNLbq9BEA3+8w9deeAhD+jItqqebK8OZBMZGV/DgNWM89Grbp4QTJr7SBZRxgnyKaQg99QwRp9envOYzmytZpgA9DDMt0X3VUCxUfWbrKvhm6pT8fV0KxuAyHzQZNZsa/pWN5xEkabxSIXiFz/lfCLUd7tOjKlbVlaHDT8q+ldiT9FsNV/dhvCojfvNpL8kabVIW1wvtJzhoI6Whu1Ap01Vc56odkzfyqdcmR5zM5lpU8ugxTvAM5dqoPnDu3z9zPldultDSS+smrFbr/leRMZ0rMr+Rb2Axuy3AVGR9kXKNM00WnTUYwMKB6dd62MO2J2qR6bDbY87My7ip1Ck61tAOg3jHGe8yyvXT8dRCPu+nd2tU3NkcbN2ngYL9DX/Z1iIpgAaChm7t1YIk2q7CrXuaj/yX+wdS4Zc0wkGAwmIUYD4HoBdUvyg3o4Y7l2R4N7F6QKK+UEWOrkfwpf9OMjQ05TCGMSgoX5GTbfmDfNkaq6gnh3S2C+D7iiAuX/I9V1IhkD9Msz4Ye0ISnZ3J6DhEEl3vWIQrWrQvAx6ukWerPVD5u29nNwNBw1cGRIGHsnqMZj/3RuebDGYv7N7ECT/Z0wvFRz9SgMdB3FGJvsYKoN7Uq28IivWelE23Os9c+vPPpzrnYsugi7iLwovDGkL+loI1oJ+FNfH2dMaqcIdLMMo3K1jjFaI/z1NIugiJK+x5gXzRzGyPHgl3P5wMw1+8Ga4/Q3uR+1GLcEY2FcsizGnnbx/Nnn2wyrnzmL5O2ote/dujDY2m7iSTmyztgOtuee2D5MxxNipQlUuHoUue2JBLRNZXxoYW3DwEvrT9V4ntaBH+DoNNx41oC80jNR6lSm/eRgamNYDLQMV09HvnGQYmha0DvhpEhONIdd8/hCnkrz9UcoRC7PR7DZfmo3mS7N9He2t1498P/L92t2/q9vlbnPcmHhvOe95A/JBh2AehA67zr7D3o6vYr1T2MZsOMvjtGqpl+YUD39ZX882vU+vK9qUSLMa9O1E0U4fUySzmf0qnHXD+On+EQftd63V7pSvvSIzNFhnOZ4o9El0RBPzhJMurLYe/gfPAusIZry5iaxfd3HqYWYqulc/FX5IGvGYJtufxf6Gkoa2q1wyw3eoyHz+wbI4TvKzJEPUPKPb8zFV0x/l7mbRHui+XS2ccV8tUdbdGNmR2Z5lVs7nDuVrm3rGZ8XnEp0Xue8Sa0fdz7hTjN1C++dFNecQPRxfyVFQ4l8caMdSftW4fFMTyjhvvoHxWjsgoXKEp2RQgdWqhMqRrwxK1i3i2jCA8gUCAMTyI+tP4sx/rexbqd0SJb+k7KiYv30aljjg+D2n3Y42yPV/gfF2bB+hEUqYEVkZnY8xb8TGOpJIJostbO+xd+azGpD6TpZyU8/+peqxaaX+K+Nqj6OHfBPsL1rq1b4HZgo4g0l647nub5PYRJyljIV0ORvbZ7BbYVOsXJXT5vWie0KSaeQlkHq9OJORVfy1RCqAhUixSkIFMompEhF/+X8jMQWNG6J2nEf0LZ2K7xPEAVaADz8rslEOO7GtaUX/P2ccy9hHEM/4JzgPE5FriU19EpOenGzP7hSmOOWpyulcTH2e5lpe5XYefk9dtNm8+vmbfMjE+vBCFvNPAGP490kwTXlDZahuuzoa6q2p1jq+r7lrtV1XvIfd2/0gwNAbFZ1+GeV6k/GjWjMtf25z+DXPfLM0ZFRfjPhos5avjd5gu5venrPAhprIL2s8gbTaEYmSTUOozGN7LUuXdPqZ+OsVOMJjR0tU3LoYcoKxwFxbhY0ODmKN06EqKtkGwlRW+gCeGgaUUN2AlmJDLtKaXNkbzjGUWmiW65tzp/jfHOR9uRQOmQZLaI1qsloq4AdarVpXAkxaVItHI8Cscd92BDiYBW7YYoqb+5VdRsxjfclAqGSgBCKFRNsgJuleMrK+TMkMVLwCFfRqid4MddDGLk78/4/1u/p1wTf3xn7v3XqH7WGhNyKz5f+AbK9WU7zRkPd3wJuau77pvl9aYNB5fDlVre1aXPzfQC3+TW7Q8v+f8L+kE7f/x503BVz++7PFwxaP/XMW9jPf8C6TPWc0KYd4mjxZsGXLzBH5LNhw4Cl4l0bESrJFiTYMD4BAEKbDrvwZSVk07AKj5rWNNvqif68wGl/VOHO4vK0bPvzD3FXjEFFkvUmbZnDyZ4VdvZQu/WXsr0T9dif8vB6h43F4SnlW225z/mbPoX5J+e0XvHbXy3zZy0vtBsjUa9nvJ+rNLrRn6p3J95PzUV/9ddCClLxZXOfTT/u7fpvXF/OmGOTDf2n/+Om3C8dEHQKC0j0PC5Zo/v6/xIBasP01tuLfToSeW3JoHm3PU5MzurCz53m1S7p8E3Z4lZSQbvpar8u6WQnfj9vQ5E3o/795Kews7JqqKNSQRRl9VFFHL4mFovudxMF7ruZ+/P/zdcy/Tiw1n25QtuQ3frITpRTEtjrODjFeVur4/9cbuPygu0++K/EbEQwQNkEpD+zjSQFMdNBGBc2F1SPd5nP+ev7/T+Dn2y/Sezv22OkLn/kx9w7gABlPdrWr5qrTYIsx1pXLf4pMIcXKVVuo0RIrbbfHPt866pRf/OJ3/7hSiTGBcTD5bMOKhJTmSGfOOIRbeRpy/RzC3FL92YNwq3nqINycnXX7LlSXKjYSvFQPn/koElL+gJMI4dUKz50VGFicn5N5MF5cvUWLoGAxNehKEMpG7jtjuhrV+YSWxpmETcnOHqxA8uTPuZ5SNIDrKr9eYLwF1MvKVqidw6rWqB0Zn5pdWF7rdPy1mv3f5EEowkgAEv/wt3+qj2DPkJr6YLVWKGHSdCeskWFRml9Ake/P4Jz41shhcrYlESFaxBPAvCE6vu5oxKxVmRpNaiLuDv+37eo1ER/DeXd0CdQdjGCJWR5PyRPfzSm2/xgUZwyjkN4RhIA4f4fAM4Y2XYwfwMi+Ff80OLQ3EM8Jji8NDX/Z/+iUjvH9N0PKLj6K9t0RxAq462mwN5yazFQ3MlKjvmrAdJHCmsI4SwUyYBJXJRKfB2tr2xHE2q3VMe9YfHVI0e3INc+hu0Gj17iDvmONTYCdbXd5TNtVzJOA6x/s1ae/e52eyIzfqglIKRsBKdNXSyYCVc6OvxAllCeqhmId3L0SkIp109WVLK+zdLzhVZInXr5gkTUD+Egj56lRIiw/omQqhqi3NNVT+v/Xm5oCxefruAgudccVgCQHc9d03H+aZMFUMEVxa3cav2ARbkv0Rqycz715aXabcM3mxdIHb2e+W6G68r8RNb+oPtBej3zoqS6vFn9Ic/dfqJkoDptNVN6Swv1gE9n0k+r2gG237rRltE2MupfUJ5873AeDZM/oSRwUis8ON4NtEbu+weo3q+9IBwE7M3yl+rwsj3ozVQceyrH/S4GAQUDBwCHkAY19snM6CLxvXDT4LBmRTnDjYgoRZPW973Xbf3bsH9ren45W7ZoH1a89/4Tb1vhllPlBEjeV8zluCJ83HeJNh3TTkbrRZGXk39uXbqHmKf3nLi6+l3IE6p/+xeVruKZUraquKG+eFVy9jIkXhpPEn31ZcPsyft5p5PQlLCFHPIhmKksVGCN+89yg45vf5cS9eXPmCr3eanfA++4lXXHYh+enrzHm/4k5SQK6tgFL/ego2G8NLS+RKmYyucnFdD+9K8MLMpougjB9A+tbXZu9JKbl4qtpqpcpEvKcQFZBR11LX09OXju9sQea9Sv/8H+8QCYJeyveHJWOZvlVNPvK7WQH2DwgpZzrkPMQhygO2VR/BtktbT82vKOHYvX3nRsuHAH0Q4IWTLt5FKD2HMTkKc9gZFzeuTvPcW2JADXo0E9GQqD2IQDe8kWaHggoBxNLxPpJgGbgT5GLTsCdW/xq78kWnBgz7MYSnGFdaBdwp58wjHyP0XzYG8FsF/UIC2Aom2Nm4xsWiAwlDKrFnuGWqG1SS/2bxC9oftO3BrRGdaD73X4XvapD37peGrwFHyViKM2vDgwHyhXtCfg0ukY+fkCoNFepLSwxKyux/p3yxIsfLvi9tJpCM2mJrb7dWbyXpg/zw/30SPcr2yOQwRBLnPEmke3sVarKLZ2+z1yJF0pnd2437fad2e8DKNr9vUvffe/N7x+LgIOC7OrMbis9ERrw3onlK/bqvbgZE3qGFDu++4bbf8RJPTfpQ+tMd9PrHwrKWOKIO/6EEkMimWxlt/2OqHJWnWvuekIXfbxngi/85J8A6hCJ8AukXXrU591zBGPNeRvnntdR3vlW1srk/ECsnimxZhzi3PM9yps55eWMmnm4jAW47OYjzp25KZiGOsxAHWahDjNR56YjyjsfyitMzifE6vMl1pzPce75mHLTV+BgPLNHdHmmpu5Rtt8D/57EcETdU9XsEqWePfXsrmdnPTdbyVKOS4+sUjogA4iekpqWJipKPVAP1eJaVA9udo5agFZ8Kvu11y8kIixoZDJtYmxGSdqMuZkns8ZNmjZlQkxCSlJ88x+GH85kH2fUq1A4jJEVw8HOhieMj3h5OLmx4wIShWZm2uDN8oL7+pcEZHQGMBSRKVRKOWswGfUaHT2KtTghIaNaRzBT06iaYRin7+4vav/47tNm5bu2bn2NfY9T/5tlUEcL7h84mnfGFc+thNc2FgsZvavePLXmoVb23X6zHu3gERBIpGr0E/FRZTir05cOHr2g9gqHM/hN/96bvpkF7mkyOJdT9AEfnmEe4DTzAKcaB35RkFBEHX3MccSTQKJIJIs8Cj+UpI/XJ+jj8+w9u4bsKDiLlqNAxZEhexbZ2fSx+riPltOX1Sfpk/bBfeo+VV9On7JP1CfsE/dlvjoEYq6tsqaQKgF4/qgDAc8YQWtedtxzKs2d7TR3tfPMb5dZgO+1nQ7eM8x3fmiksXeVDOqXhXCdDO7OVZmyfiUX4fxBkzl3t9vcAxfSzImBsNPxoSRYGIMAtP8xD+0f5hxk7olAy4xIHdiTCN1MFEfm3C3NJxdO3gPhk0a5HthlGowK9M+O/tkdmnH7x6Vuu8r7j08+TXnZAsdY507ZbY+93Hnw5AVlnxY9fQNDI2MTU4ixIZIYut1ZFqUohxWPvzyFt1t76Kee5NufHekdm3Bd7wvPNm5x++hsR79v53b1h9ZzaPvZctykXxnX/f1+Kar/oLoZaR79xIyZfKCYmTsWOwGqCb77jqyNFvJEXoojE+QeEHvy/0eRvHWDiHI2FtNITGZh5HynyZ3JU0a9Gslb/JssayQuUS0M8OyoofOnKbnW5W3XDOrNpaHPCXubIEqyomq6YdodTtegeBBgcmUlihdBChQR6pWbzqRGEzAELAFHwBMIBCKBRJDK4EZ8q9fvGOBb5L/OUz4snyqakqlx2u0r9hgcKNR9EUh0eoutTxGMYWU/jLJ2hJ0G5PSYmc/MM8lUqK+1yxCxeBqBQueqpQqls52Do9D3hqK5uj1HhMa+//s4MpvHAVj3RSNTaeVGg8nG6pP///TxPy4+Q4HWHGEyVo0TeHE6oppenCZ5VRal/u/fRmCdy9ga8Ussonow/Fn/uEdZRP6yydId0cd5tj+IrjhpS95SttQtDTEYA0Ye/2yaYqPIK3XhoufvubghPB55Y/OosCeCqG9eM7SnxUqUOuyIMiR56AnVTqrBkpug5KDaK9UoY0zxiVm+MMfCK3Dil4FOzmhmFISBcBARUE6/NcmpoJIqMlXllO8rbXXV00CeRppoxiqPpPuf/xUpoYy/YmUqatzc2zVpkz74IQxxSEOejKEMdVSpuz1rTkCCjvXk1Zw/bi+j5QY3m5dGE8b4sb/mfs2trv8EZAjMUF0CXAK5w0bA1AfYnyuANa3AB7tfPvhawgjP3RvmGWedc94FF11S67I6V9Rr0OiqJs2uuf5h3Bevu+6574GHHmnlMW08o4PndNPLS17TzyBDvGOYET4yziTTzPCZr8zzjR8s8ocl/iNCIkIIhIawEB4iQWSIIk26ssqrqLIMWbJVl6OWOnLV11C+xppqrpU22ukkRZoMv7uiOCB78xmt+4kjjPo+Vu7MRo4pU6YZeEKxN6L3htb7QK32DRnZnb/5Tl9ZNyp+fgYNyBNyFsCVzCeUN4GvIyB7GBiFRsEwagx4Zw+c1ACcAQrgclf1cYEIgN3a9P7/B2hnUQODy6155YCTQe27af631tMDMdUjpWl5kauVNKowyrjReIihxubSdUvwkStuOcEm5cFR00WdO0L+d5bx79ToPsA4RdhqjCBy7zL0U0uNSDAKETCqD+I/JjLkQVHBxAnRcyT+jybrcBFeio2LRCvxwxoWMIcTJZFLurJEx2mMeFyl7Mx1LuVMJF0rSTWJyTZQQ45WdZuaOA2QrQmcmFBTU/wOKzZRYNMvkdsHNK3GTQNwxKSMwNPj8ucmY/2a10qOUkW7GiMMEC3ii9TYaEJY5sCkV0Accvwlkmr6KNCvTJTVDCGQKHy45yFdg9qnGOw+CIBB6K+97SfPIHlGm2W9A7KFlVko4qAjfvO7y0o6pAPRXOUZ3vccfY6gcQ2hnrDom7zmHHJdtCTJKGhkWqgCOwGa8PC290ug4D4SW/ycVD7IVPCIyV3C8dp3/vKaLXu+44ZDXkLGEVfY8JnP1/NZpFjpMs4aBMHKhwzsQBFYyLBRY8EF/2qg+UrU79c7Gkm7hxs3uZtT9SLT7Ef9qr81agh39pn2Da7c/48RIz5bftqt7gCwHxanc5dvjNk2yJajVLladQ456nd/+K9DKg6ASu05j6edfIGk84z0eFI4fYvPPG83xEmGRwNSaKUR1hdCegXH/y1QdD+Z8/QqHyk4UDJWd7J163svGbVt3/+FZKZ5jzkZogpZypovosZJoaP/GgQBoPzIwk6Q4KHAR4MVVNCdd+vUZqyFQ7fJ2uRV0CqynYz1u2rNm+5K9SmBANFjR+9o97vRra7lHaDY/R2OJnZaHONSI1Q11D38Gy/v7I50HeCXlt++Avi5XRo2AfwUwA/vMM0C5sOu9X87NiDcNoBXXH787+ViF7NoAH9n9v83N1XreXN8fxEdA/zvjwD871eAvBbwp0sOdtRtM3MA/P6YgF+8esps5pWTVTNnAfjpjQH4xUU1lmpzpUIuk4hFAj6X86MAgF+9DoCfv/EzE4CfvxSAn98GgJ99c7bq/a894PvnDIBb/wiAWz/3VhgAN7s1AHDzI6Pzb+wBAAedE1AXih0QRnM/NC0/tYhfH53Y/88GDz90dYf6bHjWLS+qLl0+BUI9rXrWb2VUm3N8Un6NP/TnNuO5g+MPs58mjtflYep29U/Vo5xiz5hdXvnJD8mG9KeytHx6zvpT/duc2k1ncqam7rLaoCdMliNXnnwF+z5caDXxAlugmTebNqlP1V7REIb0DdwathXbum3LN6yi5kDNtgGKpv8v743aVG8qNjXtZGvbbN7UbqrafOxi3xZad+uJQ7j+65+tz5a35W8FW2FKUpqylKcilanKsgf8+n+ZPwgUBkdMPsWUU/ndQRowWpV0DtKr40Op/q9KLU/B/aZ3NHLd8+48Wzk7OXX4yKljx4eL1Ccjo/pAbPzyfP5RpykuagAAo4Pxfe3gDNd73K7dxt8HMN4FP4du3a5uXFK/ueTaokWPYSVxO0YAYU7ML3MUEGxJ///EYmEFxEbsysgFy1uknPUNxe2OGy9+goQrcWlLVprIOlIKvw40sMaV+S2UqX5XTsq7cgpKCV5GM6Jk5GLitCZqEskKN+EhPjArTtKbS2K/CiYl7rnLrFSZ8vYnS54iZarK36KMg/kr2rVmLCzbKpfZtGRn/L/2HQoOWeUQWUN3KHu4l/6nVuWEGrWd6ucsqlSr+7gGDR3cC25ko8fJsPw937h5kkyRoUq1ZFPNOM4eyjwunfEbQbZU0+TsyZ7txezH1YTcPTpurKaXokC6RJMXvhqFiqSZae7q17i2Ne/+BjZmjkohKetZ7/rWvX55ypSrkDLZnmrwuLO5fGo7JlaxWM3IKKho6COMONLICP1U30cpsGSphhspXeZaTnC8wx//m/lRP5ogCQ5pNilBAQZOGSF2IxAehAgaCHbcwUZZ8K6IxRg2aYrLqLM4mFggfFw86S7KQsXez+CckMjPZxFAZ8Gs+0kQkZBlgFFkP8OmpHqAUxWXam41PGp51fGp59cgoFFQk5BmYS0iWlVoE9UupkOlTlW6xHWr1iOhV40+Sf1qjWYrULDQbMzkAwPqDKo3pIFII7EmEs2kWsikyLVSaKPUTqWjUdj/b+MaXbLG38qeyBPlg5qj4Wp5gDGdcb0JMOdWm4RNIaaNPqFmMLO4z4QvpK8mc5R5swXaN4vvp/yQfiq/tEXjt+tP2l/Pkm+5y7/uzd9WP3qsBES9xBmSKtC/M8HiWl98CW0osaQgq2DrEINNaNswdmHtwznIs8NOjZoCOa60dIoIxHdDw9ZydFw9z8A3vtu56WLK1bQby53NxcHyB6CGfERAwo6VPk9uGcUP+qo5zaek8lWoYvyVQ1AEEgZHoWdkRmdsxqvx2amz02cnd0Y7453JznRntjPfWeyidzEYhYcQC/LtqvpYBV38p8k5DvSPGk7MBcJzTH7JwDOKfHAtkV6zA4TdwLVLMuhCz215FyN0kO+AO+5J4HNPk0GLV4VkzfTFr/AqJ7/rfDD5XS9seVPLjJ8TneZlHZO881J2o2bHJv6mPnHtzmknjAmTEl6OiVTKqyTkY5ekiyghD8J5PwnAk39gv3tC4eGj59I2s29xjXz+lcTSf0kmpF7YXFQJlwlrNoyAwugaIhgr1g0JsAR/P04WPo5ZnedkMaGQvZJaeP3Jq6nkS/s8uh3tnTdZc6pHVN8CSk9PWjIrDN+oUk6JK/VCv/thjWymL1JwTLgYm1Pec8qoLMSwpBYSo8IF4cQT9qj0ECgiRw1WL9I/pyxa3f+4VK1+yxSIMRQywpFfRW1IgQnILC2Vm/OlR7d3FNAhqnVscarMYGqKZeGVAxPsM4u+8GynXIwe0r6e2Ils0/11M5bSaCALr3x8Kel18BY0GEfnwQ+cIKGXTeOsHBRZjUBoRQIrCtbaWDDeRFKtCdejnbzPO0VAzUArF/+YVOe0cXaKALY4FCcmYRRnhBN3ST2F5NqeMyscHBiNc5NZjKbnZIkluSLMeIDaqPe4DkGUYq1oHqafF8tQK1MXCKi3RFYwJvpomRrOXsU0XFIMs6GQocx7DZ6GdowswGnj46H0x+5dYOAbcULY3Q0dMLwTj4T4x6TOyZIORuRb+4E6RZbQiSdvfWHNEM7Q1tr3BLmmvPJP3uytopzKU9iNAs7+Hev0MmLp6IjBGB8xV2wXhD2MuGYgtZkryAWTmcsmRHrsfbUe46dZ2hChHXPlDbRxNlCCZupw09w4L2UBWLaBSEJ7RNXLxB5sFCD5rafTO0xo9dmmxVMuHCKx/O1e2tS8JJdv/bvHtvhZtb0TGnpRwFM19KHg9kCVX5MqoGkV1KwKaV6FtVDNaLGa1VIV0fJ5Dkb5P6VQPHnrDS3xKzkOhiWx3hD0+37Nc8GM76+Df2sVG3SibaJUMU6ck+AkOSlOmpPhaJwsV3AjD3QhygrnR7oL9LbXvRvzaFQ+TscMFPJxzPfXz0sRwAwerFvatfWz9VYllrOS2NWLdSxH2U4s9gvX1Ym/Eix05rFpub2xANzUenoRG7BGllcjRj0yXy9LAv8vuJMN7tpuWdDEzp+QJaDDTHc7YU1Tg3cZ7YnuPV/lbgKRpWvDKyhE1s6iVU5CcoZ4H2Vz5q0vwc9lkQ33biwrq0cvycAqCH66wMrsxXRxF0WSiMZqlQ0PdLkKN6RWipaXQJYYe1I77tY6Et658z/J/nYv3he2y+DW1kqJyMnedptG3SRTlIvrm/7gE4MwLo2UaTmx5I1l4+LaVmd/ezJoRRZsmnbFKHF6YLJJlLDQiJIzwMZy0REObsnV2YEq6KSCRdoUyFjE1TMgJx8ebp2GApgyD3DEut18X8On1JafAggED7pNNhoiSM4mh5zzLTpTsfYKOjmscVywqO3RKYJwYGykS08pH+5u6xaJl1cqnkdEmmu5d6yNVbUEZt2Xd9G/lNfBowttMTSuCsPP/KVfy8u1O+Na7v2HvQJWo7Dlq2At5th+F1/XmKvdziNjS0OyNR/8sWkH0o8kKpMwG67zVj+H1nZ5N6+jSCPm4DKH8/8gZhEM9sAadmtnu6KxUtagI9uYgWpFSGEzyt7LapW0hMznW7Yv5b0RZnf+CJde6o9m++QOCuBunMuY3y0XKm+293rgnxhaTHOyJMrbRzBnT3Lf8w4wAgzUpMdh4nK2oMRR6jhuj5wnHZbTghLnUn//PH4CyBHFBXC5WFHiEjou90nNKyssVytKXEPHdXnBvBGMm+uv5RY4brfHcd6J47i7wnIP9L5OkXgQiYeReBSJx5F4EomnkXgW6bfPUaDuPF986+0GKhQNIyI+RxHfyyVzlk20F95gQzQo8lpwOFKjQ49ONbB3w+7fFNeg+AbRPDatHVk3sn5kwz6UsUGZGsQMm9cyutbRtY2ufR/K0aCcDT504aa52ORsdr46fVid/V1n/394eL5VAPlPvZ1bAEi//k9MWAQpNgl/DwH+5UHbO7CqDPh/Hg53VaobitA52vEM6/KHVE08e9mQRlfMjbxCtoMId7wcgikzQxdhrMkrLzIe6N1h0zI32ovtZXyhngg5i98IPnamublqa8mr/qqEIi1z8HZEkBfca+U5ckyd/DoYAhMEfi2muTNC+lk4/YJVxgeZ+VetqZDHrNTmuSjMyyCW0f9iYhPJaGKsVbi+0EhjuThQYTGd4rAYpQq+rkPMvGqWiIdYqXxtye6zqvBEdkhQbtVYpjxcBpLTHCZEuuQ14oaaGmdRgt6b5G5mbVxyoorJlDbulUkA7ldlilHXeLanNQZ1Hb1VImdINx33I+KGM0ETngvIFC0lpMisb8t7WjwjpLm1y2KjUbdBbKkv2CIemUy0kc6IUW1oOHplRoKAENUNBMwekbNLpB6qNHFO0xRzoWXNwhWHmjRWw9BccUqKj7wrE2I3Ew2yggUWxQhWR/aYIXwVJXSoIKoa8UobCgB2KC0NDIhHxbuQuFH86YcdeqF/k2FjXkilofaiNMNnyVPcC/HubKJ9GO/SeG6um2FOR9v21dDJ0WNafW8mI8M13mTijs+vgJdLUT69/inbz2ii+MMelb2czrKHlgPz5+wkIlAlQsIcdTdhYhzk5BMI4a1Z7MKeB18V7Rf54ewUt8qB5LqQIThmKLd1DgAMh8PkqgBWdupM/My3aL05Kql0g13jP6JAoqw2ksRsZecpgpQPzhJozYUJe1Y7ycpOP8XNofJMtHLBhbDyR3jx2KC1BN7BIjsuJphbQFVaX0t/gvyLB7KCiik080EMjGBa5ppXoEI2B+SkqSvsNpNSjOzk9z+CvtjkMVwVqLlIlIQhgqe0Ib+405tR9OE5CuyKOWNtyGGXDI7TkQcpSc4dp2x9sd47BJiQZmPti4+fZtVGqzwGwEXb8LeeoEBd6WVCDEL66vkClXJgJsRj8Xyxs9NLo+YSHwJWGp0d751mxBnRIfbI8GUyRi8DlMav5dpowt77HULivquTfxREy+xM6fqMnnbj1LKGw1wSYPY6h/eN8Vl/cJaPti8iEHW0SglSUBM0OZeBCeRgu7vR4+RkDzs5ACyJ5IiPHNVH5k4r6Bk4ZiIVOcAlMr4pb2ewVqQkoTMRTbSVrGZbgZAXtASHaKP111S6Ha0eaEigaV5sRfSqA4KvGyOlCN4xAaBmR1NEC0hJ1jDZZifDOTmgZnb85rM0I0CoWNV2tFcZaCwcxilhlsinU74ZD22AzhTFmN3ZlAGABoTgHGSJSBVJqW7ZbKrSbG976aTMd/96Hex2tLEa9Gl8TOPGgQMcZ8rfgukaBOSOQQo8RmQ8ZEfFwkl/88aXUKqQEgVyy4ZY8xgQqhgbLpjHtOSwTzMiJtDXtCcl+R2cXqoJmLk+VqkaJlvD7vQjn0ZSpqBMG8PjOxZdtPMiy6EEYlEI3gEdXtdtrZ6ANSr0YzivgT2fT9DQgYMeDsNhO6yHP36fRjopmzZHW6dYev+2P77SNMHd5XG0LGVlUAXnrtNJ3DLFmGUhFIW1eex3Wl7DqxDD82PMo6aq6cImZ7nLjXzTFOu6Zqt0dZJtp3Xftd6DO73ifl+329jWy1DF+2PWRyheHGPOTrv4VWLwA0bmBKcL0133pBzXFvfyuTJrHtoRj9M4okXDJ3vk66U2c9j80oWz9313mfp+yzWF/Yz6qG97+bBmxIjKXHRvFuhFI+fDzLNwx8O7XYwl26gC0SSfqEbastkWnPyh14VdTHvSJ7vYSoaQXrJjjZewvghg8sZNpxemySeUpZ99n+UZv9Gfut6kpOaeU6MvJsa2CA/kRpztMHT28Kq924PewoPfwuvPfLBWqeUF50p5OBxIKKWEUFISQqOEPudGY14rkCNdgcdjbO+nPBWtVZzTs5FRccPKAjdCnrnoM7Q9nANn8FSg/LXZr8Kqpi6Z/UW+jJfsyw/WC79oH7e3XjtFvBNSL2XFJ3nGyZ5fsUvx8nq28zsv9G31MKt9yZ7kW2+dJcJ+Od1m9bB5FoFc5zpmz7yeYQm1zikzhpiFUABJAlFzRUJKctA9ZLXxzOKFvSOocHydDmEXOBxC6oLd7fikRC1FkvRuJ5vgDStSJ012b2iPYcltw9MTi+HQFhVQZvdXJijVaCkiYQNvNq0Fk2TgQdLOrfFgAi0Aj0iIBhHpv9gpkrkmtEMusTmYLg6etubIna14kVwUbz9fdyC1bhQ0X06V9t6npTCVMQG60oWGNqOuqlG7KGXgnlfucUVYypdKLrm6DWbxqEY7F62u5ksMUpXi6cV2zUpTmrNnxlm+synKQ6pcgSHlJsAfi+WF2eukjd7P1pgZ5mo2M2rzkmnbVaGQsjcY7AXPdrBXG9byjdnO1t0GPU3WPYZU88kMqFDRVKTBpPEiVVvJ+rFF3n+OKylX3O7AZWwQ/SrLhEu+z9Ew1zDKcgHw7aTyfLMTWAPPaVC1ktN6LzqfvV2xJa64Qm7IUDwwDI1HNTQ59cnU8xvbK2osTk2arvnTssVVL2sh4mDgRI5WwLLngO3RT3glMiYyTxsILL/ey1g7gKNV9aO8vL69LNbwzOZ2cU9ET6NV6BTK6ru/a/GP8sfz8n9iPzz+6JQi+hcEiPQRUSOOJlA4Ivmkkz8aVELQn83Nj/98wXHTxRD3gqxKRkhjiIzxImKgol+v2NJrRXY973bs4/ku5M3IzkziWaa7xWtveilf0qs+mTZb2WzqqpScpZQnvKBUMSo7zfoF7Wq0ZVJY5hUvV0CFtMbjsdxq216MGuorGVrnFDMdMJ1SIc55xG4wJF7B0R0HQE+RHJNp0eikmE+ntsJe6ytKcv8/DdCn53QoAZHb8rw3ATZ5pxjtOzPQfIBC+G4vasEdVyd501hHy6xU8rQvpXMd0LuxrThzX/PBUnY3x9twBMmxtnTg7HLHLA2ehkxyvjOl0JmRNgeNs13+5CPBPqogE4tz+aNbxlQQ8SfXsdZKVtqqeOPUMwAnWZwCZsVstGaSAKN8iWJKFaFAPlI8H0kCJ03kmsDrS2oD55QS2iqFzEFVy1q4IqoQlRiA0lWjlkKQursakaIzFYUDCoiZBUA5Sk4qsefJUUoISkwiF/7iKXfVxrz68Jnm+qQN7qv6lKrzBA+NNObonV+kUBR+WUtmg5eSNShTMp/0XRjiTg7oy1ZmT3Q8Xi+EUHZXCfNk6c8W4esnNAx53BVLJCagjF2NXPIc/Q2ykoEkmUHIg1haoXe/PRTex0lcRQXcwlCEIcM9lJFLOAmP0AAIBDxckEGl7YGGpP4WFBki8p4D7wxT2Fug3IqIPru20N+qH9ZcV23i5AswqUjfbi1l7/fxd4CzyJNw06rhSuBDOEhIbeyfO3gDknQpbWE1AkLbBApLvIk0aZS0SCNTSOksAyFELDedF2CcLpMxGxoaLGZMhin8TwSSWYMT0bIgmI46xoC9FHFZlxomBHHKRvN1gTesc1Kvd8Sgz3daghNSAZgwXCZncXW8jXhLbJxpfat7J68SENqYZYsJY2KlKkPd7FXtYXSzsvsN3wFbtlZyTAzFKs48MD2W1OJ08bVr/YDxQ7pL5fwLRNv4ZKMDw2FRGbG8+mKyzpZ7DCItECpWbulV0rBWqu56CEjAduTSi80RS5ayMZofCMIqB1IBQF/cp5Y7Mo4NV33WYpW00R5zpA/7oTfjowO9TjD9McoMxGBMTt3SCkgeQgMFcs/TM/JpQHKxpZFaEz2HNlBpPbJ0AU3UugGUGbRz5mClC1MxejuWo/VwSpgpj7E7+v6uLSnk054u50Z5FUwyINOVh0W8QlDxuRh6cLwFDik5mT4pBQsTQ8nMCnyzXmRSCEcu4yT43T+VpAM2PE5g+pSyjvVwnKksWVOYpr5f+ZBSJGyLkmw5gh0bTVKjAzKhVGHMcXREQjqPMici2E9PdgpshyHDA5yhINjpoRoaAJa9m4O5PRIxMazUlaIzNIFGYLbTXC+9tQiOemPVcnC5gvkJTZjVZYosFg0/KUSRLiRGTBHT5O1zoYl2ZEudt9XHg022QyiyLK35ERrsZZIwBZSzAlZKbEUDXpEp10U9nJ5A9ini9PNd5NVLk7xUGJcuy/RmT5EHgu+Rx2c36ySLhDd/9YmRlpOhnQyU4OA0nVGcJOQdjcinL+BMUTGozdbNQHObHQvac3hI0/rUwCSz2JRO41zd2FloVaAp6RckScl0y3gC6DT8LF6FaauoZ5X7YAa2UCaIcLmEwAnSNA/S08wwpZvgdonYm0GdhBaA8CWskkWCsJZZInKkRMEht3s3nIiQp6CCE3mRPJryFXVtWPt6SMRC66FkMPeYkBfFpOQnYkhHeasPhCOr2lr5DSlWVJBc0Y8blmnSx4GS/GrPcSOuPitJ8AymRTL1TQwlKeFFOaHR21QrArSzb5LSPIY5duf1soUobLLDw3NyT05/A9JCIcr8TOth74ZSYolCdfNB6Hq7+AA0FpoB5nEMAwNZkbLfa6aY5dcVZhWthsw8Rqw+d42IGfG3BlULr3NgCuUpoiuE4gTxlc8kXb7HyrCbJi0pAK43lnDCjDAgHhw6X3BszEYzGnBuYbiASnjgQ3WrNwsOIIrBppe7hYB3kMLlelscO7mKuAkU5BScoC4tieF+/HgrzjKLIz+bH4Ivor6U/c5qyQkqHqcphEXrHevCJEwRgZAVnSUM54mYFgMwIfEgmrodsHE5hHqYKr8hyPFA61MnWjaOl8wJWeuBnDxxXDcM5A8fP3mq3g+WWTT+3rjQhEmVw+eiHgdsEUz3Y923tj6qBCuQ6FLpPWXqX53RSEPvaqa5hVm0pj9vaUidp9WGHMVtEs0W1GjZCn6wcU9NvcGINOBG3tAwJmldwvjZ+tKziocMrZQbC6VIQT+YMZBv5AV6FYljLtzPtwh98a7ANfnFPLJWzOab+B/LKjgWurRKogDzGqBIE+BPBLVzlGwWn9mhGqVYXbFzdR9T4MwYijeMDmRtNOvaWK+mCu7hNnn5acn5estEWJw6tKSRQluUXUDZHONENagGW37CMb1vpfpKK0g1tB0NIvvoZ2kn7SBRGuoLsaoGzTX2ZSUzu9hgeO+i27NMreXQtw6bMOJaT/RxEs3wGGzVsrPlt1s45GGvwrlsDSKhDzDKqma8ujlHCdaVHvO1gT/ONjwdf6hGyMNOJ0/+po0kKdT3c/9gQSaYQqJ5ioVi4a/M754T1k5IdVzLk0afUloYzNbiRzZB3Sh5R7FORrJrwzk8PhxompwmZIpCVYGpKp/uzFzE1UrzYLLc/KlgbLyOTTT8Y+p/n839bPdatbCdzjyFoqTiLnRdlE4pT3wgckHJcY+JIKGFcG1wjJcVnqk0LaKAOSQfj+T0az21+z08LQ+btYfTSMJYq8pDaA2w/ZLyLUr50y8fPHrk6t07m54jbx+8gpajovLnHrx2uzubCoHfM0q6Cq0tkvwhTVpKjYocFM5xKlXxTbhQF1CqbNKjeqhBoyFlO/XFdEnJlnBuyHUau0TYlnDQDuRcx4zuZACxymlCQ751iMDElbYwjH/URrBllAQHWLxhx6asTMHwPuOPnaFRM656mst6BvRrguvbkK6UXWZLR7Xifczng62h4GFIz3/2R5LTy64l0T1/XdEW48scXLwSToLXTgli3/KfpN6Dz8gOpBPbMK1Z3DrIL1hy+NoEk7dBKzCiNFmmyuPkWwHnsAVYbGd/pNK4+XJGD9u6laHkfHSfC9YSHW7M12DMbtK2DIptGGxhb+zYDFnXsaWaOU3zJRVVcqTdUNiAPkOiCfknwDPx7nSqzdYDQNNecKa2LN1/UJ9vBJFn3UDb9zHMTP81hWBjeKGRYxJPmFc22E4LSkctC5GTODvUDjQbLhtcc15emSqXeSH/yHg3cFNj1mOXuFbobl3T9CMf+GPEsHJyjHvtz8MkhGmqOKU200iz0Y8vn4CdoGTYDR0YdHuT2FJ9zTbXHVD8gca7qS7jGK9SEBgd8vN2nEwlKGknGH1XZZwK6tnKXSbYIAQdpomNIN7NMoQNL77kW4pN94o5MgoemO4mE1ujDafrCQo2cs8QgijwEasGOf7ZY3nBVdABk6mHHiNu+z7oaHe7ILkaXot28shnM3SQWff9abjbNQ46aKfaacupf8y0nHFD94XJem1z0OTpmqO9tbkAErALyH3kK5BWS7hEDSET82kILyLw07X26VSlwRjY4VxpeBsRHdiYtfpsUNgcAW6eto0UCMMZ4K+fJM4WXqQxZlcrZfN18cJ03S7QV1XsFYoVfkKPxdMTzSAnbFFUT2ILrfSygNO13lnF8Me2FoFOyMSkhvctm3ItHpLleCv7R/Suaw3GwH5zr64FdCr8FZXa4sWmWOcokQQaXBZBay6TXtY6Ys++PzvJq2O+qQLdcRjUdIbmeTa+iXegZLfrzPcKW6Wqo3xx/WqK+sDI8hNiGMi6mGKa7SjJwLBvrBQnZz9VPrvqikIe7GJJu+TryTmdSBIIFTUhOoTGJ5I5eGYmSuOMM8GYZibAL1qS/PlFrPIFJJsKBJx1BR85sNAg1mMBipk1TBXHse475xRznDkWGydekkClnHPbTG8z/kD5oOgox8l11xUagk4ZlwBBZJ1mrMOqVuxW8RJs4p4EEry97GeKLsA3N+5kh3hQsJXlgUEaskgMUG5bxsNpQ7CnME4ANp4AOuaP0zClGtDJ2hKpUXVEI6/kXKQrv4pvwRfOcHqUZVzJC3/EIuwYxWcmUiQe+nOs5n/zGzn4uZBvM78hEjAQApOa7E4lXQGS/D92dCua0A1sLmKLahIXx38hs9HZwj0Z7Uv0iGuwpD6tuuQvKXOYE0fIHGXw6dMekJJaAN3taoTHYEzZgsurjj2llc8YfLoZBXm4xxq5hmPbJPZWBoo+AbDjadA5C2lFIc3hHcKcc9PkWSQwmIZgyweInxSI0DTXcdKeRSuVKYAItXGaXc1l5SkxQMmQ68I/soILtApyiGuIZY5ocouABkCJatoPLDSd6JNK5kIvJUjiOyFdBbn5eoaWJip0rli07wVgr+hcTUJeP458oqNgsC/yDx54q0OekPa+Mwh/lTxsrNPCixtHEH2UU+sMPnuEequ6udADhAw48IRusYHubQdHsv87byMjdUwzbe3joj8FSUcuNuS0LDaCNiODzOIQ7APmZRLDVGhW58pSnnQ14OFoDezRjEZa7OY7OMQKpm87e3HNQmLWeQOk5CANVRkNKlzFbwIAVwD3Ov6uy0TgC+AKIOQvElxEI/QeHt0dMoryXPquw+KzU8RwUsn7yeo0+RKVZmn6DWhF5o1tfoanLj+G61YdwEju/WEVOX96rX7CLoI47tpO+vVVX4GfCkEGRC0IDYYJVyFeEcBJ4HMtgvQfmqTijzUVHNbmS6ZZRW6UNDTFa2GRrg9WC1DxygW2bNyHVLMYuZxCSjeclQIqQNtbPwsZOqIXfzjqMIXdLviZdlH7mq3EZ6ExNLHFO4ADuGAfO5PjqDPAE/BbanFuMvunCJ2hODvxBmQEn1AEk1ACsPUtAilhMzeNZgFbaLgNVgbML4HJMli28Kf5QJdxjkqv4gdAAFp6XA/NqV50V5XNVdNhptWS7G5/4nvJP7kadjUYUMEAPrGZmnFoFndr372uD+mfTSyuVKlPxx+AizUqf36SbsXLkOpkEcHoUYrD6YZeQ8G6VgvjMjsTyxIQ2uEQ0tEt84NdAz2M7ffFybfPZ0nUL32mF9rqke0NXyS1PHJ4rMLwmfc+kuAdQj6XzLDjIl7YwdEj5w3sozHnS3qaCWyY0GxGXw5RRz0SA6Q+di5eWX1RlL2EXE+pF3y+Ml7/pM9JQZ2Shk5Hp5y/VDg4MJTBuN26rpscNXXLdqIWM00rHCADT7YEJYE/8WTKQKNJOIN1CjbgEd1atcAMKLCJzp7Tb3zLKVeynZynUVq99vTQNR/HHpSP2z23qkQxbDGXB7oxycUopP3KBEJz1r5uI66j6V52avp258wtE2idx/ay2RAC3R26cCOp6Re/C7cKFygUpLFRJs6xMDhUec1pJP/yPdLLElJNj+/inz7w4Op/0zj7AYi7bi7h0YvXHMR5+/+MN/5D6L3TqVE3/8+RCUmRHpKy+MMDbSYVtTuSrM9iDCp5jcA4UkgbcceQoqBUlCWd7OhcSzUOWxo+fTrytZ0gl0JV4opSYhBVrZuqATp4LFBUZW7zLD9f7+8v5/gdL/iqCjbyIV3HdJg01Y6AvDf/VHFFerJfabBILAjFXNPTbxKjpDFjq9N9i+66/YvVOxUbCBeGy/K2b0rfTG0llb+79yEkpYEzDO000ZffclVtSKfGuqJHtlPTd1CsMijXsDthn7pB7i5+Ds2Ord64wqjIlkARakOsXZVtm/M7l+ZwELm5DrS1R1qDWbxOdu+ZjVmzt7D4xibnnvFhVvH821p2am4TCXC0rzjH4ZCT5Tj3NG7uFqbjocZZs002u67Ukkf3mVyuDNbc0NzU2wrz0DqvhnXmMgXRsEvVGEZqq7mcqgqbL4U7mYUCbkGzFSKz+QuRc3151mZNgEXHiuPau/puvircmLvqAemNDL30e+D3yK9V2GojHc8eRYiY0gWL/T0akNORjSfbIWSYNYMz17l120N5aXYFerUqCjFibYl8/c6/hLdjhimh1qFSFmG9cpOUdlkkiEUMYO4Fi/CDAAXo5jjvkEwW3pbqoP78G48afUR9v+FUiGNtp/oYe0WqN8M7hsvhqfX+/fbwXuLWyY2DjXZNkVjvFRT4666r2HH2byvg37/7Frm8iBLwnSWcHfkIGUB3EmVnhWD/K7qDfX/7DgjifvDjneMQpl5fCl3OvHYGq8v/yri53KqTrq9huiG7IQn5TvBBmfacOK4EJJ+fXnKSbgdS3m1F/hfK6i29YIOKuMPiujh8TLUGOlVnkJuJ5JlQrKhBTZZ238flxw70Y3Y9ovO2r20FRNrDyN7pbGFxxNopUW6teih3o9hnQ4CyEy3eXy2+fBU07CKgZH4gbTpKDMFCFWo5V92I8EadXDmJFOQzq+l5PpM2+gn1JR4ZOp8HYJB09jMgIZ2HE/Pk0VMYqBsLvCglA3zcclgxACCvAzDgZh1juNjqn8X9HpMJtuI9aAN4rwXL4k3HiTVo/pSLlFXiWnLWFJWGaBbBufJzYKRFzhamwikGAaX8O0vsA/TKyWKDhMpbvDVVF+/fQLEikpeP3CJaccRKJOase5WWZrJJMyhtHsY9EwXaBKof45GPaoItPxAXpEkQZgglrSUehTsk9nTgZE/kuugmSNR9Fvd+zKfZymAMXcbTlZpcp6Mt8MPhreVcoPtuWwhVDOSjc70iBMBhUIDlqmIBIuBUUsHMGfcJdh/OGO5KKUFeoM2zWnYIA7aeBIoQu2VlHcbihnUUJAV+0FIunYJbdtxDO2Botmm4DWnnK9Jwfc4C3tHSH5vyrTrCQTAcoR2QdXcHZH6Y5ex7DyQxvTjCkKQtvKHJ1MBB+c3lD/cqu2TAOSyKg3oiWqSNI65SV0XGQbIJ2mAO8xVeyzUAanljwQjx+bnE1cjFjtxhhXXIXVY6/yMaiXp5tsICpBHOmxtCpGyOP0SENJD7B3OYFWvjdRtnUzmwKbWY5BknifCiTyQkKqLD+Lkr+iwnzCG5OQlZmFtyUPqAyzQYKF0lT0rpArB7lSKcNuTgCMdMcIK3URCMdxOjDudN6vEiItFWPuRlnwgthD9GxXC1Ww5WFCla2pfX0YuzujtKpiQgJ3rbbDx5bz0yoUwBsuKlTCaBBkuATb6+uKGjTfMfglAT86LePp8YDqUQY2iFtTf0R0RrQRZvW0/IzBDiRQe0G1EVGb2SdSgrvLtQpmliUKF1qIlPW/4jYPrI+O3h0BGcC6+OuEF1B0M+QWmEoKoYRLJDV61u9s4JGoyckIJVfDcft7uaYSbwkwrDNpMYX0GBM0b+2RpbB/JnB4rvfL7oAgXze/STBxGFZZxYHlU/cn48YBeLFewNSUbc2KTsSm1NMvH49XQSPnj1c31XqwCvOt+motbbM7dkqwtP0Q9adYcXXjrV74s/i+LU6CIVz7M8y3pFNDsRfI5qseUk7TDk2TWl8LUxYiEldAYEqklG3sDNCEa/usPESSQOzwuOGYDF8WfMlR0YMMK9eBS9iioHJhwUaXAD8kYEPuze8grwjBgajaffdp95yJVjVRYSWydEYS2jq0wQgffuuYR02E1oo/MYRSmBA3FkkiqGsxdTVjU0gjtF0VAwBsroEhzOW0Dr6c0pCMLtiCF2n6t4UqDBul3tC4Y0C+nm1gkIvMg0RFc+JsBjKFogwHFKn3JNA6k8EHXXZhaZ0Zgr0YmGKwfxx4zMfOwr7X3DBkAChYAuuvo+W27/7YLnpTb1cdj504gYJR+TGd9S6BsRLW+O0nVoPfA3OzgRk/RmEazA26YoOtdo+KEvkWdPUXLrrTc+TeJHDvroXTFWotpCbsK41WxXe/ON44E8FonaHbqMHf7VqUxth+Sm2hPyF1FFK/B0turIQ+Nn6nNBzQae2L9pa2hBHk11sevQAHQ+19TgEcXE5A2LHcOyeQREV0D6dIwaABYoosbmGHKFKUGSwAP3U9rfEL9oHEDjizoicgSHIg0OQXYIGBWhqABmPu1BrKxwUBnPKEU3kqZ4F+p5tRtyxzLkcEPO9as4sfEhoJlqKHM4VQMbRjl9fAOFvyg8ZIUcFCvaJrYaxCZvYT+jwh/VE4rrSAwAUEAtuBDvrApfU8GO+8VropEbrBNq9W0VhJH13MnQIEdawOdg6hBnvfK3qn+tzSFdaz5qWqvohexXSUKi9gHQEsgJdJiR1uoKP3bMSBfKwAc8qJ3slYeAPs9F0nLNobonPZqALhMHL4BVZGfsTWztg7CtmAKaGaP4xkcvu2B7YTtjm818TrAAxlx7FPPsnWcbxT7jxNr46dXEQtQMwUfWSaf5D3HPdIuTVbqME9FlH5PCvSEHTsp11ULPbFBqF4MuM0642U/043WEBdhD4ZzNKZROkNkOUxvx0SKqt58o53R2oqVbpktMAPk/7cYJNtZTJHTeGWjBJNl3VTOYwOVYPagolKn76ZmLRvIWonTcxsPrpdR7J3tcERCsh0RODCgFm7VE3wys4mnmXvHT39/1kwNv5xfznGHZPcSm3jeqYFJa5p5t7slyjXc1HYPj90sy5r523w/lWRpT/vRn/0ytFbZBnMRdtA+OtaLbfB2cq54ODjiEkvzjPmcf7625AohDfxxHJ1V7ep8xAMuK2dmrJtxp1RkeV8Yk71fvoZH9Rt2OFiEzFgmxmevX6rh2D+3BwXhlwm6Dl9qviePURi4ASlDjzredGMN80vkhf88E4ccDQ2wo8fSwuGdYPkIg4zTNmmjZxGcSlGWmTMf9eiln8aBMKTjhX0sEwhFI34sMlsFQOyYFwoqRlCOCyKqJwXCG2VMJ3UhC/YlewZgMc5SIlC3JeQRCivEhGSJ1Vw6oK6qacMlbYJqVhoLv0BMiPPcFr0alJ5dbX6DnJnoDJGGYPX0wYCOYMlJAJN7IxP0EOgCD39MEXgHTCY1XVM4qTA8PVrxeZaQeG+hWazQLsTtKWhK3NtCaQp+5O1qx/WusdFSWiXir1GuBGxwspoKEJRuBH9UmXSxyQiMChfmhUSSva/FoH0l2bxsmiGXpuvQppEkmuV7KuO/e/x7YnokYMJxgy5mSlvS0x0q0M2vYvfG60KY9wRluJinuucCJO4iQ5TE917LLCYr+1nOUb1WNVeJZXW2uaeEMgzX2O4TeSIWPw41fQ4JDcAta7sls0D9C5OJEWw9egBCkZbunha6J8vHqEgjFC0dMsBU515pWfMExt1hQ0Ni5abT6Hr9lp6rqxkxf8g7saOfP/FC4oCDHpthRqlAIGBP6erUducqsniEWPqHURTnaOtoiDhnfPCZ5sFyaXBO8ztBocQISFt9CJE4ulPEL3UKJUJLooDsdDAfcsxl/33goaFmS5KMrdIAKGZCf7S3aGfirK1FNZO1cBYbHNsjthYvCVD2kFtiZmmJ/5AQ5AouhKWnT+/gKOtsq5ypSvRswUC2Nladf0XTiJEp5pabX9B4kOsu7CZBaw35YMHVInsQL2E61LgKPq6sZLxuK2RJ5SSJSAglGEWgGPlRSZrbrND5DKvGwIwvVvSZxjNZWvRG4BYWC4rKh7gKh59PLFKwvEti5oBPP0rqSFtM2AOQyXDZXZQJ29cZkX/GdnNx4Ysz2h902nBxV1PF6h6+YSyfEWouf9NHxz5hZHjYkwZYyRkpJYSNedz/8AaGmU8RywagPeyAmoIznNVKYQeiYvBWSn0h13APd5vK96m3nUmatlZlSQP92kw/3OUKIKWsdjAKG7R7omXwOJOtJmkFisaNmLg3dtIbN9XmxrH3WZK2lZ7+gHgu/1J27TrlDdm+kEnTquW5xUCmSZB19Y6fFDztJWEnYQ9NLizW0jgexHHOdID7tgKNo/ijyQhzR2eeogvXWod5zYPmeuOUsLODp29DWDdD4LzJrdhhH6xBy43aFIfWygAVvycgkjbqWce6w+b6snXNjCTD0cmNb+pd8AEgmdeBrMvBdndlBGF/TJVhoNDih1Cjb0MyHc/ppEVi1sbiRLB27gUKOjHBb26qA07VxjtXAcODjmK+5S+Q8LNqVE94tJRxLRXzlIoV1GzkpXZ1jsAPDZasoSs7B5l4ZjQakUmg0KghSpwKLTi2AxbP6Gdv0ya8iP3gfvmxwjTgZ5iFNah5shPumHAfjAO5JyKsS6OjT8UKsaSLY3M6V2oR/s7vrEdzHlnRtgK4tsQWRDU9cKMgszzNRsFE3j37gScTOo5ASPcdGe0ptPNXhAW3EYE5svl/ssBCEI4tWeyEhWYp2hrvGkBSWfL+xTSVvtiR14HYZKR1ZyrCERL7mz/1e9MfKuyO7ugKgELeNyX5wxzfqvYY4P8WlNpdu/+GurcVk/VTmUKZkTE726+nYFpY0q/7brZfbkPhforkDjsc7DNLF3oPEPfQHeEqpcoJ0fKlhqwnP6iRKMp12Ac6cZp8LIWOQAIB6amcfEzT5vDQLURFKKZSUt5D8RtnVzfH7gWDgeDMmot1JGtblnFHN0BTTlYKKz+hjpHwUk/5GrqwIHlj+MkFhofMxccBQmzDbZJl6wPxNoFG2ANJuxTDbpg9qSyreoJOq/ccYAc9Ev4Fx1eJiH0hFWcjbdDGCtBzyMfasfNEacEjnw25cnp++dcOi/+ytSoKS3SI2CUBMKrHVfpXbXX33tn8Fxp8dNoLBHOrSgkfE+S2uX4AEWaZMnD1SWdxsgLTUIWNzlIVkl+HGuKgZrvBglOJrOiPhFlWyy9Rr0UFtqkO1jIhk0zc3U4O2mSN5mXMg1MKJ3rR6LpBgXPoKxAjlOkgAoQiKsEZXr5yHhslY9o7OTHVg/RJMHvOjnEqZV9LVncOth7gYTxMqd6LaVl1x71PLxwhsOFoGJxxtf+iKuVXr8/Q7aYq4zl/4KnRQhBxAzYaNLzGqBemmvGHmnBxEgYiRce63DjBLXbaNjtgLxuySgIfFkqgb4b88CyWuAy9rBvdSG8DNU3gkMMAIcB8YK+sO+TBccz5YaQ7A6/z1kj9q4j96gbAqdx0yxNKMgJdCi9joYOaIeO0dx1YoYUzPPwYkw+ufZGzUVrbjhpSAyTFXxk5g+j4ufrF992H+HuL3MQC52mqTFwKRzC0obOpymJpqmpgV2um9IIWPHC0sG9wvatlElXTAIQzrfTroqcLJ2ra9ozpR+51UPCKznlReZngRPTUn/6gmCP6Cz3njxRplgYsqDYluUcVbbpWqBrIWypmlse24AClQX5u+NLIgJOHg1EmmkQkF6L+UmnpfTvS2s1evF2G3xAozJdzRzcKZtZnMOgjrDkj4MxxoaukjdBEgn9xwgRWFsa2dgm2TPA3ZskHZ4CQLer1MabpviuTo/BVwOZM4u/q02odJTTngXsPu6q1hiEwOV0WDriealKcDp4g5O9rokjVFBNAFqavsaOX1CQCWnhDFTkeVHd2snYNSbki+86hlHYuBI72EwivR4rV/OIitk/IETBud2T5p3ogeCG3GuYWvPaToCWorYg5qtPEivGshep6Ce80/7x7SWF8oHeoAQrOVHaEmtRXuAFlVJDWmB4o2+ARkIwgtcXAh8cc9ZK5tWRPbku42mtcivEmoVrud5cLmj1oNTm+zMHYqgPutIDo7Yuxn19KbhW/tnPTEGqNp2qyD9lJGFxEfVcy7RFLr3Gl/PmjLKQ7VFrCchFeT9YSnzt3848JaQjsdMvPE7KYbc9/0juyCyIoyzNyzi65MHhfLCTZZlc1iZ5C+3WhS5nC5jdgeGLsl4GBGXKIiBJdDQgnsVMWbrQ2p6CGS5Nf1EbZy+i6zq9iCPIHMMBe4JhSHjrVSeLbVrOPDYKDd3/R0n8BvTUvlGjn3in4dQVLWxvh41QqpkPVoZqdilNt65B4HsgeSdQi2iej9VSY54WIe/43Rv1Xm11L96uRe4JPKI39zihRLCdacyAnCQ3twQ9SqS99zbRpW8ZG/0KOjQHBv4zwniyktsJsKCioX108UlL1fwSKSUPz+RA8jVTXLPzyjZgKvUpY7eurk8eR4H+aTIvctQbKecHQbj2E1YDUroE1Iuzqda0ngvHracFLVWA3vTeX4XCm+pNC3IY9V38a749ws7dsbH2eG5Z/RgN3Wr7KpXh4M1vNS++U5suvOfkDrG3byrKwI/jG3fRzJQZcIPtpBL7IwTR1aeyPd5aCl0cvVIkSSlMJPadIHPNaUTimhUCXTfIg4CHN5SI0WGJtqq+4/0/e9jLMLqUrLmjfoAncjuRzpLX5Kk17is3bZrCsXnjRgKGPIbk3+us3HLUZ52HxCrxtQSXEyzkFZF/URkX5302jhm4g4LLOOUbWQk37Zn6piD1zfq03iWVAVKc0srWQPmVWJrboiDN0NWPqYaNYVo6GWsp83eqTHyH309eEmlJYG6eqjz2OVtNExFXQNzkH71tm6C3kYihBNbgAnWF75wjQDKShykNUWg+ku4UlMSXLG5z3HLBuzPzwRNjprCPOOqsz2jJWMpX7EARsAL5WyqgabGoZSMlHLUBUhHhsRTzoeVqqxgH1BhuLfuU7G/ZEjaUq3CqCXTNXZ/biXz90Ucq8uX146pTITqG0s681fHymJLQMZ4+uthseqydJqnGsl8NCrRzevT2ZJE7hn9fLDlWhTOk+0eCPdbLFzOgSOSHDGRboqsXmQl10fQNawQx89ymRPXby07DcomfusZk7haAvPD4v16RvL+/HN8lUp44u4/YDAdvSQWZDbE3PqUK7xOJA7O+h56b4PhjMzzzqBL9TIozBBq04/FayYIQl+IoO8pF1WxtU0YYUeAy16PqieCxqCDldFiHr1y6H+JctyQ4DOas4lfsoHOZVEy9VVfo69cifSjQVCkXfqpWs3awxmVaurW55bs2BbQTtoJ2WXtRZodBxJ+3m+DNvh/kMDDqj/lJTnRPfbPUl/3erLkybPXzXr2+iEW/l5ZQXyA30FvjUgj13vEswubVbAW/mUADOg4Q10H5Hpw9dBtcZf3EAHAPzX7LHvsdsDJEemrZbEBX0III6EsetRhFtq5OxHoXnx7M4iovRRG+El75sAfBO1C9VC8l6ApW2lVthQzHjRoGgXTfaW4EEpZYjFH4QE+k+jbFbMy2rKl7BQugF1vUUZDsgYinkRTIPs0wixbKKYhqjsYYYsqmxcj6+deNxpZ79+I17k/IGjTS3SU/Hz/xcKr/ZgOzxhTzkf5YVlcKx8gEBRVpxg//v5q5jVLQs9llyTp/3xUrCP+LvoRge2LZoh/rhGlMNEBgDQtVFXggj6AKur+N+20nwLFIO27NMpnuK2HNisshb4cj9fmyymSPyRJMoaaYk0RcVpr7yqMeAJcUyuniQKGBNi3hVL0K9C/LnRW4F3FxXWVa5e3CCojNIwWlxMQWrG44JcP7QAiQUSkrjnRvD1FjNnqcWmX0jMZNdluAL6UN8wlWjeV/apHxZT0lXM2YDQVtE3QSxpx05YbTTXj3ZCSjFe/00MahB3J7cllCfxAyW4qFIHcav1VIKt/lIa5AsWR4GSTjJ4skYkT0hKB6deoDduDkHS8/Tsp200qsL9QqLBf34jgwFZtrY57bRO4DUOHbqYB7yw0Vhc4JOd1EU9NBHyByJsS6g85ypsWIkQ9JLaEO0I/9hFEb1M/TkKt8rj2LO0UCAfgsHgiPROWF1ZkwLfMF3nxh+OilmoGOhnsO/gze4Q4ovJc+RYSaMZVcXlmmz7rfNam+bxozUDl59GV+JnKTGuzMy1wKTJ1lIFuHWFUoYyvrob1Lb1uVsyLi2XcHQq2fy9p+1VvfSNQyVcajP6DV569j+13oSyGNk6EWX0MbSvHRkmb6j4Mvnjfg0NcP68NnR2s/r+hjcdCvvSBgorDhQSCOYWIpsMcbmu32hBbr8yh6Ry5KwOlIIW1QMw1mW+RQpenkvKAhlEhCFcsrm1Z5kojjPkZCOxMPJuwP8UJOjXojWwMBhZAjBrypKYH/LAApV8qwlO6frJjnJzktmfnNjqbzRWL6X9sic8BuZ5t/ThiUYhhXr5031GPmNuDWArm1PlyEFXazVFSEJth574xdhNNSpEmvpPhOx+H88ErTGcIW0jJ1H9UOR9rFEFElSUba3jajmBw4RnblpxKBowUZCirdht3dGloXe6M8BR+6e5c4rEfB4O2QmNdUeG5cj1B68pwIiu+wd5QH5lQ3FK4TihhxLC8W7fhG/cfIrwNLQ+GICPzUtq39tVSlKv9JgK2nbIOsHsoMPM9kmOUucqQNBsWOKmPgrB18HinSr6cQVTEMeF5KnajSy0uI+7+QSglic85Noxlz7IQBwpf/gdiXi7wT0ahp6L+sFHI85Krx+6PiUbdS6j0jPhCi+erpQGjKYJdLEENZQprQz2B9iBj4Ec/rksazOJEdPFuATfzI1TUV9X+gEIH31Li+nyjrx1R9SlCLsPmge/iskigOzkF34kgtYQnJ4YXAXbH7dWZTj1wTOiIKXOc3vRpR/Sr03ePOMIaNyX5HPM8upzuqdGVDTXqUnfk77BG5PecIL2Zb2rHeBto1FPRAy+RjfgInlnGRLAr8kfqe11WeTwwLA1QdU6K/CKsYeuYkoJ6qv+eIJt0HvUjPETll4cdwggoX9KrpwARZqH2dA/swLmQ6rPLyKsDkWNRJFLw1bDQiJ2hDWOGKY9o5rD9a8FPM/COkUQAR0nEfWdFv3U6fDWp+FBkkHaeW+A7u8b0agMk1cuq+RUSz7s66SelGtFdo2k79eN4sAHIrJ6uKFSsh0nIYriDo/gfiy2rz6WyUOnnBjG3+kQOFmOvpAfeh+7/4a+yYZBUoS7GJdcjkrVJ8PQ4WF4s9i3NDEoQ1SYADt2v54UooJPW6pLnlehvYSgLK6suuta8bV6E6L1dqLWOYhlPEPhiaNui1iL8XwnVj+3noq0f9Tm85S97aIoE8pyYwTAqm4+MZ810UyuaynDy7D8iB/9k+wcG2ifh71VO5EpGKr8Yc2Ohg7wQPIrXeRvXz8mOdyqx7y92RwI1yvPsc2NMWlZ4o+cLZt8OD1JSMxSdB9cpYAzxBDLuLPxDRBHfSow5jf/+mPkO0blbGtFLuqbN7B9WLmrIANDWFEKVhGWauI2QVajDWL6mg7gkIRAS8ownBt9sYVlLdjc7z+6LdA/4yQQLn1wgY9Ee/eiFHnEGjuxVRFezHWU+41HcFSyumXWB4KEfUu8tIm04NWSiwd04xovmlqUGdnL/tqvtcvwg8mKk8KXzfIWdCEBA2DyrBL4RCh81ytDtxJ0TJv3ke8EZyC7RYzeQKe4pVEcrHaO7aSlSZC+LZuQUb2z2X3OnZfv8TlD2yEv3Y55eU1Twzk7Ru1ySFKrmKJg1pdNKYhlHO8pIq00VyEDESm2Z0Objw6n4KqtB8DEvqfleY3zmiO/2IKXd+9OurfjuJBAtjBCBIMxpRqRtELCw9ByJA3VnU7TDuqX+vQL3eSulpXaNidtfzrTEDcM3oEbZf3JeTO7nko7N4TW3loKCjTY/a0yCZriYgp0iDJdaLE4CXZNuqVAbDYTjW0K4WESS5j3tT+AumirLQp6zKOcmsP3+WCm+KoYhxqFFoA8VemlrLC6cAlT7J0N8ik0WX93BTbqGWgLz/vOW0Ao87R2fwPJFWZB6jmD8ftLCKRWcJUxDdgrwnge5cq0N57twehWszI8tKGbsGJqsyjK/x97N7zIy05X7OlMS2Sh+r26JRvT2DLtkdD/ddBxtey96yitSN5ilKMWW9xNs3XhES70SFY6/PelnJT9b0FuLkluokWRwtxWbV4egg6bfBKgxGHOnNg30plGg0OyPCWDDdKv62hkxTs5KkRe55jcTFL/iYX7k4TVcYlW9Uno7KH+nqNqWke3s7bA1lhX36S9t0BOPG0n+8G2KWOAgES3IJSd4uM4+9zUENVEWOcMch3DlAStrHT6fEHL4JVy/lnvwaNH3l8II/fwOw+jgL/mYcsU+OGS1j7C3mVoLAvQKl3Tn3TSnXSHYPNsZO2IeZKIsKWtqitFymWYSFgLDklNZZuxfw0HiMOU07DSmVXZXUbhpxXzOJq6Vydji8QJ8RA6hbbJwO85EGwWSRaGTCKX4P8vxL4APD2ysN1V7XI8LZS0DsdqCHyHr5P5MVEq9sNy+WnSU8N70lCr+7GP6YZe4iD3rEdeAwecka4u4p6QbZey2onQvlHYmpZq/5yAlYar20DmcIESfI3EJJg1jeokovwbePCA1JA2oOHgRmwcrloEBaUVvIcYYq5YaHyUmuFwkiMXbzWEcB7hcD4TmRA6twWEfLmWMqR0rEnSADxurJii7iOi1GMSEKo/IBwfVSls5/khhxzzCUBDQ4Z3SB8RthVAzxpSG8boLCZiVfyYn4j5ZvEUC23equNwiNbzmXYYIYe/sSzrcifjJaZIw9MdoSoVlqlML+6fC6WjR+CHEfoEO4GvTRV5xk4XjKc55z1lratDx3q0XLHuXcIOpRtIfLbI64BaVdcFn6n/44tOq4QdN0iBDb133AE7cd0hw7cMA084bIAILMOhQasoOpIZZLgNI65kvy+2ttkBVCtlPt1Mvgsb0nxSvFD6lLikdpBEU7bDBupgWx2AUMKn16CpTPXD1ZHVwdcREBwfOrZdnGLTLX7k8UYjsUcPw0JduhrsCSkgWAtebnNYpQUPMnaygl1IQG2rFjsFTrFqolfvbdIUcErYPXhmtkAr4A8XtrqSIGXOLj8Gab5xAMC8TGQ2OaRitkKb7YguQ3nyPSmBzchAk7wZHQKz5JlIZvsfQCkBlwzBsb4YEtgrWaIEtwd6LL3a+/WmK0xEyPsDw6Z3GTdi1+uraEi6IPEQ9VDyyUb/4lWn/WyrAGG10zE1/JbdNwwCkDTl9xO2dUPC2d8XvKBhq5YuVWE7Uk1aFwU22uCyRQO+O7BAfJ3T12t4AOi93VTXwVROU12ylmV8aXTRKLV4F7bE2lWwa0Uvj6mLKVrHjno3iadCJOade38oPWbRqTe1bp/LoXv6uOb+wPQX0x9ZJcaSvoEcdypfDJx+M7NJHydgQIG8/MezPYIssQxT4TwBii75KiHhU1GS+1aK5KqHBqgaVMosV5WJ/nqWlZhj3Nt2SBl51wg7kxaamXNq3R1GsWacqj2L9vIz5Vx2N5kijbVuCiT0ZjYgb1+z3tU+UzqGynqD0eXiCzMjC3KNMT8nBsDU2VW5ShZ+CGqHt0jbux4qjRu2HgTtr3xOZqpPHlZOroGyWbrgR9gnmROhO97hwaP7hTRZ7rLuSp0GrfoUDzFepYZ0NYKRXOeeheZEwi6m4n3wXrAh5pZuP4JBHBR5DllI2CrNATTohWD5kv1P5riLqlf5hlqI8lVwigwbXNh3o4lcNcQ2DtLOiKdcTTLQQNmMARvPmHey+u3xYb1m5S3O8El9+iDgiSlvz6F3gTCb7UBu0qgeEEY5Rzd20MLViJRp2Gg0qPCkvQMY8fs0kEhZurqSrDfbbsnNDWh5Pz/YZUmViah70AGRlsAo3ARMBH4jRpYC5v0Jbf+D79ct2/hwfDS7skDiYE9JgMUvz4xSZR4sTqCiG+LTxTphan4V5i4pDGvj93mpr75HNoZer56pqTR3l7bwZ/QH47WeGj2lstyCSi6ap09XtGuXQrVudyUHeP00fXf3hWia76C6JDpx1571Xk4C/uxso3o2/WmO7rwL1NDAtAG2T+Dh4Y5fVAbnb21qbcaoVcWe1pB6qOF+rX/PF8QKf2uXqZwolR17DnR4sIkx7Rke2bMiC7uY/YvrK8K0X27ZKe7m7mqHL0g0F1jrlkr3/Du144EMBtLtrqyATK1En660+Wm8q9ktY+uioj26gD17u89ZPFk5A0RJWaF5z0OoN0flA5lvR8ukrpSR+pegHl+xCrp/JtiSY/6RzxRao6Aa2wq1opoAWlh645KOwXu6chMVVq0mVe2qo/sSgZC1eZdp2ZtraOwkf8HNj0+i3s9tgGxk85YJzv33aYlW6nNYM59NSNKifDqVcBygS2Pr20w+GrGICdmHqHdI9/OqYP05qTPyftiRZQZKlelacqFcTeavuYWFSvdZTmE9r/NlZ8suLnRUfi27XaLDV9vd9GHRLfW0DvaUErQtczo9OrlyNgRU0SXK3zq1J27UMIL8UKA29I5ylZHVFO/+U63TO1mqf1i/iFQz8jpYj7zV0W0bFuaDbM3T/Lvi9jMjtXu3EDcef3wrz+V1C6MwQGnHZnfJI7d2N6dlzRPgqaw22pEx21gGQ53zcIAs88427vHcvt4QzOvn9jl3koR0TV4kuCRf/2jhui5LCSp0nrpZqTvLFxDnNi/AxfNAC97qZPo8Abcumn0oCUvt6QIbvebuxk6VGLrs9z398l/WKAvX9fwENzSZN041Fu5dzsl8+QH+zdAkv1RmjMQqabGFN76Vrfbue8oyDUlu6T145bm57TnKP+v89OpGm2I/j5nrW+3uRSugbr/T3lbdWun0haIdWtPLLE3ukJqeTwnNSTrt6mcL4uhamteQjnkhcVCM+mRFukbJh5mJWigzWRzORqVnIcyMRzUyyy72gYfg1QtLorM03frIOVf6WfyGcuLRILoviQpXVOTYOLR2JZeqwficIasfh0A5DtdPLD2SZuEA4HGDw4yWCJlXfcVXkpiK+RcTj75Yf1ObHhDV46KLrEtDWghJekQ8Lpsnu9lr7PJAnqWe6UAfh8QB/2hWbRdQFxfjwWdRdjd0/TSqA2a+q0A4vXL/QR77ivPWXYqk5zpn5JNmFmr+WBlh8WXNs0dgZVRyZ6FA5GY51jEf6CM/qx/L/GZqKxkOFqOdxrx8kdaqHQUxy2fEFlaPPHDPET+PT5dLJNX1oRkClkX160I9ZeyebYc+P1t6o2A9H831mmDuno7sGr851nkbznX9slIXlTQcIZGEamw0Az7Kx3FTQRR2v7NxdFvXdfmXUqLpYykpLLhqrrN0Nvp/0+dxU/u4PPYxmfmahH4+IzzZVc4u4G2qsc75obee78xT+8fH9N3+C9Eo5Mk4Pjuf1Z2jx2PtBWolG//AY+W9h3VjcMFzRWC+dhsHKaKwUAFcq2FT8AJDBN4g136TGQcMD0PV680IIv35WSnUZDYt7xvqR2GOqrSJMNLuN+zQlV3rdYn5ABgHNKyHMdZ/igsJ6vorhSQYDRq7AD1kP1rcaq18pnxRdVAK119/eMD/JCmaZLEwi34wAaKJgwn1zoC7OGFaWHL6QGFs/1TgmmuBE7WYtcmYT+omw8IW6UCcPqWZevg1dq4MtEeq1lvsregg2hffLP6uSf2I3CpF2zdI4kA2Fivs02CxLn5IhQ7SNf4Jy5x08Yzlh0bRCpdeg9AXrjYRlwMyA0NZlf9RRUlyoDJRDiBWshuELqpZH9xV0a6J1oA687d6aB1CRSWbpJphMZmXnpD+WgoVNF1XZL65do2N8jczWZGufc8Rc/2jOGMEi1K+fNx5KG/frIUvIRuU7xXU7Pg7x2dKwn20Z5MrBlruWiex9Tr9LjO7t0j/OJcCvSzjC0DJ13Y91cRX8mWRnZ5SDYu+IZiSUrqquK6mGxbO7oY6aRm3Yv4sW8/07DFYS4JwjZuIDSkuLJcFlRA9RjGLpRuPoOCo6BW8r3W7+TMFHIkqDljGuSPD8xqWfnONi5ERHB1YfnFCNNn4c9FU2d2twih7Z6oo4NPrFxkXKNLsyHOAUPe2EH8hW+0Xu5cGxOfTjmFlmR/7pzx5a2USfP7XGkwloh3dOD0ecBzhqn9hu0pJdbAv2kBpzhZiPLlhfKQ2y4CZFsOh04JNMPsAP6dd9Y1jGBem9MYjUWyUVa+VU3wGikoE5akIiBQN28AFAU3RMsA+vVi0rXNwbbPmXgr94UGTbDYLShyBDIRa4FaEayB4Qum5FoKDTHZ9Flo2mpBny1j+IHEnlNXUBLVmeQfepTbUFOF9XWybh7LumdfRzIONKY3nXmjpnfy5EjTrv5TmiD07XeMRxJ4IZCyiEG8pJG9s3Tp5u6pZ3CgpeKQl+iTQlg7u+U6NZVcUCu79KypbwyRW0ghxzjB/tEgOzj+PhC31TtNtR5PM/ElGvJ3YIP98ZHo/8kkw5WM+F/ydLVdsDmpZ5pfHSmJGWwd8R8A9rSy71Nxc3+j3H6Ez1y4fn7vpJ17aF7nwMjaVdzY+iG5zPAElROtXu81PcefQG8XGpSP/+omNb6RTKIYsWeCWt85J6h35hVbbcrgRF6S0HnruoX1v7x1On3t479F96eydZrc7cfFZggc02r4YL4fmi8NpUhrkN62iFsHEN3fzcSZM5eQ8vYX/i+vMhp319sAPoVgdsacygoVCDkrrRsGC+h+ZTHxkSrR4IY6e8TZPJkg0KkIf7nn8q3Fe2Vrfd5qpZ6C28UafqawnEiTCDWS4CCkN5ME35XVWIJJ5IgN16xBowOmMZaF+Rkh1wZek3Nqg9YTwL4ucGt5sQRCAv47Txztt/qSS9kQaRNveJo6dLGnTPKLYPkE4X5fz07cmnGSUtqc4tj4mmkxCcixlboBkNlSyLRrNcsn/hJWb72p/H0e5Gyk+iOVInjVqvy7jPCw0QHZ4qwgfwefxvXPOiIm7RUkc/G4m+BMFLLFXO+F/uJq1Z/wr6oCdL9ItR4tQzDCBms+53WV8Doheg0EW4e9U6iXcmf7c/0ua3v38jtdfYDaSV495OhunmSfldfthMOTPR2hxNORwzXdv9v3Cv+bfITQvob56Skuzoa2MrhefcPZ0/Fy0apeZLRmEfVfLi2u7vV+fUS3Ngowg84bfhEdA2vrvuMKDYPUdymccWEmF+mBe8OeeVP+x/i+qtsVLPloTvyRNGWGjI/Rgk2cE4sn33j/QV1AfK793Zj8Pk//IGK8T4+RsdhJyU6YUou9Mwa+LO5asP5HSQoeQv57NGfXSkEiuqE5lDmgBlYDVVTWFufsxGwH9WfRu4LNfYfa3cTSV/fXAHZTKx3F4SFmdkWf8jmeD+UIH/o4p6AWVUAl0PEhyousNSPrblw+iba5EJKKPIO1A9hJPMQf8WJZFMXwSUW2WAsRjk52GwrvVPq3d5Pb3oT1uGLEkRj8vWeAqtIbw2ijW4u2k3tKgORCAT0Eda/Wfbt6W/A509D5/TIY51CHMufh5q0w9MvzZio/Yokx7mQ+EeU5a2X8qHjowmHWeT7Mvc16W6E6FtmRowrz20B7IB2Mzr3R1vTS59mVHrFZU+8o5jYU6+f3UaPIE+y0psaAGT/YJ56vkurJR7krPCcwWDyD9Jr77IXtSqqTxWGqy1X5sbpTo3mJ9Llhxb2NInyrylz/kKzRQoXtTc77cO3c5pXD/5ZFfVeqTk1VaEsyOHGWaqxxkv89YuMjfgW9gFm4wNLBkfV/uC8cashwRqsDyNHr3QyezQ6cGsycGBo8P9R7G5Afvyb6o362DfR34TSDlk/gB8e1lskK/oCzT5lP+/uzffCfm1rML3qqabo/hKHgVqpYUUpXOI+BPv5rpsKhbAh9Zcoq5z6E7Nt/Rr8qg7LHM1cNnRQR6rKSSy8nt72vvyfHp3cXQpBzaLScwNs8uobIytC/Z/x6qeNbj+4m0HnVeksTzPmDL+Bl+HOa2PDZCaX0BeqzdPSMPR2w+DKRMw3EeY6ifjJi75j22isAsSA7N0X92Hj32p17tezYio46f+OvJ4/tPnTxw4lRQJ38ivHe51vC8TElB1CzrO3yBnscHZg2xUmlWS61Wl95nDI0S3AUQ/T6YUmmecYkHXOV9yLDYhZVsq2XrFzj3yN1To30SvNGo6SJJ4V1IFjD8j+gV+kZJLuxadH2dEdOxiBYroGoymo1iqUBdOYOs65ySbH6TfR+L+7fRmS8R2T+Fp5WiLANV6WOfBF9Q9DfEykbKm8FooQnYBH6jZs/TAB2BXhAqLsKId1KJRnGcsSC8c/QRlo+2WXLaTGGeP0RKmjy/+Pykqg7eMVgwAIAIVoLTTMDI3hS5vGS/U1MC9/quWbZhhdaIS2oQrSQG0cSCv1UFSpRP0whoLt7qkiwPyQ5EiPlO8tl/jg6DaIx5qQJp3IsbzrL87KD1VldUVowpyX9mfYYB1j50sNmLuKYV5ngr2rEhcQG1t6TdRWBj2KDJULgSVkrW8KkjSGAry3Bh9efYUt7CEmjAnxsigCET0VnKEkxR8dsa6X2CiYAtvdomRIVrmzJ7/DYek/6vqgCjJAE4MjV0K+pOTDEfVQkQ09/Pah8Ip5de0NFDGOewJ4ICB++ZB2MadJEC73xJlIKO06RsdBuz31yKQH3e7R3gJrH+N1JL+3Z+CjS8lAeSU0LV1Swz2h18w2+MCkSXGWUMIwLlK6zauyAW3wdL9wMh+dMUEI7WHjPoOFvlSxuHcT97HwdP1eg68TwvS00fogijs1dszKANDFXJS3qHKXSfr/petvsUN+HE3KI9+IS8mOIPX2xrVPcQ6BwXKdLR1L24JX8yev8N07Z9H4btdXhY568vqT91fYCaE/+GqDA7hCmw0wMOeEc8Oueg7XuW4lsQ8D9LH1IVdv2C85+Y4codNioRJ8SWx15i9lJH8fFfF91ux3oGNjO21VIFIsIwYfrRlI35Wtt86dlazlxtA85QhBJiAQ4yJdQD7nb4G2S3NHHOOKxax45ndHdbNl5jaPqUt2xlCtBjt9wiNdq6SXbV0Wrr7T2UtPSR/lE8eSZBYn9ym0g1ibPUnfxMAcDLG1uyydffpUy5f9SnfPLGJXtKiVaz156zxmedSkta6oiwlJbL/u9sWEpiRXmcSyY8z8xTqsARFi6/DfmLuk5Klig8vGoseMq4iopqEZG+mtAFitHtZTO+HV/DSWnuysfDfPe0FQfV0dLFYZS64LCwTMs1gY9A02qtoS0wKDlJp0wqDPbhphwYGqN/xql430/1TzMScQlzwEI3+47i30lvmo4flsu6XDDmGqbFbKp+dPphoh5BStZkHn/Y74zMhv8Pu6ll39UecA4BUkdfWwwWnWHzInSrcXno2i9/Gs4TsiVwUlUXKFWvEuoXMl0TyGyInvZ7qsGe293FLUX1MZlpqElfN7DZMyWYJS68NiDh4ViNQb3jutkrSJHGj12taGd3z8fYXmcB1Ve7QYFULaj56u2d3loKxhFAW1TjCk26TqBnT3lV7nnzC/7DV47nzHQ3J6mL7+NGrAbK9kquCn1E2LWk1AeUQe0d0kI1JQ5LkrZXrQwdGFyAjQsSD2Nue8nRXphRSaJsCpqMw9ASbNMuFt6xqHds9cyx00TL2DHQek3L0QRuXuU3An+qznSSSLxPk3cPK7wjtIOe65CdYIvXQ6lZbLc3ge9p3bWENLRb7fBsFOz55t2QqaTJJE3juyT24fnkgvZb846W+03wwYZeClLkUoHqwP7sR+2oLyR5R8O33F429h71TUGuWqGgQTOOESelhhCDeeVUoWcvY0NulSC7JJeREJl0knIPEih+cQzFPlz5pkcrMQSwRSLlQVwTyEHKt1U7BwJbho4Mxj4g2Ub/DV93wQoeSpJbJcJ2xKw+opL/qQDQdvgHErRJQNsUBdELwjJJqY2k1FFOKe47ml1NBQ9iYyjkQGoDNhf7Qve98rB5SMr9BiPKSSYOFItJCCESDui+Wx5FNtEjJXMpCNm5h3jQO5Z+j3cMrA6/C1JQiQA4S4ByiNrA4WzLPCoVkXLCSQ/QEaO0NnRg8AOtCBmRGMnsiAgBGV7DPcO4mMwENxuUd2o+/6EQsaraA1HuS4QVnVyB1i0N8c/n2bbiGxoE90XWXztgB0DY4xR/syeQ2tiGQ89sR+9s8kmosQjvzUBIV5NKd5ONLhPCCdRIUVKTfN4JM3bPA49Ykoo2prp1B8keYpR4lEA227YSytHlPAufLvy/FOiHOBOOR3ej1Mjf3u3zMpkyg7z8P+DD+877MAW6X/UG5yj/khUbp+PJDCSY73XQliCEyduubU26MfF/Z84DJ079rfc7dT4m265YR71IpNrJukvAbC13/DlBYWwf/PORaXzGsyN25E8HMeidL/r7lI1l630oCwYtKZfmo8F8HEZJWweZs9gAo5JYjcBa68OZLN2TQir0uewsLvrOcy+paIpO/bHTZ59Bx1lIOecfE+dPL1fyKUvFOkV/ski7kiOu7+t803zngYbx1k3Ykpxp0caeqqBiFQJgTno58a8LNW2992LL/uBjaAhmc2KBXE/c10VqbPDOys9VzQNClL0dTtJfWR5T8u23nn/26DFt3paFQJYpLLQOFduCCTf5hyBXRQHDICPCJaE/dLzoObwBWgemQpFSnwGsa/o8xGEul4FZbzl1zI519EiNebOOB4QvnIPd2jZT5V6bqI5XDeQguC8w0HwmBR3B3opHdE6mBazo4Ra2HSx2F6yiAQXqHyr0Wyz5elI3oANapJhYtsbjhykoeaV9i1nlWY/DUh/PUQ+31en/0bl9q2P7xZSPMllsaDoT25PT9eydh/Qrt/QGiF4A6NkXWFZ6uiLO1NPCdnE1bQUF3RmPL3pkfjrYoMenn9CuJt97vygqeNEZp5M940baAAmnV4rxOXGA0fGxh/4VfnJWSaEiObAS+Gluk8XmhOF5vt16PLX9pCcuS2beTw2MkbVn0ltZqTc3KBSqk0XuP2/MNCkFVxvLy0r2DbJscVKVi7k21APfproo//apY/vYJTchR3PxPpyeeJDn25RP0Vy/N+Jc8iu49Wme7Y3MHLZ9XVsiz8ZU92T8HFth1kS1pOriuk0eLHVLpTzcjvp43lDTdDCnwByGghinUKXPNT6J2CNLDgXAKk7n9HKa3PXWyukQx5w0GqVcv+2WiG2ykuZh6boivPPQgIU/h/Ec4S8ZTOZ9uEwE2JcJfrskP4umgD57GygyV6PzEJ3fB83hKPLsOtAOQ/mNyyS6btmzOXo6FqsOrCCwMsf9KRkE711FRX4PVi5VgSgdG0Tw8NS8p8hp7kA3sGFcirXfl+3zDwM+aQUv+ZlDrux0PuSOjr80Xk2rmim7Vq7OQ2WyyXw8L8lshVZLmDraqu6fBs6iicCDBXh5PWFgmcnbWtdp6EGeSmfy0dlO/s9CynU693Kqly0aAu7PZKAKcrNGyGd7lVKNjybZDdd3vXM2opNqSzlniRy2qG+znDoHG8nefA/FP1RBa9qJXlUr2Nhd0eJI22cjC4X65OMTUeEp4pvijfnEa9brDhoa6gCSkVO0/5DkFhO5JLu1C58D5nS67iJUMv0wDwZnyAcC33lgEIay5LrOSVsh10EI9ZxHsqeuewg+WyFK6HmY3qBed5sp6vRGneffgL/fqC5nYSxpqPFyIfoLMJtWfESzlrsbfQUJAA8WAqGFx7S2eFbaTG5iFbTFtzKtOT0IqGLAyq+xvoKex+mH6uVPJgUQIq4XM3ZdYqH+HjelFz8Bg1pApU5CYbqx24dg6SRYuvdzNPeHOzCLpiUP4y/6h7QmeVz0ul8ck7zuuGhycr/ndwH8d1MAef3GJk+faXSEJzvaz+jmdTkQbi2vFck72uRS5TdiCcaZKyJaaVdJFy7EcoH8h6/K/XhasaXJ5c/XEd6denwdQ5je609+jcWtn5D00pKTm43HsQkaIyeMP5JtA3TNp0IbdYm6pWNEyqWRpsYR+IQZdxuzFMqe10aJ5IsjE8GX/ZlmDKBdL+3cXOfi2aF7G9Iz7kxPZzLz50UBrvb5KE+YOLAVwvWI7E02m60FQsHD73RYeOL+cIc9UXGFZpVC6sWfH2d+lxzwwNHmd1gywcDDb1eUwn8gKzy4A/49rBhS5anV7gG5VCit4HubrBRwN/wOzPQGdvRYWFH2LtuSCUWwfzNjY3pw9/KdtnbZB8PAR4mmmaf5p+f983KLFvyeJ0dqXw4cPy35Fmb6SBfSz7FvsjKDgjoBjXYCBb881A0aGALN54DmHYpySvvWp6SO2eyL20oD1rdIHDOTz1ds646dbWeoZ83rip9tYypnY3tbfu2JRl885OxSiw3fTKVgih4I9h+S0MxNdpbkDxHfRVwkM6/XhzkbxiMOOTsZENZaGszl/i9INh+j32MmAomlsEZRM1pSI08C99fM5SE5VW5Io0pIa3QOPUuDUt5vSqmXQBFax4102jtHvVra6rrVeatZIuOvNdezFk5yMwSYzJKqLx2B8BFfpBr1uZkT9U1RNaDSpKgRwXVEIVRnhhzVRgDZGp3S6SkpPmQSQeZx1SUDjJTDku0NQPSZqR5noaZoh9AGS1KzBdx+TbxrNJaeW86npEHd+pccucVOadU2DfOVFEPDun9MmIRuHfDcZmPGkdGXNEmKzCnTuujEeWoYw8xTKcOpPmvvfJDtp1p1Q8lyU1AnlTuTrUq/4DlbYJRkLRGj+eznx84FGTRmI6wR8F2aZb/Pa8mSgvH4klEqoXE1uI74nWhfVw0sm5/cr68aGY1m5pe1GdqkdZgAtTJLS6SW0cpcvyYafvZ2ZD6d0nC8U61YHavBYCaw3X4rdg9C8ZeDxveZfuk4ow6XV3D7iuzGk2j+E/ljgNAJ31X+4mn/VUEg91zrWMqmClZW+l8HzO5ccpKSzDlx7XAUc7WY64LryJ5NOU7q2pRg7j5uiP8HcgAJbl2G7yxDT6BSu9FlSYVob0MAJMK06DpZzOqaXa4ktsgbDjN6cUNSbmBXFE2AFuwgpsG29k41YK8gZp1f0NEjl+WcB9T94xP9cT3I7527ChC6UY9JUzdLlYpV7WX3ErJi18SKB742JGT5RHA8IwjmFafCwLydCMuYasdFuONike2FIpsLt5mW8zE3f1GPB5m8yOvB1UOLM7u5mRp94NfmY2R3qlFWO0NTui3/VIXo/XCxk+NvbftzioQMyoRmdaV4Qb926mxDfeEZQ0Cw5Hh8SmobU7BQRt0s1Jk2x5QFkkboBmqU64FLP23dO7dv97mF2+1TXOk9RaVHG+uq4qWRIpcPixcGFZ4XwJXgRxT6cOvCoAL/EFwFJs6cYJLdVA51btg+u61Isrk+tVzZCvuREtWy5XxPj141JmgeGNNqcHRtmXZyLHZuG5WBk1s6rxCtDa+EqINwVBChhqgDCFQAjks/hW68IvsUDkbs+yzoi7a9xbpI+6hxt+kUebFuQZd6Qt574v5YsBSXGNbpB+LYj39KM4ObJBlzPJbULkxeiMu8GrdiWDPhlsEwIZqb3VV6bp2iJuQgzXLNazK3mvLiR5gFGtPtGrKdLjcUoptD8oLMOTntemEBsjkkMwyflTE2PTsmaoaKDZFzDQ15A8WG2BkXytDc+qKQStQ0BoiT+3QLx2WiXKKcU9m0lEZwuaEhc2+m27YDw23T5tPmUyHfr6JmNeWopVS7to91TjV2O3Ysvm34RKX4z7IArlFrPWLl2xOJjvxKZUMpv7E7US2zWqRc/H9myjShT8z2KComBKKKWtgpfMVEkT1beYmBv6VzDx4ShTHtHE9b6pYSFb+KmTl0yR7XPw7yHuvur7igO/vndhlPsLzq2jj0Y6jr+3zn+PFTyJDfUhE6M37MVaEfPjxfUvvtvNd70HlDd6uqv1FyaL5QfX0FNG40lCY3la/XLXtkPyypF4Hi29Xr8Ykx3/A+RB/5xHBXUvkIeEvJyNtSLHHMruTST/fYtwKfHi5zRP3jaq+ri7/vUw3Qeat/Uz/hN801ObYNWS7AAXDnpLlGPvM51xGfvXRW9vhcdGvqRCp+34p9xH3Yz97fjKi/a00rfl29aOnpRmqodwopvNSe6cumGW2CyWadsy3ulJs4x3r5dAcMh3cG/Ic+xlvS5abUcC4DQlP7TfD4019bsCxsliq5R53s3+jsquhWJThZHbkwovsfn7RdyliaEqeMqfXpgIDnuXpfQFFbS182cXZMYWe7gauwoSNXnBafUNAEuNsE+q7qBMku0gqUWTbJVzo9mfEudle2kxg8nPomBFqyVMl9pLBbE0qTUhKqOr9OF+FYnW/Fk5QaXCmOSaULBA5c5C39rKKJD5a7B9T6QZZVjWvTG2m50ZZL+t9WwTG43mhd0C7IQ2I4QlO1nWlaKUF6M8cRnpamaVXW7mEB6vksK6qk8eE/imRxg3I4F67QWTHoQKGDpdlBnqe4sedsc5NhtFqq1dcKHr1Ph0FmrrTZ5Lz/yNduBB+bMy7xEibq+YgQMy+MWNV1lfu03/xn/oFS4nEqOEKFwyudFzApFNuxbS1B5E/5I9yqkZt+E3/+TMdN5tekQjjhlh59sx0szTLdnvF+3c7qm8/uC8ft/af/uOabz/HUNy1oF6myko8KcXo+ZFRXBBpbfPNhQpas2p9CBYtogA4RnjeWGs5dIffpr2uurqsDXSZaNK0dm5Dhq9mFyzsGyhhpAJhzH2nrL2eu/W32eKocCuE4FGI5yE/goL8uQart2+jqqOhVxbtYHTkQAuhWykpiSzNXsfvIYYc6lJZCqVbWefXa1ogTCK1sf/8UxMZnqzh96ppoICt7fnnDxenJtKZJCj9aOTXBNCmtprzWpwciHAv4F7lm3Ia8zFFHuonKsIvRKVSwMN2sU5jQeHiMZ6Cjcm8xWImrRrJVJlypqsMwZKZHWeYujB8IgyYRvBwbmFIrB7XOccugekU5YAdb5c2ZdGJZMUybvtPBc1NJ3brpK/xJL9ZWLQ6JChVRzSfknsJEHRfxJWitSxbQ1FQVOy+cR3Z1KtZCHLLMKKRzTWFM1wU0Pt+IIGkg+ltBmdi/S/SjqcLyYXSbaf/W0mpVJvaPc3xxY2+gMXB1PSTTZeyZjra/9WM09WLpwZyq+hfqZyv3WRyHjpp5seNipUsasqdz4JRGk8mAm05rgnruZzm6apymg6JTwYFPVE7vu1TqoY9I9tOyBNX4vloUPb461yjL1XQh5KEqvOdF8MfuXDRo/aKcu7BeX5yth9YtCQyVsB6+DvwmhOFX16oWFUDqF3sCTdsyr5HBj4aqHggSDRZEc98h0D+MSvkLA7Pqx420x3zGlebSnVaqLlynLUCjJ9Ao3Wj0pNRxNuqv8ei6S9wiQ/FKbOiLf1QWn1TRXUi3DlgoP3qMmIEG3EWaujVF0MiI+nCggPpZZBTKI/jf0yBk/sjycWe5Z9JiD68pT/tXyg5WYiJO8YfTDT6j21uT9YxAHP9fQU2tvJiQUK/WXUFiyrKf3Q8RNO3eGvUv/zd8+KTZjnyDcVBgNA4IjKZBfOJ+PHrsenbByyWlyMnkXldenTt78ipW8QslhUMPXwcmCx/A7uGinRV44RdQI6280eyReECdZXaMAcKWXECiTKaDdlTIphKsOQkVUsw9ZFjqA34IUOIIllGKKkWqiC500GTDG/faHLNYUVjY9HtN5Vrb6U1OD6DQtxjUOyj00ZdozDUY5LZLENgN8loArzW8tlY8zcuVTEtmrkV4nYfD62tlsZYnnlZ74Qz3SDUd7IC/r9sIdHf5bSP9+ug6l7Mhl5qOdwjUTNA/E9b1NsTkOt19lxyYSm0QJWU+fcXcWcSqmoZDi60Vd8IuSlaR+etEIp/Qk8GHlrWUITlzph0lQeoOfIiuroRvgHIvkv+mlmz/luU9e1vnZpaPrFwq2HaJeSUwfeDxEghqt+If6uBrNNCtF1h5sFHA0gF9r2+OnJVmPpGw43EIdROO2Mnit7z++s/jHfbKJ8xUBwy7Ugx9fa4RqOsEjX6HzvqeTvteblriN1yxso/7fyMIVq0lqbs6rKl37dFoJOr+kvW3aM4crV0j48mcvYj+6aC83WISphJQliAyx556KoIWV8v7X6ykZm2lAQjLysXCqWg0E4MZMVP6jIJ25f4i3FWfK6YWPRR5nqVQkKhAMQ1QwegQkSLgTLAJwWNVykormBuxaGqqiisY47VDNULtwidCqLqSLWitFCTtdT06OB2w2BpikbqApxclrnsljTGCwR9M9fYb+Xa4oHiJvVVkinJNbyvbaNayPBNfRQmEXajB6bRZGQeG2B1/EcgGOKwZMtk0Fnua+tWIHZeYPqvAeq8h1wq2XGL5rBDy9gLbNs5LXxHxmBEoCHBgWlM94d4ocoqdjDmFDIHK9eWxb1aUpZZlIlkndmQbCFVBh87o2wjv3WfPndRdHeD8TXt0AQb9esnI1N0PRuYV+7m6hhKNBi3GM9qm1QuWbR5Kea1cteyFmJPIcNflvwkA+GnjmS2XvtZcLEx+41cV/EK2HPAK5fv2kjZWlvvbKY+db5vmSu8x7D27b/fJUGuVUfl9LOetacX0TYGtbVtzXSJJohPxy9avnVlbuW5memZiZg2wE7oEYBq2nUA6OQZdF9/yvd/cCpOuz4YiUAFLq+viGZ8FzKVE5KAqXce2/116Ymf21Jd1GmjbO6949DSdi6v5Z50h1Sph02ggTl3SLegq+RO1xZHPiOlOjU1LqSt8bcQG4r6PVx+BFP6ba9EpbMpQimI5M3sq2YEieEDGt9XeekXDbp/Yuw5NMZLFxM/YNHVKC6n9LS0GY7hBoZ+V465PKkVtNlUsXcy2wYOe0skVTRyw1Ngi+TsQlXl5LgLLItv4HBMzcY8ax6U6YFicIxA4JBrF8hwQeEt8Up0lh/I2UeImfWc0FpsmhXMZv1MVLhN88dbPIq3bvu6kDWWESeM/XNXT3l/OyCg0ba7M4lK+5tXgEbGS2lnjveq40V/XBrgMtBkGnSQBcU652S9BDyHYRBITAWeSiOzMAf4d/tuTCA7hlzICR6fg5ZR5w+3OT+wG3fsM3J9/FfJwYAlXOzeRMGvjWcdfOen2qdRWnUP+wHIYQyppYUdZb2aCi9mRbU0G/5J6ob0BwRWY85P71Mn+E7rl6QnVRkIdSpPQdP5UUFMvZgIw24rd1dZZ0a6Kd7/tmye6F4WecpySaO0ETjhsxZZMVXIfMezSBNJElCpVjV+nC7pcOs/9QCCwy4DoBQGnTiI+fgqWBjmE8ZtOuhtwTaIG3uF/9mR72XTmSV1XT7dK5wrpZJpx9MoVej8pHhJrGOWxN0GnWacIaI11NpYoUcdHjTF5WW3lPwfGh+/u1w7ob5/fpo/d8pwUcqAd0z7XI4Nmn3Gsd9uuq565QBAIlP7vPM0cGuxrE/UaOyxrlDeD4yx30d/epoh0Vooa7DQltT5KLvDBKeGTCjMRknmroCMx09qUYiJ273WK+gI+wtYkyYTn7q5/NU/nlcx9huw/Iz59GojW85ePLrBqkpXFxtkubjGRghdV13PRx1l0dyoPCKy/FnFjvsLxAkAOeuUYny0UH+xcKKdeLyyEr/XKSrh07ExDg3qoKGbviCja9xvcUqOWi2Ma0yVcKybylS6uaOKB5YamgYwPsQKtdcTa20atfWXxtfy72qwpWmow51L+S5S7jpgxCIIg6H2oUe/1+EHPk5P6En4cOy/ac/NGNar66s25qd2xXEQBizRqWZ2AoY/Vl++3lWh52VLofQfCX2rHUSDg1G7izaeQ9ra6G1ZPmqPURv6lRFbq0mWaKdbSn6FvvQG/QKxPQRE/bWlukyC9f3XQBpfc26UIz18yKFUpUk701f1ULmLsnf+Efz0NJDfLhmtDkjiFieZ21ruBQhOA8nsZyVll2am0X2/6pZkTJXog4OllQkwU/T7VY/ymk+ngtXbUMBJ5EwZ7jEQcDZa8TT9UgjK2AJ++VFSil3wJ2FLySW7PS/r8r9xcvk4mEOnkfME1kfAaFHYTgTiGgD1BIB5DLrtL565XgUD7X2e//gtfwJhaNblZP0W3hn46eN17ffz63k+0Qnp/7eTk6imGDe7j12fpsZ28UC+19wk3xYSbaHInIVEWZFMOmgPq/0Ax8TiWP6FAWxYPvSYSXBfyhhmslWcj/0YgxrUWhEQ+qqe8HlzyUXkdU1sZc/ZCB7eOzKLGE2oTH6N8B6X+JE+oTHy04l8Y/Zxo43vCIq9lydiCq6ZfLtC2XNQ2f7Y+/k28qAKiLUzybs3P3YEzotnwX82WvwW/08EFq5ABXyZUdg2DugGB3kBhrn2wSNgXlYc9ICDIeJ3p97s4vL1tK7Zx+O6cRK72586/9dXZryC8lYkyz6e15UQ2wa/2a9hcfRW3Y+jnUNfo4TlMNOk7GDs7erjox7xC2l71nGLUs7KTfZyq/FCZI2xhh1v1aEpDjvzhdPd95GflJzBr4Yn7bx+htLbtnv/FQz9YqijdvpwR3Wftx8TN5ERfNL0gb9i9vSLY6K6u4pgV/dOZhu0pO1nGUn+KSxio8cZ25qpjyZ1pmbSI4qroTvH0w6+lmIQJmWiLXcu9KS9vN1qqqyVPWl4pVHTscu64WkW7P+G0VRQkZoa94GVpTCU1vo8YEF6nyyBPDLPV8bPs5OMZeuZqUsC+uFdlRG5akV6QnLHnAW1AmRUbHR0V/fmxLtrMbMLXY+KcIqoF3/MEbgCYAwvy1ktLaMKLuSpWHz3s1FbU7EqLrfWBgN/r0VZPpP0kpzqVAa2RsCEFZimgtHQ2slxYLPWUPMvRWvAT6zv6DKGW62SdcvUdhj3La0F0mEsH90coZh0kl1uk7hLk10Vf6ZX5Ylw3ukCIqLp2HdzRWDRhb8h3NQv8AdLNVEEIpreU2roDLHe9tZrPbEDgL1s8Y9yqXmZuvbYUTQ9p64x6cbxKM9FNMknNrYhDkLkZYrem3OYEYZwmtWqvsEdL4yTSyWDaSVp5DIGNpSlWaUb3OCGVWa7KeqMP5o5P1qkVMfAkopdjBvP6TO0ugtl005VF9S3QDHjakYVPPr6NLmloChh7B33JaPgs/88BxwnBFUaObeZoXBsoQpGGrYcQnmJiNOHP4ZWgYoDGo1AP1meTRw0O7GhXuBenfrh3WfDONrlrcWbrvwGzbnFnrUNmLXHR4EXANZM2dHpr4gzpEeRgGCv/4y9vTqczx4Kh2wwzHSOeWSKJhZM+wCXrJCdLoVIDmWW3Xj155his9Ix3HQ3Cyrch7J/FBO05RWj7XYPVJiPF9lRznxyuy5QlTEOsTmrjzQcqNwiEiUHBdza+5yzAsU+q8+m/MFo564AINptqZI1YrYbPMwrDfpJxucxaXre1AuEp/qHDovoSkWUPO6rgycfcWnBT7QiO7R1t4a2fdFBq9GbkJ3OpuYIAB0UQatPVrdjqV9Be26vzskP3ZWNMWX7zWk3bmzuKqQlANfZFjlHv9lweoyDIVnV10q+OS+Qkhgf4Hhu88R7vMUUj0ttm7C0P+B2TTQ3E+CutTnTh40+5K+ThwqQroVsti2NyXlhl3d06W2a9ozmHNnM4sjJd2CoOapkX5jWGCAISMC21yVYTjzkbfkCGLmAF/1Bgf4A9bzZjuR40x2Zsnc9xUsQSgDwXbO+xtqYoPq0DQeHYGLS/64n2J7jTdm/ToPsqvEesY7UYwS6vtXUDuqpSIAFeN9jv9ZJz84Ax50XOC6Z5ebSx32tRzOxDYcYqMbZsVa7XLqkRJcsot948VCxbAuu8Uq78GBSBK1TNCJbs4QY9UqHTfmVjbPeDKfa5vygIQNKQaMlDd+xLnQCQroyAxaOKKbn7SODR+jA2t6hwZj7PeZ5sUhlpHAjuUYPNdK+t6dX2oP1IjBk1wUN3D0ZBncLMKzD/KeApdFGwe9BHVU3AmFO1Rswkd6q4RsCnm+RL60fiWTq2QFITJWsmlxlFuV/x8I2/K6x97Mcv99WKdZrPq/NTjyvfKm/uOqguFFxgKBg4Bhwrz5xN5Wt5rCXHUDqX6Y+VPI0fT7ONKftITtss0Juvr1QYgFDlfnrMZ6k051IsoZ6Xo7s32GG+gUxzchDzkV8W5ue3KhoHxeK4MjmppHu7fj2QAl8DWbTemoiv1PV+3RAT9Cs0uthgjHUpsaDzQtPaYQkRmijbQXU0z5TFBMKJ6EGVsHA+7c2uE9k6j2uH7mt4mvJIXJd8LM0/F1j/98m2kzeH23RoMtGUGN6pJL+h0EyLBVWqhnEjp7JlvJNUaHShwYR7IDykU9Q3n7p3qgkrZXkcW2G/5BZ9Va6mO85kzhdNPxsvhHQCUktzUmVhd05qaX4KvGuwQKMNxws1lS0Igq2aIQvM5JaqFMRztmyAWFB8JnG9BCVIVOs16j55c5XTng5qZXyHSKt116/gW3+p9fH3zQW0iaGsZY3pfBOyU2YZYW4rq6IlQ2RKtjErJ81V5C6r72tJJbd0so7oQGsU29WWukmlQ8DlklLJmURF/+2MWdmIBcivCvIn+NVvPPwPa9Z6uH4byhIOfTVM/FU9yKZsV6E8l2PGfqpcVeh/M+bUfMo+Sbo10lHfVr+hEalsaPc469vyotp0ETHQFL+u40ismKxAp08W6nR12j1yp6ZTlITIRbu7PtKzu32T0p6SrJ+UiKqUyfFj62qZz0IpNLrIYEVgIFE3zbOqbsKfLdorLsRHK69WE5mBsFfyrOuqn5ZI0JSKctmIxXZpl6gajNR2veznh2AaWsUZHULVuVTGfDDfgD06Li/TRIuOK++mgHn9gzM7S3k8tTu7PANrdI0jhs0uuSZ0l4Bx0TxnqgDil3o/y+9asWFQ0y2jboIKGjKHNDrfuYaGjIF8beBMVxz+c/zY81FMLZvmUSdn5LVcXWjDuepIi6S83KO3CUMi/eeGM40ONwdgTUUKeLhAYPP0nDaAWJFBB1x9rkezGluXC+SaUV1KR8/RzcbCWJvLS0qjug4d6efxAQUSrPGTYOAi/jJEZgRdITc1u6Y+xzxTxhGpVi2hRDZhZuGyvVM+WpJ68NPqWB2JuwUZejKXwmD/RZ7zQOqOlx7NhDC1lbrPTZdd5pfmEpxmcMd8mL33H/Jq5kv7vjtgYB3wTknfQ/urmcWL5oAswFVzv39Ilb0IPDD4xOxbaoa3v8Ca6gyoksC0KmYCIVX5iZzAcjJfbvY30E0DXbaSLoJnbybMfghNKca7ocE7J2HqsSAYqRC6dTIGsxLZe8fkk9zox2BgCpXKdjHNnxu3Xu837FCoyHJfJhjLqyQM5W1I438VjarRVlHgIzZuFq/bbIbyLCtPohatWTmzEn8MeTPvjhaTemz5WouhkpCo1Nn/z6Yw+Ftn98xp5naIz2G2vhkaZznYX1lxcqDR8mXOSyFgGVU/QU2f7G8B/eUbyOVnWa3mgC0vs27Rks/LtFppX+vAseyjs5jU12Zz2rPJbruRZ0OKfg9y+gMtJvVwQopVBeIMuRUoEqBQzxvQLdph8v4o59zghmO3nGFsAvL6jJICculG1DX1p7kd4gnfqWvbInRkNvN7SQCVul5REDvpcMg11odKoYq4BWI9icM8qeyQHNP1/b3iwuer7D8wqbQK3ReKGZ92hBnIxP2AIGrRu5Q3DCjL7MdzhF95r80dVBiq15dsw3gvCGEse49YOzrk089OKs38k0XLmwaKcpaqgZW1d7SY1M06q4K68TCcANRj+l2CJmmB1cmEoEmYYU0isVo5dvdFMIDrbre4/oJJ/Vha9rDvO3n3pubI98yFz5DhM+I/nJB8/uTRBX9ZavMjBNZm3PEN5l6iAw6bPS4tHdhRZ9k090YUILlMphv0RcDZcamT4St5X+a7QbJzolqMuxlfeG/MfHQS7rUAC6XvyHbUJ+jrrXTIbsQ18ZO50Tbr/b6xy5UUuS+5E+gaWEkcztuwyrd6rSrMQGYz74w1Rd9uKYoSiZbBxM9e33jcimm9+ffN88yatZnhesraZcVHqLtfm89pMUeOZbvhTld/ILYnt1jDHrv3v/40nML8s4IKXALw9yvWpTh7NB6wKjpFnJpT6/QBXo4tBU7oI3+Fnj7SYfNQlQD7TcyMnRtQO18S7NeSW5NYl7UOI4duoabX6eKV7mmVtxy/2nz3zQDBva2evBYQwRmBhkuCerYsGXAT1bkDZm9vtnV42Yl6uNo24+VFne90+Obgh3X6Z4ttOmhQBzo1G23Ty+1bIeN+GCcTQM0vC9MNbUZIJRSYVFaLQS0QGsvhNTNKvg5smC8pqalhwZoJ926aV681psB+PzfRWL3G2FTR+ybcs2PtAMN9KLHJ+nMBEufvtp4DoLyRT6e39yvw98BV4KZl9PHGSN+PUVEol+h7Tyul8HrK3adoJ+k22akIorZkoPpfKY+DTaqE9fb5DRG0LQ0p97vzMyuLQip+c7+2qaw4b6FP5p3lKA6orVpcE21IZsnsc24HMKVNp1k3rLCxJiP5OsvPTcXX/1a/qOJ0UYPfUpDkhbid9+lvLcCWQDjoEm3Oji23Em124JOqvxkQ7qh5rfb9TgTKNyrMMzEn0fEDgwt7Mh4tY/rMDg3b4W7goxQyBWU5KNGe4KsA+DgEfYo7OWNdIvtDDiPocFisIYHO5fhYEMJg0e0CoY2OT9mtUgP+vVQ/Qszm6V47kenR+eFPyqlH7lKfUJmMRYdTiC91TOoxiStz/i2WEaspJ8dE1ersWxX+wmyjFkYGEdNfvVUaLMk0amNnJDn2TFgjiZ1Wq8WJ6h3wjGdzGrR0qUgipNMNEpE0cZYNccahmNfD782wlWcAPwA6W5ll24anF5nZIQGLVj45kryIXIZBVBLqIRXjrMaeJjvI1nFsfXpwljm/XZLczLaFlBBi/U6he6B8BtFBFgnM+MaZjMpH5lP+mA/AEsRFpe/icm5Uejo9Ohn9zPNTLAopqa2kyn1iKXnBLwQz76iQESyYdEbA3mEw72BwNewnsheJmsxcf/szCqmdPWYPcDfBw8Jt9jIqGt8BbOnW+BFN2B6CJrTDUeufPrH9OXHvOzA2HG8sULBOkaFIJolGgnKgkksGu8UvugPAjJlTEEMU1MF28rCTw6uT0S/dOYWhkGq0lRSFT9QBPM5Yj2CIcug1io5bkmj4JztRyolpnbY03qEEyzaNPDYx1dAUSUCmkPtRtTYneP22N0fR7rwVL35mO+SWGGptIpuFSfPNcHbY0Kp+A1jlHa5VFayEhjU49fuC5Od9Ho2Abt/wZwnxf+JjFe7n4WzLUiT76Ay9BARy6r5p8WBtOEhrg7FAx3qANPqc7KAA+Ad98gPDnS1ItnGkTz5JPMR83mfeMBPoMjP80HmYRzA4Z3u/vxH90O0nKCSOkkIu9O+O+Oij8OoyyTSJ8bN7qsQfT8Ijqqsln34VPlVs8NR7kPleUrxXf3aAak/oQw//Mvw3QfKFZWkR4kz5KUGVEBcUd9LhnYYc0W0c1cFpeNTr/5JAeMk+p0EpwiKLwS5MzPbjEdMkkk+nhdskx8UOEhxcWkJEXCyMaMkIU8MhmSJdMByRqBaPEicS4o9Ka7CRwe+C//sR+I9vuoYkhQdhD0cjESrAzLZgQyVq7oygQNRw2nUU9iYMswig/ILHFLS6jceg5hPJ81CYcYbB/1wpg3pivphmA/ItbXKiPx2rDBDWAZybRcqjIKHPiwvaS5Em+ykX3joaPp/tTf1GshUCQANrjEaUuoSCSTF5O8oD1H4C8XADLpRmVSOIMA19nu5GeqxQHMrAWwP0H4HFOwI/IxkZEUaiwEoPeXi4bCTCjwqNDVWOlA40TvqUJl6BuTU1SFFbPzkpRY9sOBJgp9CDs4lOPdKIxCzgMk3yQL1VzdaxBWJzWArrNuatQwgeCoUPBTy9HNO7ZHOQdxDIGzD4DSRiuxx+6qJ1XjxRBbEJO1NFxNi6P7wClN6J6iFDSfhcQ0PuQFhi9IxfFD39AhB8GuUQtqeKKPFJQ9mfJfa5vgmDjyCcWxAgQWyRXuibOZQx72yXt6eWPANOmT7Pi6noH4R8632waMwLIonDxZIe0/cDrhdDPUIOuT5nMm5NyFD9Vb0J8+fS/SnFYYxTFj9y03NY5tHk8MPDUOj/cLypPMJQ67n0XOAb00hl/E7MCNP6otyKwDuaYxhdVjrS85P4fbOVGtqVwXPczFwjmnfILLJE3512LG18KV3Lnct6GDPIG/+6ItnO96OzBySm0lbVrtjRsO7f030M7hthZ9JztDlKj82CWQtNK58tGDuP2WiMtWZVib9R6zKDRbr3AO1en5QsCg9k64MvS07rRNEZv2OH1k4YPaVIZewWpUYXG6iyyO9P0WwRb2ntfDSZrHFN/XlulHgqdme4eao10kRmM7U47RaQvk/AvGiWM+BF9PlSgFx8bICdJ2tCfESJai2HOHV9yaI8KmfMKSpZLggMl1yM70ixXRcLyO8sA9Y1WHMX00YLPiUY7zGwPKUXyrwrfqurTfAu2kfxS1M/Ezd0m0qfVNwj264bWcANd9SCAOSDgAUw1TAsr1BnUDJr7GtcvDswNkYT8jdkqvLtoHvVj0JidzWP0Tp9Tp70cF9z72i+z9Jh7HBXjUFrroG140wjq5QDQ/2cdnuUl7wiVWU/4eRY4eQ5jrYKLMhfkS3xjwMfV78OiD/SZn7c9zoLU3drt/IOMSknq3BNUBe9KAtZO0Sae72J7s/ywI23ChJ/+OaH1+sY+ejVL83nE3/oIv3Wwo9r6d106rVhXkm5ejpOjhSu3HWj3PGBakNd9KpdJby3PiZegj31z0avqovb8MCv/+qK7aED3r8tmx2nmDxMmnuzkeHPrDeBjvDTu3dHNNJ1xqv/9n1xC+2k/mFtk+3csDfCevQJaV5JvnqGEvw5Srhy99PcpqMXtlz5kHhhJGx8KmZVLcbt81jx0ZssTN1N45GNLZwbZ1Awwmjphu4EnzAfGe0NFcmVOlRgiEKzVMssCeJZLx42ISpagZC8QJ8fdS6MR4eU4wl0ZiiTQDY1YyiMnXW4QEaGiSRWq52SNFQ5HemAp04qq/tAYK2wNzetTtCZ9rALD08gvtRcmTUJ/ag74QwMek+52pQk8rqeOCkZXv58S2tnOC244AsZhuCIvZkeuNgo5u4FBLE2MzrOQBzCU5yhJnsaFXA1WEwnxa33yPLbXC9oN6dNGd6CQmZh/1HKTvd1dPrSz1yTpxnPz90Fys0dD7e0tMztKtxrUaiek65R8ZoLz3+zDXrjbppTNo1iBBYhiMphO2WyKZS0p7+eWb7xvy3/zXeuPP0/yN43Ueb7mffT3kgLLw+CWvZL1y4X/OdSsG6toKQRgBjZ29RcP4/u7Lf93Lkk08MuaSZpwRQDygWuzynUb7bLNQnnJVwvLAA2u0wXBSrdRv+lTlQMqbWucw0NqQMaDXfGTdTTPXiS68mkw82n1MHdv2c5upJFUvJnHv/KmcZ0byxaXlVVVKvSLq8b6j3RBWuXolDS9pmwhSeGh/tm2+BtUeFCqysCxl8aggVm63XWDTG0X4BACKYFYaFZOj2zHlFfWGo4ng2eKJVNSoAHZpeVjm7kgmWvUIhXtuS+ii5dCT5UPeH1ENGRCaHVTmKoZn7JLJp3ZXxYDQcyciFUaxoQUqwYH1qYTQMmSJDvUDwpbiP5/PUCy2+m7wsh15FlIizDpFz7Pmq8V7OtQ6dZ2yu1trkQV6gudwvGETxe35wxmukorv1edyUrDJtMXmyuFx1nO5HdFNdZjgMl0OvQrG0r0Gwbl+GVhnAaTQg3Hr5+jKcV7UULc+jABDHyXzSPai3VmvpreutIWKZRsZV8eMjG8kXEk0Jf87XgrrEb7d0VfTkei+d7uFJzJV2nZXQ/UPv33FHtcDcSqzX53S8Vu5+nuufv8mgYONXdXttVGOWlHjjAw8/IBa5aimqF7aPGtLYKfte4Mw31hadro9n+tg9qJpW0TZ3OsrlaGSMnMXzA22XBoSRwmcvKBXyEG216VxGIf1ht3NrSffL4tqr4sndX6mQ313u2J/PxLp7DHI/08qx0spMH6uarnujioef4AE0paJCAZ6RTmW5E2XvW37MxpaONK95aj3mKxqfQev8rNC5Ca80MbI/roJ+WQeMGCL6AjWR5aOuGPFX/T+dRgvfbLMDhHtHZD6VURH30fJYSKjLWuxz13mcBx3afee5rL//XLldqXWFjYZin6gImDkhE6SiReIQU7bm4wIse6aisG0F3DrMRxmo0+HNZCstu0zP82ayK2gymKd0hsyJpbiuruiGdYUoCePYCk+NEndPL9yCSpkb0tzNsCLiZu1TOKbT6aD0WAgFiQTsmYRrQ+EyBP3jnpLM6wj72wnxoSjFVxo8viKVxZcO0wv5zDtYqI/N0I/+ddEs1kR1QH3uTtZY99aWoVE+S85kQ5VxmyN4BNk21bPpOLXkl59R3iMyrk1LuJHqLdQsX59QXJT5jgL8/efui0pNY9piwWRpRDcDbVZgGehbdIpUdp8biDUjgMzI5ZNoZ686L+Qt/17n9mTHMP6PtnJova0znldE/f1N1PrSNjPF0xt6BrHg1sEGw4YH2AVOA3fYnMKCiH0htw5uU8Y8Np51qFtK5p7Q6w8kKKj7w7+PEq/PEUDibysxmZr6Krng9YOwGHZzfPqCKG9UgKzcp41UPYBWGiNdD8Y49HyavpDAWiX4YlHIJ0o1vPhXnhW1Y6p/loqCyVV0zqwPXH4uAy040Kn/IM3ofPAbffIoMsE7n3zh2NMTrlfKeeekDky2nsiAc0zjNepX1cF+ozLsSGnctVHhUZIQWTPj6X/78P32auezvfudz+uj+u5RJj/kcmcJ3tbDYSWmjkhTHc0/5bm2iTiA3slZ47E3QLub2pEsbIDYGrnGq9w3lUI/vT5h8KM1W5h1ltiPvjPgk2/9EpWo4t1UEyb5v7tt18mQr1T5VxgvTWlujDTzm0WM5IBuXAtwqz2aAeQkMtlSctlaHR7D1BPZKiOCOs2BcRv5NQ9TmGXTVbDrnVL7WcLKcig82/9l3h+ivGE9Y5HV13Vqw8BWhtW2wrW2rAop8cOJSMaVYbhgb8MlG1cgUOmW8SqiVlkdqnp6w2rXmOqA3V4wwtm+ZSY1NYvvBawgI+VHl9fVwtgtOnfkA27IwlXE1f8f4uRnsDSgqcvkFvDV+vrmzsjnT0lWlYE6x10TS9FCQI2hpYtH2MI1Gj5ihttZ73SGdt91I6Gt/Qf2fRYDt8uYEAwWwPSGu88o80mjYjuicFh6SVNlWh22d93lPuYNJJsheiw/Z047Ix3gY0fgU8t6lsntcFtYQfNHNwGPtW8qZPdmm+0WaQ/VVmzxXxk1kaLchfX/9sey5HWIf1bPU+6uo7uaKy7CQdRcdFbqch+z6AYP5c+2Ycsz+6eGy7ck06Mtth4/jo1PBRegryJnejmntdBevcxHd3Vj2FuqO5+qR3n9ySrnYk6dUSOrIndAmPPfbY0cjEJoNj6M2/VqPKSDcv9rfZBPbvk6zSbtjS9clE/EGfs/RIxfnFomnxOuLf82lzqrA/LqhfHVD8ylv/fFFlSHPJSANx7M9oSVa/ygb1dXOQrsLWgsiLdMsaa+x+ZItGjNuSPyMaCh9FIyFI1Gphw3RX4+K69KeNhfK7W83T5SyvStu2sbwTx/EVQ/psBtSSGl9x/V2uUrQSH+y483lzuWy+HWpwBxAUclMxjhXv7d2Vwm64tPNOy3H0GqrVgpbOl7SOgHIE5WWfvLZTJdSPjyyO384LyX7Yb9b6+iVopiOdAnfSshI1NtGAFb0Lmw0ryMjIhn1kZfO7gsIAdiWtOQraIXJkkMxIcS5Zr68/U9bgvdRob/SlHFIfbQRPGsbqO2q1yse2zDTucfi7P+hWhOpnaYmR3eNhwounqxPK83RAk3Fs3uy/ebd+NPjM4BF875uUM18EvdYnt54ooqC92vzX6e/ek1xJ9JpC+hNd+jKL0LbhnVp2L+XffO6zRObVA82yMvJ8Ta3qx4rd1QIXqebKb8CvtiCafnn4dvBe+/MRnrT8r7yzuosXj/a90KQR2HUWKjT7dMkHE1555H/oXIlyerPiW2ycqprvjsvab2cQvXp8l+nv35NCYSHh3P0xqbW85A5aZEjExIVOT5PoTXXSJW+tLR+E+KLnVNdTpajpqYZzwjoF/0tQZM8WkH1dS/muVafVEVBN0h3HCp+PAdSsRTEHUXRJkxjOmIFuogWO9laiteP8b+gmUalM0xppmZ3lUH858HbzE2Uwdl7NoiC9XRfgc817K3ZbXCM9Nwt52wWFWKbA6nakaPy+E1dbvkWhYZZd3NVd3qXdjxPnAXzgMBvzz2vHowz68pVaTU1kyLqlM3AyzXPCpH8mohBPXCVKPzVoiSu+wHafv1ZB6ilXI0AiRl1RJks1VbTwUqpL2yD8RDmVzguP2SHdXnv+spsXhlTlOfadEq34LUZGXpsSN/fcCwbQ8sduwSH7vc3jdghxjHG5unQrJwcD+R+2UCv4L9FsGWfZO0wGPYFQSXXGnP+CY+vIiV4zF++AIlsb1pmQKK1nRQN9FJj1i896nGJhVi2N1R+El9xlcrpaKP3e+p4oFg5dsW9rFVX3KvjLWy+RosffK59XRNoXVyT71OKa0Yp6hOtbcOzMclnolRGodL6JYK0IXhaIrbXIr3d+ipFGwoo/PRALd2h6epORAB5cqy0Xtc6WRmJSS0DM+oIpRHw1Ui2Ril8rJ7fuipby/sQQ3fF/pRgbcvsRmdXaY8y1sauyTYPcC9aaPLRquoSz9QxFaE0KSUhq7XlLOmrBBPmshuKzESWqeJtdOKhaHF2wo3U0yy94PdlAtu0oOE1hdDtc0FSvlGskAXwULFlfrn3gnvuihjWzeXbjpl5n0u3eBeeHDypWZWd6wl446btbGO6r9FCq/X2Brqps9Ve4sV5FqXCnAVLxbWCCeMYpMhMaqmQwqmEee1XF5bdzhD6ogIk5VvFamUULxFb1lR52564KePYBJcfuWD+nPPR25DcX38sa8zPxnQ7LTrYUk8397d7Sj1ET6TFXPWGHeAfo/q+gj+3BYKgriKLQ+avz1pQ4KsHdvqU36KnR8GotyDzmPGyeagvC3TLv96NvCyuvudoV83rTfGhPb0DfA3CiIEhmyjjkJDXbRPpUVWRRSHLiaSXKfS02DH0zbSbqQzpb8Lqdqie4/EJST44lGYuLs2fLvPhtZQvmy4oGr5byr9WWmDbXCMr041WXqbEtP5DysExF2t4A2OaDTRqkxCrZEeEDlqeJ180qkcv3DUw2Nw0MToUUwPuwfueiBCc+ljcxZhjnA0hFWuEuKHqv3ZGAYUCarFQoU1dXfNz89W0oKvI4A6rqCdi3lv1wpZV2XkenzDMB/dtFQVpL/ENLR/EXrNSXVR625BAmlS3Rx1sdFKpUVeqIuou2OXak4VQ85z+ojQ0wLrzzdiWcjEqUng6e+yOIYRa0PB8t5pPUa8aVOQfD0nKBtSKxuchFev8STsvH+gdBb7rdRAQuP0c/osPtwkKwWY0tVqxQP7xx9ELFAVd0cbksE9unBN69dgegaJA9fueVoBP42YzJEd8MsMc62wZ60CmeQF4Eka9lMh1bnJCs/OCCdzP9FWnNbY+1wcs6Ty3MnWRn8OVj2Fgc3jQXeSLub8UCjKHtXOSsdrt1hGF5R83TkUUdMVrk2BhFrtgfll4AeDe31MzuCYCwzF8JyFWVuCLrzYDpQHnby9lW4c3h5gFsEOvol4uC1DyqoOVjnNkNxBZnvXb7ezyYQXBBIbP92zT011nNM+tRF3g5/D7JihY0shXF/piXi+FgkzmlvnlTguOE4haaYYxaDLTQGy0Soo1n41lcvqFwMxTxOJVW2iZkfopPLJeMjR8B9eSp9TdS0r0cKsBAq/1OAicsMftL7NOO+DopSww9ZFusVzC+Orx0y2s+FiaEq2MqV1zpBCNuwADtlIq5Z1FSXQj/XF7l6QSbalInumasnOY89eAQGvZlAgJkanFuImbPcb/sUNMCTVw0LfZAfMloPaykug/dJRR9VNSSUJZO2Zq0X2ygaQQRVLjMKQSmACG5q6Ot9r9WGValo/bs6b6EHtXU5dOsjp7YmpyfKy6SEEXFK8ACklRn/IoH8xpH3Wmob7kbFGAB46lRj/KR+jaT8nom4V6fHNQEUk9XQPPGRZn3gLzBDxKhOuCc1igK6hunGbTzRbDHcAlP951DtTBc4fFma9CuIIObEAYF1R1uBCNvdV8ObEQmtHyN/0a5D2a64lc5txj29ZYV5lg9acatSqFtHa8IuV7g6z88tQxKyVNEBnLQ1I5v07VrqdoP9TCSgrzpbeqKnXYfZ49CYpTUh6BK8EXKFWLFwLVl9yVnd/xraPt9Wq1VcSXVWtSYScXz8rV6rieE/ehrySuFdub6+dE8qpyR42LLTCjWkr5mHk2gA08A7/ZKI1GY+4wwLzWsP4QRWoY62uyUO9VBvMEXEpE0NqkUvy648GTdt1yz2dKjVPJIXcdfptadCTzGtqT9B1y329XFf8p1XBYGKN1KbwEGayYAgUVkxBlTMF0QGGhkDpRl0PK+HnbVftNcDSnne/Fr0jw0dONZfFSg0eZ0s2MxDa/4Tm0Mrrd0NZeFrVVnPst8nXSVzGkDiCux+TuD4UotahW+KNyye6vRA5qKe970P6PRMVnrew+JH68H7l43BMGE9ylW9ClL0h0Cwo6DTeK7vyC2Nb3kb0AXYF9BqZCRqwukvedWjVhQD12m9FstMVtmBmztY14ZhmWVwY2Vlf9ikWiCv3Kzez5TS7p/VdTs/ECsrAju50BquxQ+n+6FySRQe43Cu5nv6dVbFCEtLHAE7oFEdiTvTXDT6wP9HdmncgM7OU+A//ULcDh9bMyJZrwsMQtcHu7YrRTa8JxHwoxSfHhhkJ4s0euSR6XU64XFhi2Hst02Ghv6785HGVdY2z8b7qXbaXBT5DcirzGhswhbb6X6ENog1PsC5c3DRQSKy7Px8aONPYX6QH0Gxw3jj/CR6m4bp5VX3/aK2U1DSZI21DJaWuNBk2tUOUXebu7jil81miTWFZl05o0oZD/tz/B1g3izG9CYLOwOpA2A6Bi92mS/RtdjIa9DQkC3UylELDxRgB3cY/WPq7bjh17XLegy+akwxPWj+YM78bBkBJ4qbHW51QwPT7J1JCLRyrgWyUWWQrTVauLlpcPTNGmyzj2sOTrelLzLQLjRxXDDfHiKhanI6WPSNWtRqSnwtohFI1TleL7VKxKOD5W4gfKrq8lCSGsqnTlGDhKzcMbwBycd5IIJh39vm98s4RR8VMmxlTFTVtoM6p0AvSSBR42MKwYvgdGKEXr2j96v+P22aKrFRRRWUo3YRjixz0Ku3tUXywQ/NJX1d1oxgzuVd7Qc/7zU/7wGfHgPgRuN86WszaRn7lICjtZ7fWZ5sY/p7EI+3fZzwPb73MHg5ZH5oXP8BXEkc1DPicQQ6pzVNyYuFlc3A7gAMTvo7xH0zNS/lNi5n9EllNnmwfe9JYmRm7bTJbe3mPfBlwk/DC1EQwLL0GlXriXwvZ7T0NBO65svoJx1bgt5UYe5ZZR2EvymH+he1INpyFmbw4N5bhKPu0uGG+7fKBnSSJ9BX/isUFyY+JphfKfyRv+zZXuQjqazio5FwtWovwfkZY9kcu5P7PLXBDvBGTWKJS15TZNTdugPuPKvOeUMuL0CRfd7tfDgAvxDHTC7tdc00LM9GfBUlV5s37kSKUu/+Yz+1aJ/6W7jtjaBtysd1goaR1cF++vBZnuvQ/q1EZSHs/dmsYB/0ilEUZFuW3HhIVknLF/tcqsUGoXsUItQ/GMovIyTpM0DHsSvauA+LN+xnSEmQ6wo5k1nbz2M6tJ+JbomtFR05cDcCuNv5HHMZM0YqMuIul9CorJA26oWV+I4kerjYjBA6Dzecq0W2m2OzwdvUP6Wjh6upH4NygqE/i8qiQJF5f7mCKuk+GofIEtXhffLXQYaHGahoTBtgHdDyA9oSH+XIniaPoI6Euj1r4jsfj+uBKdyov8UZZr+fK9BC8r09llA1zNlSMn0277ibUpRXmPecG9Qu/Dhy2KcMXNctu2uiwdQCUn/iF968B687qKO6mc5E0CJACPlVHLLyaO2tpGQDs2n9pUKLm+Xv6fDRD/ChmY1t/UVDLY5H1oOrGH00MZk5tMEzjAMqG4vEKwLZfIrfp9hHI8Jttes1zS0dsQv0rfEV8CLXhy6LHa6tGT7pjzqy2qKmrfq6Iwd64K4Nz7ASitDdgU7z8oqm4TXP5EJOj3c6cR5toT1xJqJJL2IEt+efeK0ehHbYdFkETmQloCrzJOToWVH6k+PlfBBU22vHd/cPLZXVtctVQR1jZZGXKZ/g3bU7a81Bcr72MsY/L0QpWipuwY3zqjHmdSt5DUXoNU4UGXTCJYhPHGw7czPZDPKqdd19Tz+0YZvp8Es4JcwbIqpgDHTHGYDhAf7zycbi+QVxEkNhWXbZ29N9aldyeyzzE8coFT1wqbqpaf0R2SMhyWqH0iekV3XgSpzHQuk1Som2M5gGRLR4wiq1cY6mmcWu/qsgFehd2KFrTuvAvwOCvtjj6WTYyFm2y0K5a8qo859733bSPjw5CCZiQBkp6zTw5KaYqxdJAmLAhXbBUmjZakBUQsJAVbwG/HDaLkVjLCXW8au9LcKU9jaBRlKI/HRoWdSqtYAEaRXNdF0/rI30M4Mc9UfIKUmMvLxWbXRHzK3BcV/mTOsUyvNxkkGGynTDCD4xBjogx23l9vCl0MWHxAg81G4FOop1SdDpBILWZDrxZDX5CzmoFeCYGfQ+DOlZyTH2oa0FuijsbJgLWN19Eq0v+2ScULqpJ8dOWtl1YHieUWnaFbh5ZP/LuGgRkD4Unwh0p+Wqu8xb2X5CC+yv2KWvH2LVWrr2etV6q6j7h8IkDNWVdP0n5yuAOK6ze6Oit6VPEudjLbjoY7ktrvSgfKrPba/o3lKbK5q6g1qmdYFakIG8CgR1BVewFdhOX13mfaZk9MS46rrPXrvOZr7l0TO7s7y3syE5zs7myXSMKF1IKrHJjN5/SUJwc2Oruauwtbo3uOqKKU4a61TeXEViV9gG/QqM9RHebCzNWOi/0qlPNllrGctBuGSzgNr1/l7GHKXHdyAEFcJ5t34pz3SOpI88Ab2T878NH9ndd2W3zVEF7bDJyJsDkbakJtgZ1VIqyvmXQt1CDkbhjfr/+HHf/xnUyAb5TtW7bwzv+SvqhQuwnA545LLO5bo9HY0Pq8XfV5kWpZ9j0th+GR/0tMOwYZ6QDtoIfahCsik4+D42xP26j7acZaYfYt5Q4lg6+Pu45h0FM1UxS1zyJNBIbx1+Hod/2KKk6AU8lyNtPCDszaG2aekMYz4jPPXS3v450kpun7hbdSBur+bCmZtCLO8eadjA3+7bfQtfKk15ZaKuIuE7eWHVCYT/LUxls1/KMqSgi9j+IfFapjnyO1dJTGQJkjWYHJ1PliFSmtZJuc4tK4Bj2rmNjOF9I/oI1pcC4eVxanMRZbF3YyADKFpaQNFAW1gvxrA4FY5CrKhKOLDpf4xZ1Su/2AvXnL6bj9qG+Vfuibevms4uF5srHxrlkBAW+eh9pKgultP2fz7+THdbkVlyWfDrkTY+wJf451kS34DCvvC7Bj7M+s/rk1RSfc5QJK155kY/p3/Mh2iphAUrDKpmhT+IezrrstouCvCJQ53cSvtbfh/KR2ON2o7yZDJ/4i01YiL2U8RxeVDkvXI8EWD2G3VMCyABc0Ee7Ycgpl02AwXGuW5rLu0Jmm5pxeOccuJiSNE0BjdVg0sdCdQGI/eAeWIEqWTuXXi8rNTl4CxhF4JsaXSzglxkFvm13DAvMQ+FCMoZhg1qgTqz2DX2ifsz3Eb9knzFJSivQlIdNT1YmBYGTxY/tW4MQ/c0VyTV+fuu/eS+jV+gPzL2NzZ3gaske9fXfs9h7CE5Ge0FE1tUNoT12VR3Uyl/thZTwGJKc0cgDHyZGZNmRJ1f2dQ25tuCJG3PSF/Ds/IRLtKg8W+bjQQWwrflHCYHwyYKxSmZYeraiLn+rOz5LsbVLVqIRftzCqtnP1xScU90kwps0e9Hx3yPH/VS6hHWKIVEXiOEtX4kLLHzgtPQEX8/AhEtfmM8hFCX8Np/7CIGqUsXbNJy+89amgfjariKeMEr3T2IZHgwvFUc80dicvBemKAark1qiuDmVvx/NPo0rPfsSfYsb1IhZbJZgSyxPci2JGZyGi64fA9yd0Gy5F/LL53/+f5OlX60ezbtX4Nh0an14tikml8wVOEhjxR3do8LtQarnRpnGTmjpMhqG+/8x+0+KoljHCxErPQGvLyFCTaOupvBS3RW5lsGgWvIPkQ5gdtSzcgAbxrEYvopa+L93p6B45M76oTBQ3KFvy4HK9BYMOAKxQZqYH+XQxKXJ1Mm82TAiVfDwnSGMgjhmiR/9AdYHmLg4DDcTwMwqU4I95vG6jH687MK25iPtL8N16uKpvRmeXkjI3pzFnvovW2WR8UvWG+ZNd2Z8ecXTHc3SO7ovZb4sunrmBr2JI9Xapq5juCAFqsdxiuJNNcJOEifroHRaQ3dW6s9YuJKZYr5PLdDoJq8zwsGDU60Ba+iSfd26DHe6fDeG2k8sHzKYmToTba/68Qw7wRkClJSVSKLxSBRCqCdgIqlVTrXA1muvmUC7KxcjFa6uKVC/W9GQx5Y0We4kTdXzkW1QijZQOnJEM7QXDjpK3jiHHgSIbrz5UXbaJw/6z9lVlR0tkIRU+eL+vQlEUEGyXrVRQFrYa/mwBy6+Ua1Rmfs5JXmyqafQvQGhNq8ytsPBzrmYkKj+h0bSzA5gcBVZXrG3LZYTb53ThClBxMNDLwtJe9Z/PbAKC17SUh8zFkDO+37qbn1kSbkEXWt+lh5KzqW/a23uZt571gWptDpeWAODrt4clPExOhwDPG0sL56yQ+wirYlw8ZG1laX4UTw/sODIW2i9pPgOGzt9m0p4btmK9DEtS+vKBQ/zhvXaOj/k1wYoH4FSykX8JU3RmHf/sGELrJPiLHD+cMI9t6LNWTSqccaaQCtE5qMl507YeSCCIyCOFNvq1hnJb/g34e8JcnN+9sYLup3S8y/tLpXrCzxEBpfi/R4l7x3IO55RKF1pJD2QjrSmZ1NSv6FSmkxPcIvvM1HyMELu590MH66dZ3n4WR2xiAcxnga6kIs3M8PNK+Cf1VlSQbr6CH9848vMEm5NHK4TYzElunCzB3kGnagb2oUrPTuVv3J9EEXS1Aq1VHTMVkiFD8dkzvuc09NG1+FbYNca+8UAAwq1SlrwQlorR2HjQRXR1k11RIhiK+btRZATtdEFKOIIZQv0da6VNvejet5MPK9sWDVfdemTvmITCyCYhgIvoZZFI1+8mfyihZP8Zzo1IhMmDcs8KIPtA/84veMtGfsktW6dHwk+O5fGt0LrbtLUVrGdPK8udAaJgVgNGGpwzY3Xf5evk2+91yST3iu9+ZOGGEv71VITKaWZfD/4VXXRmmL+/LZLyzMDSD0kMBqIrlIPgty37ZaeMh2PYwRNUMAUtQZTa+vLhE0P9hvvl2/1h67dJC/jmY7mZv2R0KbXE4uL/pFAq0KY4H4M8WscOoZHOCMA2KLWdBCFtflkf+jMfrm2jTJibJHE3ZQTHdvM/i8fnhmvM2fXW8Pkkp4tgT5cVLtc26OqmelPsqMZi0musFRuBlwiYLeGnI0UgEOhfxTP6m9qbc/rK1edNz92uP6OsxlvUTjFXUidWCk9gCs80c7bTP0pMVYljyjXznzFq0QMTnB3eCKkR69RcbUDPsqsOhgXRTCSkKByGPK88+iykCrNbLI8aSXUrjdyAcjWTPpn18j12eDvz1iOruS66vM7UwvzjaemL898/v+3Ka7AFOu3QqSGSrcMFRu+Nn/0p/2nkqbbcKOFG7m1cazsDikzDVlDc+ziOFPk2iSaa8tR2pzR1nNA0hiyd6GH+Obb6e/PDpO0lLCMZ2gVn+U4nq+vkugLXqdoYHkMP+i7eFwkjTVsw0No21N9YWepClBblv5mPK4ItA1jQprxLZDhxJriP6LC0MjhOkjwQ4EMvJmL+MyHfY/3EQKci98H3CT2L+tv1ba9BokuVI0wDUP2QRGdAW1EpVI2JlowbsfLdFCgBkX17nukOgBCT+vp9yGXXs2clusKeX53g3HhnIYSqJdr+9EbPWsovuQVDnRLqX8W61eEuHOS0qRzgW67CA8B6JC3Q2WZO3qddJeexi67aSFUWbnjx07y6rGXEeq4jmSpRZTyhjq6mexQIT29wGkM2kgiJE3ULII+xux0s8Di4/1dJoqo4C9JY+uJQL3BL6OB4xFkRpFl1vo3HrdLNPJRwfP93npZQ62WzHwpwuIhA2ERnU0X+h4NbBc13ltEJ71c0YYLi+7AvZlsNfYfUd2q3+zBMEAJNwnvVNjAlKQe1zsapQJdznn4s+pHwfWw7tlQ1Tii00KysYi3rigtr2+kLRjlB6ft3+9bttXVa4juzqxwZ1CLvjdaSbLpaBuxIrtvO6ZHgUBZ89K/MVV6srRt/4TdvSljoEn8Mz16ubCPCt+QRPev1s+MKh4DZLja09YHjxycgag7VRxDZ/P+gwKnU1FFhexv8Y4FWPBr8nkrR468gdm4ZfI9qvCy+tocdRWW5S4ZbCPy4a6wpSDo4Ubcb/B81DRSnAm/Apd5qRwfEza73XUAqt5BopstZ5naMGwiBugneMguYwilCw1vH7jAh461M/1j6iPCb9nY7CzwO4V9AhUwqlWTOZ3Ft2N/ZbwS1FAn8jf2aZ/07+Q1rcM4d/oP9dk0c/xvb3quGXw+r3nzLMEhEUjv05tfqCmzq2qp9WivtGx99tlAEpdxbb+J2oIquGwTnK1qSTMoYGKnmkCrT/ZIimcAUE6ZB//bI+DFK8EAoeiCQwW4gEEcRjPlq/luR8C1fCrv5eGu5L6SWHDQgiAR4cXxX+6KnzWoQsWQG7QGRDAACY9ueYNuf+HsPWAEPAP+V3Smdu/5EPinB+/3ioWsI+UH+Of5n3OtwaMGZJMBOv9Khd+Dp9Uk7g0rNOseL2EycFYLZGFiQ1OoqTvKqgwgPs+kPJ/kAQPve997lStdSWjk9d/HUZ/PuBM+/GSdeTWnGE569S/HfpUwPxX+mzgbmDpuOXPbmOgHE/7EpvPtKOOXiFsvw693hbNrXUta3c9r4/bsv10fVuQJy2w//6VTcs3dTg1/di51i4Ko8U8jBIDGP6t1bbiki2roMyB8sQRTvyQgl9U89BwDa7b43PyW0u6JHparlK6sNDJjOSIyxlGtgU0+94Wu1GVbGCSs4Dk8VMxj8DsvH4vmzC2s1FD7B7DfAVlxjNCvEblo14A4XBDR9D6eud2D/m2MER8TfMJoStWPnmjFzS/H10H6Ni6MjFrpnwlwXgt2R6ERdy5gCdk4zqRE+oPHf9CooNXyt71bzkq6PRV9L4anHjzK58pt0TXJQJVcx3uuA1/pZhdxwZITnI+lUKpzm+dCIbYBk79JqR7sm4hsK238Sn0uLCrvKW9t6S6Q46GVZKIDjUIBlIa9o5qW4RthpUqWPrhR0dMQ5LhPPNj9sG2y1aR+ukeIrQ3RJ/QXs7wf5+7yQgj043HWd9aQsTJR0R8DD5Ykuth/4Hhe8+T/BZ41GpBfM2KceiMYmstSQosRwt8L1Yf6tzNrHvKcff6+1Uov/N/fLrZr2esndoBiGUg5MrnUbYCuHNEuAkKmg3LIWpIfWCNEZtFJg51qHKNv4gNsEgUwFlyztEVzDm5e+Z1FAJeLM3mz7gAUMF259Yg8KgKCj4e6/N2G0T0OEZX7bixyKLgv/cqM9+iKhZGkP76XI8iTajF9os7O23pmHN31beazjYYuX6VLNe2q4HzuS668K1NvazuYyn1vOdvkIbfbsfe/uYh5ocODTblqQ5t8YAzusblJR1jOEcP1cGbsEX7fB+c/djTabM72PkixY7fGLML/5BeyoiIyfculNAsnEqsHF+DZ2RoQB+W926rLm4UOr9SPXYnF8DYSeAzpEKiK3ZxH6Vs073HakTtJnklLGpOVKmVk6MZBsCo4LQrVZ2Oq5ZTC7Z+hd0Azh0pNNqIjMe0WyXxWbIU0oxly3RV7B51bLp36c/7ELU+8pzzBd+ZY//gaRiYqqsH7OpprgGL/HuBjzxxrQJknAQ5xD7JY4oo8SS9T/7XmLmOT3mEb5J19HfhJ83hc6z7UXi9vo8lspWbabPpZjjB5wX+89m3x23fXjE52PsTIRf/L6D7iYiXvkeC7NDsXh7MHAQZHKR24+K/SW6muUoja7MjZiy2CwBzS5wkDRp11LfN8g74M2CeNvisJlRPqMGWKTpHDXuE8SJW6ZVGdZpsQ7TP9zQAXuV36yOdDfBe8/LJFYbbG86hdK46VkSYznqJit0VDE5NaY8gIaxo/UC9Rj+w2MA2siOC4QYFIUcObKjq4pzJ6JI8uzmzPT3A50UXEWm4Wu/3h50+zkK55EuqUPNyZT7qniTF+MPHuqfD7SfqLD6Nx/6FnkLK677/0coMgs/ZzgmYAWMwdMHX68We4z3i0M8BNV0gQCW1WsgqoCqU6BjUXLLPhq/qQy2NyLYC+iUSmUUNRCzP9ohUXvBcAB1zifP5OR9YIpyXqH3dQVRtX+bX6yY/WuwqXX1zndOz60fUuJ7LqcTGyF194RBlYPQpdfcP3CqClLV5pMrGzGVIvhPGjWyJBwYMgMGYLkUUPIGBGdTjI3NRkvxMRwuBEExAizsSJnQ6EwZuxIyO4chWTjAlbZmJGQc6l5dE2tAo9brHic4/GoxUJE6y5kB5DznLgx3V4ctyLGc7Yo3fjyGM6OC5UKJk4YrRUox3YbpAAQCHQXbeYTTFM/GtulFX3+eGjK70wGOuoIFq45Cff9IxIBAqn1/07cLBRt0Wi2iISb5Uri6JkjjYUKOGAijQFueKl51F1dYLSwd6S2dm2kvmCbzCVAkkiAbXiNbK+zE700T01/QDhUi1nuijrE0Om6BOwxAsiKR5s+vWfbU1T0EUzyJ1HbjRU47TZS5AYmc74M2ZyisN4bL7dNvixsuy66ocKsd5KeIMTNZzI3KhHJC2u5G7hrMGCko5yTrJP5BuJTPjRBLC9LkBnKnXgACDTYhq7VlCwHJpiZrmOHQtz4lLPBeGC9iRl49DsdcX9yFrrDXJS0Z28lwAxQuXcPiVGI34A0bh7KBqSkwEhamEyDDUFuJUygtXcJ2HamV2d4oPeTp+7PFtVq2CCzG/ADCh2A74pcw8LffY9warxAZqjSqJKY9FBpuS1nBKtupIdhmMBtIVSpXqPbCAWdXc/aQIXDS9a6Qw3eLgrIfJCl2m2HWu6Ha9oUPKbD0yWVephMB09p6uz6DOl5fKEWg807iU6eQjf00vR7lPArtaVUwwjVhVcXajE7UY3IA1JGtEEcW6ucSs0RMyqkBxN7iGS5mRvnmkxyzUHm69oLQ5k2pXb5pft95VYV9gv39XIrRHchQb6vELYAwKbS+SCQ9eNw/uczU+S9Ss4/NrHi8V9IRUTj3HSGsrNG+QIWg0OJTXv6xFHn8dgryh7Av9HjnXdonzllEE1MXkpF38fFJ3b+yBEvUxMA0cyRV960pguE7M9I0K6+rgcYqRBbPH4Jp1aLxk8oIc8k1T/KWM801SklbY5YSVEMRyPTfC9WJS3Uo54Zk+YVc7jCIddITKysaUJIqvZlazizSq6WmlnZJ3kgrA8QetRS1wk5Ao1rc9+B1ryGZPK/ZgFnV8o1UhOraG1Yqv4hSzjLIXeLzWzAGqrXjXcr/9caIIpKxVqXntdUT1v9KuZr3c4/ZQGTV8nVEjM7e1FwaUL4pYxNkOflyStuaZU4oS6qK1aGlchzNekVp1OHCWUF31613L/Va2347xWTrJUApTk7STVWNBDg0FFVjQR3jZVZrXp9amxBNUVO9zw42XKSYNGM2/I68W2rH0QuTwzdfJEpOmwGkN1J+5twD/V19wveG/hXzeFyx3ZNZRWsYbJGWzSE0lDZCvEcI4pu32gNZx1aSDApqSsOijEOBGdE/VR4jz8AgMkdCrekfO9ZfxLe6ehNph972YGCc7FKdgjiFqzZPsW7Rxwwh7McVbe8/CZ6toswGYGmZX0vWaxxRTmLgp2suyCq6X2FQplQr39GY1Y5onEaFEurkwmvDAlqm42zvETXZGZF5aRpP3I3DZX+F6QwTfEB6Zzas1wzO7OIMGtKOclNmdcsYIpKuVtsYec85geCLGbP2452TPh6IzSvPEEc8GxpchYoIXT5kcHQPM/xhmiHHrNkzhlzwZ8g0FdFx90hHZHstXbZs3fVl6FpqbbVFB0fD+enJZCODCDDN2oYBhpFIQbHDAy6naC+yR4b/ROGDgnZ98V+FsnuqTU1qyTXbR1BFu1S/vIj1L9BXAbqhtYIMv4d6/iAoxDcxFVzrLDOuQ09ykc54DOk7IJSNCXaS8pCmshfa25HJkgVPaMFRRFucVZ16ZKSTJx7bOY1EYr3okFjyqKCLIiJdslElSaWybQ24caHdgTlcDLF3LhSaHOjN/OXPlxKLa2bIJJx4/VSR0gt10lEL0TyL3XmJ/lOE3+ObBtPm6uFkuukphNO38qsvLfV8gOIh6Pc7BGPvVYmJnEXOZDmdHc5ieyrMt3aXpbNr4F3/0TaIscxuk3OxPbNbiCtd60LWJraCGOdN7LmodV/Wj3J7xLl8Fn+YOUBS+cPwx1mfvDtrr4aOBUme89tXBRKW9/ULZp5acsD4nB5Tb7xZhLrvJd87OuFALZRbQkf4q2Y3/Xdk2NIRs9ce1ZQ5D88v/cvD9+FK70ma65oY3r2+SUz3NpPxDFno2/iceNwk0M7YEE9LH3F/+pu4/ugLBuZm/j+0mVkwRnpGxHm3cV+enqsrEvtWlSs8V1kTuOl5aXGoxz0V4M6aLJd51qGeuNz0AFJfFBDMq3YRCnewEnYjjaEUo0NayqVl+lBHzsE6bdivZbQ1xCVchI603YOcpYQViILRgzc6znScr7ScX30pdM+IKTcXZX4tZb87QjXN8TwvJto0WyNr5C4Lkv01syHfBvyrNzsJpxrp1/JbjtvMzpt2rLeHQegBrbs3apB13PuDAyt59xiCnaFP7s04x4D33Xkl2yinJTyMng/YSWiYKSJuzdHeeVSuEFLfIvNqxkFA5gCEhQoJ8xBFqw3ZEezSL9KlYXahtIMy+WJyB29cmPPDmFq4FRMXFa+C01VjykBx8JYqAiTRBkpUc5j7vZOhXqwxg/MppV2dK1sMbP1TKVw37ADBy0+cXTY6ef7xXgQe+0dwN4QxZSVElYiCk+v+e5mq9r/YN0E5Dl2TdHXgHlovb2C+Wxl5X53C6hcto3kNsIPtJuIu7lrW3MAUgE0KHCneqvnSpr5T5X8MPBFE3eUwR050bqCEbbOM73tpfoBlrfXWZth5cjudngvHN59fpyduRxpRH7NsNmAolEE1txGW5S4aISd01KI1tIrN/9UiIE+1ndm0CMPUsfIML0zMA54dzMHGcScQ1Rha/pBCPQtEvkTDHUGLW7nGRViFiEPxtOtekBoP4uMobHbwnhemflre1hzw4Cew0eb738Th6qmw4ZQ6HMwyB9o1MMt9tdJ+xME+pN43Ze/yg4LPV9shcDOwRH3YcjTKMG4reZ/Rvo/EFKZB/07rE9vaXLbcq1XshvaEy/4nfLfe7rsBSm5v0xyFQKraBj0l4nLpKkRfMDtxVorxFUYU4QYRtGADu03z1i4uzYEdQkJvY+An4MBt75IQe2VSBl/GNE0CHZ18pG7rAuUvHEOp/zm1DUIDTUMFzNhp2D5Ox5mr1iQTDOwThL4QGjKPBjY8QKHOQyDXMOgr0NgR94rfUlY80ZjvdUhUBsp+J0UrqsEiBJ02fDh5+EDYn5QSXEVHrEjXymttyL1St//ROCUPhx9GQn7CYl8AAMeSfeBT/1H558y7151d5K/FJivCKiV5VHUK3dXuoKm/jLzsy5fa72P/dxyOKzB/3AVQbW1TQvs42Fdn/0SRpWGnoid9UNZmGk3/mLNKQtU36IAq8z9YsUL6leH3Xs8x/EPfgmz1Ka/+eJyIrN166WenDHrGeU8iFsVh2dHPrj2bINx3hrjE39jxlf+pdkLfWCbzdlHpnjLymoo5CTm/Bd+2pSaxIx0TPXUOrH2hnC77+ik9V8DnzolfdcrsjZ7ZO0Z2VvCnpFZ8/WOTHdm40B591jpR1eXcWge4qxdmySP/DnK5WYTcXzMajaPht123IZhF4aZnjibA6u38YvdREWha4xrP1MkVxBaauapeJrSagYgKw0jvODvK63gWkIdeXfwR2CE0XTicjoxYi84JaHyHn9faZRjDXUaikPXmNZeh0vOIXTQzJPOVLXVrNNZrYiuYSuNIKdQz8PJA/b84o/Yv/YH7ru5x/ai5epYwKGjoddsedsqpnnTHdv4trcrS6YXJ0bWec5yYPjAG/sW/aFp5+PmJ2rmHi+zB4b1+7jwyelgkb4kmfnmGSW0nrFWfpJH2xeX6ib2GhUHMXurr84UW4FNUg99DDRj2Ziq0+3H+JvhNdCp1NAzBopV2XyxQZ046xNZ8r1mtqWe+SdP5qfsbgZ6HVWsXES0e5VaaN4bnj0pNX5Dlw7cbFX+cfGxFLTyC8t+cc9sQDXPknYyTeHvcuOmVB8R/E83GCk3298ro38reJPy5uNF/n+Vsf/q/zf50ZM8MhNgLsG4Vbvc8ekcqeN/Zhk6z/if813aYJTWRpb0JnaPrnfhG4ZXpEb+LS+vVmtnVDG7DOCXeNdXIRgcF1H6qI3U2PLQ3xZxcBZtfCHLAcsK4Upvtosg1xu+xhh5vcf3fcSAF3ESDELG6xjldSPrddP0/w6Q9DpKey0wlBdwmCDT8b6F876T+d77oydo+m6ULJ/DPc2RFHFiP3ZH53H4O5HQaSTNzJKZxOa4wYybFc0KyH35yKfRXzmmb5Arvk+OLIx6uSyfAZ/OUsVR++msqzfiiPiVfj0LOZutSmL2s9m3I2gDsuaGPwDTmiRJ59KSZDVNYjOzulSD9/O7ocrmj9m8dWVjzsHdWSXU5/x2SCgh2KykDeilRcNKE2bERTNcxyrneYuCGb9IiRQcNX3f6g2qXQXvIUZSBAYtQVsp2LIBVmPnc4KWmJHRc7bcgeSWgErGInFlyAYZSBrXK5bzPfQobwK4kuwOW/S2OkgbjnkWDrsmgBeQEVbDzvnsYuKA2aRQ5tgBbbxA8bGOzglrqud2U7FJ6faaFO6PNkqJquP5QWUXeRdBcBsoYtSReJrEjK5tp5DzoJXH142vPjEIoVqIC5sQpyhRbgh6583VepeG0h8swN062dlcW4wc2DC3ZHv+IpgWDA6/obQcIdVWuZMgarldxLn9zv2ySHCbQfJWuceC59Iso7SdlaGHabcdgupTcxzcJ8g4QEW1Tyj2lXMNoS8Um/85CjZ0He9BMnaXc4Nwb1lsiR4pa+x3uEpCHRJD9DPFTdwGpGHghAzesjCqBTWxmpiprN76RT2ZyfagRi+S7P0En3W/I95tLPyTTkP8u5oUhAe0OeC9zRlpeZ7NQbuMHoPBdUJuozE/SA7HW309jadIs7D66XjDVtKevb31pPld9HSzqehEpDHXPo7Wq/LASNoQBDK4xr/6b6rnfjq1h2mqYDKmulg/jOFalrJbh8LtwtbZaEfSIkgduCz67RbHo7NjIkowHwd+WeV/1pvjFJnQR+SG2DMOBE9pybTvIB+oOlcflwUfTN0U3bzWiuH0gw3eQNj94t4o94AMXDgaY+el9GF7qzE5736rmNdT1tvanDABpTYLxrb82uDuw2sb5OUSwUe2Y0bbW3+DiuZeYwo9c2O1/2tH/pzCcjKu6Had8QbWBnGMxuC4KvCa7SCY26SKFOyv7G/hPw9VEr4KMGsgTfusrFniaaf4LB7/LACmcCg85pwMdhF8dYnviEXMM+e660sTOlFbYI/93xLdfIlovWZKz9j8x0Tt+aqc5lYdlBPYaAGnewh7hUrnc+feeZkaPazUuqBLV6G0+ZmAfk6c4itxl8yJv7S4zSBwOOuAVK/P1hTGDuF77xoZXbYb7cgNO/AZiwJ+HMsFsT89mrhx9mUq6U7oBB7npE1Gc8uc+LMH2dzWjxOMrBZ2WlrvFdVlPxXccgp5kIbjIjq4lY+YXu3adMqDarHiqoArC9SZvbrbjTWd8uVtvh+67+TJxdb+loMV+44dDZSBaVEcrmT7WNySwiLZWzThcrUv0E3y2h9cLZH3oIjFu9rcR46mJswtR6VVWMHvVxmmqdA4kGbcu/GcQNwAu0ND8Mp6aKYXJLrS94szGQGg+0s4xB1ARO9HWd1V7CIN1PIUnYm+C7QOUoXSA3iZsVwmlftt9TugDmtOFMK5yxDT9T26t+pPoX64E1ySvv0vtMquEdug7ELE7aPb7rhAWrpwGhvOrGKaiceQN/8O/f06hSG2AobXtvcLYmb+BARfoO/yXD9SgV4ZIgZEbLmqHNZ3ZR5mrJIt/FdUeCCsUPvlJZ4Lydri5aFxF2MKEKj/MJh/4dB8P1CJ/ccou0K//77/yiKxOJQZ/B/MA/u36lKPk0D1u5+FTWZ+be07jrY1sZvaYC/lf0/BZoQBbu+f/aWHC4WMk0kJJMpDKijxJceRH3sBmUh+JcnB3t8KwINO5LTHrFCONI56W2Zk9xjFFZ0gtWW4EZWRZYMI97w7MZgbs1LemSTQfqlo2UbzB3wBOmsJWPp33WWh/hgHq5+B0vUf1CFk1wryI8zpVZYnXRfW6JYQ19Co61Dh3nlti32UD4GmVmdkabdHUFuLaBmnXU/lJW5cmg+Bqi7x0Ij9XT3VjtWPtF3yrMjimWvWhi0n5XVekAfWeiauRbZl8fDjFM1AubhztCKPmqa1KBqBCNqwoqlUIZ4wWg6gpmvNiiYgknboNLr/iuwTBYr49STnXJhGWg2EqKxGdzUUseeVWZcKI5TtU0uWvVlUFIpE8ls7+itsdFbb/5CyBctPJFSGsDpVW4OtOLdA4WNmbP9oaG737nz1Y2Lbmf5IxFmAwcG/yjqku3I8n84mh7i+Zu0PbinikvVaYXmmD6gcUn5FF4TjqBwVp78BGJCgb+VzGwq5bx9wR/f3VuweBVuBqM1LZvLGIV7w0B16YLTlEn1DcaM99AayKqs8QCMfxd58IKHXOn3D2vPXuqu4QsJMXYdYpNuDe7ThbK75p8BQdghsGAedvyxCIckjvFPJoa6E585MHhaC38J4CNu1SfMD8dwyyVUwtLlh0M/hoSn3IbBIIwJ/ZJ0fjx+dd9VvbtfGLpKNvyP0IAgCbxDriwLQ2XNwCDVs3Hm/uD/ox7xlEKm5tehxefKQqxL9g7U80gwck/coaGH38NfLmKHbOhryPZvE6SkdE83TBBvXt7vPDLSWrceMDjTE5Ay5FTPKlEO8/N+z5enuJ9n6O8K2hshx0ML1ndGSh1zLliH/LcP8C/NuTNm/jBS/by5dUc1y4FvOAzTTrQGX/o5bMsWr5iVMAkuq/QwGuX2CpjWAb9YiqkmfzeYt78w+ky+zWrv/73vZ1hFB9lYbWV1DdDXbCytCq6Cqyzzk/TJlBYx4JI9JOReeD7h0d153cohL3nrV3nRrGHMJhVmgvHsp2+q0tjnMS/uWPHxTj15f21OW0olbYmfrI5r2e74U0Fx1ow/89a5aaJQ1esPGzjJT3pvujHoXJ1/vp9e9buHdBDHo7hF0FV1adN5W88442w+IVVw97p4PhThW078wiiVuhgWFmDLhXbEt28Vnvu1B22g18Sp+xgJADZYzjzgGHfN5Ec6G8lL6wrm5Ffk7NcuvlzzKbc7vc6w1OIdrn5YkeKZQUOF/ZjXA1Cl/R2BfVu0zlfssTkAHp521ySuK2cTF98uRWnrrrtXYvRYINuXfMOoFSCXkETW+ADfhc9cfR6f/xR7BQLHJfE1bgY2u+PAiFHxb74dXV4EBhaTdoRiIHDzkc/7o/m1lPBm5wfarHO3DNZHvCcx3X1qSeIO4fiJFekwkNLGTh1dkpB9TyJKLba+e4rU6VW9qhiCKrTbEAv4/vWbQ+5d/wMHUwfBeUtQ1dutAGZ/U2mx2NCsh+ZgNDpxBV82jc2HGZrxN/kxx8Ekot8eAibcVDZy8kQKW36jEB99fKhk1p31AFTuqQXZwRnPWjEMyZgg0rrl/t8hmpmFP5D5a25jxv3is3skbl6vkrRuyvX4Hb7Tou5updQfVy56Onz05apM8uYVtbW5gTAnQ9jCUBZ4fzzEG+RqIV5YtICy/Ts82KThRaZfhjqoaLa0H037joAG2w+JmgCUPh+DUAKg7nPlvIkoAHr1gHmZOyGuyNjXaEVkKfd7Ue5xI45n/d4Uf4s9Ip7b320OGpgnu4HK0Jbml0w/GP13QLfgI7g0P12d6HYemX5J+NitVpeXX+Y1I9c68nZJ2M9XMx1QWvL52YewC2fQqOaL9kraaK/NM6UwFGHI9gCjZKa0QVZZMrSnjKxg+s0Gt9KpDMuf8EbiBLA27Bcur+ee58f2j9adBtCuCYBepOS6aEDP0tMbU+mo2YWHsDqhs/0Ye4i2xc0pbBUe33Jqcxx/nc8+oCuGrVZqeFYD4RK3YOhDw7nszUzrt9Ghyu7nayfhRJaTrt3/IXmOA6En0HwiDS5uZ+p00C1Uka/xKe3aJzMTlhZoxwmJnSKiTYg53RlbaswvDKTShp3bIKQ+5KF0bUe9rN7nyMmvlqgZDaGZyLuYRrnWx9VZHuZR88gzy40tyUw8Yv8nWG8x9FPyAb0+ZNqYBsEDdA0WZOnmwrvf+qdHstyp4mRILxftrCoQ9w/5tBYcdDwCy8pieH2iDZWfs1sBsVxZgSS+HHmo8I1vaa4ul8ugOh+FJ86l6XDrTmAjLrK/q2PGUGAtYGFA0PZg66HypdaUo0rZ4OR102itUr84TvNiM33f8Av1CmeWFSuYPnGtXFNenzskYm4Ugryu3cMXgXFd1mXpsgyuO0C5k2Rtbgd/PKy3frH8C0jeqcDUj9yTxktn1FMvQaRvEOw7N6i5xCOMLuvDgtdCJ65nZBsx7Iv7Sr97pmwU/5sfmzeCVWgWuT/JUBKflDdWpFedTMZ3p8015UUMdUXv+UmuY79q4vHf++ScGpAXrw/q/ovrglgWR09CEupHDEdWfNZo2hLCnudr4NdRiys9X/nH6x9BpNDPh9vQPnPQtpvUbMtDOSemhkpSdtz/ZAxkPX0QCv1rOovxlKoxb6aFETc7JYm/lco6fq1XdddagbXkLZ8966o/2vl48PPQuRVkprFq7SusZpCUI9kqMTJIRNvJKcJxt9GuyM9gnezma0Ink5FMWGXF+ZWZ28oU+gTpxSsC6YJbNHmpqmcjT/gnU5k2EW1LNS+ZFuwFF6iUKpClG5p2zHX98pNftjSajzwHsxy9APYVcfr+AQVQLGpiiRGTtQAbOaGtXApP25l8l9PJiRXrEw2FS4MHPhesrHexG0iQoz/DLkucTafFVdYxV/LEj39fKpKfnC63X76vmqaFIfarDHTgfPYp7A1KsLFE27l/bz3l3+oIXHkcnK9Rmm1gldi55P5Gafv7fTOsf8sl6k/X79y1E36ELc1vz8lCS/2BBNXq36/Ro1tUakl0cjHawm2Z3J6xbuvF/axIFw7eYVQrTBpWvuSpKmQE4bFCPasn5tzSvXyHllJYf42etm6Owv6gW/ZjvCl0iXKXwvPrjXqFOW3HXBtc0YVlE9mVNqhQhXCf/MHCbuG8PuGT9ekLVq2WH5vM111bY14Xa8glg47jh+7SV3xHPH/QAHR4mFTyjC+PDJ4/V+oWVig5ZWZJy4a7+Nl6HY1hi8tndCpvWJA+E/scaPh6ROrRtmpIbSIYi9eH5Pt9KeUeqAG4YKber3UpF9f2lPLSmOJGPzOZ/+ycOeEgBJzc7Uffap2L1tcFlK665/06weO1gkSnXWihFAkcKy7X1oEBiwlfBcEe0uvI6RaXdifoplYxvEMt4Xmw11f6bHm+uGfNoIfcWhYsYocBAeaDSbrBHGE75VXd2yFVx4Izik1lpQBbt8EBYmPmIhqnA4T8T89WMQQtCIzq1RY2/zfCrdrOr28diqKK9Q+VyjOv1xzRXtv11sqKtfGKrnjqlmXNZb9TH0q4VFBivD8oLR87K6dcLxZK5C9Yp6peLc8/VN2n69MXRc3V1kfP8riVwzw/Wqtk/Id56pz9wJ+X1QmqCD6nNWp0dP6rxF7Lg6i5Hcrm6DE4MqmvMOkkkImJxp1KQDaxJFQdSVqbGgB6Pha7VmGwGhczSHUPa2AaRzon0AkDNM14KAvjs3+Hsvxy8NtY0FDLbcMgmoSS02/RJZ4W2EgtCxrmy8tnV7C0Yt7bxPq2XtFdVVU2RNzHJK6Ly0VWdX6j4smJHil1U3gIh80I2s7fbbT3In9NGfb7lfLB07LwmrxFO1kA0NVPSQ2XaXRmCswP8PJ8ZToaT7JvN1x2RHQGpCyYjRunnh4m1WywHKNuWWxiDGsoGq7yGPtmxSQFzBybKrJu3HD8+SSUW2gnl8xeoeYoU7BKpotZVxo2Ndpe7PkQLoB22VPmB2tptdusQ61jKg7DnFVVglnDUDIF8r7ppNmwdHF1fkGJDTdlT2TyfNIlk1qIri44WWBkg/cfLX9ruse3v0J2rStmdYzbBU4Ftm+XWFPmeuycGmpLBLns+lZRnpF8tvPlg+Bn+WMDd6GRyh630/7o6NRnayoqHBIvQ54RnCqbgSF4odZXzXKVX56xCyJk9i16SD74+CJmm9d9YDANsoUZk7aV0nNHarppHC9HaeJFnhMoD/Q0TQ5Orc9zRvfYupZlbcuI81bMO9bKk3nB3LZchOfHTLOvU9EuDA/2j5VSrllgn5fYmR10cf7SU1tLh1Yx1uNnrYVzt00DRWxHwxpYrutSIuul6vj2QuQ4JH4RAcx3LAaC75h6FXYcMXz/TuPSNXJVNJZUalBKK57DONgsDGYSjQuG/OGOOR/JveuUBfoTe2sYr+fOJaVTxATRg6KrQPALBqqXao+z7t+canP7rBLIvIPN2m4vMo5ZXzd+Y0yxVaI3+75glWXFZ5tBxdfmxf5JbT5bxILFE4uZ7WztfTOQxALXUqQwpFe47665yrvY84BCruFv33sGJNDZd3Z4PHdd9Icvm97S2No8ZdBOHi2Pa0wRCFzHoA18iv0eiubgiNVtGlFvtOQxTI8Aq8MM/JHtrf1kb+u2FzxHgCXkIetfXsUydBGRILUdH6b3WUwkF6KpWy9T+Q2Mnh/nBVWU1MxSIaFvNPzmT4/N1E76BZWlfBd/KhNNaGVZauhES4qVTiHKD9xktJgVCPPMUge3i3HTKTO2s3oed22Q2GePlPuwzye/7if3c/YqgLhDHm6UE7RzGoFaWT7ZMom9ftMPmi+f5ej4mvqSHh4rbugbLmaM63bz7SEd/JWsUAObOPDE1DpbHkBBOGIJutiEj+JCA/3Cdw2N7uMJ2pP+ZKg+QItirAKzmRsowl/OyZpZsiFI7ZeoqY0DMr+w9rw+6BCK454xG9V3DfGZs9jBlANARtJTD7iLe/nMAf7FpMIQjmGpq8QOAWnk4Fqra2VDkG+vQkiZEQXhkdNN7K9hA2rdkRQXNwbI4dEqh3gR2L4sXiwRRaWVfcsroAihKozQl9ab9Qtu894iNV8Q3nTFizpIJehrwehSJL14nncvzAUfEeEVFnSf8JJXGQsVO+CYTH7mCswZwT4eD5yUT+nTTOPLBmxnAkurANopd26Aq2m1pSlxVwTgxn0sPcVRG5br9+Dwl3FT2w3dLWXcMnJFSFNadLYApp1h+7eWSSLZpAl0XItwDLZDX8XD7pOkdlXn+qYzma1TKTLC2iit/h2g4/DSO0YljP3ny9f0lzduYl8gJ58qFWK+5VwEtT838RMNNl6s92ye+KwrVvxIX5p32Cjeq84Uvt+C3b01xFNpubr1Iv+g2bSFdTbu4/wg1HgiDX0Gk6qiSgqfVgeYEae1yAr0Yo/orHA1KoOwPNz6P5uDJjdw0fXpta8jbQuJjMJUuhsHHW+jNL+gaE6fi5hYnpJbg2KhCfvgyMLXCRPboQKFaIEW96g66CdeYHyym5fgQPEaQ6bWZnOq8K3k0z6gHx9AMAMy6Kc0fvZQi1zihZJYkPfEFjUB6MbGAZIi9KX7blVzfzPsukMO0Mr+mJr4/hQoUUQETMk+FOszR/p/K06V6AR/j13GJ/V//HMSVmczt0DrYsAeEqL6J9z2AgeYGVbe8McUp34deMWLlRZ5dAw9Wz7bAzOQqzdC6P6euqCT1uXIrdEw0a8WOC1hzEKlOJ+ZepJtyzAQhskQe0V+ssbVXpOKAwZYJvtggK4fXfvrZ0VLSXxXWJtYJWjZpm1bxEe00c8cdDzQYaHTKr4rsRb1Zog6OUqzPIPPi31KxJx+opfshETOMKQ7/pSTnKmw/kB97Y91Cvpfq1ngsJhxPpYAo6Ig79Ki+4U83q7CopSI/eKzCuohqMuSVL28oICfl+vZc7vd7OhK2m+KYQyFj42nIbbks5ywW2WagFvqAUK8dF1lpGlkWGST8dz3kozY6lISL/T7Qv3OKgZzY/i79D7OidOiTSNRnKMz6dCsGOexioSCGwD6P2xA6ajzM5IdVlo1yh6sv3W3fIdeyf868+RNIh5c86rpPdoiixrUYsG4z5AK2ELE+hQWCcOlOYKvDJW8Haaw+24H0YaktHdDC8cdGnOpIxQ0HJ4JqMPg8z78kgHQIh7mu1hDHpCVn9wnXVTrYDYQpQ4iD2jIe72jEjm5eyu1R1nUfb5GSl5ZTs4u9uAepz5T5sIu+BrDJP0SOyo9MYcdHpv4oY+wm+OSx+mEapbk4d+y+Zx6X+KXt7//cu3f0wf0iX8xql64Hs7PBa1jKdXoumYspRXTjjJ4eRxc/3sedcEb9UFtIU2qV/fngw7L6N7Usj/g4M9ga7Hg2O6crm36kHWrw9uKXYrGzrkebOCG6zuOmoY4yvUI/Q6nMudub2yuXcIoLKJtkk8L3T39tEf1BPlM9a91quF3qr8cHiPxRaegqTZOnQ0i7FvrzMZidyu9JtkxYur4LNQJ17PF1jT2jaALTatl7EVKrGsG0IuzxCeK6vTUD347ZmTmNF1KaqNaaKO8HnhXoRtToiDu+xNgR4QVBuDFhMX5JrGWMS2PcY4JGHYktWV+YGeuPyx1Pm73WWmtxOLiU9/29w4Fj0I2Z/YcZQiPjUulkBrmcbkdYCM7tWVitrIoqCej1APs5gGrDSycSa3X18jhoSmJDGpLp91La/4wuE8+Vki+HTJ/A6KsktyZIFvtFtKBvoDwUtRqxoNujkIYqzbUSAuFTKVtNumggCRZC41Fhd+YZOXTmMRJts+OzSwOlZYc3zjzf9PSoSDqMDW2Y8clWwvkFLUKz0pmwcpToSuIqV+KqpuDB/o8TvneFEiZ+6yuNYimmTCj0i69JWOWez14pYvMWbYTWhZEbbnq8CvEb4sLVB5jBS7yPBKCs5lM7Y/c5Y3f/4xGEqlPoQKHSPD6jd9ctyIfFM+aFr6uxDwDi0uhMvk3lEWpzldlVM5Saf0gJOy76n5PexvKIblsv4SKLioH9gMLkBbqvfj9QIXUZpWw/6D9Nhc6ejUx8I3UTldovYSDGfNRPZR5pzqbQWlOCtZjaRpEpv9427MIRl8u+uTzEazDPH+6qZKRVmm5PdnG5xITo31L9NTr+yNDTLpVh5gYrSTBjEIchsNNCgEJHjFxochKYteuxDVHioLbm/fP/pAp2tIPbuVHjAUfea621sKOLDpDTFR5NPLGdP3BsaYBJmae4ql4Iv8GMB274Tfh8PcJlZHzJjCtK4kMOjSxARVNjBVfeWrUm3i3O45PhMG12o60GULriARUsXp/p7699HCD6SUQKFmuHc+MaGXQUpWTDr8IzzyBBs0tUCmsGwd6gqSW0zwymVMXvk9uTiKgN/Ynl2M0jh5N9Bm9x5hxfMu8o6yhwTcvtSQXnT6s0b6KYWFoY1xvOZCvGu7/Bsqa95slTHj4s2pEuyqHX5TLtBnP41v47jFHBEybggKKhElh8si+ZGHNtn2tqDuAyZ45/uX9LcPH2HbrltNuX/+fuePWRIdjzpeX4mphwbSzTa+Mim3tVQGtyfwdHUue5NkywWxPJEPzWheoUO40ldiCNlQOWaiAxzfjrNMt1/J3UBYldvol1PvTy33T8kL2OMZgOfUsy1xef/p3mEc0zDkuVccNDAqj7mehl1rdLR4LbWXHrCAbCDgIF3GrQ1fX8axJ0cmB+1KTq6lA5PKOQenzFfeuNfQueRfwrtXWy/r2zT0aWYleWokfIn1SWopnfkDzqKgOxqZLGYpffWKEuXxDE0gCwAC4nHOTYqwMeqkqxJCUzy0LJdrV3pGT2xBX8FV6sIQIH7c2ZvHgXICGPqnMt6+Fr9110cjZZLbhPPHoizmgZ5ODfU1PyA6z6cQ7H/UCi/9Mrj6+Flprpn1u9PfT//cE1bfXPCMWDn1wL/+TFHG9JL7qi4mAjfzE/FwgEQoC60cOE0RLThJ2Bu+OXhJe23RVRbvu2vRuP+l/d34qgIrnuJ1NvglLnG7X5f5z45Z+xNJqrn7o/7f+4GhZ1vjb1a2TaF8Jo2hewpZytpmJ/me5grHICVUyrkOjXapnOriCwFuf/P6lUmgvEeS75bGhwfeKBueO9+V3ZaT4Ov0CYc7G9jveUv6uIHlxHmBAXTPnLLxldV3Oj0lx6gifw4fhN4c3tz4XcjhWmjxc3V+CD7TdFN181uSGQe5ohqmkfjQxIyWvLmVlhsongM9Y5a/xZPswn+ENU8tzpwlexuUCHBE1Tmkla1K75oclLfHQjcYP2v/+XN2wiMnVUjPofN0XpHlsn/73WKhcXawCtM0BVz1WG0nUGmJKywC85Jmv8tvgenS72bZDQm/BNVa72XHpCM3DPqSs7z5dd/X7JUPGwycXrzdg96kf/hJJaLAC0SSL1//YdwxSVZmouFdK7TatUh/22qjVJZ3m2s5XpuiXl2mumlmAU3BrXzv/0jMnMGQ+ZWjMJdCYTZSrGieKayaUnR8BNeB5SUm5UAjcet9P9yz2PrpXQ+2Ts8wC6ieBNI+yjokS5QpcKxbRRDA/vqiunRVOUUwcZ/EalGRyUppsydgeR9gaolM1uStdtjBG0rQ5j8SVoH36AOtIG/9mgw1zyrTHLPtHSc5DmU0S2vJ9EE4e8GczTVaJ78Lf2S2SFK63KBcZSwa+EpsB7Y9dF17c9EdF3fpSJ9qHKqVGpYmo/g2Us5LDfTw7TB6ddbTv6W3lj297qYizJ2BjwpjqxCSpRGpmymh6o50eqvzU6pk/FtC1NaCrO1h+VqPIHMG+CykANYGvtZ3jOs5d2aBtsNgkd0JKjdmeu73NOputP9W+bigo717/Pnvk45Yk6sQmQFHWLz39QrpLk/jHNLPBEpN6igLRaVymLv4VE1VHO70nydvKEQnNls4IXACdwHo+hGM8SE5BfzWqYTfKu5OQChwmiXWwugia9ESztujKPE/5LZ+3yOBvqs98DUxRqiyUQj8THxxNcxFRsnXw8IbLpRd6LDVLXmWeXnpOKaM9+NckwMBedkGqcnshmJseiiVjgZEtTT7ZrSjSo4uuEhEhWQGLpDv6rAXERV8eHQTmHbhTkAi+cV3f3pe5/Ko6gDfYNZ36QgP8/GojtpeJphWS1i8leTGjwwYsHQip3iXeJmBKwIwsHgu7itTvjw1WhywnUXNN7ffdKTuL3QXsmLzUtlexDnyEOYJ+oTybua+7M1hWvmbaaugExRMoWTGhNksdmTog7pyRkiDtZjAli8QQGqxMOAPHKlfeSeFk1/9B8tfralixsjR25h9CgWyRx2fuBwmfyD8+XVb1AnNsDLlmyL2jw67Ks+44jmgxMad129VqfmCpH5x2ktw3raLZVHg8zVFjXiwfnwKi7gvBQCFnQFmNGtexQy32uB97t9mSddm3TtfjyKTYMKVbbABCzS1Ex4leZ0viOQEPL2XtnvwcCvaX4d+Mzkxw/6ouGnuvyrhnx0tXt+r4M23w2gwXDm5rCNbSbotHVEVhDVkz0HkSZysy09rW0VH1Gr2jZE0xroRrY5ZVel7I208nFktcGGLz2dZ3s6bH70Kuy4dNO2dGhv1CmzlRNX86l/31CLoY5ZU1if06nozOCt30CiW2S6dybsnXywj3F3Zr9uk2HtoulTs8N3f6CsmMFNrLo2Ye3gXu/QHWVdnTbgtdqN25cW5ttS49mig/D+1l/qptsmUzYqJW5DebdLbpWEZBL6YkCWAPuiMByFAfCgjaDkf7Id3DhqDk86dlo0asiq4UdF/NT3Wab3GDhegOeod0d2xQOpOjs5oAY7TkLugXfaJiyjn6uXr9LlTjYZadkbspHqS+KIeKsFHacRS6AvYuGBML5Bya1sqEd3OxUaDyHWcy7gIoNXm3DOuqmWRb1YpsoO7auIG/+fr7de0GdJ1yoqfOc16iFC13pCzp/bB93sPRCmwF4p4SQmgP+Qxx37zpcZXUdVl1ejC0UzbsAu/CZ/QWlT/2i2BO55HT4EreRkU9I3DUtcRfftnJ6ZfrKaf+V7bTfocN+jso/9Vnul5/9ywPgy6uClrf0P2dWn0+YBuV83vHKoNT36k3xNf1ZTO8i674peNLGf5K4Ky0tov57kLe9UJRvKyiA155zrECSI129cOn+yFCZtSvatevnxhrpveFKT2DlQfCIibs6Uj/dj+/XMblHqONq976rEt6p3xc/QDuoNM1UANxSzz5TIQ3NEPgnxBNM2RMEvMDZqWCdw38b+g/91+o/W3clBsxw2V8I/SlP9zTr0uj9BxCaN89USURf47S/XmwJ0Ggvw2iRfZv9IL4soLCrUy1ynVao2kwMf8JE0svtLsMg1WAc2pkuZojiOqt25EilFEFgk/SQy+wzxgPP+N2/+Z2c6Paxhzq3Xk41z4NepUWPL5MmU5y7ri0nukrXFywVVKC3g5OYynK+HyT0tw3wS1qFJioFlT5n8iWqjGIR243XEmLOGvJpEC1CEZCD5MJFLO0U3nJGjRUzPNZXwn7Jqygatkj+SMvYqcDMos7jTT1E/kH/N8qh2F+jG76h+B02s+uoWuNhlT5vyFVx9nLFTVfyHpnyxpVlFxXgqp9WMGhdpVmfQm8GRxtjXWd+FhXh8f9zpXIC+FkhxhPJt5HYxP+lm4Z1BfBw8q5MvIHBIppDnfa04t6TgrdipdMcVP1YBa76sYDS9wVGIi4YHiSfgpcX6t2yLdFDhtBq0KVaI9vCTQ/thknq2zj3S5HVL8pSSba64ZLysTuYPWgj/qaFCRvaqaJ8yxBcAVri10nH/BxWtiQjt8gXg4qvgV8jsBB3LssKCvTDhQW6dSFex2ARLeFO+yDD2PcDJdG5CmGGLrhtuuM2z0pUnL8fkCWatha+Mv/zldBKUqXEPoNELkmW1kPUvrr4bwB3tI6pPwGhLJOg+zf61m+3UgB2hcv46slaTiXeZfgEPlbqz15zuN7hkz2yP/zuyVnQWRkMz3NOaM3x5UenZhkm1OD5XRaajLybk/Tg6ky35Ih5b8bRjFZ3LuILecAxP4Yt2mWe1HH6YCnjK8tzZBSFS7QJCO30FsUhbGkCTME/CjCtqtb2xO0Ai3zCUYa1k9xQ223+qbMT9AvToBtQ5rt5McL/otd6dIHKXnhtW5c2oPuVadFlfmleSsxeru5B1OrCHL/RXqlM7BWzB5tDXaN9EpnIt/n/l5tqDJPJjk2Ft9kghYwPEgYB49ta+rL5s2dikrpYsRMbmpdqjS9JeQUuKgQBb8nuKp5rX0zWUM28Vp8dCpED3ZG4N8Yfbw5yH0GsJYCqyPsqv//2Z9bUt/f714AP8gyiF4vMi3c7RMHhCSwq7ezRRCIZjbTT5mYWHaV7kN1pABuVJSkDixJGO04Y3T38nwJqthleewrHPIIrRXJ497SIGVmiRgp0cn0JT8LasM0u92a6wq/PAAuu/XIm81JWN+zKFdyjZJ4pXIkQvq6+mbU8WUse8R/dRZYUZKl9iXgEAgAQBAAoEk94fVFbASX6T4BE4YDF8pq1C9FmrL6AHZwSllhY+hXykCiy0z28jceZailtN6j59VIWzebpVjrJeZ7eDPMh40Qs7X8JBcDwtncDe8q9n9Gh5kw0L3yXqz+M+yTTb6/g5Luyn6o2+n2vmLipOfKG8POhTULY9e5sNnSuMRE6hc7n6KQPOcwfFSlVYJI250yONvRtwYG2qqIEYQof/Q8Lixa+u3tPlbLb/H+8Q05TEvCXLxPRqeuf8d3NrQ5ILdFxIBu8NILn2f/RGsanNRnBfksGz5gXLKa9OZ12AzX2JqYaMRthrD1kHL2T+wPkClvIn0znT5be7mooFmaW3LuqlRsgWo3pyNi+wD+5yw5qEnUIg3JjNe3HVcNVw/1L/f4A728aufMo5ve3Vb9V38EI47//dT/l+J95BOEHyGlbE6h8U1BzN3oFS7miKahT8z3UPrbQNEo7IgpEO9OI8oCtYpO34Nrp0JAJELVlZU9TUca7mMCDsgO86iXjp2fv9xkOcqv4WXHh811H7GPmP6gq+hQ68HC+1b6HQKexOQAm1YYCln5pkJiQEMshfsoE+zkWDtHLqAKsaz4KicLj0OpIYVP/SDN/mR6ad6z0jbQIl4H6ueclMkuIYy1hF2sNsi6bryWMvQmH3cRibsLgNzc42tBj4nEjNoclAygPa98DlN7LOFd0v7OeHIY2dI5FpRFQIGJmD9FUTyUKrfnvry0xVLcy0RXiOftAmf0SFUEVj+OQ5o9+e5geTfdwOl9yXySadTdOkY+Mv0cCq/AltV8GPkDJmOP822ymA9H8WOuYerAspU7SQjdeyMYr/TGGeVl7PPgpi+lENBEgZyTraoL0ZLLw2IinHCeynm/BNcuVchaauLeUGiBzSR5iwQknogtz97jKzjs2rHma3cJcSKSce9DYBswPOcpxvfwxjQrs2+YZwckqk27+YyqdpYoed5tLSryQ70SVXkzN7xYyXp722h24ItyPlsyhg16NCC2FgyvdfNepn8VFeHxRwCv5ZfCHwkIX+KlRKU1fyCLo1HngOe2rh9cpLILZ32lLK35wMuSBWGY2w5d3C68Id8/H8rZhJKKCdU3Xx3i/n9+nC37KFcUQDza4+q1GrDbAM0ym7QwO9lc6GSPemIJCvJmR9oS3xHIYGZV9RIRXROs8YSauMYq1Up9W8ORqQ62rMlIjD4KKRwTCPQNEC7oNH22+Wc/0I1oCnfbBAdLeVptV+sVEkBKR2zIJ5d+1qs8rXnyMZdFdAFlrWq2JdGdSSvUl/+XF1IUDECcKBXr0PzzOaezzENpUj8RpS4u0jQQXTNOVv9SDSRKv/lte+igKdbKtMqPdpIdxCoExqlIFAK2gLFZM7KUfFOPahq+8VTCcKPfpJDPhmTBSTLDPlvHClcpwu7bU8EDOVhc3dV2+E2361KLGKtxuCD5yTXXu05hbewQ732kd9ebkw9pp+edFtvZTNRP6D6WF76bf+3p6DJkpBaVncJE1fdXUEX0eQWvq2/sMweZvyHqVxGBFSQJB9JgLwgbDdKsekstN0vLxOVHF9GqvrNdBH2qdMnN6e2qT1VGSc/9pxBV6R76trOzvV1dagkx+86gNJgp98ymW2RFq+U2aOe8+DcMA6tIRqONFb3/hKt1+y10jtKycU9u6S2d0sMWW69WweRqh8d4wjCidmN5lFM5oOBdYY1K9vp2HArog5u+gXIgqtjXZT30ghW9eaYeoM0YipRgk2c4PkaMMrGf0Vx40+8YExTCTsbb/X/rDsmCnZ73YPBeCgaJM7ZcbUX/DsiwGV9xYu8JaaMa3MNLLDj6eIodC938e8oIKxz1Z5oFBHjgmhpVOR0w/SYtwSYpAU6L0MtKxuSMQ4JnZbZa/1W2ilSNMZ5TEWoEA6OeyAQpLHjo/3PvloZ0OUCCgGsix4DhSIAa5Lii78nvFWaD00L/S8K9N/8skf5UUfX1QqQhcLlLuyeHg9Y2aOXDIuZ8QkJ8it1HAzY2cRz4cHfcrdNhjOOAIXpMzcWHfZU+6lSE0bfaTGh0DfGJFZritM3hLoRV67Qxaajck7audoGbUInLxp/jve0pI0+UtTMPN3wcax71RxSyMhzvj6xM3Rhq5BM+2kzGHFtkhHWNo8I2VgwBrc271j4qQkhbFRGjRyhe7Xh7OdirdCS22MfY/BuPpyQug9hymiymEwY3YjccCtN5Y1T94tFdR8PmXFMnaAGLmdxknAq0UgZTXeP4/AmqZ9sfPRL538S5Q0D31j6BO6aK4cLxx6u99efk87wzx5uaxW52szQehzDqB7JrjWdLNG+PNu3Ozw6dr+hNaQPtqADokPxkmFbJ68zhA3bwy57EwM2y1W70eS8uc5Y6mSDucNpIv0TI0J7Rnj9cZLQ8oVOqqUaKILFEyPv6iEsKJ+LQycUzdZDV+b3/KODD06O0BOC0bF7SxGPvDv6cBXZKZEruepK7wYuvekaoOv7RiUfhvKpAl1FTeBYsRv3pAavE0MehSFNHO1vhobZpiQn01ucwjM7k7eaIlIibFurzNp2ulfyVNn3dgxUhR8V8zf/XU0bgSi28ouZgkvOxNZXotEN1BxbzdB87bct54p1Gb8TIGs7kQrd4Ag3pkZcf/dbj6b3ZuGMgOAARna2UAnFgAmcwHxCZTa3G9EK32w6L7srwF9bRloGgC5UAHyAuAc9+09D8HKDbT6HJ9o2x6VT/JeZ9L2LhrtGJ3kte89S5694kEZ9pr+DJlKWQ2uFB6KN3cJAxkT2A73PpfG535++M9aIRIkmmp/PLlFNDS0tImKdiutKhvrvrANeA92FqQ1v77/0iGypUsrU/LJOjxaGGs3Wdvpt5ZdtSvD1tbYsg30q8q3vz1nmkevIV6R8WC4FfovRhjiMa2hkwk7J4yVcFNyfJmls4fDXBpjM4uKwLYWWz5iJbUba7r8Iy/DAp/cHchZEP+ynsADN1WbA1wCmEYRaqqG/MfYfRYmaJ1WlZBuxY6ASotxhGU3BbuQmyFu7wD8F3LLMZpS7Rl0MMAQpBrKD1vhVj92W19I7fem9lqWZV3upDt8A8280gbfdzjINwaI5r4HZkSwE79h2lhyCfLdRl8721PHcTCRAzLdmrZ5/nn6YpattXVlhSz3mDbkk/EjTWkcZd1iM2MYkmcxmAizeorCXC92Tm3bX8l3kLWGo4DjOq1XrCeRjHCX2yWQHU6XdX+RwlhZj0POgdEVhr4Xdy5Myr85jjDbXgaSoyCKtmp5BZtYdvI25GKMEMNeHc6yQuKOwHYyHtAFMyIM40tK0qHZXwi5k7Y2ootrJZt3PXXL7yeXf1hV2BDqoC8v73WnqyplL+0Vzx63Vx7BKsPX4p3CL4tiVqWSx1CcNxiUN9DY3m10Fvqk+/MSDdN2xFJHlxid811QtngBmjRkJU1CP+tGvy2RcS6OR5UCyoaTKVfL9KZro8rCvur8j9Wcl1DTHvpHcHPEe9IwWTsw5DF+6onAsH9XK8x6uTwtpinip1+EflbOQ1Yba7H7LmXj8TDrjOvHt8W1d7+VUdJDps2VOhYja46IS6v4wLukpP9c/hzTrjwnqla/VWaX7ZqpyYtVp7coGduDsr1iTNy5mZBs2wN3ePS6VGXk7XGpwm2npyxcGJXwjn25JC4e9I1w2/xmDUpIOqeXAesaas9Vf6Au4i2M1m9nnv1XujUsThm+b2mcQ7xyQjCe6ySLptLEmFPQa/cvUURtydMYkB4boIX3xPZWgRESvp46Nekga6BmowXDhW0nQozTEwn5aWLWLihC5nB0n4Z+VK/Ni0DkU1lB8Lzt/pfRei+mx2fIuRWKsuNTWlIn3/xFIOl8NeJtLzjmJNg+Ki3HgQZBsM8acN2YtHLQITsUL+M63CuXcyoMVR4P6W7FoMPAkFTjD5ascCFiXLFf+HRNGfZ72QLjSxBYQ4Qo3UlfFApjaT7w4tM2FHkj3cb5RHc6LnYPCBrphFZ8/Jt32IYviWTZOmK8cn9lYbFzoDw/fe3CWT8RYDRv//ytYxigOlxJhhN0saucIvrJZSpj0Ao6EGCVgnNQ1KvWt9xxcANbBslpeZsy30VkrMb/vVvbcEreJZJrIrfcNH20/1Vj40qmsmYV0ci6r0eXe+QwSMKq//rlNacDP/WcBBS2A9ypkrN/E2f2rsgaf+iCAzoJb0smFjtYPU2ghJoNgWDQcPXgmEzrpwYDQJAesjSalWo3j7/eUJozDm1pv0feS/WQnCVmX1t8qYyV1kQ5lEOyILqhvK6g4fj3KAxDZaf2lkECsS1/ATkMN5GDJR5QNqSIiC0tty07mBTovUFmtBvrYHbyR6mvfW5Jy/K31BD+ULS1CIcUIUqLrrfYoGh4gAIAoubL1Hyq7gmrp4fyRGkOuNU9FYZb8IeCQNAyc+KmqJEqtlcxuS89xJkymNvw4DtlIMnOPB9BpoweBVqXSIe3AdB3cU1dbnT8Bm55+MvZcdyuWZcJwfwKwZ0cQDh3Hyh6YzTdInMn+pzhEZkeabWqRlbqfaxHK/eoCM50hrKzEdH4qFhEyxnKYKqJlyYVNeqKjfUKqeYQV3dxWn4p93ToFleOiqjbxYUoNfH5eXseGajvSm/r9SI56HgyIIKvGyzr7iQGgXAUBd3k5yHKzLVCNrZHsMJ3ZA4D0ofDBPrUwAo9ZVbmmOjcyfyV0STjdr+J2dalgMJPDenb5is0/kBQGSQbNaF71z3tcG+vo6Wr5Mb5gwkqS4FesuVSVyHAMfI8jPrD5q3P2W9vSpIHuXsHe34EFRQlOSBjrH+8KTabRWUav38rFU2nkcfBrDjiLPuXSkwq3CvrJ60h5dnhtwoHT0/cS6WehezxFFwjLCcjq8Uv/EQzpIZKK7TMrTprl0bAosD24EluIuTipC7upHtPEPlV0jJAH1T+qoH3C/bcOUsEPXjmra67ZVBnSSbWl/VIXReitB+o/6cFPnZew7z+t0DI+ChcRZ6cweTyk7PZG702bwX9rF8Ca7I1wxjum2aTR7+sGl0cxAfDYjjGZXgj8SKwvacR9tyHpUEuwmDG3QxheS4fGgdENmCGCPZfCBmhb40M79ruziQbRb8Eg2bLi8kxkINqQoKtRI75o2WcEl+XJNzNsWTF4wTRJVHbG4RmZEggPffAq/Hv0fukxXiPDKCFtCZ+8Op/eGjlvQjF2jHSQCycNJohY17w7Hl6pRSXInyRMyMcCDOfz/yGMjT8sAWMHr91D1vqizMJRHa6cmkFkC/JVKzPCfYXVQwBgPdAGJcDJ+jF/rQK2JlrDWfsWJ3j7DGoBFAlp3k1nwB8PiO/qdsuGk3WUS6ncq8xQSXoQPCaOanT+/FoAxJ/5cjfxybhU0T+McUwNGlhZn/+HQwyYuKnNhxSQvDz6EGcltcFzFL8CKDH/DIwoxjePMoDbWMVHEOgTKfICReICsMJ/FxhYJeQ/ul/2Jerk5+eRXcwQlYWfKsUemA2Yw4+gcWuOok8kDlH11sOBoB8o5nZHkILvseW8S6cTgnzzWJM5H1gog3Cb5JYLG/NoE6+DsrFv+xMcFjKYlYBV/BBaKo1v5LGMDGKqO9K/OxQlGg+VAMJ/JN6rrIq2syI2qc+2hJvzrOwanOgZPcD9Pd/QsLcxmPFrTULMhpwxhb1Mox8QudZyu9Wl6pFHVujamWl5FCgX4jI7SKw8dm8rTAVKZrCmXxE7/K6s9A4ak4sUEskNtNheZOerZwvL+aLtHD+86YWjPE1W6IPTtMxCUFg9rKSHXS6KRE04jk/Tq7ZIz+phdNz5r6HC/kE7lGvoBr6sp1KtR018ZUG002yTBlJY06juc3sI7aerQHYs8iC/tShSBl+WJOTYhZCDCUTfm8PXzohQKqJeXxYf9mXB1pO2RjTo+3mxZRrSdDDM4QJPq33QSxMiz05kd0wsRT3dhqB/nxto0ZSOEgM5CT7quTBoGTQ9d4UIHTz27n6xXdfYe1CSn5UDRDLvKVO61gvzmDY8zRhPWDbSaJsUHdTjMmHYt8gNihUhlJLKNqHnxB5x/FiMR8N2kW4MCpIUfinmK47t/wi78OZqHBHJNwSlvhFRQ247NhnqWP/Q7RTMxvN2jb0dnmKxOWvPERywVe4OVQkxAia5yWCY/LKGVJTPLv8Ur6/hMavw059Ncem3w8vDoc/hQMFtj8nkVNZvVF1xyIOzEoLhZPc/a8jDYajZ+xQfG+AhgWnWuY185nCQOdDTGaafwi4uAhDUDZYA5tYgxRnOpv3o2se8v+Rrubi5kYMMq0VMhCCpc4XDY0zQ1JJo1YEOIl9R1Hq9n9AwkIjst9mZY02R0OTc9tS4aEJB4ktVH7Xl58rHG875OXJmY8izUIhRYctdX+OYDLww2Bi+supoDL0KXVs3wYppnOgKQZgBZXD8ZMBgNXHxXDiu1sMGFatUKrE+dnzlD6rS2hsFU10RmERBMX+HVjaTlgj5IEcbNyH2e+1iKmZoPwlxSZSfFGTsmbxmDXM3FyP2+8l2OsvZ1OcqpUxgrqTe319CSnUmWIUNfXumZtW9hm9sCVkLlqfpUZ9hogjCyVdX0C1DdlkzWhcGPKPxdAlPFEcQrtL6YB1KJ2uTq/zhRfYaxS9enaoOapb+ZfV/0Eq9VQwafBBMUIqHXpSlAYSSrr+hiYT6Zkfk0iXpxCB1SfwBteEMI9ZNX1QvsfCYhWC4FHHxRkMyl//a5N0BN4WJACmVGxSMtCiv1QCQuVvF+4d0xGG/B1oDgS2dD0Fxf0hUHmf15fXbqiRtCiozH5bhd9YplzDpDpcLTs0hyP7RA4cRPqJOPAOnNAvTeZQ7ad/SmUQp+wbKIlttKKpLbjHO9zX6beajQY8PzuVA8YuxvP8vC3Dt/0lHy5pZ/IE9M852nY16vmUe/aEAwzKEP5gALmUbWlC3mzDEvYOs3kaSOV7nfWCidy3C531vo0yK9Bl9l2Q1gLcLHgu/R75VlRsVe2+Nt9br8S6nX3/oSq0gMVW1ePyuMV3vhL+N94Vr33uLMwO/SvYy4XA2ZRSTyZzs9PBCelAS03p5ok/8VLbtsNbRKRy4RlMZMIzQQ9QOYm22dxSIScWBZ3BwG4RbB6nH+9o7fUcXMWVjjYYrD4PSwSIEHgSX5T80hV8gioGhuZHb9WD+iAL6R2sE70PQqGjPjyiBORkylrA3qc98mjfjQvqkWQDvBVhL7aHDMLp8WTTgTjOT/fHLcidqCkND5VNOG6or1catH2VDy71tKC+0s9355YUiMRuc8g+C5mXMhm+LnW8UpSZ6LkMsO9R6LgD9SsJzPCjjODRtmXvSQHXLlz4/N2zTnDyYXQk3lZa07Zw+Yu+fWiDNtPtIjCos6ww7nkG+qFZvzAmpqJH/sqOqbQrXQ89c18ftWfGLCKjLu7Jb7mo/L3M4OLEVAZGIanraiqHfngoKw1S3Cyc4FniuneThk8PkU/Jdsh5ApEmBzJv+uZOgH9sTQWqNQcB6TkpoT/znGBoO0Uzn8LzAoT2Jk0G8seE3b84fGBrHGXQr5LJmLb/x4mU9xUed8b4V/rwJhMjwsrRx0GNoh2X3+Ylox3exo1BEdrhZAvjjV3IH3a5w1y7/RhvdC++B+0pMhup+n3MFKzY7+1mlWLDt1F/Wk01u+BchAIDhSaSSAwP+dWxviIL06sZlHU4XAofqE2G1FUn0gAn4IUbbzR9FBuV4r3R4D3nQf/vQJpIQgVX0g65J7yaJ0Q+in+h7KiPaeT/92I1NkI/j//2jvRGrf+y1tJxZ+sEd5c/BeS23RKaBYJk0LF2l0j8I7LpYyvhduIWpdJrnWYd/Q6CTBYUBlWiEHrhhDPTpQbyoA5+9F/TviQ+mA2v5MwPJnj4VIw1bBv0KHjh2Xyt77FcXnEk8LP9vBytQ1uUqzzbymQVdE/IBYBwl+1lcfaL1cehu3LWVb3YsPJil0W0YK3sSSF2SKWG2w7GjHFGMfnaHQ6Bo1t+876gG1V/YuWrWwc2FHY4ORzqMOj3EY/Y/70CooR5Pq6KeWBG20agZbtDy8jDwuaCLyD0057f0JtKCsCMsavpRwGj554pu5M5Z/Aw9DBSXMHglZuC6DW47OKlk0vKpLFO5VLefZyk95oKIB5jjCLEPal5H0xx1UAY8sQoQ8V2Rdg0D9foLkGLbgrGnGhNOfdg/yAJP0uJHf+d9gidY6QKBcxiqniuFAqoOV75bwFV7L/cEDdI+S7L7NPBEXzN0yWNiQOEy9/hCxwf+7XRW46CZG55uiOPaBItIiTcQJEuDFnxSlUshjjEJx4ABZmclR1p5yF/oYU5m7dzXRAGR/+fbZ5Wa6p5difZqGYWnZ2yr8WddHfUXo43UbDc+BOzZbfDxLJgzyjRlzCnb8aElCfhalEd4SK3W+oGi5QWbUqyt8/P4EKEOQbxONCS3WjlVXTl+obqscrpbBO8PlA3nDs+Ky/uXWAnEFHL78ZX20aMt2YkgV/uPztSHPIL0ed6B2ykEcntiq7qebquB3rxRv0ypLBUE6g/6VxHX2uI0QgnhALniioVleCP6vO8hzi+4J6rSIpiSnCSltSqufpBUKeDbmSY6kwHFaVulXMYvUB9QEK1fDjvFn1lT/55kwzm9Vr3y9DFWgb1XmZk+WNpbS26qsyJN9VAcKAVW+q1ud+e4uM9fClxYdP2+uEnJ/2Xp4ykr1cL5mW3MmHAv4W+wvr2rOxkZlVvWDYJJ379554o4vQA0aVVts4s9gH6/ohoftTaKKDezcJPjh0gkO5FrUb34uFzxa3Hd/s+LchApVDesavANrNTgj9NMnW0Sgqa2tSWnvXpr66qPUe5NIzSzlJWzaDxMA6vosd6MJlvmv+v78ZVX5MObugM4D0zz9DMwJt5bNoAKNLUEt8TmfmSLvBEDv0ai0rjfO0RKivkM0jR48t58Tw71wX2WbW6rvqh9zm+Cnu5sQpFMRqX2PcFG9zzCTfY7Uf6Nkags9qLTF9p+S1K/AZdpJ+hazFU1/zbs5jnNb4cMbhg4cyDo96eCYymegiVgt5An7SZP9ktbVslY39+Sb4N5iNTxLB3zTCvvnURjZtDXvT6JSCB0x2g8Vh8e1a95MwCRK5GoN2k0me3Y6WBo2urpK4fx3jJXp6idqtTlrIdXdytcuQ6ca80eN71DME/BkKeQeOuBM/8t1XSNQdBPyOZ7EL9S0U9i0ccREGvbj6NbH2sdo9hKUHdPEbxC0I9BbC77MQZx98z/JFG+sP5Ly48xvcEWoq+Paozq9KYrO6nBFZa215FZyHyjm82h5dVQb/ZWbFFwfs7GnbdsOXo5DLweCtSNTWKXMCcm0/jkDA9ZcZgQ8Kk72mTLnb3NyUbNMLcDI9xis8hE+iC9X5B6gc5D3kDNZBVvkU1tcs1zy/q6wtVgcREilC5MTZH2Ufhahy0KHIV6Ii+bz/UOVFyGHGYWARzvbmKCx0G1nbg4e5xdZ6he7kvo4iawdZjLmewiq8H1Wolh+gslH3PvybznFcGVav0+nrSqhQAheL5RJwXy1DWNsNsCaklUL7YQXiZbgS0vJweM1IbBSHw7E4AaKWX4QLsHEIopYKJ5QhNYC0COBwY8F+2lpRUTfQ/zjZ6KPwRfnA45TNFZX7KhSysiLzysfC1ROroyba9k1/LPhiTrF11nhIJA8GrbV8mrDV8fysPqUpaPkq1jb/to1rwF6jU8jOzYpi8g8JBAf5DDSvTGMBgKpgssvjZvfno6ZOSkcSsty9XDDft1Q5wuPt6uWZ/odgCtmlcYstxzl0F1lH1Mbnn1U3loQvueEGSB2nFonjLUMJ0ZZwBx3EayOscXHPuv8yeXsrEpMw/vuAyUcHPl2Xp3b6k6V4QNgE5h6H3vG6E0L8/QJwbluUz7BMvYOiTMH9pWHv7nMy9qyoNyTGfEKY73dxel3uiz29n7pDO3t20Sp7eJ2HXgv8hEA4WDN0B1blELkufUhJ4bZ/hH0IlhbBtF/jVQDx5iexmHPv4st3fMucQXOfuJ0bGIDt5aZaMhxpG/7hicEB5b5igxi6/8X7ifNJGAiQ/3x8rfcfcSVZ0Tve6cOqd/711T0hKySSFO7lE38+NOOJ/PxWbn+2XjgcL3kQMOXYIzE7FUcs05hDxo5CbvUTl1O93Cile8yiAYDdaXtPB1z2YTD7sLjTGMxpi5DpYDFYYSZTsCGViM4OMVgiANqPQGAjUWxoyfJYVr/gUg4aoc+IRNw6F+ObDVEPZK9fFjjvBSkOZsYsuAcxsyDgrSjUFjBkpsVDGaEBwQ+3Li6Nizo+yX5HGAQB2+t9k6r8CCCb981FA5Cz13YYXAO/09fpgng9MPM+qqwNDZl/uAxoCbmaZ71D6l1uUYtRb2ZX3oVTOQjShm/i8m0+kApnN0UZn+8ECeIeEss2CAN8fkAo4vuDVij087UiIT8QTWDEuX9zxf3mxuJvJBbfyke8w5RGscceczjOS3Tv6Tj1SZlyz+6YPLaBoqRjERPwAwi+4uSa2PwDaZKHjMP3IZriUTJEmKMHYZEGRDW11HB8R8XSf4fhb0GhT/C4P/2y3KYc6+j/vGmGAND/gssab0GhT/HYZ1DobQ0AwL04wH3goJnJKNM7OkymBGjpDZUm0HqNqZTUaKq7InjppJ2j66K0We/pEJhDEvojs2czGrb4Q/d2tNOw6jVokHwaJeyDhm8ZpotMVmVlvozBhJCUyY4eOmBxh/eTEpstQfqyiM4lIDXGntlQwFJCs5Z060nORvzvEsYaHRW28aa0w4cPqg47aK6Ul67OViiiE+HJu8gTOXn28K6W985JIqWzDDOBQuxGnyirIdm0pC70yXwyOZ9MHpwksaQa4phIrlltM8mXpHSQ4ylbe1+zOfzQJ72HcaJdlc6C8k0eLyLs2IyVR9wox5Y37YNDD00eP+RJPrKs6QASdHTmqpZDxTurnIjXI0GPfdJdCHJoccdhjwvfJ80HINo3SYqMwCW13pJz8Rw2On2B5H9m4uTAeMFTe33B7pC0HL1VlVV/eweflJnSk/lR3y1de7diWa35Vwpq3fFtksAoXFyytTJaVK2Lzi18fSUUqFtoiQ/R7L2/rVh1iPKZxLkegjb0bpAroKmNwOp1IkqlYXIjyZvlSvYHeMEkaFiuWmqbWqu75H09bApyoexgNgjEXbWfWnVfAmk/3HLoccKqsqWlZtlLqxH7SwdXJfx6yCUtyZ1vhEYyAp15ZaKmLKGjQKdS8XXB6sas8OOc3EgGGTqfcOnE6zyyQD/3eZFfbpRrjLcC5zoYvfP+oM8GzIJ/9ZeQM3M//avfPDurZ859+pLfHDgAmDXfYExZY+yAzPYNovQz3jhRxjS270FCN3fdQdP92wN7CTkqFkQefMPuptZ2dTMPdWW2dbPfuBBGh283rpT75WbTDceDuwkIrzNEaLT9rTwmS2b5gp6lqrN813HUhxjX754/RMusFqh7i7uF0Ik4FBKJwpV9xcBum+QqRyDoeGwUlTnCp7RkTgD3qr5p3e6+NM+52626twEcOS3rmk46fs5Oy66tAOcHDTFHFJaYwi75IpkmOSB3RJVG+UHQ/Tv10YdUhgqZQ3ygWiX+Qm6Pqm2yo6CRw75fHLW/OxdCuEsuN5FJlqUCpCBQiYFDXGPJr/fJRSKbBiwKhWDiypgIFEoAm4wVNVgso4PI4v1+R7ab/1MDwb4gY+/q3K3Thfb8zsJ6EddQ8veVrAjCwcNI9yCEMZNwmVMOjbC0okpajJJIW7AHeQiEUbrpM5+LXhFONnMlgv+YafbQYPSKnthPpnELdl3Ovbwa1Ld2p1F1bIVRlG5HpF+X+WP9v5RMaTCjvebeUMC8WMK4GfPrrXX5Qf9aRTdH8hBrTb1ukSl9HnxN9PMSc7lTqQoNf/PUKTgpS1sNxWcjDBvLFCU1Z9pHp+5k/E0NTDWpQi/iut0zm2gKIt8tssD0v36kzr3z5Wco55lcpMcaqJMdnqYf+EFCt0qtDLX0mMS1UAgxdI8Pp8mMIg7JYWi41ygSce0Ka8BLlfiV1s+cMXstsc4fJ8ezNJ+5Psjx2A3Mq9lsjXss+HjFUpRREWJORBDPKMljERhVJ3AoVwGM1re9eqkKqLiE31RT6EIfoWdXOqqNqNJuUqldFUJ+cvogMyjWiV18/K0Q1O/AaQY5YIzJXLhrsbQVWs6CtcaNXsfSlyHKUAQRTTD17v33ECQGV0iMcoIbyeyOGIgRBkZSeZCOr1tSUJu5pkN1qhufQ+DaRk3HjDrFyfKzCd+nAWH6bxOOjwzZGqSsNDHl01yxGmCFjnR+fJqfofKKPh8h4m3PpPyYrUxg8J0JQsySdUlirrcJUp8tjSaNVfd9+8qj/QQLcKUIkWEj7lgmN0pze5ip2J5kSlfW6djbz9UORV/j6Qt/5+ugFo3RjmlMw5mOUpK3eQJwD2SlMmCX2RrcRr8H7LVf8lyCrz4vRDtmeBVhaNpU6YpAzHde/F6KbS2ykfgjXcTpS372TDBJZmmcGk8ksLFOQNe8VCZtSiKeHSGSLwxSphd5ybOBYptmiVGOq9cniLFF2jWYFl8NH/um6dn/G2ziuSEiyXEQE5Hz3OIsgnqiO1tlrZ0qrdvdiGcaVZJ3VyqRtr/r9XHt3PBP54k3M1lGjz1PErZbQcsx2BgFC9v/OUrSW5C2mWLxWiFZTE+xujjeYqxV0lopK4DhrpS16kksSXFj8ZxyH1y/f5/u2BxiFVsIoweBG++cCFkQOOSHUgeLY2MpsduOSauIKtSkIljYV9+19zTOy4QfULoCdVpcnMdqrHEuOefpr/bi0V4dm4uil6n1ct1N3iItgVch3tYV0P0504av83iYOLxHzQiC2xERLf9OU/prJmJWjO3P9xqyEzs8T6Of0D2mDs7J4/4ne89d6Dtz4cpY3V6dbelU0WBKZfB/2f+XrZES6NHEFkv+1uvzsXOvDpBtyBnDe0iMnq8WXeu9Bv00M96bZHmTgZQnOzhL9xpTjUIgBJZ8dorgw9iCYH92z30xhk8gqTEYN4mg0wv50VxmTy6M7GauiDWMyWhiY+wVuZa9Sp9xLuMissY5AfKGnvXWesOZOonWlHBzIKvDVfFIvhFjHW/9zZLl8dIk0xq1sI1gVzdGGuuxNSZ+z4Jxqvy4RlGr7tKSP5pFxLof24ip3EU7fljkAPCDRfHg7BTy32k0Om6ZFpkJ7pvqJC+we2AJXGMHGjAOms52qyzDTHhnjdwnyQOGrAUVHQ0cYRM4ndEBheRA+wtswTR+0NBlpvB1SA8NDcq++AkCHfxz1H160SYk6jdwPX+4ESSF4KOgS8eTUirQuQTNy+4062o7aDDrsyTk640gSFHOJkswCDy9x3zDo0pACZJYnSGDvfp8ld1E1IuvABYLPX0umF+ZhWZir67SXDCPD0wXIZm/fp6+cGJua14eiAeAcr6X72mIXNKszY+Oq+J16YfZy1ZxY8Kq/tp3YsWTGx8xXHd7GNTZ9rR8LTy4012Xdkeml1amtmeRzKgAjyCtQ+zQ+TvCB6VGRPuEzoWq9edYD61dH9uwl206z5MwzSQr8s3ZsWXaObzvH29LH89yGp0TGTkfTR5AQOnztv43hGPr+OWYmO2PXrcQWi4itDYYRRc5BFOzQBhf+3UbR+uUKMsL6URzvm2kCPwyIwSXPKMwKQllK91vLyqKssURCzQP3UKFqfiR2pRu9SG+SOIRfJVq3OuO0xekfnB913F3cpMqInUP3dUkIS36SBak5E1J+CL1f7ei/1YRczlOztt30U6L4eYv85DJWM/n/AfhWIBxAgjcsDJP1BRKi/WQSJP84zG8yK+w6TWXIxbGWsKnNvRHlNdoGPMkwdq/3lTBiniTHp+WWp1qEr+coR3lt5QR5ZdlnROyHU+n/1sR7IbU6GpOHylLYVf4lPVYqsavb2/XS4mdJi4iNQVYCzi4lAK/AcOtWOyV7/2NJtQJqZ5SfxbRylYi+xWe0yJWvonWGRiRlWsps1K1elrCd3PZfomAmNrdia0Uq2j1Ks9r1//pRLfEu02O9BG5ZJ2/AvqpoXmrr04KMrTWgOwnw94qG+v2sjMXo0BzMB4w0No7AGQrWKPRQEAhi8UGkG1g4105KfFY8djxL57rhnk0UPf0pm/vEz4UjYyikY32EYFFPgKPAAgw6vq8Y3DXBONCRIxN9nF+t+qJOPcPo0Gc7QGdRZ7JseYoX+Ckk09hFzvQn+nVNJYgMJOFRjaBp2BeXVmLiAXzTNQNoLq22qSz1QZvfwXRNoL1eoP+OwxDSvCeAHHwsapAXKclYDwXuOLvcufS0E87PAb5env0gJsJJpE5sQ7BOuC6ozQlhc1gX1j32/4vnt7xw0B0N7BWhBqd2ddK4+04I6NtAZW6+teqUmt6PcTeBW6UK3pXmYzFFII7L7Nv7PHDwnPmcgvbI1tgG0bBcyRAUADI3Ltps152i0zBBXnluXLYdE5K+Pz8housGt+YmBbNwr3V5d7Ygi2pW8G7C/OwTzinix5de/phh/AhAoTgnI9bRgTwyCiAAN7uerYr54D5gl1Cc3KsG4gVJWkmusf5MDnjyG9pUC9cVN0FnHQ7CuDNwZu2g9a+20MomXVbaim0jD3DIY2mpoDNYg2nGsO+aRypa5OZBv71RiNoveOp/u63MJwbjrnjt1ZyhUkO0quRnHxUnYty3kn5o2j0P30Pl/L2e8x9jbnTuUbXu0qu2OjnTiE4+yAmZg0aQbMcfXTVJnXtHPVV52YtCPNErJa6sjd7KnFs8MGt1mM4PkFuwLgjqIJg2XeDUV+H4dtBj592DN255ALJ1vtge/w2ohH03NbNDAAr5ZvX+qBsfrIFe9SpPsfpOKvhYn4+ngJaYmIcfbzyaoUlBp3Ddr6CLb+p3nrronfqBjtGRG+3mtDIOjAEkkknjPq3yEbQuC897BrjhLq6HeZXLoVEYNVeA/OgYltA7L0GQnRaPo1eZKG2Cqay1avXRLF3RHbx7g6hkXXrlIg6qDTEOac6p/VoMABrgtACcDmhaDHAt/HyYYjiDPomBP8P5AhJoHAcVD4UAQ2RZ0Y3cn6+Dwcw4x2ImK6+q+AuG8jniDbcw+2cFkjC3UBDz3HAqfCgW5nG36lMiigyqIktqSMFXcfclNeBNfAfNmGqYAv8x9k4nEWVW5Mm0V9OozeGSNMhk2hOUgTOvMy+w2ptE4k2c1PYAy+0PJ6ggnkbMgXY3VpXabP5W90yezMMVwXZhQI4iwDVmH5+bT//XAVcCPe2Koq+sqS5WzFiu30q44qpcZLoohFmi6pu8qFH+TrjOEP/yQy5kp6Cz2aYrJNyRXbmPSnT0k8VXK/g7K++7dzXosiO4oyZxWEsxdVCGqao1VSVgC0/gIbpnMOkSgNuM6siNebe6GVAMjrSiUApVK6CdJRkZP9CtCbYxt8qsWX6WKmACbquOiLJx8gguxRU5cxVaTYhnPvBZvkjrPx3ifG6iIy876wihOvKFu8YTfZu4lRl/7EfIYDbXGSjAQe6AKXIsg6KhpxSJPp8yjMixhoBhXgPn2o5wBIVAjRD+Wxq3IBI1HbnFu0U3PytiLYiJwd2l6+Q7xIY05Zjghe5Z8Hja3+u8PYLwzZAIuEmUCpYkmdiN8rR6fSsChhRjeaBH/QtQRWl5azCFKPezpzvSKjF2FBx/XU51Kw3GBwlFWjxjV8NICkSYD/ooUj7jZuZs/cW+2D132S91CxH3XTOVekdT3Sx9hu+rLe5GmxMuvNLB3HgpsqJI1ZJUe1cuQKmZs6QqrQ+bJ8o02a1xgSdAxb/64daxziW1tAMJ2O/QTGTzqNLsrRfkRrzuIxjjMsSS346IEXIaRc9LFRZWcXhmBVmZr6oqxxKjTcohaAbZ4ZQ23zJxiuC1/xfOkRI0XpF7fCjIwbdV5mYHWcPDFWXVvFYMPfELHML62sFVIItKSVTHRIAlckfXJa8OjK+AdAyBQz46oz8Yg5QwBZW358ceQ0BeGWhzHMa5WrHbjsbr9iI2WS06TUCtbF1tQF1bGrOmYDkybLilYk0YWN5a+CGC1qLxeswyNtIoRW9dAn0Gxp94nKQjSlzhjeDZbzbLNmIp3iHeOM3lTzs+fsfhiFHUSx/2bczlpQPgVsXYlSjKhflxXOh+c5O+QjUY0zZ48MqrsVEkMse7STEWpVs2jwzZfubHqBsCoFymgYBIKliWKd/Nok43BlZNutivhuu/nxSN45S27Y7nKBPxS8G+CtE1hxU1G+Ca8IXdA5jfXCRmFGcTVf9qLLWW+u/k+x09D5/DbMeNs4oAlS/g9PWV8sLX1jV0xc1+s/q7meb/RH84tYmwdooGecIBwM5CGj3sLt/BtZvSyp4qyAJfSZOeY0nWbw4gn9EIdFLEc8IPL3M25QAo3uPJueIc1gASPuBf5Xvufw5Ya23MX8KcO4LeESwwJW6tK/mWqTwYQTiCwRj7/VIn3mefrzs3DLiWcs0S58je8j3bsPNycNbNh86vGnzoYktANNPFKKRoxBgzhbZ7r6AJhq4SiHmTBF47zc+gFv/7Z+I/t7IV8R+sT+pcgpGPSWsXPadGFgxMr9NYpOZeKX5z1A3oTFgHCSuEJs9Vxl3DL8OhQ5ZL3SbI/loR749pLPM8dgSlztYaNINwE5zUhXldvsqjcWtrizcv8srTLG9robV1Kt/MLo/D/tsVGxltU2gHEWuZ69aFdHYKIQjEjPL7pyINRJ3Z5WxDd5twjn3E1vikLjNZYL6vUMzV0WsTqwKX60WqLBmfDIEg9UUPMBWScKrzkWo2ruzM6KpSWV1eFVEU6NktGSN5H0myWwIQY8OTEDjE66O/FDM1eNH98UJ+LkzR7hCE24idnFS5lAaZw56Kv7FYP6DwdpXitRXY3e7pv2ZVvq1lGzje/yl8KxUj1vF37GD9x4enELpGiF7mW7tGuvQWaRu5Za+U6Hjcj2oBZRFe50pP7Dq2fvBQBPAnviDmx8t2zQ9mn9QIDjEl31yKLJMKsVqNfopAnURiXwPh7+3ydQW/yIK8dSe9n3XASFQP0Y8S6t2vhiZz/CKewaXKce0PBC23BNSP5QaDPDVV0gqcICWZ5ZUpdaibAY2QJraS2IcqvrVmpASpQljS8+hhw+nhnQkjhLqPbZt4GiAbmFpAlG/iN1JMP0AQ0N9VUS9SnNYMz5GF5Vu1I49HA1fvBupa4Tg8uRod3wJ/0g9O1iZCxw6jBhGY1qnSQODfvRMXbANEfDFC36LfvtqgSyBYgZ6U34UCPMODofAvkBjDgesVC3andYhu6Vnlm8QDzwUctt+Gf9eNFIwQ6yD5tOkBz5nu5B+5H5WEGTJr81qqadFqb/QrZ4zbDd9r2a21jzLs4dkM10sN/2g7pTPbFNA8y9Y3G+DpQdhy8HQB+IJg4eYvG0i8vT3FQjKkTtUzbmNFNhc2scufzeBQvTwdZkMrg0ZsDAogiV3ItotS5dxWGUUw+nPYP4mLl1mPeaMNbGYlyIu+ZOjZoChMSvLrQcBQBTSpliSCw4tK1kwA2CWrS6y0mTnmoUWifYuDfVhrGiK0MTXllqpPPS7MLI8lxaRFjd6JxK+Ewp0CqFIq6AgbiMRf8IRPyOQF88DKBllGAq7iUbf2Iu8sWlvwKCPz3uPQgZHa1MNG2sS6bVSgc4oJvYlCVebSKuT4K7yM6P9SDpuAomBoJFZvyCMBxolwjA6sZNCxqfYw/+15HpTSflgK3c8vf/Qy+GQEUIOSbgxs6emzfnGWxGDugmD3jyFLBuGQ20XSij8Gy62cmabpPLxkO0D4sgxDHHUjNz2SdzKGTl5l4EfcAjbpHdqX9y2a+O34fAVslGz3UkrRnltg4FvLHuxGUsLvrMzBsoN7Cw04tHMm4fcKF8sQ42GQFK0ZV94Er940H4bicr1xxqUL5TD3E6Xt8bub0Wh6oYU03853otwh+m7N6unwtQI39XwwR579BMY7DEGvV3n8u2P2JZ+2Ze6xD2y/pZ7nXBNUgpHa7Vqqxaz/w0ev8tKy1BK+qpXwDtoZx/vJp1Z7wBWZPtSevNZbmFLHn+bYEXmoEvI0p4v6kQUw8vTCKsEoIH/qqRF8LI0ApsPbsL2zUJmdRXFBNNQcplEW16c6LbUxmS++Cqckjd4WaHQCoSZOO6BwAMzklgEUPrgLHnuNLBw9FXsryjUdwiYed8o5f8n4N0WCa7xy+6hkb/A4d8hJIKbQu7PQsHDxtiDdCIcsRuO3AYqPScNCHMDOvmC/wRCrV5DgznocyUnUDY5YPQ2FRYf/L6MevLFR50eQaGPMOgv8SRqT2FsbcBuYGZPdmDh8MyLeWexqP7FxMifQIDG0xtOQwucMevBeYtVZwdb1n7EgbLV/db0KF9FNv/rpv38GgtZ0fNdUxUKXQLm6rw7rKmb8asWDdGsIXs+vu6KeQXONzm18Uxtos73JyvLuqKVKwfWumIMWYCkVDNGMmQOhYBPd1O3Rz0XXwjXK4Xif0UirUokMKhOIwtPsx17ikC8J9z/kEYi1Isu+wCj3vbGZt21fWjs/6l+7vSbMhzpkcKre7qYJR/1OKpSUs/BXBnwUnZIAF12SxMMWYVAhVG3KY0wvgjVjIpdfCIw8rQgc/qcPVqLOnyzQ7cI5aOtaEl02FmERVyBFL6hvrC0mT9L/cIYC782zDQpt1HPdf0cUY9ufwaJFcEz3Wq6p07EG7qKvikDkgPN/nSmQMI6CatCCFh0ti+lPztYfkIT+eqqKpOKbBf8LKwEEANy1uKFR81Q45JnSMogl26hgL4rhD0/+J8l4c1MkUWqAscdvH3XCHVEaC5Pwwk759zVfuqJK0Tg+ZXy8tVvaoGgXASIzWrt5EnEsvRE6qqsxOsqFl+EnIczmw+kD5k0RU2eFjltStSU6ZHTb0WVy5Juya49B2fWH0ehtUsF6kOqu24lwLDFxvW8oY3YgoynZ8FqwLsNhS63KDfsjNhgJJQ7zes/9M2j/gAJSAVIvyLhciNxN+IeumSJZGrTaTVGprfL+MT5Frd7J33BQlc5zgxGSRLair392CfhVV1/mcwP+prpROhVWoS6DC1zkceb6rNncHXSG04BZ7lREuK6y2wjJg5UgIqWDpXXM6xSpAwO7YDvGPNR8h8x3UGLlRN/uPzgh/lXIi5LTsyfxXrRqWu1+iBFUFHn2G8cU+j3rh7pVg5riaxHwulf4nPXtaDGYlnjO61j6lazjb6hPGOIiVv9AxOPxZQdiiSnQdW48HLLaFVSVJJ+IjPS3hTyhrxxFBLpNEazU6hoK5SRoxgIMVe42EdwGAlMfrFhm4/rXa8+UiLl3VUlNTXn7Y84vrYPnnkybwvlqCpT2ErP0YV24U42E0ffInAMGllAkRW5Dm+UuVwBQ3Grzp8HDM8UprPpIbFYz7Fq2/6sYCgMMuGXnokvH9tVAjrwA6Ysy8U2Fei4S3SmwjPy7MuJX22RN/5V0sndrSIjoE6H6KGF7vG8IU40Ds0yPU7kwyhuGksFAOE3aPx4iPs06sF2yYDGzQMnlueCoDv1OxcToDcwmBtQyCNve8RxXXMH4iZ6GPoxfxnWLpZ9fFUJs92zfYmWA/FzOLJ5h5dv7WLZx/3yMhsA0mfrP+V1Rn+a6jOrCv5f7uU1hjGAgprWARU1jkgDNh+G/hH4w0BBjR04UcTVuwsiEzm8+1LIncQJP6Kmbsn6c9eHeswrreLuVuUDIBAcGwnQRiABCOFA6PgZl34Tx2rDXRo03KUD4pSIGsHI6DHohCZEg6Chc0EG1hljlZukyVEWB0CFGBs8JCQYLVXkIZHlnDTL7M41wEu698WWX5cdEv9mfYeFABNz3OhEUD2PBK4bMe9nhiT+4451Wk7PbuVU3dH9ZtZ0GAPoTEl6PGjhtM7EWHhqKHp4731DbWLRTp7UO0jihZHFTGMTy1MnTnSd7PyT0t2FPMlPuq14TjeTXmwfeI2vuOervYBIwBYtryiSWMyiiX8TcucUyyx67423ENNtlXsnJj2osR69RDcomcXxSmlm73nAkbrxiSHVCD2ToFy/tbwmNN68YCIPQ4U0S1jgSQ+E1qOvWHbcNsliDDvpxXPnNS+mDwEl0eOLaPekiGOHJ26X9g2FRcEJSdX0TkMZ2YX8Uk8qygu/K4Gd9EzfW55PTHqlGef1gIf1nYP0iu9f3tve+GbIe9HRYwwA6W0vlVQlVmH5VlhwrfvN2nb7pOj6XdbqU4i99sGR3JGVEuvsPvr8Xc7On+H/S7AmD73KNqV5jbeHvMVcCC95t2X/nThLFjAy8UKcyuNQZ8bJl2Zj9nHJmM9mpIE1GxvTYn4LFiA6DOmVhOUjtuW1sPHnI5O8z3QemY4+KiWehekbdCWbn8ZFkYgxpVnFTbyB0ERl7BVvYcEhl0+Qe2idqA6Y3Mr+SQ/srUeFzidGn6qr2PwLLnrDWlU4e8MTgBg9BQePZANN7KQnTS3PzZNeXGp5rW58eM+kPBel8aeT0RwGjHzlkYAm+K/aGbmFpxBcVWeV3OwVeyxEV8N9TXUxOd8F4Pcgb54wyoO444HAh7YepaVavphq1p38Mm9QZi4dzzpvFvRBXdmmxf13ExWPEkuYaHubAlvYcQ6GYwhHb9fPVnAAjmEct4Ar7yCElaswuzVC2IIvSO9lVUBKvAD1Nw1abOji0meIh8+IGesTV1b9C86leVgkV8FNYYXj7LL6D7NHN1QFLHWYAFCHq8zKv7CMTco/+HHgIg7PSCxFDekS5rAu2x21auUlV7hlokpEdZ1igGnylyezwIDeW+f6grlz+j73T0ZP0emuUJRa/luzB0MY/pGumhVKwQiOZhyZWOGsa6jl9UsybgT8Fb4REBZr379MvU1POVruMnALzz9whdoDvODnKFu//9LpzpUmNSd/X50jgJOQJTgxlOORo5QQpgCJNOUDLa/chAqciDfE0eA0dGhgmJrDwapnX+YQWCHR5JtootSmhSoKCL6BaFD80brFrw1vrnrBGHI2lN1h8nf5hs4oetwU+tRnjChxCEY15THoL2N7JeDs/WzXLx0clmmGGupfeH2+mM0VWc1Zb1X+fBjr/yqxJPGbxjHJZomATsLs8tK+r2EHAM9p3Y8+TEN9lCaz2yK4MRV6pQtrNKcSE1vlSe0WHuVuc3VKXkyle5nt+YNcAxTdWhOp7A9b/aHgYNhCitrr3PQtWnDAgy2yKO2ljwNot3rTzr+IiqyUwUPPpiagzCv9sjR3L9UX9GeyOAwfT0gKPFTz3ljVHwoWgatjAa8TSTHbsVyoXaeLmPZH6Sdb55O+Xe5LKQv71sJzgAlwqKXhIflP+nPa+s+gVq1fZ0wXlacbSs2UWvjIbfZ5i5yUDeXyUqBdxb2C1cfnslkIe+W70cN9XBCQg69GAt0hYCMQ5DYBm4BgpwRsBULcLpg0SnRP2jL2Z9z2GE2VYBYE6BnqnvehwbHW3ULYsnEYL4btQLg7BWQRlR7lUrhgEJdQe42HjYCyqT17glABnVFBAlGBSxrcjchd2ZgB+EjATQA/CXgJ4CUBOwE8JNLhQWsRYETZL5UabvVLfayz1EHjvaYwJE1w26AJkUSYoA8OESV4FbCbqAxjfxADEULsIuqduRpi1kOCodtoEGKKiEnDDV3mOiu6TiQS3zjRw5MLv8c01VEPj67mRJoGJYz0Gxq1Urc8PNGRAwzUkMRaMSLplQMkasVNOrLIHS/IDTeNu95BblhH7mggNxw07no8ueEsuWMtheBXdWqHzyTfKAQPdZb8kWHSD9vh6PnVqR7tHhzXe9+QJZtdhQ23btgMVDfz+FDPoZ2JMuojfQCPbwu0BytjZFr1vA4iPUk2qpnvHkAp6PdPhKV/xAgDURxrXb4NJv7Tz1gSB7VhXGcf/1dFnpCXyTmVwDmppzjyMuaG+9MkatKDDdajT8dZmwbqYx19k6A/6g3pcWIA5Uauz9jD3jaTyYoVx/ie8T3jLeMt4/mUL0osCChyxESFurcO6G5X7dJOXFm/NGSREUtiuGWSerTYdmztsiROigSHW5R0ZFa41UDC9GKmex0+G1OMF7yWUx5cWx7bFfeoekmhJ8KllEoI3UuPVaypa+jHA5y6o4W5RLmi6rQBkco18eVhhZkECJxBCAm4EcCQBFiGP3G45Hgrm/nmMM2MXAjBWLhGhFBCFBGBJ54zSKASVMgDOykBi2TgBEnEkoFMkrAKU8XGg+NcJqjX4ZMWqctZjd4a5xWYoggeCDQsPBNBirZ029jbjJLHj98Zu7MHeYvKseQlQtWgiKj81GLxejtSTDVQQtvcB5ytzn0PoVRN/hhqi6tV1KgnN3OX4f4h4OF+Hyqg075xoOWa6/QI8+Aabd0X2Wauhy5uQuueIE2An/eHuOj9oUGdDnNxENbVxDZL6ovolFiDLUoPr7vf+k2U93mbW8FjqHwrlxWZMPFiTWZmrbiT0DVMJzGa5oZJMNEaJ/d9c9UahM4Bs+ov68dUBW0PlCp7YFDP8aFr6qlzVOVO+X7MI/xv5HK0EiwMYI8rOF+Y1UoOus5D7Yew3zV7DjyCeJJ9NqZqjFOM+n2KUT3Jk530sUMDh6x9IKtVUf53ArvhaRgFdNQkSdXaz1PB/l4u8uvbCQlmz37IPyfML70bSwOVcb7TOLx6mPl3CaU+4spKGfiwvp2tbg5BkE8CDIypKfZJ1iFh/vt0LLfjuJRJK1hUNE1JenV2Y86DPr13gdNmq8HpQhKG7YfYomz4nidsmbObxmYAt9TJ99JH/FEWmzwi/VsK0BbpmbvouPDqsYc+94C91Q+OeHntf1iLkltQ/kjP+qIlX13LuCMEcLunxvpBuIdGZU5dom6hGlXTohXRleioK1c99TXQUF7lx/SVRppoprmWOPcMB/H8mazWZVfRlQ4Z9a9Nd/7ueAPfrgJU/3OQei7DMCIRGlSDASAzVQ1xA+wab5zgRBfPJX9mPDn9mmtm8Bpy0vg5Yc6biw9LfsXA3W3NOXVVwq4J70qba70QBdXNt7KsHAWKlSDtuSaYqgq33bZVNWo51KhVp16THrwZsw0TyVyuFUST8J21msRRU7+moLbt7dNVYoneyNnSUAyIOgYiXaLAxnDmnid7V49AQaUtmMsf/Zv0wNzkxo069JG38iQeG+dJRwHFsYZ0XKQ4MsOZpt4gJoXmdfidsDc14ZJRMvnmlnxGgg8APRFmzjVfy+b25V9xBH5u9TRETPf6Z3f1avSukNKaA3RKggxruVNYZqxpGLKey4QpB4ikTmQtI8zgDKWQKGx6Wfie2QOJad03wtZGL7aqSgzVNLiJD1iBj67SLOlb+/Nz/W+QaGP3sAnobMXh+CJZk1UkiE0sciVrIIBt1KSPZLUZpv8Pid0LYV3OWG8xb5lxeUC9Dm7MwEj77bw3r5L8v1TkR88WIffQD7jrnur7jzjygZYqr+B6YxMNfpm8K5I4z4BgTMc7cuKaMdvZcM+Tl6fPSC7y/ltBU28+o7QaTMZv4MYhP359/bqvHmceEXQJkU8Errgym/vDqQKTYoLfg7wZZeR5kAcjVKIjQQXskFKecVN7puTcaXFye9z0bOMV9RpWrialLA8/LYk3Mu5RGYfJC76UCVT9mT1skypTVvnFjzfvaz5mxioNG5nicPi0crDjze2fMpB3n142+sBVKgQk8W05qKQDv9PEqAcUTeUfguz619rSatZvt97gQyGdJEWG0kMmyd68afwaXRN/JPiatlyTjSkiStoIjCVQWegz7bGYJQBIqB2PEay8/RnTsaSBT7fcHl4N/dXV0PIDde6/OOmOy9K9DJvm+h6egI3wWZPMw8OxICnAqmJYAidA4v4PU9zjw4o1KZjwWTWLe2izn5n+2ON6BrvjJReDmQOiRT7cOeyfSP6rvLZ0nBr3mBW5x+BVhooqBNKsJcvM3LOH2wEs52MPgd1b3DH/Jan2/uHVh7A4SSY/8ZqYFYm9LziIeEm4k1Z9zCnAdJEkC2BHpZeHJXzDOoRMxRkhRbswanZpkdmlEbNL/zW7ZqKgCzgoeXHnofWo3n7/gFP8BodKMFXf/BGhnvkQG/TTLhYvCeU1jSgPFu3Btdmj9cyewphrrWi28Pr7RY8IyrJbrKfFDn06w6eG4T1Q+QXhcfSGCP3z7TAiSaYv1FfWHhm5QIqdI6LgMUfLER8Pc/A+zwbvZZSfxEvSxkVfJUjCSa/Fmy1+b5JTlulVHBpO7YBODQmlIhhXFLCEcqd7A0jWiYfQLUOUwBAyGMcyLB0l+S3c/+mI1wbxHKgcQBw4OoQvLzoMng5jxxzWCuZwweJaK/QWXtGJVgUoPIt8C9TAGiPHTFFMLTVYRISy/t6IhILPv3JA/O6otCWUGI9lCPDQOeZokcu1VtJb+E37RSeEOFa2kq4Ns3sfyCoTYHr0ERHSArHh6AEiyrrSYKiOWZJLTe9C8Rxgrca1saul+EercW7saSleckXjxmX+DcVGcDBbPKF0VhQ3u6JxpbxUiglW4+o4uqJ4X5VHGlRVbp6Nn9V7Mk/5Du2/j9noApfs3Asuc3/UFbmPild536KaQPKtfGZXn9OC7OsY3CVOIue9vUJh6ubdgn3mmDF39dILvSM/gi3gs+iBwSeZLU4Pc0nNx87CMOf1nD88TCN/g+zRTllVX5HojW/mfQT9rtfbublf7vMxVjQ/Bl7//Ym2CMrc+B8cgSvAa9G5fkt/7Xoox2qu4L+mnlsfT0cf8vsQHjQinw8JBQ3qX6FiPOhDyMScgPlAA8izOfiymKd9c4vow2t6Xc7O7eIy90ddSf+o+LSPKkoZEOIqcCO7j44LP77ziFK1FZGaSzXlmau/mkz/6DcbeQR52XTIKh24bqj5SAOuu9+E5AautnVknTvUa2W0K56bKq9WPCc5+nX51zSujUa/cWwP0X+C0X+qUfFVRQDUyM5dOn0c8LCaG5hRT6r4NJi58EX/Ut5SvKT//jXFflPjxgin1+ezfbEajqFdRuZU/jG0IuPJMevjYVizg4YQJRZzzfglvR62K55Pt+yhfBMPjx2FxrOo4tpLTf7uc9lDhvTgofr2gPfKVamO31qudY/3AtSyaLc81x9QXBBW4fxy6EoAhQ7tO270Gz3Md5kloZyqkP6NpF+TVlNRmKeylNchec/SNVARqZYGiveNX/26Dl2pDx79HjdAMFM1/g2wJ1cOZ9u1PdBuJN9pktwEdTEhjxslfZeBnmPbRK7bDsj4lnc4z8/nrj/r/mtrBxn953OA1H7BrzdmB8PBB6q43daxW5//n54R8ALsXl0IbP09g42UDTZ6Ndqy40lmfezeWjEKov5jNtjo1WjriCdt8fjpaB2Ho/5uNtjo1WjLjCdp9TG2VoyCePQhH8aDD273MQ63R3eCD32w3P8kjCHi7fNZPcVpeIAJyT+k3NkShUZ0DZ4q942L7xVx7RP87cyEJ/KcH+1Ar+AQOJRDDg0izzHQdKafzewdsxi9jGfxMM3RZbR8mafnS/qcYr7he5hFji76k/CIIpx0nM5bcx20U72Ky8Ds8M+guLThxbcza37+1NTfmj7rYf5kmvJ64idquSR02bFe/dzf3pS/gY4LedmgyvsqfePPvAYNFjY9xHOcEleC+s4nofiEpPMz1oP9x1xFsF4VmVoJXLipYcNk5rN5emjdx7sZaVM+rJg+dHbiEPbdDOQ1mOTcO3q3s/2th7P/zsN5jg4yOWeJveWz7X+PJPijKSzJAQqmXdavRXcsul7RnbBo7rHhMdPD3y5ULxK75T7rtRM7DnBmw2PwCQZ39qu7EEx/igvWq3GwLY8Kzr2i971l+9kwH32BdfbPhaTnrffb+m5CU/bag3XuS8JDnnxtdxSLq+7mocfjtnU42t0Ool6O1rk/6E8ObZtxuK14d2a37dNG4fjSgzboyXm+HaQWVTnrd3vXBn2VeaZPRsfMISST+KDvpDcJ4H1AVGr4WzyGF9ahDV5Yj2WBaxVd0frNKwd8MXDhtYVmnfuikBd1kQhnXyUuvV+cQOsYebJHffhRSA7tFMb6zcSkdfgzT3Itj2a26Lg8Y53DG6lUoplg6xbnXjGc07/tFnx1YbMgOw279Z+6X6F1bfza8FrIJpZD2lZsj3xv2RcJjxBfOJznSs9O+nDc+g3tJLH0dpHMbVcaMc72XiGCWrA4QVvn8GUQpKoyGOqLEdb+JRCcw6cheVWZ4cviV8vrzQvU44Ln7e2v7oMLX42Vk+/dGm0phF8XRsauLJ0YTkUv++GtMVXd+Xoe+SM9xPhn1KAgAzRP9FX/M8Trs8D+CDsKzFRYEeOzFzPjG+bOR4umzygq5TpqExdw/9rPT0VE8SUSf25BfSO7c+QI+73Foe3dzbCSZvw0WFJEVFk42De5mumHR1VzfD42xECvZ9JqhJ66Cfa9hEEyH9wtUPFhKvqx7EW2n8L3T73KnhYqW6BUr3ofkQdvPg/fH36EAt/KK6hrjnV3G8xG6HFsFyd3+2bOrYNPfQWDX/6j2vl3zbf/Y+WI6K/E/ynJ75kACKClwL+vnzubaUUd/hJsOyjLZA9gHaNbY20HMFf0ONj5ULZJ0VAWsj08oOvhKbgentN2u3DOKLwFR7BsbKabkldXnqXtrxGoSpECrEerMkSKZpMTIiWT6iImZZN+UzgkbEb0PCIVScUf+hz/D8vgM8ul73tXPiMNVTu+QYY7yYbdj8YPZSHbwwO6Hp6C6+E5bVdjLENDClIBfA6SfFr2waZhv3k4Z/IpgKTtc74ZdpDfBynx0V8LWRZpwlTa7Vz1Ae/xtfIPBdxMamDhgEd9ZNgqOzcD7QJsk70XBTVyaef5AZ/8fFzY7J4WdZSdZ/Yog5Vm5EQ34e2KeiPSQBqi9ld9NsEk6LtL1+UDjFBl2poiGNQvBfZSQ9XUlvUBaSD2wBYh44RjyYJwGsdz714imNZE0f2kFYd0G+1Q1iGmNldeCXhj3qZgrOGRQY6xwxiCXuWvxrtx5gw3tDbO+FL3KSq3Ppkks6OSbL9NkuAPaTwsEXoK7N7L9PPLtSNSeFM8Iw2zBjtM7MHD45Aqf8nXOH0fY9DDZRCh7nCrjv12jyfws9dal6X7MFbcsVVH1Kc/k62cbCQl7Tx4NjxLUPtai7p7c/3NXkRthQdBBUlRDh7Beqtf+h7I++WzwGk/ugTgrfjPw5B/hXvdq77Xo2p7vWq016cb9vrtH+3xrF39EEaffvVjzto4a5//9ZjJsNNufTCnWc2o08UtTATUTocSyjutuGLoF17tqk8EWdxlQCdu7j/Ngow6+/R94k/yTsciflh/HHmYko6BBV8PRslDbpK5MjLsYHUvgVDlz/s0M9Vih7U3A3ZFJLP4FAZ14G2bg+0HXdQdWDY0PsaTvfP2tDWG+srGU0J9z0fq0uL9oETkx5cGcjDlvnD3yOrb55hoDfLN6dW4JLd5Jl+i92t9VbG6O6qS161Vm3aLqnDr3YqTe9U9QDz+3YV7Z//3ioW+JAx3uPm2Fz2Duz14yghtQCEXY9Lt0As8PGfrUvRr4GmwWON1sWNvdnW3/M3u5lv09CL3uvGyIXjVY+jvIR4IgcGG4U230JC0SN5mwO/03HzfamC4VRhtKT52M8aai/FaGRO1KHRdTDxvEb2w1Se+3Q6/nmJ36Zsz9eCMoArySrAAa7vNCK/bnaOCfhFfwylCAGksIey+6dPWw73PhVE1sPLx9NsntAr2BkucrKE7xDdL9NU6QXOomPQgtF1Y0revBewrJrezazK7mOtxvG4WvrUXH1qGySZjqoHGdPcc6ld/W7SmkV/AAKsV09Xn+/lKMFmxH+SXitauntlkfSvvhNJiZiBpn7AZH13CNrKrZDVc6Mxsh8Kly2bQfZWymdwLFstdB4fmsFd1sDOM2h6sPnapieFWYTWXKzYL4NId7Bpu4lqRSet23t9uQ6tg1GV3b3h0+7hnNiQqkrsb3j1IPu7q2PcBfGtCfuHetJhHrOnp9cxO1sVBaE8gsCeNoN4oJHhDSMtpbR0WEF4ni1hcrU+lsYkDDUw3r40gv2SU9Q5wjWqjDpEqp8VPz7EpSHrfSSira6EFqRqw/9sCdSVnbRr9gnW+2rf/PAuwf/yOj5dp+08vpm9/TnZ99GVfJvHj/5ykW48kVg989S+4dH7//I7OH+B42USCXr7zdGk02PkEYKzPDcDHbw7g7iiAS+cv5V9VLx9+GaDZLRG/UzrPe1A5scKkb2/cU/3x36f3Iyhw+rUPcBxxGVfyBSvpePzYjtj3kV3C7tNbgN35qOzbOisu/l/bnP/RXf3l/tOxvz/+54lZ5n9wKLAEYByOAo0diK8G55Kbnsf+IayAc+MfHz3vBHA4AATKnazPy/Kxj//y89C/yEt//sOvo3/BAfYTDCAwjhXr14ME7QTcBAoERLICOHeUAzZg11u+GJuz9ZGGtt17plOA197u570baF/J9xuj5FU/W9Ox4asXA1ZUUBD342doHy29rLJ6dJMFIAHAFfkYlVjgHHl6U4tC7XPzMqbDQ9NQ7yevPK8kURrWpRjiADcB+ZEZiWeCqAQVttrBKb1R/cYJQJlXRyJyGy9POdb942B5BqZAVEIIio4NK41dROh9N1lQbGg6GNthzDAuJV1qlHfnj0RYvHes8xX+hpznBIj6uAMCO/wqlZlw+sjYTfuW+vIMPgWiMQ6hdmxkJCihKH3iATKmvYRLl0ZK1dX8Rl027J3qCQrW0Ox5yDRsf58uxdv6gFS6xmdVP+emO2Pexmcuoby0K7cSrok0GqqmeaqsZjfKSGeoIcTOB0xDUYGqaZ4q1WylVjsQpVUHE7W1667CPtxFiiR1yttQ4ew0QdV5THgXdKo2Iq0Lm+o+im7kPJkyYmUXMUJ46SyZUsWVXoG12iP3S8mg0OtaJG7TUAtnF1Os2q2GldPp0nZpKZtdifQlIc4w1FkZebEW8sJIrNC+mdRJVMNABuka8A2lk4emy6m2a7gSCAC3mJqwOYB+vlE1zVNDrpVIMzH9sRhIEyu9HLMu2KGu4fdPloV58yPfoYKiHAClXWN7upRETQ27cMstWW+5hABkAtpy0aWa9eWl7qe3kIRrVG0+nzpm7lM2OLOa2YkhRyVwAMx5LyECCFEetARTQwWdl8BWKCVqgLTkoMrWWVdYyXTcW8tk7ErVj2iLUa0FqUm1V8IAYJnfWE8lvWrGZJ9df4IvvTxNdTZYTsyF/R8OI+zsGQkZga5pk5vh2hrKppGWU+VBU7oW9ebPbMwwvFwqqRkDI5OLbALgAopI25oLjXTp3BM5bHREJJ2JsBQ57LcjhD1lYTGC0lxoq+RizZmXXKkxtM+qY5karjiTCszwzfYMjbEAU0r7HEjJGl2LMzoMbxUQv+L2qdfokwVa4RZfyxyhyRUd9DsMGekeZzXSJb0+yF4Y03KLnuE0Ut8UKErZaFCbu8J02dKLlCAzddqeYmoRl/OacRp3fJufdHbTLUfTCWLtu6UYI7We0Coq9WdCqaR9rBZeTouxaY05zO7gCd2Pyr43dO5PP9H/kWmzi3KYWW8CfqzzDvZuN7C6bS0RtntJ0O/U2pLLW4ya9Rtgfe5J6TRa2R5gc1H0ApMSBGxyU6Nar9D9lYoL+uO4PfSvpWxhaiDflSmaLdAAI2M3ehnqOkCCSfp6n2AoB8AYaZR4faphUVICb5+0qf9sUhRxtrdSvRdRKqnHWsGqXTYlXsnmqVSiXCpx7DD5wU1O/VgsKklh3WNdEnb/pC/XxIdr4RsNlfixlk4lFn0HvYarW4Aor0YwwzyyteLDc+8bDZUMXEVpmF+L41hJBACZOrceLwU9twWqb640NhRcahFa62m9c96rwGoXjMzGnHZen6vJcCthG2CykVxLhYkHFDXq7ND9aSAx/fgoPE1/W0WpJO83hgqq9RUmrMCkxAIGJVuP5HaGmNOgvAdPn6njvL7XbriscmXABaJGrLqRNpQm/uzqpjhFsmOZWpACU4KZJA0Ap8yJnFVNOEErKJvT5vyygmBkNuZUvj7VZbgInqBvpUDfwAL6JrRV/BD6GrMxlupHd/IcjPTHPChXTguBcgmCeQohSors4nCpptIo9yOjvWPeHzeMP4MQjBSpVI5pIVAuQeBSW6ulbzXYamAwMkPMz0G5segPjzPOJaSwFkZSEMk2DKzwg4tlqyfxiYOaLziFJDm9AYfjsHwe/T4gN1zS1Cm9WhluC4bq8hlhsqlZs8jaj6keS3HEWU6taLV0tTove9ObCVZ5rxezj54j1xPfb2sHoM072mkF29apVgtieTTu400BEoG1MuOOSotlN+4UfCPrBOGrG62/tCxk5Xe0Ubupt32GPI8nvGzkMt3KlhQzT5HDsV3QddpSibaV7uSse6bitVHFRiOqa9axiOqz0t6v10xAZJmQJGiqO3YsC350i+5PLDewo2OIqvHiqtszaFFhiYsZKOj8lSSqr7JdJMtLi0pvoUo9i3mKpklKXkuw/NmM+zmo7DsbfLMtfqHLKNHUJNvF0c1RLZD8Y0dhMRryVrDGxqlJ31jJLMInnJhilLGRmnsuQb0hMFkDkPeAQvclZaQwub8pUSIZZRVnCLEn1pRQvCvNiqRorZNTiuAlGIlaPuTWxs/gw7/0PV+w05Hzdng4ASKkwKgxnA5KwknMwkzKVizEEg2vA5oQZC2QppVkFWfFr3NPeteHipFXMRiETrsRYNWgETLQMoA8/595RPCbAq9XHnl9m8RmbW+8nXHwkoG3opUvc/z9MxjlfygPXeURXkYrFhEsALwggca87XXY5gyxh4VpAvj/4wQD6k4KfiFbi5S17+WhwHSM8ps4u13goTvxchf/ptrmbGtZ5wn/ubQI+lQw5vyUMFI0/VCsf3LLEhdnbT0P7FGrs4CDs9DNblPSeps6sMJHWJ4wb6y1GWpYd2u9R0sWnmOBzTHOLjDHoBeNVe7b9bsoQ0MadhAPmKzWO8NIRvQ/gte/U6gGHDT1yD/oqCvOMlot0MtjAOg9TUaCHGh0Ph2EmVp7K8nrqGY37X4K6SacoEnufQq55Osr1IpQSO8T+oLv2JXqT1DgPlOO/L2nzZB9pOXPkk8FjkJCHNdvuCi4MoIjvXEwAWMhGGyEC5aSKUzvSIYzVxZ1wJ2KP5SYB2Qrg6crlNxvwnn29FyYeE17Nc2V3bBeg5MMGahcoJ7W5AjF9DMpyBCk1+OzVzDiWD9aIabJ0+ccaqQ5Nr3NBC/sjX/SFPgFGh1YVYtEZ2sST8b94+1SjIPX0+xMBCm7BA8+s9iqxDIJdA7kwuVSUpAkEA4GxSSRzyTKJ6j+2Ujhk+bdMURgqhGWK5nAOn6IGQhyeuvoC0dM2HqU9nC9EjBy5jSm6o3QGnqyj7CMlTEjegueRqFtiNRpFq1ZXztDhHMc53hEZI1huEZGwJGt85w7xZx7XNUpIqdoAatOVbs29CjRqa/DU79iNdwDjXJeBe9IqkgxobolZbyLFrBcOioZLhbR18Qwqdc2pbTmGulGa6ey8yd1WIGRsheA4mRciqd4lqdS0iUrvcJTjbSTgOIojsyleW7JSbc1AzrVjk5pnopsyV5QrId5hBfKlCxL54wVoXDfGOJKfN2zWnEQp+Dkd3FJ317wAL1S9kRL0aVtasc23WypY1Ltanea1c6iOvHdFPp7U3MSLdYqq00p2tzRnjX2TJGRICvn7VZAW6/L2lMNKxjPgVsn6XGd74awuDShHKAXO+MFUGU1myt1Xiql8Dap0tylKt6uufRhRKFkLs3zmYVYPgOEpkDSveIMMyr60+DFoEo5W6fV1s8xpImdjECjP+FodNF3kV0SP/BEqZJn5QUeoRQc22Nd3dBqAr3gqRTkHqqsnK+fMJFACtJOSXFsNpN5xEtFDir5SGMerDefySTvGVh+QstAH78iWpDh6RkL8TqOyF4sVd40izTlo3VFIjBeWnbLPTE/e6aSgVdFlR9h1rMNKzBWVwpSU6yMhVBLJOeqDq5hOma5suSziZNv7XLTnPE620jh6mC7YbkHORqAIGrQAOBr4p2ZO/Ft3C+Kv4yOmLceaxsJVw2rcwi3I0ETNCL6VUWiz3q3bSRcHWw3TOcSHw2C6f5kIROy214qBRmYibeNjtiUW/zekAwk0sUSPaCtSEZPCmu/DmHuGATX+/rBCTJiAXVE6VXXhAZYybeR6CphrTfvBkEqdActoNgLwL7c024j4epgu2EM8G+49MnEe8D/5YnR8crbSHR1sN0wB1YLbhCkTy+ph86LOtMyUWlK44bp8X2KgunBw2F65HBUzJZlkJ/h9HDA87IWpsYCOsUzJHgEXR1sN6xBSf7MGAwEw/3Nj0LIQQhSMsrVGAjX51cqOqc4Yyg4cd0DS8iVKWVAHzNsgobTa7VkHAVXB0theem4zsG6Bdc58FSVeK0zDDWRzEi51TRfN3KakUfSGPSCmz5rsh6KRRQOvFHiRMjQrfiFM/ayZQD3hgRSjIjapnunTQPD6WikvLCzyxKxjfAD4/gtplJ0C7PuPvdcOX8zcU9jB88eguSdewE/rTHD8BWxQq5077pEmDoTxVXbo34eQeOJQ2jcSlEPC5tC0z58lPlqMrmVH3gZ8aUYGaZ1M0VESgNJ+OlzNf2m20bLwTeOXU4yC4w1fgi5dZKMtwR+v/e7Ks3+rcil/B0nVFoVh5klgwKQtJAlp2cajnXhf1DpOcPcJMzoxmpiMV/FFOurs3Chlg6fka1+ytoyAq8kKY6qyO/bFqwvCeb39xfVPsKExJUkYVRFfl/nKN6B+fR9LX0m0ekO+lrAs+WX51EisnjF+iGJNMK6eauz13PY82cac85s4lO1SlSd9Oxos7tWQhJKwUpKDxmeqLdB7nrI3QraZWCXwbrhDGKvRGGVFwH4oEreCRB6mdN6Lq+cyJsTuxC5DXsPMzDOoGwbPVFcmipkm50xfcyMUSl57Ot05AhvR8191lGiPkQgbAIVYTklEXII+OANlXZV7ApVMkpNV+wGWOkXuxl6tQ81QbnN34pif4qDvX11wAY4WW3oRA3YMxfPJCf6TG7vcOXXBqqL8BLxpa8NHf0uZSH6OeyS4hVd5C8sLUW4lZKkyg635+TQQ1IzVGyTy8PGDnVwO+mYi2cOCVh7uSvRNy6DS9th0CUVhwq2UJvqAltSw7FX5RVdU26PYKjaxf4GamHo4t19tCFJJmMp1y/U8HzSDigytm+NEZrqSBM0eMl9VaY13lk1SW+huqo5hFWzVzaepcXQ7ZORBR2IB4ZdMmDoRDIBZ+YirkgOb144leqkcnlsiRiLcIAttbgzl4cewRaUiS5nWSfVzpMCIK0poYSitDsA1N7ZuUsqDZ2ohr10EZCb611Rn6ylGV6y3xgiQodh1/Bi6L1vZH7oMOzaxWLkblyJdwuk2AskwAvTm165wBdXIgGPLdBd/5e1JHr3493N9U9+OoCvth7ZdYC4e1vmYkiZvq6GRTOVCqL+m6l10rR7nkj6XtwWjJ0DfG1SToymh1is9fTsmJV1xa5dDbm6dpVqpF1C0CDbGCU31+qr5/kfLJ79chEeMuFy+qMUzayJK4A3V1ufhNgT/x62zWrK5ztAzjwDRlmBKWbN/vnhelq1dW7wpqqf7PYCJ/TyIMei1Yw3ux6FhFCFuLFCCtm3daorn4iDLW9Uog8Q3lm9a/JDbXCSYFU6eI1IJbQ1J8BvXuaRogQNh/Ge54Eieuyq/o0wN/9rruftoXoUxrFxI9OlCMJ4mohcRXXDbjd9lQTkBsrsaZYn8c5NaL+7b26xKjIR2o8WBiK4i1AYsaHxRTYChPyIRNhLfLNwswtJgH3Msqc5CHub3VzY1wE0gLm3e7o0Oc/o32FlqdyRARfI7AFrG14Fxy1s9FM1JtAcG4u/m1KuJDvCGCV5iCCdJC82MZrnRADjexMRPVQ3C7foXCUB4aPMnmJ52NtM4w/xjTEkScbm4xKypegx8rsra7UOPIXr9MZp9/WRKl1MiwMWCr9V58jUIuIA8K6+jh27weeMCXVAue23z0AGz4MAZ3bRGyrB3aWnS7BQub97qTsYUQvDKEqEq3Dti690/5uv3KTHr+5ffsKnS2RmZzDKJhZvi13crZya0ZU1qAStF9ZqTCRwF2H8fLIMPoafpTcMoHd3wjPfNdRRsLnaIkEiSmeOv5Q5hWOsz0qvR7e6IxfIWl28YrZrR4ZH8mrQQLG/LTOjd2pygGSfxYTUAzFMUTK6YE2evN2/Vjp4LnZrHp1DeWq96WHdMj0O5DTArB3sNOW7KFk/fu9yIoPO4+1KlFVtklmUO9anpmLt7MLBEeup4qVw2Pyw2xTL8EQLPHALa5Na53u4yRqzRd4mhU43fucqG5ufQc7a1UZwrAOO0ITTrfn1Iq4DrQa5ux3uddJ6qoH1oLwm/p7OZPVPT3QxCYBq6kIwlA6Wh27f1qMW3Gpf3WvOzfPIkNpysc3A5vg11amOPGh94xtLVY11ryqvOlMXXvJHAmvIMngdt7Pu/387zuP6GgFPcV+BZjbc4uUj8+vO9r6dHvTFYbTpOLLVVH7Cs2u7HikYgvgb3Rlub+0rTKrEf6Dg5Jh5f9mOAvW7ZxqRRMXllcaL/uxREygZ154/2+2Y6sKSwL6pORnYyI9fOLWzzrzudl+8WmxPBSlybSsCLhyqFpnj3BC+qwufNIH4OVIBtgNG5u78vOKx6as1neHb1So126ammhds5W4h7of3y2J/LlxqEse114w9yV43kIxdKOMaIduUyjY4IzYWNfrrT3EOGVyBzJuzKMdXXyEK138oQlUGctm3RK497bJiukEO1/ckfaqbwAXiMLjZSMIV7EUx5wlHkSo6t1lR6weg5f1yQqjg1pVQpjinfpFb8qsCK/GKZU+uLilwv66lHuG3cmXVqWEdmuGOS52M4IHTvasODnYtG83qoRF0sAyS+6xNJnDnuPY4t92lY7fXHClHEtgp0+HYhmNqbRPq5tPzTeD8uO6715BanLBOrMHcGIPWTCV1aNfG+thvRU7Y4mopOOBMsLvhhk7xwXBtLZGkQWuiChOG1Rxb7rfWrC4jYuj8DaS8tZy14Yncx5mKCnvIFfcoCvg1zLYbr83VvGV0/8nItaVbn60vXGp7X8Ix4DI24Tqv63w/yzWT1buV879j88ns6p36aq8aC4FSd3NXvhoY+TsOVy20cil8mxLoh61RXJIa7K0vG2ATQq+X3bz43wNU4DkkdQrFmaB4gogZDgZvptg5OgAAzgA/EMrOUftk63UAslj7R6cy3N2qwe3Exx+LVSKAFS8Z6VVe/5Tj0ai6vjFrgS2XcxbERAHnVWsfKKSlrki0rUqvUVNm6f8b5BH8+z+4v3903d3B6DyTYusddT8SqKmQ0cQFAHDiXxNhM9RWsSKQUG9AClivg+Pfv0K/P0VBgFxjjazvcWALDiN3JDV0BjBJazr38tTz8iLNFasuqcw+MIVf3OcqIcs/nMo5WT7ltSN/MlkKJJzEZM3Mdm6qVGdaMJJAEm5H62vjEgjYr4+3j46Y85XS/3BJC25i2HRLfV1voMeaQJ1Hm/E9forydVQTlGfE1qm6747YXYvk3kE7d7NgJB4d2jysa9bMyWUDnDofOWVGaExBZEle1pd1n+C1+9SaJZgRXCSLlWD2XasMs5OJY6wCwLCRuh0pNb6jDgmKUwHmmkPf1cyL0Ccre4ys1qH2ALtrFk8Hbe6A+AsBCXZ7IJ6IzN309HrgSQq30ufkP8Gua6+Zx0mTDoMxNQC4lcNFA79gBUywXker6fkU57ewQteUqv5dVF/aW+2kMY0i2KaLkQfZT7NqiMmmXpzGbbG4mZDFZ9JJ2bo4aI3AmN4DRNOAeZzjsVpWD47cxk7rw1TcbxTCLQmlqSW5CHQcoLu7Ay5lrVO/PZ22FIAw9ltyG1BgRWmOskbKpmaDrxzw8Bnm29eaIR14bDtOo1kCLR6UVSqsLr0TeIpbLGwKIa4YBneRSeNOUds/bQfbnrqTGczzerQ1TWLOSFq4kavPAQF6cwtsdz5/1HJNJ9WpmnlbGLai1qu7n1ski61qrEcSSYN7+bd04x9TIzSbVp0vmekEQ8NQQlMYHNQua12Q0z6VYHtHo54LBQxkekvy85B1bKPtdjozarn2jn9U8FdHFwCMeWs0k5l/EjZTJjsRetmO/qjzqhDANVI0WoVW3AWj4kMzv5v5J1+R3JruvE7d8rPdX20yR03PU2/tGcdtInz66yvL70+R5cFIiOGIQ0e+w1zy2B9k1ymoq4p/Kg0wOFMbiF/b147w95/NvbX96DyzE7RfNArg4tQ4AFbeQH2gBjHdOakCpM053en8Jh5Zr73qfZlG1GGSXtw5N2QvNGHOGe/zd8sKlXfKdMeWXi8pSiR8MJDdspMhtJI4guZPuoauFDPoYJ27CU4lJuYKbbqpp6k7vboFDhXmc5IHPILSRikvI4CKPbIc3JuvQ5g2CN9hIdJ9igB3jA4T/VMiKff0ZrZWN1yQVRNCca66YtNB20qSmfDUqUqanl3GFNrY3QOvHvZLAJOxPBrVRIZdfNpWWpXJQZxGS1QKGijFTAjZYAluAvVmM76fQ+p6FrB1ISqPazR7vyygwjBIVjXcWGBofO8hli1J0/dMvYpngYtbA7EaCg7iLlMjMktzez6NraYyNMqgw8FnTxHEBc3neLcaNFv6FbU6F2goOBUGeq4GjRhEDzLcHZYhkDfxdZOoqQZSXNN6y/0GqW4VUsYeRZuuZlgcly6WpqY5DrUapBExdiXLsg388HvOL3YpdswsOcOXPal4feyljqatCBdg3liztU4uzD29IEFzTNsccliBH09aVCzz+9aWVnmlSuLsdABIs7wHfvfzlgaltEzxWeqDqKE39sA1ZfGaI1wdZasK1eYvim/rLUqFO/w+bvUdAhLEaurzFCT/pUbInfu8J/Fp6P8i6XWrCBfNiL5RqsZ/gxbqqFsQ7PQAPrzxV/gFQwX1ZNpQ20BwSFrMMZK4s+npSJ4P9PGizemFOR5ILCF0945okr6rS8khHi1cGvEqWnhdLNKRBaFpu+C0e56SGL+0op2mabrk0bnxqbNaZFlwkuJzcD9UIT2oteySzsuUxWbYLOvHFD7E3Yl6zyixVLy+TmqJoMd3F7pCFK+aqHI7DfiQgcEtoqwLppScANOqB85136oxqz44RxUdQW0O2KLjE0jGGmhnlSgg8aYEipy5bxwNn/MjmrR5B1FBui+sp71jYazcI6nSikSthKPEpfoXmSx0Wy8Kb8fF5qUswibQK6H7DD7D44ostMNrh87D7Qs6Guxe7Acx+jdFcATKWI5pPqLMp+3KcFqT9SU0DxFIQhGFCdWuKFj4hfporS+xQLxiqWtz6c+iI77vkIxXu5M6lTnEvWagw6Nh1POegGBCHXVfiR13KvFyW7NfuVVskBqzHohMkG0DZeRcCV8+hnwRIy8pIqS+TokJbFINNZx91TNfZTtObf+c0/DufPdZ2SqL7HDTu29xLXR8BIHm4tCXJrespZksLEyVs5IgyN1ynv3h4XGazkS+bG9SKWfWZ4TBWPdc7aNljTyjOQEqr1jQXZUC9dVJmpU72YB4jRhnsMvjQXToXw6paq/MZSceiXRGkuYTP2l2BvB6FugmNM9m5fRaw4N5jjmoE0e4Rm1i8d7ZHYOTGGyn7YKS4GZLTAWBSyYqqKLvKq64Zd6TnZ/dcjr3s63WBSWWiCLOL6AupDH7aOfUVXwxySw8BRO53lkxSaSowF82vEmZ9VET7FeKcfTS39XMmC2KpqvzHU1AxauUvNe8T8nhr2vrAJ6WIlsZCKtuS2pH7+k2VzSA7JCCpUDi2T9Y5nrhpwrmlH0WpEnimBJ2ehpO1o1cjPaMeZGTdxh3AF6lnhlV78uKKeGu5MiR+pAN0cETRkeXalVkyzMa9dKc0VzlUDTxWYEJs3dgMZiwwqjZUg25zY75IQFUuw2ZCo81Hg5/1XBzBD+AwROdjT3AIaRxDo60WFgUr+i0Z4ZkH3etosWxhhun8pnjWYjAgLzzBvQHQdIcUWsEFKAOWgXLUw3xBoV3+LbwwthzCNYZAFDiqEhmZK99PrQVNF9iwN4iqHcO68r6hN6sY4JtMpMU97ZYpVn4ioAYk3p/X91lA+KEXo63dDsCe3ubJZr5qpSyYVD3O3eEdwBRbYzQdgSPdCd9hFq8y92mLvigYT2nUZ18ZEAM+OybWcYaumZd5IIzGq1RX1MnbLcMRrob2nFUdf7OdSIWWMBbGpOwfsgxnkOg+A41fdFk6/V4GR/3VGLA2linLn2zoBOliykp2gyDckbgAowINVDNZmx4MhfT5PJr4OVZX+41jZ+jKegkrVgkP6pPfK3ICWOWGG6AUl70+aPu7MjyuNhVgeFe/8fAjSxuBK4qErzZ5zFFfP1VnPknrNgUgIPmAL/pEjmQHV3Fh0wAcpZJ8/wzJnx6cRYcyZOzp9v52H8ZvjQVt8IGDXmO0yBMzY44V3o+yGQvqgbkxe8RuLX/amz6313VurNJN4djv/9ENkFE9jfJd6TnvFjxIlHa5S3MoAbCHLpndf3zmHzdnAtKJbU4mYLJPpZ63Rc0deu9vsxNxnorbu/SdbvD55xB/eroNOfMNwFkL8o0ifQtaZ3u/vaIonI6FkUqQ4s1MPwgg6veLinoqDmvqVnNYr7wfTy/fHn0T/3T/Xa9TMMfqXn1voOKWuWytRVTTfGm5iPmQ+VczSBrfdsi1FJh6IvnRJZZ+n9y1vM6NuPJ3vLqB7brZqcQI6wTaEKQaZmeSss6xV97mJDP5dcNclxhsdmfsom2AYKSgRlghgZZbjDJ42egcb78dei6XZGlEsE7B0NelKmEi/R7oHHR/1UJSkcdxCmXGdIUJmRbuOA6XCGQQ+YJAfYDQ6ocJGbSUtArpyiBhpMTmkPUnGdWsr4woCqX/F78WU77v69DvcROyFqpBDoapJZraJwZu/rn/aQ8WFyLhrHoqfHi0WJwqMfCBLFtNHEstIK9Fab+k7nicgygSRWpIvX7lfRgW4u9sW//SHg2btUCXTS2WdoUN8bpAAEtwfMsC53pl3hwNtbOGDxZxQsDRGooIKBxjNHFzvrrxmnmMzGl/aR5wJiW36a+BekO0aXKwt8P4DrBDW2cXjwrpRqzgzHXpr3tNKq2yBofOlVvvMLSplBMfFfdc1juSjYj8KnqcvopweKGwtGm3WuZqhR6BjT9n9dTMw00lnYK1ghPHCddz1q6eklrZbZcbq20ctJcCxUe6QsqH+nIX54yDEgenc7PpB/i4NjpOBygPo1Fxgf1vpXgBXcrFuZP+VkPp7RPn/6Pr9e+8CvPlUqC1W3mFLBUzjPYzGfsw1wWxJCe3mx9fA/Yqf97NBX3amZVRVXXSMXbUDF11oQ4AWQWjrqwWIiS7Xksur3eHhE7G4w47qiuy/Ko/h8N2r6PRS6YT37+XJULVatpkutZW8ILhxWg0POTJq29eD3ge5flYT1nKBvtGIuNaMYD1G2ufQegve4mbA/akgduu+Bq+YE1MPnL9sqI96NM6sKiUIB4RMjOh81/kADRFXV9+/4MDb/59fNpGsxlaYi+OepkcaCP541GcUyTT5l/AJnG6whYbDdMVZlIvOmdV2W+yE4158GvKpw1KqSjnZ/uSL85KbpzbtfT0/lJXaDaqkiE2//QnHdLOs8Y58/rIs+CbguNL0ActFvDyuzwbNOb5tAe7DyO5haUBNnB9UILs3Le3eMsOHTkPIGSv45Xvkw5IQUUmIDRtlukDHzy4WORQ9Z+Cerg66E27HrqhetkR5cyG8tignCR5QqgsypKShdg0W0cIFE0EM2qV4JXkwFUa6DxpmnFBU+Z2Pb24hQM0miN55jMvqpWd8S31ueXgv8NtyR1C9I1ALfNklFo5naW98JBFBE23loa+PaOnJD70QYzkqvjEXTG07tzoKGi+DzJnDKmDCXdFvURnXBNMrjxosB3pZViFXc7TafjdDlcFOt7q7ZTbWL1r/zfczW8Uu1Torp+oOPJnwsqXRsHGUYeMvotXiKHge/9z4otiW16WtWAtq0aWa1sIcJXCFOp5QZKwOIVEMrkQzn5CR7GA+JmngG8K+t/bHbr1rnJ6YE7MfW0hLKuMolY7TGMRj46vE7/PPVlD4xn/JXn3HA4POmKeMcFX36zDdHOaWS54hAwI4Mtpr+TucEkvPEMmo7oEAgRK7ACaCmwnUh5Pt/hp+gutd0huEADMQkYYvLq47wBjDNXwbswVr3Gdf7ijkiSWs7iKgpKDbZ5WFrTNF/KYQ9U97jLV3L1aN3PolZJSMIogMksIs9d5jK9cGqvyazdF3BB4TuqAJs0cO+Ey6vNqDVt56k8I6VDHFnKQ1VCsndjA8Q7HQDu0Q1B47hkcidzayKWXbNp+2VotTvR9gY0UIXzsfamBHbpOCzPNBd/6q6e9NjvuNKgNrzjiBQ/9dbO+DQ9WdMBG8qSY+WDHR7Nl1ec1l0goTGYQa6Wdo90ey5AwIH0CZP06d4Ptl2Ze6q8CdMyhG/KAj0XZHWUm0fqOTj1qawoiDfoBhRDFFZtPZm5yOEr5bIyxVqMt6IMiROPDicWwwQSYFjYPzJrFc9ltNuApn9QI2hMghc1s0aw2eIq7FCadOHcCo7Bhp3G4Gs40lwP5QKc/GbQnqB4h2qH2zaLCKtXLKCgHvc97Bv/oydzWcLg6aErntY7Pt1BLLNQayry9qtQpbicm6WWrAsIkyoDBWXVL0uSMB08t8Go6xtG7cOoBvcmO2N5Sonnw2+3cN/r4z/U82ute2T2cqTcBO7mLxPBeaXW6SEfcHCGvachGLV+Tu/yfEmRZm6Oyjkt/dg2h6rmuuB+i45+pToKRp0m4QBsfb/p3r4+7ufjOOgv5ktdJipVlASXdhlBZmdLPGCq8PXOyKvmFmF9ELS0u2qgkopQJRFJUBUGC0n8uYWdTRQ5JZK6LlQrE+mTCl3hP9jtRKGS7RL6pUhLoTPVuF02wOODl/kSqOSrOmDbvI5XijXdFEk33npUhblPuPFsAJXqoJ0DB3tor5d5lDgFSgEEVH5RluyT7sXD7kF8ge/w4g2y8bFRfs/6O1CCbXmeappGnDv2SBgQPjZU5ngHJESTpikWA4VLJlOHX+APT2XLDnnQAZEqwPq6EPed6dwZuO2hrvmLP0+9TFIX/8fLq8ZP8R/Xx+sCROYzj8xoRn0pHYyv1GxmE6uroFuLQzSN1XI3HCk6NRLRxBKCg/wy9LVoi0BNYkbHpfbxnxw4nTtVARDWLNR0bCvVDurAhWdy5+hI8c/jVKyWv1/yDSm2j2NhXQfHT99BtmiPh1ze0RWKPR+XG07f44etCPcFuVacDu6ObYISVPFsiIPmv7ofbU7KH8cyRz3ekuHw373glTtA6mvftcNWsDaiBUY4qnd6N2hGbYKr3NVtHBwfieNLmWWNTxflV0EoiSTSX2HQtcC2QdmyrwCj9piXKb7NdajxI9yyTxtKVD+tCiBQf4uGpBi1+sJQRDSnv4ritVbcrxkk5wrb1kNszX6M6po6S73iSAZA02EddDLNKRwTVEffLItEVaHrCg0si2C4fPpNzqgxwASA2NbN4/d7ihSnDcpDWfrPKWyOM3Uq0HFu2CK+LZbmoFAWYCtBrDVdKlJzy+jfoQOT9y6xML4xRUlRwMOrf/XroW46g50U0dxpGUxfI+ZrkAvx8/Rktplvmqu91qUU3iyoxsxQ93njQORtFpvgNiUgnnFQzjb9WlwFPI2v2DdgCo5N1+U9uiY9Z2dG44Uy14ZOwHjHSJz62uBwW7uo/ERs2zdMOIj6BI2aBi6L9dAH+wp2C5c4DeVkUt3vkUJm97nvEOlJhBRjyrODgAHpRLO/qoANPAWBnA7h+FTdedDBhjk6TGVF7pb92s1dlQomJUUUPDUO2w9h1dog1Vet6G8CE866z8L9OhwemZ8rhK8iBux8fdI9Yl7IEBo/BwqccrkFPFQ2aIL7lwFlXM2xfdZ8t4ODKGRBITqtpxe9mVbXMgA17YzCqReL5rBRS58/SiFOi2cGwPtnLmgJZWM96lduxHpRRzbVX0ZZUQLICSjIRaaGOvhS/CshJ1wlN5d7wqDsRyKRDxNhj0O2i4femlXtC9oHBAigTUBDUDSNOgKtfl2hn/ulqYkvaDjS2DiLRuckHQKpTjk+wZHnYcZj5QiVB3t1vV93LrbC243kh/wCaL7JyWcPrh9sBz+uCqHT+G71BkFufLe1n7jJ+fN4FfHGwOXM1+8H8boJfsVCSSkX50OWsEnxoCbDbi7+COeLYBVALVmUFvCBCrdqTeTlTuqy4rOZv/q1x06SFbfdpWXOW9HqRK10geMEY2U8orhCGKtr4YtWhImdiWXLEpGBw7bodNFtAquXm+/iLEWiGg+58uixGX10+nrLwt6IbLuCxfecOjuCr2o70diy0GVXgpZx9CmT6vyUYOjNPJ2947Oy7e61XwXWyseuHpoB5Kzk7tX2yNEtk7giFRvvNQeWeNYNFWdcsG/A74Uj4tX9KBio96y0WApbuwti3rVfv+/SZVdfWwKGGYvB6ET0nEp9mKNnimHVF561OSt7jkR4Nb181+Z09sxK22/qUD0ksGOwTrsgGBhtivM0iEUog+POER58XhXAkFzTyJ9SOy7jJynuE0rUALvCor9Fm4dDNrutSCK3ZPBdTGO6+RSAjPXuA/Dz4pMj3ezpbOiqGXbrux2yZxkY2SXQykXCyjhr60L5WHNk6mdwGFoZMA2ywtt3SolsQvllhudMLzLd+NUjv7pzSqK8jpojzJ4+3+xNWeQpI8EHcEL91lQZheHrUOtUZn22zN/kLPdjgvvUbCm9gRnb1XZ5SEzD1Qmb1wHCzF+jj6wMfaxGkPEg0KyDTcyaWyvWMvQkfTSc1faGRQ1nzdOJRAzGnMeYy7MZOokde4iP5KRECO83T69zb44+jd8RaZcedPR+EIXyjPLU/QmJ2S0C9EjnwQotnC0tDHurdH6cH9ixWr/TUIgLmhFZPGSE8LVh495535OUoadjfYoa0+63yu0OcUIWud8KZ4GfMmKwecQ1HvOsYystsOYy5OYyUVn7SGPJRgMiXeCfuSO5Juzpsv6mnwYgy+qu8NKoGVVVFEFTMeT8HQ8iLly3xiybs9kCKL5KqTCgjPOJewxwYiMa65oVI+tp2jTV9/Zwgu6VbGwzWHFtDch97tGSJ/KOa+9qvsUiCUuXrheGrHgGlENOhava3CEHQQdzHtU7a3y9WURCp8CadTaQUBI9+VgE8Pe329wtOBealNHnJGk1V/s4RvAxm7FKb3cZ1gL5UPB7acU5Aq3tSad4ofPPXJQIElWaGNHFCqLvedbIssR1TAdUBpqCU1HPggfLWdQwnO1anJ0DRoXYupiH+vD5RfnzGnqTt8aTNpL+oqRBrKfLVpYqB+1lw4iyPzTwougQUzbHTGONkMkVh/CuT908dlbXx+ZY5oItzY4d2DqR4o++CdNOPw2d7cZSESyxc0VUClpk84w0ACNOql4b94hEtFnuRvtenIkSA5I/bx2Za1xNDoCGAHv5BWc2OYaYD37D3CKiR8nDv14sSraMp4v6rqnKvIvrMuH1g3KhOA9wE6iAfJFPLQ46Bfx5HmEQgunZydryMdWGhVFNDjd5vx60ZyTYDMZg+kJVB2TjYGqk5Oka8tNxS+RMdH20IdDyOrUkLiISWrHzVNwehJOt7suxolrfod7kGYNdsiJhXD2oU8/93Jk7LK100+R9T0JbBEhqwB5ZKEu8971Gp5fAuRoemKpW1lfdLCVklCIrxbwq8Lev4LXe71XmmzjdtCIHRHqgPwuDhC8ZsZw7zDPAtbx2ljP15cbP3cY8jZTtr9NJiMdaj2dG8HAbpVSPeRagNWZ65snC0wC6vb9q648Gk2TZZJ19+up55pvdbOgqaeQkZJYOT+udaJu+ycjPKNlFVdlhFucAGO68paw+BFUpwdC1n4HfYQuJ8bLM04hKb7DYANX81orVZTOXkRet203BjK+0gaxpeIASKnH4Jou48Nh+EAxjY3K3fIgvfJP7LSJuyPi5+SzQrF41uwTEeKwtosjTuen6gF6uAjLToS9AhmyK+xKMH1+b89NRwfAH+hnU01DTT4Npcg9qnatCeZWqQcM9s8t7lRLwRaqgec7SFXNV+eYW3jZRuQYreBFXzS3zpgvycHuBhKzMIXVjbMWF0xrUBuPXsk3xfGFtUPv7VzxLAGc4K5c5gW0H5nhzYkF29HZ1kZ/WpcirSUEwugwBPCsegBDIdBNNJ5wpRpphxMAOcaGjBNv0T6DUpXtdfCq/ESPXT+dhTN60/jzTD5vTZRxTtsBfN55wnW9iBlmM6ZIPEL0r02qrj7tR3PRTmbiZaddd2pGOL5hXoSXukdnNPsR2O4Ye2Qnxea+XoFBtEdaY+8cmfU/pXMRuHcsj9CLqJ44rzvx9fMuK4/Utq7dvtyuL/9+AXly9fX3/+vx0fb29zpO52Auj39hxpxB+pQ9Se1KNbMDdjGUMZ1yUGrcotEPkJDsJYDIm+ukLLIRVJceYfYCOKC+LIyDfISWi4p6AGnc4kGnTSh3c7mW7fJKIMJojIl01yaLQXbmu/S8NYLiyikCWxpAXM7rgdT+zuCd5H8uTagzp3wUMHbeGcxhFoGZtTLouFDyri6TLhMD5ivNjYAth5J6Lyebm2c+zhXWxODbyKLBVq2YmQmFjxW27aBqtrkv9HCFMNdZwNP9rhSkeirgp06evkvJlIbSgedlXJaHgkNAtto1WHeL38FVWBQVu8bFdOuiDGMUOl0+1G1QFRcL0Gqxm9VwA4LySdoQxHEm4WtpAIaN6RtU8J2q+PlVI7h2cZqBayErrLnIGRu8VU7eQt/uKkXgmJ8mNhUMRJxSK5oMCCT80gO0EvZ60glK5CTdgWp0j8jkuwPQUjTgEZxfLZJRhlD29rccDJdVTqmo2DZ25qk7euNEqkR6MgzOaeyZ10qeqkDTqTApR+NBkMhP2jiy1uSmFVklBApuv6wY+cwE52WUefLUoJ1RwMIukQCGIOKdqg913T2NlGAYDKujDMZVkoTkemzhjptJwxqe7GknNWbGpwui2rtLdoZJmnJpb+WJI/LSTCcb6HWlXvs9KpRrWUJXC8xKrxfubtXNYkwKTDzmP/R/Skfb6Qom8Ay4/Vl+mt00FE50eiaa/aROAwqvq/M6+uPcHNN8O3VhpIO+uu4SBZ+vegxERED4+H4XNTA24S9cVF1fEqXMdm3u+mXUWWySEAkUd2ayTdiYzqhbW+XL/j7uB967f57/uvbxxYe7n/OfBV2+JzSvS8bXAVrY1r+xaoez1B0d/KKZ7kGMhOqZ6k7lMCHMDwQF/fUewZHREjoNFlvs+Iku/Yd4P58awNMD2nxcPt5v0Vn+Yj2tFBCVh9wfpybEiNmt1o4HCwwb88jrTCd+Hl1q8LggYz/LeJsnHzYJ/z5E8r6mVcp7jhHwuGyRHUSHiU0AR4+4SDj/p4tX14zCmMnjSnsTuXe1mzMznVoEGoH4/9GCvliVJhRGQKGGuQASAyP+ei6TXTXKUAByuMT4PWeAY+F7w0OVyihMMBulwSnSS5mzQeFKnbkzHmM9Lu9an89YGY1QT5giTphU9SFTGmXFuvzZGLwzWaMh8xpYAend0XCFGCJfO5vluPtZ0ZQDUFDnDbGFAyYJBRmEG7kBvtiEIePvhCPTyHNpwdRf85+H+4oKO92d0ufJ1ux1uc4xd5Cql/izjP2p/eCxIjcUfXqbnD31vfz0oYQ7/B/Vr/hI/VxI0XxhvtnXKPg73/6LpdJlGOrp1Ev6P22fo0T5rv8l07wbdPSuLn3uXFSb/BRb4+G2Kd4+MfDPoyRN6/KK6n+PrPC5efBj6f/mRpa/2v83dx/mH4/vhbfvydfinkn/Cvl6i2V2K91sz8pZvYDvyZ/Tx9v+npjs4FffjO3+8mP4vt7N94YymgOL6VpZ8/p7nuvanUaOamtjNEJomEwgYDABvn3bw/85n8L7WY3Df+vNB/eki0lBfOf/3wtzszPTkxHh2bDSTjoxEhuPRcCgY8Pu8godzORgrRWJGtVIqEfJZCraCMe9Fo1H/42/TNAHFdizaw+Am7uPBUZ+tVItuLfPTKoNmOsfd1aTpwJ5D0xRiwNzy1RJ3nSoQ/7z8tcQ1jC0e2urLaZX+35n7gEw3hWuasVBODThUhg8QT7aKAGh0sm7zwTOS51fPX16+QPyb2jpL4kV4Nn+fb63OWl5XjAYSlWS3Zbr9njLoPHlTnFkDCcAB2UIzh3T46tPwxoAlSeIch67F8ASsmYufXU2l6RduwPkNS6IAe+dpSkJjfaFBDkQzlw7BI6Sr+18Bfd2arskzr1SZWAu7chE8T0FwVbeIRQkC78egQRauB9FrUpZnBks4t6kHc1mrDr9+6Mitgv5wWiboMwZHt30ge3kKArNae9aKwcyDw6tEVbefwtdeCUKxdNHWLpgdH3CNd38hVZ3VzEhk6jqdAspbIjLkrvZ85ki0SCdUzRwT0GC082cHBNKabFZy0+BtzC6ha6N6MSemdiShvsHn7EVjzsEORwF1OGhLVJ/SuL9Kvskyj7MrTdl7GRXWJztBL5GOpar43Aq5Bs0wNXvDNnkb69KYpTnLlcO07iaCJL04YFHYjUMeaHxIXOQMRorymklXes7ASLIxZFpzR+di0ltBOiDCtgNI6BY3LBMrndadYUGu6xjwXEsmy8djvsXvN8k9iMwwRfsweXKyN8/8BTfebvC3pJLHS5mLHCZf1NlQRkLz0g07cns9eFaQIZhvohKNdnJe7KOGybrlvAZYqCPNsWMJN4byMIt0mKHE5uWwye8iXGy7WCNm3LvCyvSlgYZUI05WkMi9ODjaeq3auJ8nq8s22kn6SHv9rhypTmS1KWU+MtC5NWa7+oj04A0aNM8BoiwY6ug/HzbxUv6Ck5HJBHLUg7+k+g+Or7+cYTEq/zaUuiHK58xi+gLZ8+b0X3a0hWBRUS8T2D2nbyeAx8JaFnkUACtwIKGj5KV2etzfknSlYKDCxQYIx0WaF1bEWBfv8umP46P2w8f789Np1NVQvY5N+Eckd8j4+aEvP58O+N+MuM5/Di+83NHH//1o3n/479+3G6/O+qTq9/D3KM5XbMgTZsweCyCsQedyRiTIHnjGpBn6LA5gplU0PjyDqb2JAH9Vrz9aRMLeTgZmhUfEZVd8MlETBiZswyDCiMMbBjHIm2Cs26OU6b4wRIBiZHuP+yY0EyNpkqvWuLMBwkpkjlT+R8ueSSyJYltwrMr4HuYgKgD7mLELkD2u34aMAoDRqdKcny1W3vWljsRRkwABXoz1qoimmSmTcoXfZpicPIE6SX8V0L4o4vzLizZuu2/hK6TFqVdvsir/4C3W65/9ELfuH4fc4lraDXRhB/XaatcOEqABXo51lwo1qMJeOTc81J+8DwUAHZk3PbGn38Zt9HDp73dvX5xtN+3HH94e99Ns/tv8F2y52uqKatjwnq9Tmfnb1zJ/83rm6++av91sSdOJhelmzqj3Wc/2oOvAKJL918+Pj7o38/7yuF0Oo/5n42+iZypao86w9lmy7HfrIEEunqvqSE8ajzlXXhA4V+OpegzXwpBge/J8pXOKTCNlDlcsFCgUzf2xgxj4xn+AxDj/j+6Ly6LdLx45yhgtrgno2Mdr28va/q/VZDZZns9KKcrf2ht8/7b6nQCEoCHxjhmew5Lmls14tDYc6XSJLqdcfuvda+vy33r36vr/eg/qWhVPrd9mg2GZjMFAo4tsjbYZ0/wjqUQsGg7afDafwLNupx22wlaaIgnMKDPJTAadVq1SMKQMqVjI53FYmdpdu+t+WpdpcK1r66oMPkdRPPYiM9eVbf8FPO6XfR2HtoqFRTZfXDQ8v7rfFjSbSpCAp2J2So6ac7787OHMmy0dby0nTlLQzV8oVGlaENqVr9QRWjhSPVttb72b/D1gqHMWK5E+st6LQdWCowGNX8o5CjOj8oIu5GKGT/yHq4YeNKHRk5mVBH8pSYY6lyQoE6Z3aT5IU4UoxALHTrIXhUwZlz0wibbuuSZS+XCwvlBP6znEyK3UAKABmMP2vLGXHi7owc2cZoPX0ORDbxfuh+eX9sjBoVtNubFEy5uc2EShAPYY7mAmOS07P1sOd+m2XNZ35VzNlFiokNMPDhTzJKY6CwGvNKcnzxPoAyFp8SuOauITvpZqMVEluG8pkF6+DR2i6L74MVgdJIL6j5MnLCU4EpBsh3cr5iTEgP0rR1NmrnV5vD/jx31cdov7Bg3DWdF14qFt7vLw7mCPBT7vdPQwVm/98jKFaFQm/HkgqAKceiAV4riIMxIEYjjYpyyilJq0lSyPajIWBcP7DQoMhI5vphzFCBqCtwityPuPfWYu3zKEpCtSsmRCtrWLwht6STxbNRUwa6TwOfP3vD+9sQyYDXp5YiEc1VncEmVDOyq6X91PaAEWcx2iJAcn4WwWBlKoV9RXoEIGkM25iOPkP5JbCO6xeLmoMFPhJci5BiFywhPGP36v1fjTCSl9Ay8weoSzMBoQKoIqaPJov6tWhAlBwYx9P5pJMfTDWBqVJcvbAZ6+tmKcz0r8wygnF3ogiJM6WABHnQOv0ZhLLXrFUWa3JwiGJmYb6Kq9NXEMoAv4Wgk6Hzge6O0KMiG1IbSK5M2KSujEAJo9KY0Na/v7zqjTdfIaXzfXojd1mMkRBEjtQHM10+tcFCj3W74j/JvP2EtzQTYQnlROdVGOhWm10CD6iezGz7ufvcvSUmuqDPPRjxNZhgzhZJ8oW+hlyFF1UODYywfdsMb0kS3aou/H+BWW+9fYNBH+gOd+cX+pC95YZIWH3E2CC25B8anbafxpgoSVTFkIw5rv7FTDq6xSLHt6QnLv9vHFi7nR1olo89Tv8mWcJOw6o0LWq/FKXNxeIOqtIInCpUxVflSk40JYQi0qsAKVgRonS3xJR7jUOQcET0MTNx0K90DIUwenostbludqEKEWlJCp6peetVmqrWs+ZUyGBWhyR68NzSM6EbNg0pbCjmqyNPJQYFZ7CjSJ4qh4cWw5zUXo38/Lbx/NZLDMkddoARQL/qOyiOm3J3ziSA3vooAKz/Qub1pmcYa9HzL5a/iVuy9WlwJbpEmuLbCYggNQ1Opcm1I6LwmpMoyBWG3Pok7yjYba8PepiTS6m6ZMs3mLwUgAFuxXVQRk4YOyz1NYIxgNF28OWB7S75B8X5SCJPcMZHmQclvW0X/KhSxJay9iRIX+RNmkL9da4TqgJGzelxyvmYM9dE2RC4Zzc+CKp1NmsCk5+o3KyftFM34IrrSYivhouTnddwIy4TZ1mSaM/sFJZti23Jg51T66Y6Nawkwz8X6swSjE7vFzIqhaql7fYrXo58u6kcu6fjj8A/AwbDvbHE7jyai6SiWoB97BW912/C96w9ESy/h3IgBViT+QWVZVOSHCv0WtzWyroq02F676E67UYgqho6XJFIh3A0IxZTgL8paQvUxsLql8LTk+l/dCrAfZUfRFfCRAocQZnE9An1igk+6OxsXLCjG32RqmaEXSlcWcpQZuCal3aoKTKwvMiK+4zpvHv39l+P3plbaYQACrtGMXgw8+gHK5r4Y7Ujp6V7SRp7k89I5UVVEEOEiBu6s4dVmOhYnUPwLPJoVhNsB1jilieAgNZzbNgC/bp1SAZi86XSNPODopy2GjGErex23b4Scf2D9pIGryaQYllKNSVUfW8pGZDXdyqQc2lNyHcsJVPajSyGXasES9/nDCI0+iV3umDQWGtvmvEsJwmSUWBBw2alTofc1N8jRFA7V2WNTcjzm/ZeKsLw0xMkG3GDJ+kfsp8szGhZEtJu+j2UJYBTCURitVHilnd4ddkBCKxU6iHpSFZemXuAQIuC72qKVTPpY9KvLsh6Kj8X7oqNXIoEUo0RP3dRfAfGI1Eb1TiWZpSuusFvzPYJlrDSYX8fL1XEvw2CNqTNmonc2F8ALc2o70KLZBIKw60taqZ7jyueb7PWWUpjJAaVsKzZbF7lKxsPZRPTJ2HBpFqglTKpmaJ3wJR4nfCcdsTLpoiCaO7h6U4WBTMVEOP4FN4zqTd6yJeM081PVinIsZswIeVcTPBz6z2kRdoZNTJ1nPqQb3ni9mErK39ESZ7Q+XZw2UpMS2l/uesiqLWcwixMhjuUxsNJO9Ne6ooF4NjhlejnQlNlwO/WvQDGQJT8tWwx5+UoyNtkSzNnvngDexBCaslD+3utu8jgNBZzQwB0NCGi/APtMX00GezlxgDYdX2UcTASRHNT3aQjCaKW2jplNA4RvUQgiVUV5isK2c0Ql0eLYO/zqQDD3tbM5er364p/VOXg7G8Y8XF0Yw0/S9vX0pBn7VGJTqI6Eon2N7e2I3iB0wjyWyGAE+GVsJhTyq0sBrM4HWuYEpbybuxUbN0lpSw4rw8qG2ror3xitzqqj2UFKyT8a0ShOfqeP3kIPDjcgb6PFkktlqvGsWii+PQUqPZOAWns7TREUapFlepYE+v913G0EfQCagS2qTgYnTbbdrF1gFZi1vcbEXQN9KIcXZ74fmdAwD11Q35QUS3N04JRJxntcXDIYbOSpR1WrgpABtziADzS4Np/BWtSuLqAHWJTCcZ0/rXXC3ntBMb9fq6qDBHiIZKsksTUHm/MK0JtZlR5iKPA6nCfAn8Mw9xzTVl1eVYEv3bJFIGqe+J/xpFsu9EfUVwvrDbwx79hvWozW1EKxEJBYcgeRRKZVnY9hxGDrHRx1p8mGfMuueKe8vf0h1wOzwzC9PUT4ns6u2gljECx0RPLSZWYQzQxhg8alA9N5iBxjaXCB4yrkjlfAM01FekU+zEFQvIdQSBdkosj376ha0hZVYhI1v2Hb0QrXewq2yJHYC2EV5kWrMeDswI/BshG2aEfolsGrc3UiTzZ2+VKSo+8AUIoDE3ZxKBjj9diLxmacryItWtsooKW4OWxlrn67i41zuNEVPVpOW1ua92M/T0nR7l0g4AOmH+8gcwqY7MZyhy6mFJSzgZW32dZsDZ8pk6ZaPwdZ/lPZ2gRojMBCG1EAhUjX7AGKzVbfpyOF455J85GVnN40R4Ri6dyVXFhK5pwAoTCHMJlxe8yRAw8nWK/AqWPTjBm0xhZpQTxiSs/iOTZ0m0awFOQ6WkJq1NvOjUuRzhGeIX1nCOo45yQrT8m1R66qs+9yDP0jbtUXuZcqcokoF++utCS+OtZSyn+klsqIGtQCeuVTfe5LZysy98rsWejd/9cOWqu6ut/YE81XGxb2V37PeKXMx4/4y6i5sX3TxiA9Bmqd/aH74Du7ZYg57l7KOFfQUsPTTccZimhPn8rlEUvJWdULCfEqiKrevMQf+oTR8M2aYOXDjUfgX/U7Wx1tl4wP8zDEvbuoibHvqzdQ6EvYx/SA9GuEKbKEQkb+SJz0tWaBYuBdCBpv+SpKDxkXTt/0yT4zb2xaQ+/V4Rc2wnOQ39mTZWyAo+060YlrxoTMBjYcWocUg2ZDQWqQXAWT+pqY9W5iaKUsaRFIVr44m9++8z0twFY1CDBAU+2EBJr0gekhzNNSIdROir22HeiG+mC7tiAJKu5Bbr+N1ak9Et1172bFvYbop4gOnZK62R4srC1sT17TQJffFmlYIzAS6EqzKV2kXCjD/MoPdHyxzHUA94IzrfeAHI2GT6mIhuUP1ul45YICknRfPVZeJpQcp+70drmOlt8khlZRVvIrm3hwHXdiImIjsLW2gSFDJ3ttg0UaT7GbaF22GnYNHIxV7E037Sl3YA2fhDiC/YbukcOSBYAE1x2pjXm3+bXMRUm2C7Y10Pjxg98+IhOm0q7SP+lbu9dC7zHAlyyqMaw4LJYKc1+3WWoqmhiFEooCl5GBxIbQOLFi9sJWlIBli47zZK5SfiM6GqTMfUJwYwLkN0Enagzy8TW4luqwXuP22SqQ3kNwxRXxIWim0EkTG+AA4ROJCQJljJl6dHZgTmc0tvPhghVsDmuX263FO0KYEYdUiALYalxuXMTjVtpqUj+KzPvNwn5BGmAknKjZpnmqx9g/I0eXQ8RSauxIocIppP03DXQsfj1TpGTqgfqcD9KapkfJiQaHUoKotLK0oPGaf/NDh5h8pi1xDg4WJMdTjNQ1bB7J2yuGp4o9BMVgvj9JuwA/0WjofVs0Ece+BvxeppGMEe8K97F5y3SEfMdZmSA1BNh3pChjbZV7bV6HWJJDoZkvabZEJtrewVwqR7QwEcRShIXVjBQB6fAIX3rawgOGQUV9L2xEcPIQGIZHDSXkhNwrL6VwUfkpUYYw/O+QUOZ7wL1JozEiHcIGOSTUmifNkvkNEc5EhCII9eTk4Kc7Mk2cPIjIoTp6K7Mr+kPjwveLRslFwhebhmg+ql4nkjEDQk4ZcPbROLZwKUq/grSQhgUdXgtPA3dQJDbjA+Nmtowb2rMxPh03mylgan3pBDYC4IbRIIga+ypzOw2iHlUVB/aCb7Asx8YGHZJpBTer5oHeWFEUZdISZOdGzNHfChqfAgdNJFwbhGut9ng13btZtAjOarGMlPnyPClA+qK+0/8exFfVt7hvpb0AXwIYSf5qaESbh2WW1U8IhVSex51fFXFWv1+AeUCf6YJ2BGGGKCSQnG7tO9Xu0VfJswlUuIHre4mFzO2eUHa2brS2/tlhMoalpUGaBO3g+PItug1ZxiZLcvMbQTarqxYu27k2Hq7s4/5OpkvpUjerjeiuGLtkthoEeIT3bZYste+tvXUsGPrGJQ+TXobTAvHM6syPTLNFoMkzC4iGpAGgA4SSY9oOLGSkGKzXb1PWyKswomm7vatRPg3iAk/Fi6sn0zQhbI0y9Xh860cCIl+xgrJLWaLWsFTzUjInByqUzjC1JqiqS4uC6Q7TAMqi50FOe02kznWtT34/0t6revfodgjTuSAOyGbN4gohgEcOWsqRTlOfeVGpWfPGsKoe9R09tkxQ/JLpahFyhWRKzAI9mAY3niS76WMdyEJ0JLrtLtc3M3WO1sJJq2YHSWjYZ6dwMUhAVm/ilQgB7tVYDHa+yy3PPBglRX3ebH9WkXFjLsmevkq1XFDlFCc7WEzDwjT/ZeoOHu7iTebAgZwe4sehCZiriyeJ32TJt/2kJ1vREeFCtczcS/KZtxluKzFy6r0G3z310Oq8LS6cKEHvDNJfWxpDRTGTV9Lh1rFvyHO0p43lrRSuHhRk3TJN1+z7cCVp3N7HD1ELwoAjhVIOGl+AuerXiTPNKhEPp/OgpEOazDIxnTMzJM6K3KKV1WCNHfDUtCVk6+QqS6w3Q2xWvKB3Z0gISwbho7WF8O+hy1qpb+xCsiIOTGnvEjAkIijD5qFrQ4J53dCi7OKUrUj8gCpVwkVzmCwS3TleFDo6xJauLk9IdymbxovhM5ucqvWUTXg1WWFbcoQmMp3PwJIZbLGUnS2YerkLGkJ5c+2UdR/fMAyVf9mpmFRhKvrQGZwhtLE9uJf95q0iYIRottEBG8af8NepCwgTvii1PAFUMGNmcWu7Iip6J1pCcPbq+orryo746u7aIblcmbP+WYj+wM6v2E4jacCcRvX9Qo6EwTeInU8RsstXtDKS+kphDsxWT1SCnuaAGZsUiJJkCskEXSLJGdmLIcgh+6XTmAaYYzxoFts2xorVGkf1YxYbtmMaIMteDzy8A9dJL0+3dI4zYs2iPDpCn2afGThfNk2jsw4S0aZ2SuQS3Ay0mdr+xF8wnsk4+39Cgxm2etw0WEcwYToi4twOrsiyqlyMkYylMme/3zoJGckkpYsFCKm9kJ6Z1DPHCka/iopB44orJJlUA8mtN3fdQsgu34dY1ZalEoxMC6zU+xxNQtUpiI/pdriJ9gYArZL/8TFykojPjWsZitEUiQmmuaRQpi2Wm7NzUfzkHpSldY1qUh5tDPwwx0xYa2ZLm1deeDLtgYetJL1MJf46Nuvq4NaeV2BdvcCn2sxEGK3c0PKymlkm8tivM/G/9LAt6YddA+QtRZF6oT9va5pzCxssmO+64vKzRJT1qSQwkfOCieq8Epf7yQWm2R4HMf8LfeUim/JFljSxnaSvXa+1Mo8JU0yKQELIUAOuqImILqbhcrQMBiNv3/e79dHTt2z9fflU8HN9Ob9amZiThAoE+qVozRDdKdGzLUAtWWOgrIfkDN6f3Zj844jU+3qNfBcvA2lUWiNXnBi5TMlcUSAg7xXISwGqf149FXRpFThiVrISuOzAWCR1Kf2YcmgM2/UPzeXPsTKLwdxRRb2VAKgEuN+ugIOJN0VkMCxxajiSO7cpsuL7G7Diej+NtupmlDmzaHvK7ng+ANqV/LspNRNcgqoSVJLW6xY9aR/lTzq1R1VAPHnDAmMyiW6Rh0ndA0BbKVPKYNY1aOhPd9Qz1N2+04tuaPb9eXiGt6nWZyhvug5RrtMW3IEXcGPrk9umqielaiV639PplXd/l4+vpdbBq1vM/K7ZCRqMRxSyG2TazqSKCC0ai9Vc8yUo5Uzqdc6o8hCrrA5HdFhc92MO3dgE5LOx4LnfI7j5SgjHvQYHWq+FMS7gcsH9/z8vOQ3xDTd5W2zVqp47imzglY+x6eJPyhcWdRKhCVcKVgCvQcw2WYrivFhkxIiGyGLYIE56AhhqvtTduGtbv4GuqssQxDvkzsMWALJIOuiTNZY8CsyC8+pT8yVyX5++OpF0IY38M9Jci7LCXAIIPHmjFGuN7PDi6nHVX5tHEU/78k+5Wv9HWm5iibDwLFyOim7ACE5WY8ixop3KzYdTExXPMjnkldGNf64whRzH1T0cjNND8GdWc4QC1DIAYNTTk0lNg7K/ZceiNPM28lyoZNRS29xUyQcF1xaJC5hXaDFU5rxoiMnCWOUPDCnsJ98KUMWsrdQ4av8sduLWdfMDGAdHpBtFRLXXKgWjdrn54j4F5x8ynm0BNB2fg4+/DaBVfdDFVxk2yoksUaxatqLbpUMZrvHYZhq5FMt+z6WFeZnTbdzZNhlL1rrnJ4cYypAoQgEqJNLU/q8AuEpCLyyIJFBKn/lMIWFjDiOw+Z6SHBW72pILad/CMKgaezk+NXfPkEJgxNh1CAWi0ixlDTJLqZh8F6/vQWihJj7NytmHu9l4VlFwCGVuRDnDINBALzWiZ0QbNi1UxChXDHjtautXIz/LD8RFRk3Ur4uT8CzjPpDZqEYYtwYWWGPspX2w30ZLTFdmLW+6t4xtNFAjXw56QwqCYLGXKM1VSWSQmuyMtij9napKSMHYSncxTF6CGqluV0qqbK21ABDfgtZ4d11P9sKvPS8DefhnP84PYirz9lssB4Cef/THW5z1wq+moaTgo5PLJ0PUfpnWHd/iiJXdPHtUVHO5F9YI1vHmZE1LCIWIbYnmiHdsMZlSmWuSUktXM1nmqKJImjmm7TVoNU+h3f1DDSWeO+lhXbG+Xx99nUSJFeYGynpSAM+xtk1e0JilwbuCVe5+93RFdx3fYfZ9GTO8brM9hIT7sBt36sFJTfWFC/E61c38G+0fxrlEfv0dR9E0yHhj98MJjjSvJXwb7KNIjzkI9HhAZw392G3AYyol1mAD/wHfAplm/Q2QSNaPbgskzZ2vjnDAxEkVqebATJjRS3GIYmiyarquzPndBJyhZO8usUjtvWOURlbtvjlpKIKcajTJNnEXBUUBePNd4jzJK0voTTlrtATVvl5rA79HWecoHMcQLeY75svbyQkL8FO7GmB6dXuYd3rjMqP2ZRyK2nERwQjR+3AdRBNWVVTzdWTyKITF5xfUG+lcTDRCS6fvrJY9Orj/efhx7Hn0WgKbWGO3tFmnnZ57d4XLqgrZ5me2ixonL1QxeQoDA43DsYzdshKvxu6p9YMhNFqBnNfKdFx0mMU536kGxdK6aHGQJDCqMPTrRs3kGMbSuLrVPj0sdXkhYT7dcIb674C4sjVFOGl8sCwhiFggUsR+SUO/YZHUbU4vx20dvUaH9ULONR2wcBi7gRb12ai2CEN57s03fGBiU58TeJR/qjUn1i9yogFDbA8qM7t9U9pp8PyFY8y5ITO3i0IgmdGgy7+oY2Xzp35awbVuzJOIyXHuILFhACExSzR1O3tbKRyGnAMZYhpxl7qSW6GeBSxZRyn5AMKUlK+vUdLvK1Y5moDXknVpZp1DJFTkbw9/FXY40D1bKVDxXQHOTL/pI1lPyauQy5W6XMRa5dXstRY1SABbWmGnz7CVIbKUnv9z8eCql0SrrmSGSXCM2DiCg7s4c6pUcdJszUpHVqg1PjVoqzQEe32xrF2Xd2NOhs5dhrjooAJkKOjPQLE5UBVdxcMH70aJ1Y9eHIo9xizp+6QuL2YCHgycedW4CbbxBBTJw+VVNIIkioRODkwVVq0rEcKR17mWDIonKw2xteNcl8Iu9wTMyz1bOfyWXvtWkJYgpFq8tEpbSZR/ZU0gzs0kq9HGo8Aa/pWq5P8ugeILzkaejCUOn+iqGGMbBNwtUXKbjyuZx44nO4+nR+6ajugpPt1ISTS027RB20TTMXZBrWqWSfKDSe1OQdNs0xCSn4nhzgdNwolnNdfABLkv0aPSpyFc20ZogyKzyBJhc5AwEycjFuww03a3SCOzsbcY7rSgsWcGm03t2CqLuIikgnp1awvPz4drQqD4e5iP9gDFdWl1WEzfkUuDpcI8fa6QeYDyjJYKBUgp2c3LJLmQdEdKkovA8ADkaD6W45hkn2BDymsZ1oqyf68Qw2NKZB7MEA5yfzGSfiEii9LnMXkDV7R13B+T+6ARrBMEjEhHFmI41BJFHg6oD8LcflaypEJwJDJsYiebGU5LxnSrcjkpTIuypDuWRaCbBYTKSIqgL+B7JGMhkC4pxSjtQpjC5UjEQKpK3FxDzGMLRQphwVvVeYQ73BIjUPb7TYgFqf6TxwGFB45oaWFZKSUXUxvRdOEQKB1UBnohk/ErRzAxuowsb54FooaUgSXpdJReDcbWUZ0Wpv0RyPLkvkwNOo/kI112LKainGvB9TTV95RRC38Va+lKq4VIXAOSuR9syH8BDDC/2hOtWugiYtKpGEPYsdYTDig6Cq2mdUw65ZKiijh96REdpWnhqoK4FMim9QYyWQCSIlrAEiAllatzrZzhFG/2HcrlekGC3dt5JfH8nI7JC+g7nLhFhJvn2F8UXBRgJysfSIWm4egEHbxi/qwArDMa8DJ5EkXN48G7FdTCKAuXyCffznCH1vS2m/eJ2p5GfP+BtUJc8Au5fMh0a3qdOIby5w8sHJMvt8T7dLSUFH9tG4lPxVJxVUEG/DXC8gDHEIjixx6O9WfeOLj3FnQpmPi1TKT12M/ZHcRA+KUlg0N0s6e2i+p8PePRvk3RV3MR63oteKk5Uqu19xPeMW/J3O85DuKsg5WuHXoP+LloNNzaUqJsGRqGl0WsIycLJ657vscoslkM+pqWjaV41Hoxd7sce1hpdUZrpq943UHjeaaKf0j6qOjS4ULTm7eA9iBap7oBtCnpRblUIMZFIDZbd6DZNWg0D14u77nsPxnZ/H+7epCkcRP78Prze6EqgZlbKLGtJEThuIrJLKHuciv/9VoHQQxjZ4VT0uR7Qx4B7PMjG6EmVRTNxAwEpCOrZSEUIcUUKYhQG5ourQN/Qr8moDttptB9Y+OiARTWFXXznZnjwI0urNewovbtKKSNptZLVnJJ3cj3FMgplc7mUmgcje/HGOWvFdLOoSCdxigTTVA0SXOOlSd4BE03u/wM4KbNNXR2rcXchFn5HFqe7r8WdO6z5y5Wybdb6kip23OVlw2oqcPbhOu0Rlr5Ja6a2IMuKhVmeJ5nXIyOi1yMbrryysdzgWt1Kihh+nqkzqnZqoQjBi4m42+jWsafpXXDlBODDkX56WvTs4unr46vVqND8PVJoLBakVnFmd5quGW76MhNyHhC5LOb1OWPwa4+19tIyFwph5Kith6jUmklmFr5OnatFYOsEGBShtbrQihh+iotFcLUcyk8VXlxy2xexiwQz9C5IuNYTiYt4AIPkXS7zn2/W7394f7rNr8fXfu1UYgyPtOjxLR/uCmk3hJKAn1IhmYaelCzPi0g7F7WYRjrkLvKQ92pSLpu7IvxVZgS+s0POYInrtQWw9TuLs0Fy/8i89q+JULoTQ0Tek/GdLavbvV0rezSeKRtTNUkFgaXyeXYOUaJ4LLDjQHwkBduXFLVOHcqkk8awbN9c0fAAxoS7X4+36/FxelgDjFujAgnibXGbNWn3FCdG/Ysd8/4PjZVEcYLK3QETQdR+8LiXTZucRomZJLdeJCs6ZTR5rIg4V5sR3F9H+ts3JK9u3v588VV+fzwYVRVCktyTNz3i51LDbL9DVR5c4lYfX2D+kzLfibNfXq+HWnc7kdNjA/iH8SRGYZTXzuu44AhF1x28dCpC57s53Tux4rXMCP4ZxGXQsF2pwwqiioXnKLNoGnvTVP04CYNP3Odbu9IT+suFSgtrHLW3b5zEfYKrfFT3rhgGqzoqi2rgcnnYxAxuAtIfNMAJGeUOuYSz0SRKCquZK5Rhp9+o6SMsHSysWrnFfz1uDKsZaP+U+F40DUBFMIs6VCuhEj8WBz+lxsk50wywHVjApwCjCdBtsq0HIVxlDrxl4AVhMTeHcqvV9rgEN8SW5Np5d0IsFiE2GCN4MkTE0jJSA8k3ELMG+YjR4iCrNEpNJKnGbakF6fMY/RTylj+ZftwwMdRt5siy0rNPhcrewmKXR8UvpAu1uVXURoqPIlosYDNWDUQYygaaTV6JOjH42puUl2+5IPPM4VUED92ObmM+EZFaAj6PZunQ/wJ4Y4AJZKeKn0FyhsKiciVYV2Nwi/iP6XWVvpfSSrvjbOU2Mql0TOzdqogiNf2oGCwsrDQ3v3kCuiv6JhLdPXbR6+9aXr86D+5Wn0spMc0t2fei3gBNoFadoOmUllW6erJFdkIMy9d/KaJysUvL7Ta2+b8rNiH+dA8QuySmv2xSHM4YNn4qSOXFjWCyWcx3c/gvyM92nhsBDg93RMnp27ocBQxJTYWvaaIomPc65hW2oWfM+x8/MWVEclX4FHHUZPUOCVLIjup+86JpfLTVHwhh9lNlOd5M/g4CP4UVGcnODoPgHjVzY7/KAUrkWhgEV6cRdLzMiJLFvLT4LksQ1rkjPs86NzutGl+xUkJaVmtZdXCb4Cp8z6aBkp8Ny/iStbLgDj7Vuv2NiMIFLp6Mrzzp+3E3VXI3FtwjimG3XiQmzJAw3/Rftjittykh8/F2Xz21ze1yeMwPq5upnWzf213tE+gJU4jh8vWYFql/8VKSRVjnMu6CsSOHpai6woAyWcq8m3HO/moL9dWAfKUl612uwycIikDqdRBNOC/d50ia+OMjPWJryKC9oRcYUHTodv89vta66PuYoiFASbB4qc2OO0NGYlBbjW+XquHc7KdMxWS+5vWudf9kctVSPwsMpCyulcS+qawi9G9SxYJXF+/l77hJike8kbhPEGhElCTdnkglk0aZa1qLC0ukOoi0uh6GwODn6b+KaMBeGBzwUgVcPUcB93D7AWyB8Pk4+yiCJOoewXONsZhBOSIZNZ+jQ/zm1oYrBRvF1XMgRED8Bzp7RP/EOjBsJfFacJrBYKR0bc7L3hJAqJkmMh6+iCjFIIZTjsMk/rw1ZtckZo/VVSLcq6U7LVPq+18mCJrcViXdVqnGR53+Q/7SbmWGgRTIaKRFRIoEb1yN5MDL1uoI0FSS6JDKfS7r7FmzSq9KmkpIX1tfmAeSXikspoZ1eDtpcnFirAT6VywAfHTHdlK/NTMbT42ONRwXhxH1msxxABAEEm1AtBDQ9VUk0ElJYsMLDps5oVMi0jjxPILYqRjAjOALcTh9dzlE1yn00vQg+oqwARZ2uUDHdHGtpxFXY38j2fU6t3fto380VSJv0kM955d9oGbAo0/zw6y6CPbn6b2orUKx+H8fcZIzplmKmJE0oxdz3S+bvbL6BMKag0qp7JtEW+JSmttgosyPcssmQN+NOzMp6xYtMmU+d6Aq7ZpZTCnWGLG23/mbfHPfeEj0xVAORuGUlFtUwQHxhBvAMRSoL/t1izoKWJZrq4mvWqXqOOqrd+SoLfI8usMWHYnsPEWMh0xnjtZoi2mcHkzpWFjsS59UVWFRgzqlpRtty+LuxMeP97eXhzW248bqLlz5dK27AChz7oFwC45SWWQfx5BDUFEUMERNIwALAYFynh9ub4RrqSd6gyq32fCr1BhPPnLYKD3PdhEjzfT+cst9eTXkKIhBYD6aK/+MM9i6R/0h97UNI71xTd/WxRVnE4lWXxMBB67Ol2hwut+JhNK4Rrql+XqseyOw1REYnxnpKh32NAz9ivRgNnMBEWE7RJ+yGKJ/oxxdZ0QhDd85jWYpYIuq9JCEz/5TiysXWd/Oe7Tlw69TY0tmgUZxLUaV8MJ7t15klx5wa8GpYZXnzEOTi1PR1BkL2rD2rgqz59YDYTi01+mnEz3taZWDepcUZ7CkAzw38SwjirI1avo4YdJrRCJ9yPAoRvtLgvzqTpBAYENPiaByI/B037DWULvquTK2bNAKpvQQSvRRXI3qSnzpqSvvmt4wjd88YfR0pW5Fe0bm8kxWB1PgQ0cDyHyX96Po+q7MTweHVEXGGL7+hVTHCHp4lZN1pPEzgQFjMtvtBMMdi2yZ04goHErHlwE72k5EAMme2kuTtfUaIt1iXA1d8pWWPeswqsVeS8No2Sc49K9uMviEOzr4x6h0YaMh6+AmEgUPXyE20ziivTLkavhAbE9ixqc9buzZCvZM9Kan5HXGV1UUwtaFWwXPq1Op+k8DU1i2898gRnL5TwEsAy+lgDAvF6Ae2EldrW3XiEqU6c3LB+Ad7LcV+R+iL7Xv215DSWAgDb0w1o/sv9ntf7vJDOl1kGAd2zJROfnFwEw5XCUo3p58QHXSPls48eem00z3Mj8LcuiRvdRN7pWvFQlKk/bRSh8NgA03e2TVsw6MDtomKlopPLPMGl9wr1NRiyh/qPzZH+81U2JAkcDqQ2b1vb2j6Vizx3pLIvgRE8spGYsXKq2llSV7ZeXQdr0av3dIXtj12dEjCUPFV5xzT4HLLIoIKv11378/7pcTpYreqeYq/PENUV2Bwx+tNDX2/CXxrqLjeJMPZnpYlkd/tgfKG6FBqCst+edobZmpMhqFyv1L/Q/K49Ox+ZCOgbiclYKBoDxffh6OL5D7/gZHrNPyQWPVMyTkZiIyst7p6jJ9JQG2CSdOvc2o75fztblAjI1nTKaYtLpDOzSXdLc9T6M7jnmqqNq3ln8evI+OX7+laxv78XONDNamS+p8OfalFv9/W1B1WBgnIWMcR13HcxmnxjwUGzoBo6AxfIpkSC120OL1HdS65zw/e1i+1ce8vz7dr2fvDBBpT5LGME62/bJZhwLjUFi7q3n1EV1YHB4kGdyg9BzhWaJ0/ZgIf5qFjKd1sjlw+FOk63aR1H9Z6G3qQ+XG5sR+1sK+ZypCw27z7sHM1BO2FFlsbZF01HTLaUY/0ox7jxhjQQEA72M9YuK4gS/XI4baYu4AxWD67uKVj6lJfA/ejW4cHY2hiuroyGkqATPuDhOhk8jHD6QvBHxPiIinYC2jGmWPiuMIv1qu7aic3R4inTC2Dxt23lGrjbYCUh23z+GXLqHfnBmarL5o5aW9pGsQul2i4ILG11UEEJ5XE8Pv7b2Q3O/J2BPl96mGcH9xZGSUXBCK1I/QQvYjyjD+WE3x6KZLsfqd/fNpODnPvTmuxCN+buz976XJcseyoPirIx76ov7cGc9YVg0o4zHIxLXbPQ/L2J0uRO8k1BFSQ9VnMU0P6KcszhRY70YRarvfE7izUvE1QY0XjkulMHMPG+MgQsQoi4CuYrZqmw1Wn0XN38gn3e8cVGCIExGK1IKEZMm1TojEVhSKF68KBpiiJlCHDFKpeccdgdraEmxGTY3Rab7APZmQuJQSBoBeJYBYpVaMa5o6nO+PzRB5uFsr6Is33PH4EGmp+eHVwwQ9u5Ex6yWTURmtpnVQTUEQCaYF3JdXllnsJ5nlOHw/nrVCvub+nNF/mkv6CHcTMRmEDIPMnEXsHfSHcu4uNb09fVzP80GxngrqkHD0ArzkqWi5uWqYE/7LGHbCcIPSrAxxhuHpwgMB+QZtCdt6XPAER70YlnW3/Qa4VQGk0IdcKIS0Dv8yCrHtPRNiH1JHzaVyCH3zp5p1HcxeW5QS1WgE99VH0ZM7sidTVw7MzraVrrVIg6R812hwb9VVBrGIH9SKWMV52xXMsgAf/YKNKmnShsLTgyUuv1D3iI0wzdmqpq7ypUexY22sc2PmIAS0Y0/0Opsm63buZwlx8PpG9slCn2JAJuvNUAKJbh2plR20bdAOi3H1JXrRXbOe3Qgdw4kW9HdZ8uA1BNQJg2R21+WkgeMT+WiiQg4jNPngbbg9KTZ2GHamOO9AGFTeJ7yvkF4O7yy2Xh0WFNNXqLv4cRMSsf29cEi5alupVoqeAiKIXNZ2UwopcckdFDv8fPNaqpXF4/VKYUHtWzR3LDx1QCQJfLWz7TDqJpMPi314Jqv2cswW+0DG7FyX07oQs3KE+WQ7wjI+BesjNQu2DHiuIvYmBY6GMd6t0+sd6Wu0cluaWLclo6DcAP/8Z2CQqphj4HQbDFIVPzmiZx/hLBCVIdq4VHymbNtefbwjeXJ2//L05TRjZQcoUzskRVO/w+eZHbSR28DcKVBym7CpifI7KMj0vcuc2oYF2SictTZZZhXNDJEsyQxkVdflawozBy8gUPxeIRK3rPbmLoiOm1vIDdLiAEndFP6svXTeN1m3ac0ejvD5cp6rTk0zFrVRI3lICzBfD0+o9TpCASxvuYOmRFimeJgzElVv8ynY4HBNFfrO93LQJityxSEQAwnfO/QyjE4By1zEUWUqIRMO+/mEFCu+qceToS7i/Z5qvOLj1AjiRgz5ZJjTLmqdHNWqp3D97ro8WC2R8mpJBBor0/seyXDDMSCwmEfs/5eQDERznH4z1TepVzLHjJB0x9Q7M6hYYGC377u2pciTvCbpaCZL09AUymsRm8b9B0oCtb5Le5XFCvT+DUwmGJw8ct/iJvVDJLEPd3hnViAQ+ostqbyChL1P+O0Kg7/6BnnF5vQtWh4cw1JwHu6GelB1AI4+8xxC15Mxj+SmNGF1ASFoKvRSMbhlaZHbPlkDuX+JNr5lxMZdOi0TtRWBTL7OupIMGaTjFKluQbjFoYmuIMlwtHQPp+hBjVFpTbjnXGRmLpq0UNdqtwBYZs2vPC8EArvlaaZCFh7q7MCcSD4iRnS8AyUMq9GxPbIQYXLnaS6tzckOuvBz4OS6WuXrDnWPfF5bbVkXeWbUGolgVdzkOIK6RnOQvh6X3d0/vpxeeqNqTN7zfHjG27aE4CiowpCAkGLZXNUWX00xlRTTV6lJH1DBmYnzqxuAtUAlWMpbykIdNxU2HPJsTIcVcgcUXf5UJ2ClFtXFY8gAEjTn6VFfMl3XF3OpS103aGSghsPwFyFskNk99G2pQuYTzqdEEtSBvNghk3QB+RgJRdWT7PZefkIyH/jghBbs+1HTN0aA+yBQh+0fkKR6QPiQQeI2BwclyIqEQ20qVA4IdEztTDh5CNMZ0H4xxvJzzqYAH9/7iQgn8w8k/5CYYiXAyFuyEkYEBFtL1lgF7EUL82S1mgevcN3no4ip+yueCP6BzIJpNJFYaHe1NpcIaGAxwNwXBCyrDwSkCtNKLry/KSXYojonGqHxE7UehEopFYazx8tMN/rjcKzN4FFN7A0uaNLYZSYrd7SDBSFs4NQPgR3mGvJ35d1WUA9hhP76zJMMuxjGhvt93KI2A6MhUV6ashYO48BnCV5+WDY23pmjOIjmBJ07C+W7VI6uHM8DU65FiaKKhkLoqgkIxm84+b5iXLBvj85IzFTcNOJlBhx4wz2FI62jKAZivZJy/F9f0lFvi2749PemPYWWaJle1OOymA5weQEeeXx2ce7DtstB4BnQMVwzREbFbu//iGfGbW3QyX0MQAy7H7/Lj/gxS+5Dg7QUw6yr78wQi7Ft6c7jv0hDFKvPMbSe/5e++i/dkEmqLJDfvPb+jnUZRtsxi0y8zhXdREVoKhh00RHSQmk8XboXQxPWxexXMyjcIvrxQ+I7OtenMm6oUtDJVmETl6k62mSIAN3t5HPBzkrtWuKkC1pokAVYKSDdE1ea0BjzEaQqeRL/IX6KD34thwlTu/w7us407/ODS/hfX8ja1PNDBJ8KbvYf2gqIraVeHPHmh/crDkEtDtZWbh4Mhjr742fBZLax5WtkxYvjHfh2Q2Hnx6rf/NDPLcc6xD6xDn7nvtbfKah34C8lzGJsja0tOI34cll5WDADS5ADK0SQugz7FyEHtZQOY6u0du4MK5SrsHrr4tbil1XHXOIBdeOSl6Ah4U+YRwABK/6QAEEAM3MPQEbuPzfcIUx/thtSjctHKX9gd1L3gwIQIpFpXOhv2YBAUbFCWPWAHanPH6nAbnRKYl931hffqg1ZySxnWSl5PtbesuRrFIsh/IrkJDC9LyisZXz4KcAKgz6v7NunyH6lQsqtv7hbLZ4XAQJfVt1T2o3Ij5djn675Kam6nJZg8BVWGOYxf/DM/DX6M0RFxIOzUFnwLZHaBNefn/VtyoWUy7/+qyl4twgxFM+Jkqs9gDdeL6BKqWdSDPO1vEYu5yfSZJOnduFT8iof0uQPE+bcLWxwiDExRoXsIksC444pGaFFni6nLjFi3pKBz8pSSIM7huP8lVBuyLoOtnOa3C0sFlIu//qvimrT5mX1l1mlGsmCZX+kkV7K91lcTub2nNZ6O78EFik2giQvdYkAEvBUENiZUtWgmWpfUch/sS0H4aMCGDHLlt9zpQH6QM/GMg1IWtlaylXbKLKKnprNp1iUC/XXzck/j8vOmFgLLDdUN5kcoK5mKgxC6cs2PhlGKtjNbCNcn17hZToMQnVrncqnB3jLVFiFFuXAOjU9tRqctp1k71WNdbI7v1MqQZiUKBWqq0Y6aILQpN4VTQT+QaAbw6BnsSUFRGKrqeLqCdu2tlYkVblqVUjf6Q1tKLk8mJGConRwpYVprrkrjcKSmM3YFfCOdICJQQ+4PDEDa+CrKWR1+Tt29Ry+wuvG6j00ZJGMEukdY5DCVRSyqvzxwQoXeF4sg8PvhQa3pWlNGIt/LPMhO3oJ1RGaPmolQ1sqOtnLVW8lEuYZVJhisoT4QBQMUO4W9iqEazeEAJGPxNf5COChwPjOmWlMg7NOWrKvHj0167PVlbSaQuiL7Tz1Q4a2vdiNBU6kwiAY+2Hm4cQMxk9xh3dUsIpCVpOf1g7qmJDHrNeoiXquwSFbB31a4OtZa90uON5vtc5KVZFQ1HZ6hKiR0A6+OLgbLh3U5bbcmdKnqypndUWIL6DjxGbD6lBI/nbZ5bkzn9ko4J52uqf7uMuQIRnLPuNmcQaUfUHY63OLlBHACIB0cYWl7CdJY8Ssh0HngVxRavzBIJ3K3a2EJWdXJ127xN26hpi6gOyr/zpzpcYsygFwWkIDWSrIjcUh8BBWNI3p1/mMy6if+tWXhrbMVlbuZ6WH2zRlQXBBYFzlPQaBciFzb1mRuQ1v0pRkDFK+7Z7icv88B1GeoLjB9OCw1/CHIoJSrkXSie11sGUYcDkNOYSNEJ6kzkReQIaRyd2CVo3CIDBoIQiRDTH6F4Cc+qLjl8fSJ7JLpEj+myqSPOsdVRiA/DuMvtqrplLpIHM3BA2EFZSqa3bLqMsZy8WIugi6R0UIkuORSMgJoDOH+Jtp2ev6NXPPZVKfGKDpXMJsa7NR0XS5CpvxRuuGgDi4AKhtAwrBKoCdkRzctXSth9SGeGdMjTJv8pJUPNP0FBq0jQr6nlnz51WZixe73wDw0b7WMyum97r+JK30exMyBKbdk1OleIM3+bZNlXxNv9rJNgofn3Lv00gfavmZNNnuCd3ZR1+0SyAw0iGYdESmmrJmjzyFHI+XS2/pSLbRP84WSZS9GPe9jcfYMf8Z+VcrLUrgdEWCLzXIhyX7xjut3bmSAzgiRu3mx5jVIrQ3VG5oSstiLIGE0MR0Rr82ESHaOkG/hvaYVXna5iVAQnAX+5mO0QY77Uv9wka50/ct+/lfuhqLBodUq8g4/aaI5IijfAB7/Wfur2XpwbaPlRcBDMpJr1Edtgd7SZMqUlLfVW5O+ZqeWMCb5k0p971LlttFBsT1HLJfy3eMRnHcJKPmc5WtF/lGsDk7ydxI/1vT6BGvSMCisE72qmATwuZ7GdU1utVzqNcsLyn03pUBWoT8V+v2QrfPr3GVbWJ9isFULx4Yl6pWUvR241ZqrNKK3BI6bVsEAiTszje/4M1oFKImCng5V6mEzGXzhb7/QBPnAYmnz1IWXqEdyyBv5YVInocs/tjglyTwKY0artfJ1JG9OKezpH8So00lwmqQ+PgwRAr1OXz/AAtCxvzVyBqJPLgO0i2JUOWCN4GJHGcuBI3dCJGD8sqILa3LXCZaoD9wRo0BIU9vOGJtf+xcCbvIav2AFh+hNJgBDdN8NxMKVHkazR1QtYtbXhDx54Z7NCSRG/btcdAWr0JCtzQvzCypbE2w8kh/7e8Opxki1H47ZIi0PVUeH3Cvj1jnOCx+PRYSlrZUgYUwC6xrnbdFlUBoXo4MUxXIlbszJQ6va10M/NYpyxyfyfSqn+c3zV7P1xvCmeFtZDycT98GW+b8TbyFx3bcocbiEL4PZPKWu/6zwhwbYj9boU4o/bDwHKCj/Y4bxlQ7pvULUXZ4bkPkFAhu3KBcru9tTXYNlX62MBU6M8aOZPS6o5SqMEjPnKhqi/lsftNqxZGb4ZW+Bn3zzxQGAI7Y4wG9/wM0/alq92W9x0sZIXG0Sj4PZFhk1DPOW5PNK8yKHrTwmYjvNS8T53Mem5zHOue5oInBrGsR/Yi4ZabxSTOELF3iH4uMTZ3nnrjh/V+Ph2kwqv4L+LXQ5lVZeJWq1I7xuSOxcAZysGMlnH0o+w6tdW+qrlvONIRD9ZARrifL56y0GGLtnIKSaA14g25OjOw9ngJIep5kG5dEVAOnigtCCMA1raBPExnpdJZkjibqremwikpxieEWHMK8MjYDvqS26dKfP6hdI/V1bhxQblJuMTOHtgifYMTFPqAbjYSWazQxAQH9pRuOcyFWyPn+mDwi9WBm8ouvFn4VEeomLpaH3PUWOQDDBYSQVftSJmc3qGi8ycL3pxkAPF2uAngDDgyPjbY/o2qe2ley3TS/wDtTj7S758wP7vcsaVMIILjONWwynTb/Er0kIXzx+XPlWweAyVlggrRpbGFCgaOst+Kr5Gl0m8q6gXtTnw3skiAOIjwM5eIscFz7lxee0nE+MdmhUU2yKO0Qn0bNlG8g/Yf9yovTmQeKbgrWcGuvfNMWPScAicdXLWYY5dUT31spPB49w2u4QwR2NCfT3wYHnZAUF/i5gCCoaqkJvOhELiGuTAx5Wk+iX8UqgMG/KUfGxadwZVyNabsvrbrCSQtgFhPxEqRQdW2RE7uWjrQiO+sUM4riOZIfTVNfgVQUn7akPTLBefdLtmvEkYfsh8zr3tpjDrOT10s8MRGng8Hn2hWfbbfw1pPlejswQQhji+UTZn+Q+pYdAmAI0g4hiU2DpCKZjFLYoQJHGC9y+l1zMWA6ytNeOe1tDxeCJFE7EVusewzOAzzOf0YTzJgtuwLqzIsQXHCjowgOucPAV0IvPc+dVrL4gKwCCyL2MPIRaAWzEEkPzU578e8QImyAbHogFWFCoVbkyJAZaDz0tFD21BnyX6q0H9knznRCBTCuSoPqIikIoxMPeBR1lBI3VPuwQXKNRfkFD5QmKnAKSW38lUWjOPnOhH6i169D2vzcogG0xj6E7UzQv4qiDaGgcvHEqr6ghDNmnSCdt1n7oCsZvEjyd/72MON+owJOmB0UrAD5ZPXBPCpvjyQtIUr19z3YL0IbeEVto1IwLCoj++KAY/P8GDMACEihfC0Sk33tYtVXaZjTYyqMv8QiXXzyPit+oDL08TgPShr5G/wcWFq+DXpfQmkUuKwJQZ1LUugukUhIHzGOPXSLzDi5Xic06hCAyK/o/2EzKs7UJOKUrQL0k/tNZ/hQCERLhRIDgtGFAx8/6Ch6hDKZBm8eoBNjsE7Q2R6tAEy2fQNIxt8B/nmQ/9SlAVU31zKiQ6wu8SPF87HQp32qsTfVjN8IAC+pc0KQJPhEjTMCH9if5npXn5fq8iHQjw5a6VxO1XSbVDoxzesYNearCsfXohmibK3OXPJ2J8OrOD9MQYrlRL2pcapnM2GRrwIbn/LCde48kPfskEY+JfFHKqxX3MiD9ZclvzlxEXTJt9JfdZD9qTQIWpwm4YgRRznTZ2CFTOJfxQVhFkNwkS2YZeH0XS05mwk3fk24/52GySXd1+elIn2IXIr2NXUlkbCTC3D0uvTV8PG1aHCUrdamy5BJhldxHs/LKEAw7P2+bDBiSJXxfHd7hxUaEEWTzwolQbL3cauoS4CHmQXFeVzgXfDmiGACrjyRRHw9N7zYYKEdhvmWGZVO3DYIRRwjaXX/OgqHCBROE11d/DwV1Dqixa3ztzV7SChURSSKmu6lmmlgoieyjBnMfPA2eTQ8KI+Ewh4PR8JPzBfLOrd8ZYOpQsHaNt5WuuM+9upsXVfio6YS5V0ug9v0h7JOm9+RMyNd3lDm8zDGbZvLIytMK1GtKCy+1wuKJaI6EQKqWu5Ns6McCD9elzk+Pul7ayL0+uNCTK+EIC9k8RO9G3CRg/km/xtTxPzJ4KCq38nz/XMt/MvYvtW1QRk9S5anXMsTn9x+d7D1sWPUQ9pjm6rRiiHB9lOufVlnRkJyEpUkOLOKlgY5mUH1Ynyw4CkpbOcZ4DwY9m79baz3U1KRgMmi6kG8jbKLxU6XBs2Mq2KLlVL4nhrGKzvjobX6mPibUEFs2HATEr5y18PZf6u2nEnnEq2niuv9VEeWaTKN+vITrTMOF2o8V7joAlb/tiOr3vkvHXQA8r4sG93edBX54EvFYdDEaJ20n9L7qeeLDLwEDGc0UIIQ0BNrNv5lEetMw2GI3LPnzC8X5yxrrUbahUGPARMHbz+Qr2XdS0YyympOTpku4cAdq7kzZL5Ma/ohcFLu2XN2H3HuwuN1R1qTx5uuQ4eJeVtYwUx+FkY14BoY7bdViQgd56U0EBbBefrxZRfI2BC+o4QcWF34Z/XLf34uYUOMavVEbVYszP/LXw+sYumwRReyVXGHL1GpTv7syDBrk0ho8KQ1qq3XB4di4OHlaqT3X7EbdfkTn31mFuZopqaORT4wL0Nbbehw2jLVy59dxZA+maFs4uGOkpep/eVoVvtf0Z+P2yfjl+ccFk4cMPSGu915NF/ySoD1oQCKF6R4lpTen9hD+y/loq2xypIGLjX6j1fZSgvkGp21YGrZ9MZiw2W0k1FNxHIBNY2fbp4Pz5erPFdkD4RVzw26EYT5agdRQQDZ0iM8Zd0mv96UoyCz2C3LLk2bUUh5sQi4vzLQw/zc8fshDObaRvNK7W2MZ+axhFQvQoE8i3RbesmRTimofXukp8zALk+d7UjDfxUITtm8qtBec57RFJyOWUEMu+hYeJgplINAEao2vyaGED3lPYkIlRUy7gjeJb3pR41IkCmvWo7z0lEDZuMcjG9SjDArTwo6zznzUOILnen1zgA3omRWroKqeppalNen2+GWOoVe1QuMsJL3QJfHc2pDqAWFBDZXb8Bg7z5vnQisSVNqTNB1WlOay0gmj4Tvkb1BrPe3OHSPpv6cmHd7QhwbIB1jAJRsqHuZgfGbyGLIqMhzUc8xrRVyd6lBdu/wdIoJ54WtoJW3xM+ik+aoRSR3907HLlrYcyHf73/MrzFzAj4lHzKHKz/gllL0uzwEO2wY3SRm80Y9wTWuj4Lq0IoQxbWH5rwbX5YABRqoyMVW5PZZsRpzjMbrynjMOxqhZCv8IDcWafsfP4BnWHi2/W1H64IPtyVaxLJROCZamot3RzQcMawJjw9fUjMoTlnRkHD403ZLFbHQ820IFT9tvQL4wthzLmFIXAwfPWKA8rjowcLJ1z5BGLekpRpH8Yxqa6SWVQIyHzl4nXIFemNQsulR5tmnysi3c78woMJqYHjx7RxAHYWrgCcOq4q5oqn2KT9Qqxn0d6qzLnV/M/HtAIlfJsg4NRGcRQyeNCdMuBouPlRtULPDSboOcI8F6UTTb3/NhLUPMRFkU07QtEBS98BOwAI1AmYNTyeczUHtvGEx7O4llgHG7mTW60vmnQCfXkkVuRUKPla/UN2PcPdIzcgEQIAlSRDMrc9ZZ50yprJB+E8ekh0CwV1uClVeScg7Qjt83MQuD2Z8YmQ2sAe/Z0HYMeJlkRHNP93lPGr+xwO9qNhkVwGcX7O3yYwWobipC8MQ921FbWfO1gsKYPuQPfuoh0oYwiSQABJD0fhAVhbv31gkrZ8yk5xqpsPeigtZRrb96hq4E4y9C0tAPnR5NDyVFkLBlBF4aK8wwGIBKaMnHo6DaLXAFVa40zHxxk5853M33WF2F70WP0/9FFBgnp11IEG/AOLgoLZEZpsUPbIoG6n3WI0RslTA/Cbx4CmnAPlBcKC4e+r34JzKxzs8jGSdBAJZ5CheJNvR80MeVHVd7mJpAL8xiA8U/6LGwFhOYR5c4OxvTJ6q9ipJkPS2NTj0SSe2IfpSmdlF359Jljy230g1KJUexS8NPpbQwdpjD4frMLk2CFTRQt42GEai2hPCYtHhADosUmvObwguV9BcorSqhQ/Up3ZcOv9cDAX05N7oNsd7uJmDE6ao5Xjf+aK3VpWBE4ZDJWjHkjeICuRQpGRQgnFJIFbym9pXshLsTFUet/Ua6twrWehGvxyCSkqKwU/EumidujPbda+NTuH7M01JWkSwAZcZSzrkQ23Y84+VH/3CHIAbtTGMndsrc2lC4+ZGLVDPdtIKJT4VHl+OQRrvSdXEHqcDuW9n9xlwZxH4XRWfuYRHkIxeAHFu27Xo3PBL9BF9q+ml6ByXGQT6KpANp/5g7hdrF1WQf3SAdKccJrG7nHkkC3FNoQhi8NwmUkj+2yHPZJmUXqbswqf2O/ydreCBYDWP4FIeUPOi+ls6VsMi3bG3FCUEWfDldvI0fCf4sTU4oJyRdeD+uVXhsdTWtsgY7Xlbala3SOay8UNqtAT9YRR81eOW1yx7sGgq1D9TisiSSSnIKReQdEIkGMKmRYXd1Fl8Lr5AtybuSXLOqVHQs/lfFkITSdF7BQ3eVJlzLHzzkAjkAk3vic8pMbdASur4VPR/Bgp3Z4uDg2QLl2l6mIbbrABuypyFKo/ODLnehf4v2ThHl/gyloaM5m5KbYziIFt4vgPZLsWtL8uoHxhO4zcXEj35dPqpR4ws3LEPR87N2Mk2CgVweHrlkYzzS/FINRrRzBowcXnSERqim96cLGRkdZ6VHmu6N5leVttMNBVhQ9/3ubsKKjgE+nylmYmsaQ1VG7ViszTRKNwSwpDiMC+pZMVUV6JYDN5/E0souJptTnUssGWOPHPDHJ/QJgXBI82oeWxmZMKfM6SOWC+jWs9WT6433uZC5pReZYPapqLjhE00ul1Z4m4ZGYThsTuMzcisNoZsZ7TIPQvjdngQ6MEAUf+eT7qAtBrSmcnXs5yAREFvg9H5f5qRgBLNC46EiwkkgkSdRZ3EraRsgggDdKhSzZDwKhXS0wJBgDC4U63NoWBpHeQxGzwaJMnUIaWJigGR5uX8KaKTcBE9FVg2iQDLODy5g8qu1n5aMvfp8awbXmbS+JZJAhJUCIhaolizHCGwvhJq2fB4cUqBwezgacsdOxDaLUPSfylDOkmYfO3G3WEzIygd5shuIIOLsJ99I/nRCg9I2jStUUU5YSs6iYzOVLCdQJsDjB02LmMcETSlM1CxcOHzD5IDHPGjVzHVJQNiRxAYQx46xsvMwwDzyh7qhmR243hQQBUY/aI2Mrkfv9pG8hVjB9QIXKNBpk2TZVRu/ymxv3DQwOxKlIyM8OfZEBFosuntP7zJBKt5fecUD1Hw84cKJ7Kcuxg90nQVvwKQuNWSffg2REoJSVWQJB5LI8iz7puiKZujtZBSNfch8RI+bAUPAG+8J9RGzk0KafWYu11tL7Z0L2FpngsCCM15g3ruQZcOzfSiw9L4OU6uZ0YqzZxRPKh+skoR5RnIddVtCWM8RHIM0wkfylTgorh4vqlv5tZoC7TJBZEPF30ui4gr1PMrjf4bmc6B5MeZVz62BxcMZPuwTgN3mCfbNGtk5bJO1HnqpTKUyzZJE/re0ss36SiLjDd7mhcX2KYKK1SXDjJlePzIE2JOJmjTDWkiaFc5EAdqJkvS5ssNyNGrUuriur0zEqWX4IiNmyY/FxqONUh5EQuPs7RCl/OM+nhtwHPWqDXy4n+bwgzLgOj4kvNMsrVcF0qZDuY2HRkDxnfUV5II+P5rlpUrelUUCnrfjGOQ5p4/UOCsNi9k/3kKDkEqyHJNDPsTs/RFcM0uD1cAzQQ2mWaATNT0vvek3XneVGExxkxhIvY+nlaCBQ+jQJ1lt1Fp9RT+oBjxpWWCPwGrbJvGudXQ3S8HVQfFoNAUDOSTGoN3C+vz8CPvmxTI1uoXvvpdoIOhWGlqkipjfg+Jfa4EUSIBYZJXdFDPsKtW9YaNPHZtJd8pgPK+eM1z1ZkHaA0w3LJFheqQnMJQkok7F4eeJBvSNi79ZJI83ViVKmGUz+SA5um+uJIqq7idzBHkkGpkq9h2GwP0k/WTwzpiOHeetRDjOqBzzB+mCyq1b7UQHoAkxvTuAClslbzQW/jECXbjyAPc0hQPQwbBCRsECqiEJxobR47OmnrTvBxx2WwJdtWQyeF1nrwcSDpuvJ5U6FD47CmiEJ3JIU/owte/oZU+xkmPjptJNSSF0JZ6wbDpDkIlvm81gwrhtDGgPt8ym/t650mxbKi/Jwcy1ioOSb2MLlBrpRjtL62YknIHOpJlaerqYFyLV77hiQATQyDjdaImS2/YRAijir3ZolU5IB9hVRoQSNify3vJgPJHXEZYJ9EieVuUBAnzalhgIXXIYGF4ERAeQnKIAeQF4NkqlflPS8KwMb3+SoEI+yKGKLP0DXwKaZQtmjeHupvMXictcMerVRne8I2yQp0RlBDYs7sT4om8WLE1GlcjZ0UVIaqtkjpjcGoBXvQoyQxWmL9ngmpOuoOaPJlqEEujdMbaDqcowpP3FpCGOa5XXvmdsDjDwYYya4IV4z6rka8yfvV5PcykheuF3nM274geMBN3HPY81uJGY9c60d7J1IierYs213hTDbMCoaNnQoIE9FbCwC5HzqDDPBarJB+/Q61ZefXL6TA2ekNC3HYHqZYvorDx/Mltz0BT19eYNbFBf/QUWZumtA6PLO15DEMYn7oytWKJAlc3DJXE/2TIMsULclXYIj5ky2kmUUEEnw6k5vpFZpa83wNjI58k7N2vNKPEgCi7UNdptWEO3h1J0SPs5mm78Uylmbhe7nA/R9p5j4VWmZFrhRIxKfBevfA5RuGRlEtIRpZVsL6Ck3jELEdpzbf7dhq7sxfQF1aWhKVoy5hX22mnyQ5tE3RLpyzd/hjqYicI7Km8UIpSflnllMqKpXgQhZHYtZjFhLsW5/C4qdVh0IUxHgE0rUiN8UmVVdpsk5Iu3sN0jWwHMbzpC2u9i04Lax/QLYLLsnX906398JI7B2ErHisYE/6FuITXLfY7CW6OT+Nr8a1x8kqNWZWgtOr5g1/IDrU8FpjgyZhdy9+lT8mJM/gFlaouMwSnEIX+BV9468fzYne+6ecns+OBqbKDL+xgf5oAuQ0CA9gFbwLs4ZXM4phiNMuI15w6q9XVQSk4YcWHKG0VmKeq2rzvpCFoxno1T4KXToXmQ6sHoXKGEwOjvGWnKvuGlCwxnz6E9Pi2WkQ+/PobbjVnHtQmb4s2kSzjmWdlHbyQ+diIL6molmGZ1gx0A3Q5QIpuUWgr7osBRwL/RcnCC2oRjh/HurKTioAiVREM/rAxPRtLrNyirfTpDW0B+KJIyFwhvoARJXuKsPo2SPqhyJU0IraLDAnxanVTexrca4fmYNEmAAQDbXrdmwnonUeUmI9wxcZItm2Bt30pHm317TtLmf+AfRtyabIHG4ycEXajEvMuhlK8Vz/Fpi4NiweT8K6a+VCInz6O3u3dLQ1N09NZ6sTYmxITrNt71AGBT893mphhf+GfQyloE6syQI9fDqSubLYUx6jEJyk51uQDUfzF34K/NCrbR30SDXxEU5IVX/XYGn3/U9xqaUhgtOKl1ZC3Hb9V72HgZviFOD5F6fvCjosZtFEBNR3Ec10nVpTfnYX0KiHqPLk1XDcMbhXk7IwvvSpzms6xjen58KxX+POXcHPYrYM6j5FHI1QuIiXiScJ9y8zcW8rj+wY7+C6yncFAOLEJCnakFjV4LFZ4ZUOCRxSU0tUaLG8Uv52tFVFZlzHkqmfnvf/0jW+UhdGW6jpoI1CVvKHTlATFA1U3tuaUnvHXTgS/aona9QK4gKtxE+JdsYD/pDkIBozlA5FCVgKUtco56WAfX+8JoStk46ljDNUZVoOP4wcE7cSUE6KqiuqRwoCa0e4fdledUdLYLsi47aKFYKZp/Kx5RlkJI3vDhXV1g/DSwtakk/D9CGfoTMdbzaUT8ocR9Mppnjgj7e+scwO1b0Kh+e7eve44hJlhm3JvJQRcrnAxBUtMUcjpZ3aVBtWWZ5tQw5BONQF3Kb1rX3682h67YyGfS2wB8O7lXIAzgAtUtuqh1TOCQr4YynKg4vp87w8fpRYNvESp22+pngQ2m1lhEReIZ3U989bHaWx3fqQSaLqmdfZujzjPYK+/YuirzPJFdsgbBS1HQjNWoAc6oa2luFhNbO9M+eE7lK2D/VHwIY/N43TKWqkR/IlNS6LHhMQk+ebVfF2mmtxnXNKjtMDtFtZZEF73Re7OF1evfVGUIisl5Af+FWslFiS6TqyOj9chimZI/WGJe7gX4+GtmF+C7/JF5kNhcoqyQxS/+ReDwvyLYStNZTs9E4atzOndyVc8unX/aaxChaSHxLlKdzDlmvArqJvQHTmt48zTnaQatrC7SG0PJZmdqefjIMRXM7rQ+uUrSsNSc5cAcO66Olt0yqte+gvCXUtPValV3XbG7JXjkVNbhVCJhHHWW8IbYIAKDKFfFtjrPF/srJhgvJAgyIT06peORXvtaWGXDiQQRtY+FnknfiM8ROjZygj0vNQDRkAmd4OR46PqQ1NJ/YwGS5T7xj7eaurShqLvk6SIi5pw+hN27g4QEnX0xGz3Bi9ncGlLJ/rcQ9OO/fb8oFAUn49K9j6HLEXGHUMBhlwZEyh0gEckyC5BQd6zcI+jQoRNQSMI0HLik7X6oJ0mVbhnKQGAPvnm8XNKU+ghQna9BR8X9d/vSu93q5nYISdhsbfaa4YVjGpQ+d6o9ke4hiwpSKyRnqzz43r+zt5xHnbVHYgg4y7LHcDdAIcJx4+WpDFOFietl1vhTNP09eI/ZXocH/fxPGnB9lxvkJTCtxIvXFBZy3gDBPKls9sso0V0Fwo46qWs3r0NEcqFgt2qFLKmAo90JcqdRupMquPDuWnGNSZNck7OQZcYYV87MMKbOC2wxmeSPoDvUsQ9PgPTB7qQAcH74BclvMaVH8xnEHXBk7PNFm3Ght8dPu25BEDmdXCEX6kzT+zPoeshV8Z4Vy0fKHKmfg8Xqm1ZwPjd/1DyM21Y5CiukrmaKb8icREwXMLSFVMENOL4UOIUVs4yUBj8KYYAhWvgEUZXWURboKxekEYMaHH8V5h/bTDbn3/wnCxcf/GKUMYvAhvcazD2Xf7ROTb9+fvM/W8WUT9H6NRNC3PWAtlbpYqilXPtFJUJnzaeh84Jp8LHf0WNQcws/GNIOE3vhteU+Oh8lUEna6sLKUyh3JHkw7ert4+ny2nsZX2KHs4e+hz+PKajJTrdJQCFpWffOXHKYX5DFmMN+tngx5hnHqmZw2hilvrkR0gPfy1I85jTAELDIXXDVq/OJyLvxk5CVZm8+Zt92Bw3OcEOiJ5Zx/KhR3YCRg4jYNT5Nmslt5+EH81aM9ZemSsKJLyPZ6Xv257v0vuB6EV401hteg7gW+l7lTrgzS4cJmGoisfnKplTTmInJcQQgXcZL4QI7m9huzO7nSUwhYst7qsuqZxooRhrtEotPou5HV4pn0hFCm92TfHm1UL71IFwCArFR8VvBR7ZMdQnXdWqNag4wzqJCF5Yv3rocNAmBJf2pkwqOheCwGHUg9irTiV7bvf3fn5bfsLFdygS8D0tJdq5Veb+kJOetvod5JqkJMglivyn8QpqbBBtKmsU9glpOarwu8AKr5ROhi82VpAIUAMc+1w6OCd5AkPEbkCmHpgExgnbRWpXc6vxYwlcnI/toWVBfcEZTzgtQ3Yw6XklxkMN2liSGG8n1KXK8lj8leAgnBy8WRtyu7SIKBsXdUhjJ+XCdW+zBFH+ukmNXjTNRpBhBq/7LY4xaR5BXB72TJH+AW5RSO6Tx691tVB1rdj+CztKRz/0Nl68zosVellZOOypb8mRWyfk2NB4L3skT1CvLLrsUfurGfBz9eoCUO9lTj6a7yDxdo+6r7on9F1ON8Ygl35x7GnXW6B9wAPwgql5g0/79ZlkstqP1w14dtkKt5nRgGPnFZ2YY/zYlnPsfiu/Ex2at8emuUBZK+7pqJ4IHQkLoeyENdp/LVnVr+/b1HHgAKRnscer01GU3C00UtXv0N5yl1WqSdkMS8zmyI/wRAC9BESPxTNnaEWg+ScIIWm7lU7LDABTmuU2DCqR4y0RIO2EHSJMYWGvRLwQ1jbAmtwoC+FN6hV+qODMWlIfx8HnVOTUG+PInVlBW2X1vWLf5ddv3vMWOfONZYWTHdniibWzzihjQ/wK6zmxF89Kj4xqU6SQ0k/hPECrbBIWNgs4wOMtAj+s8WroAWu0ELSjC6Mp6+gRIOisXfqKZLitLd1OJNrSkptIRLo8eRohxBgXW/6lgcuz9qGGlcMOUOA6ezEzl0vzupSQZ6oQm2KLwjZh1xMRTGF69/EBQIWaAFyvwTRTdZPOcTpQQ6AiAKWK3Ps75oizeZKRR+/jUWaukZsQSunBJQJQ1JVdktD1QJy373AdBCz1YWJnAwbmD+qGmuVLfktVzkzdXDEIAvA3dBVHdQG8s8qCGjKB0MIHjrY9YlqbvZ7OTdMNfQHA8AVXGwlDrMleLJYooSvTQQ2EaesNr+a0sbk8eAECuiU0iXaCoqzerB2vLtGXaoNM9PS98Xkb0UO78zZLBICAHL60X49I1xFZw3/yQUj8D0Az/y5EFlXsH5eiBUHfVqzCvhJ5smZ2vAuN6KFkCduoUliZAQVeXiKMowBLhQHuVwbg2f2dL/LsVdNUqrdx5VRwSCw1lhFi4Fxm8gW2Lubz2dPSbaSat39ebxkEwDrQWSt9CXWWFvLBt1glTPJWncrSCYclZYqLqG6ZPbmwH2QPJil/c3edBcXjRtfNA1b/I8Ju9yOUI87PN/AJNnHfUJNOIUW6lGfGG1md25tdogFMaYchG/3w854nGt+/7hK6SL5ZujRMuPLHF0E6spFTtbvSNEuBqO53s6xqkbZP73KpW3KwkLzQhQ7foptv6oWt5ZtaZYo1dIpF9Que6QIG/Ba3+yEIShIL7RmEa2vggaztQzxklaOO8MEgPoRsd/+eLE7yhuj9aY6AmxJmu8DsPTUosfE3I66V+MvZuUAIOJk89WRlmZh2zmIFOLYEWTyUE5UpWT2aNCoKkxMLwZnNq1kufJsSgRXFmH2UP2XHX+yuqqusy1sqJWqyRL+xa8nsia7KS1DtZdlbWn76UNQDZZLrKKLsSSbIWeyMm1xnmdqKbcBuMkk6mRzTAA0MaAcf1yVAIpMdQ/k7nILyHDxXZAKivnPLJJl5y2ESUVRNV04k5k3ul4hxtNEnw0oEn6QoEdTQYHuHh/SsWwQkJ+/YiR5jqhABbQY6aQaapvxsC+70QEhwuknhg6MPyM2JcOTd5uVDVQJpDjFWDikBABqZGZUlzQolCRlG2kVoIsvOiGClUC7OmEi8dFF36ybSPzK5lBJxTC+HDnXCgTnvUn5Z7g51PiN+3BUL1DITB1aPJm9PN4BlFMic3nFWe5GHzS6LUAQTCIHbjHCs2E/o00PYgOHRVeLpbjGXvBFeePtZeIdoJ7FZkUgq7V2JhOLgSWZmGedF+kaZiyvhiNR6FPKThW4Qj/KiRvAiJUnoOImQOHP24cpCiu8YPZTWlUfvo7GOHXDQVo5zPVUjCYCZRj0cVa3Dq7iS/09pspZTCAbVnYtInpw/3fuuEH2wADlDL0syCYCeI7NkU12h5L6jOixqaeQ4OHHhp63NHvvX6eQpbfbDgtsgRTfpW2k7cqUUuAgOLzONz/tkrcaTi8JKFLgULovqeQNnL2BMD2iMZPPPqRKMa15plpWUpdHgZN/rp6Rdo04vFZwYzrVQv71tEoI9OXgxu7CzqMjrgWwiozy3WEDc4IrBXnfwLBJxBJhOFAtgm2EhMSNdKB+GPgL3o+oOH3AaMB6QFwp/MzgujmX35+Pd0mtVc1GwyaGgtwzRzS6aW9bCQg1e1O55aMzLaWVdMEzev8F1QHfKUhQ5yC9jajzTgBrQY22T1xqUgnB0x4QwWisVkpicK1Y96HTcSJ98u6tgA2+1Se3DTOpJV1dFJXHMEB/F/eETXJRqNWFYXn8iEWda2rWbHpWuHnGymVMnCfcLbcgK3AklXDLqWj1A2bl/G2Pft19aJmca1JYLQr7F7IA2tN1psiyeiYzeWcSnV45NfT1Pj8Ojhm1sNNvbhYCNQG739YsBDcm5R4GEjSucXg50gngin8e6oJMdscAJFnqm8iFS0ISipNa6EkBBL4Eg57E6kKcs5p2t3MYnVnLU+2cS7jQBq/lGcwUDgTWHNBsqkFH4Cj/GwUo81oss4jBnVk8hZ794tRNXi7Bocl7s0zOfQiHlDc2X9oW5+DokAyzDSGdFNI/stJkjohFhdlg8+slIE/733fZmgNcjbRILs0eBj+dkpMmHTrZr3mNv1zxvsjqpiSwn7bKazeZzRkwRkWhfp4zLfIovfEt7QV3wcAj4ZHL+C+eubig+GOnaP8Xqz/I8Iz+DZAbEn2hUY3WWeIzL83xYhZw9e8Djr+DToEeYgFuy/tIQTCVr2+Z0SsIskyOtv6TjQlab+YGG5Bm3/XFLUSRpztEhGgnGkgeeansiX2Yu9r6T+meBlv7TZZxsP2Dg3tSl4SCEVRsPlLdnpGNsTeS0sP1w1yKZbQ/dAYaHVSYLX6PR/MKUnFE2qI5A1hc6SbuPeY9ZmnmR33NDRy7lLBg6eQ0pqzJr80amErkh4XwVjvuQFeCrrIAvcxI5YXjyou9sk2DYECFGTsHyXLmebOlONNfET1I3DKEcUXKSYRL2RIABeSNMnKfj0WP9cJZKME2HAwaicie8WCETseQwbOCYQdThC6QLRtNTW29o4sIXLp4ACvOyBuqzs5kl/dS5j5yfuYKszDFBdALWY6AKt51DQQYWE4rcu21hyGNa1fM1vrr+Klmb4l1znqEacVIKpFnMvlh2rOJlePY9Y/rA9WxZyo7Qb/YBDdwB/fqoWfKOytusRlsfOenwihvd00jSLfPv2ZiVOTB6xLEf2ZGD+ABZgtOtXEYiCCckfZJ+PLuo8pOa4fpPyzf9n76qMU8LwlW28MAgOwuUgQHmkzC10O4fD9zn25wqP8E+vtlolDaatt16aSphwVhSDaKQRVTc5XzdYePjHYebPHr+HTE57OTxhyf3G3aY2UftB27zqXzap2z6mZs0NqzHEaghiXsQjpj2mH2A3Refyxs2eZS3j+NkdJPfexCNenJo5IGI6JTSDAT94ONGauGrV1IRxSnSTfJ3fHNTm9ILSk7ydo9u+rhORj2hnVIb8YINdFl0APUCI+OBVU5hpzJRFKwPBLe9dltWN8akuimcFG+lC4QX1m1b9OJ0wbkDzMX/H2++fJ6P+lmewZz2pnfmt5/+qSh1iIFBIxTpFEnXkoTsaxh4R+7J/JeQ6KtZiZkqgugNwlU4/JUv3+1qWOTH3IRAf2wnWI7vwZZ0P13Whyg/N58+Efly/oyFORJu6AcSLbKVYckv35XERu2yrlBdmFF8baO0YpGV+AKjaGGdv3Z6YYsb+6h+PcKvxTFTCurRZuIkaFKF6glQpzNY0bhJzHKOptY0tEvJ2xaI9vwNZtL0UtH9DH7uHPsB5as9Yj7b5FV4gNXFSTMiN3QQu3Yq68WFASBb3NWmxLbRQ8cI4rIAsxl9KVzlb+QOQEZjf8uX874g1xIewxVE9FeT6CmgFGUFQIhKrRqJz+SPoSrFGaWzpQDE08fqLMyZJk5/rwFUN/ZT22RjR5zl2fyJeL7YyYiNGSYlg8xyzIPVZmDwAAAFtQlqUAlNuGmwymn2CiD4DQ4/lKdGruf2B3UnmRlmnbHe3T40AzuCLNpkzE4e9+yMHA6i1U7kRcU+uOQS8iaaS+4VIhPPKhQlYwVEYayQkIgKglcwE63DRKwOMzleUEw6Xn5UNRWLcG7GZiI2S7qZh0WOmOyteWJksz2TjZ5rqlRCrbauzNp+tCzLryC98Fg00YMXoYKbB6tATUqkyxpo1anLL3jMfLA8IK8U21vd/eJ7uLu5zM445HN77bn62a811hwW390UlTFAF1FsOhmnEe4nTSZeONwUZ4kmNghqMniXT/SHI3CDp4hLCEsb6akqWsGAcPTM+dXIFmcz8umq+Y6fPU102j7frZ+Agww7+/1OY8s+lXxTE087zDJdubxDOJJOQg1hyTw1MUtLZYURrAxb0mWeFQRpI0McOCAFpYGuKOrbtywfIkGn3nmrpamiLBwkMJ22+vp4v5/KXMXYyB/4Q4fvaPeJY7unreushC14fLsLQ2lTUXFzJDHxGjqFhTRRSJ6lBgIhemggYYy2dEJtOT9YzBkcUpI/fCfU1uQaQgGaMoCK6u2VDfuYH5P7UJWwBPoE84KPEoHBiWqvvsKkvCiuFpI3BsRTuq3wT2eyYw+r0XVBw2S7SDnRqlTcC2iTRhM2AzUjvq72gMJZNFIuDnj92ewNOTfW0XGM344zp/iYJ+ZyYEZt6+5m22nO1rWzfYh7FwAxBGmo6jTS+rrElWUqcj2M4kKG0zRpcldyn8xsj2Xz4RSZk8fXniKULzDYFkYh1NCixFyaGIh5GRsgmAkbKBSWFQ0YQrLQwHSkOlaYw3CQDsmA+OiD8tJEzO/jWZoCdcp6bawsT8Me3/Cb3VyjQcWzjYaFQl7eukoohFFsd+VWetQwwLEQZg6gkj5P0ixPE+qJR02ytBNKeGvkWIng9SLfFpY9+jBCc5Z/qdzTuYPlTiprKi65poZ8m4cAWtDZaqIL6liG8/OHTamheNOQUn9iGWcb9V+uBCfk6ksLuiX0pi+VDuJ8WNznOvZQ3J0PqYSCFl6kKMA2Op4Yz4den+GISmX2OVQZLTwWslP8+bQFiOxEemk0ylNDOlTM1FPc1gJ4P2veFJjiDwNO2fzLMmcB9XIu3tdV1zZRxuufdef5nQsFIKWXIKhjyJT+UynPjNwA7DEp1qPW09TKhjp2r45w/uDzEjkD5wBFNJhPzjRm7wfbcVw9kuG9mFIoxRFlv8bqm/s07LB6ZR9kP7OZdGV3146Y2Zc4DQU0jq+GsghlYwgLeF54Q7tzqHDcSwzu67R/O84P+pOBpNtpImBIUX18QMq3oiqiFU7y5Nno120y2sOcK/aZyRkWeocI/YxldWhHFluZZ7E2uB08ABelwbHKoJprZMgjCC1EFyWiDFgDIEyZEw33vN6a9GcxhJ57x8Ya4ZWXDUUWM4aCOvn4nfElo7ACTdCqrYdfrslCa3ur06FwYP4GK4mI5BQTW+hhN/TbORHMFYJO4twZEof0pW4deMiH0Q1pSitIzthS06h2LZRKMSs30NO+/co/BC9S8l1jbAbkLdNPACdk/fBw01/2nevO22o7OnY2WPtEhkPEp3SV0E12TS/EFOWeDKnrGVwRWYso9kjlJu5dlUZKTlqUwu1s5GJvdd3JlnLggERZZ8lJygSUSBknv/DCSJO36gZVFq8fzkgZMBO+0VAUlPypJMmfwAM4BM8pMj6JaT+Yj+WGsoF+fV3R6sxzilQ+PcSiJlwtkomunaBDRe/BW+Ng6bkZBeoF8zbj15sDGGcZCIM+s6OekKQg4gvdMdZXYglFSyZkhvincHYaSx67jPZBauq0lGyTCgAP4qtmSgh9UDhin5qPJDJmxemTfR4OGapjMhOYaTg7dtq5qWymT/uhhSJuZKF5ci2tVBOyfq5Z9MHzFts6Kz61HJKBLYpquTPfpAGhN1iJYMMmMKYCNJgjGtgBsYyv5p4KFOQU62uY20InDf9Td8OkCe6MBMFovtftJMNc+tovW+6MvXqYx37ysiRSB+gd4cCJHW3MZPYcTRKM58x45jSKKdrrqo3aqhjgAjQ+N5Z+FHj/dWwwUr/LVVlyJQ174QYvZXdAGVotymuwHj86asmVhT0r4ZkaZF86mY5b6cZ73Bt1px4HxLk3FBlS6t3Zs1rXYkq8A6/y48/77iFFo+v4HKvbFIaHfIFZuP2I3nrbE46me8YHqX47Pjw+H82H/SgLEv3FQ71XiONXPT87DzT8VSi0KaqU5QLLSI8FhHblkAWwBIciFvCKwEzf4E9n5ROS1d/OH7UfHn9VfusetGqqx0P3+DoVz2wyzo8X7nG0W+0LPKid3lG9IljzCN63nTrZIH1DCKoSjUPWeZiV0NwQfPr9Bjx/U9yMWfj7OxxljcqbTLdMSu/QRg81amMmXaqzUQBpXFhN1Xosjs3U3GnuDV9aH5atkpv6dfYithtL9vRiUkzdJluBckQgS1HqoAkYYeoaVp0OckfzCCTAVVUdmGgCQwAfK+KIz5emJzK+DEZ/3Xc1iut0V3nL7axcvbrX9/OmcHE9DvYPC03OZdmRp/nRXz3qqwcHPCd63o9sdvyAxeBvKZfsa9u+S6MUi3g5a001Um0x6Sgozl3cQqGwW5vg7YQv1ugtug+344zkwfHt9f56Ps3X49XqqvmFQ+DyNqa82Uj749y/U3awC5U6Vr1NAVzPNicQ1OznSmrT7DyODdmvWM5X+OB5PiB5cv788fJxPdMI0S3ORXQxjnJohXzdyYGhKnK2BNDEKJc+1WuvNJj+mtUFeIWmNBCcFP+yoX+VWrsCn3zaatVypaVWAaeGmJ/0NogZlW2zeqz5Dm9e6/ZOvQUEk7IKHii4qG0YdRgMk7kXAo6LY2iDOZvlBWv6DZcAP9ig6D8qgtbe0s3JDcl3mCfTUauYAvTdb4AtDF+nhczmJLi5olMFt8Bx6QoG7EWPETWGHbQEjG8D7JHbIeaO4tc9S20hmJiaElEYNyqXEddxQEIsGwBsYT2Vu3GQ4Gmc6EV1DPjw8BVhO+BD1B3g3r4JE5687M6UqwVmD2ZWhrjtkVRjt9/vWajiF2bM7sECI5xQYDEWvDAV36szBTuonVasH/Up8Cu/W6pxxmSm26PGTn+IMHuKbLbqLlao2ek+yoy7qciVygkzlWeIaZZBWS+Ht8tZwEAB5c5TRlEV/8EDmmOfoxQQlFx2uOsY3Z3qUsw8Aj3S+eQzRqkeUFXX8I2dqoUL8zwVZULvrcUaVLKIHSp5yDHrws27Qp1KpCKVLL376/ngc7q+395156z12i0+eorsGYcfvMEtyXs3OIon5xllkkQOMwc/PJMmx1HEBM7QID3q54zX9NEcJTdFvNbjCXsnVInoYxb+4hFH+awn9EocRqc4LxDZ1mevRjgUxI4/5OmzAaaN+XL4jiCnD2uGEXzBNmuOTWqQwsLl26bCN7wArNCiFjM1vXXbW1Poz/vTwhFf7ElWc2i62h8o4EyMSgH6fFXg8avemaWh01U+LQA9cCbuFgi2mn/g9RMrfkrpBONvv86S0GR/9EYDo/74OPjZPn9WvhifHklfPD/KW+QZYsmyxlljTjcY1BYDlH7wWFTLd6wZ83RVQ7KyMVH2+rLv3u83JC+u37/+8PX2dn8bwqgoPDD3jnmVnrRm25pYdPciJVZoIIRO9+XdAASV/XzK+sjaYly7WKX0k2+uDlueDWEV9y10XW+b8u8uDkBedu/w8nx9Ps7SHWLdgMw3njtJnBo7/CHaG31WPJf0jZ9lgQ75IKW3LFz7q2oJRtpzaIx3fwK7cmfin/zgdhVBmECuqMXCvtAD4cVLJCtb6PCS/vDlL/bw5vWnx703exe8V3AVHIq6M0iRx9QlE5Zrf2IDiGkgKjll6JW6CJ/xsM2zje6avu07aHgBp2tHlLzFxrYX8msTqeMh74jfXPtKlObMDMX9MQ7HjykM913zfIp15xeAPqS8CbjH9ZDvT2T5YuDVi3IL/NxhuVmaht+q5ue+Yo1hWysTK2iOG9HpgRyKLprUkwHW07ogYe7qE8POIAiHsEznKqkOVrKwbUOy0t97UwdfiX60M3fuSD84wyWfYl7kCFQ4dYwJASkmUvKnPWyNOUvN1AZW7KLXLtecjBInJNcmg3woOBJIiiwzZsNR56DRXCWc1o6wTmO50+Y3gVTJJnhH6bFxGZNO6Vrz1JiojVKXucUoTd9RVibf6cqlIS6w9zlxRTo0BOI2cEFEf02jpCf7CW0L8Ui4AgmajmLYft0uaX5i8J3ZfpVHG9aHbVDvSRgGJLJ0GrhGLyFOurLYIvXdnxtanabjV/mWGTEhx0v3Xaxt8a0xo9ippkOH/QhQgFh+9TliOqfthRcBT1+QdAY++2cg9tAZQKb1mYtce4vsbsAz58weespM1WXY8qTD/gYwmIbxvgyQ8P383tBIFn48SNQ62HhI1KgXmhVQc1WSXxBWDIcBaU7O9c/dAii1KfVitR/ZNoTs4CxKj5A2l4IBjBjuwLg4Sv6343t1w5lQzbFRKUwko3CCtcKzBfyoACY1xoasAHN5lkHQh2LA5SuTFtF+cZ3BzkGfPeHA9uvU0SP6Bse8c+FDzs8EdHfeOUoD4eCnbFJkXqRFix87xig1zKct4CLgtc8MbWY057W4ZJDAx0wg8Vvw9H5oSbfB8D6lb+zGc1fMteYKL9eVlZZH30cE5xLBC0+g65MQ9lDyGzgxDaFlWD0LtisW4CfdYOwjWYHfX2vBt5niDFuosHTehyUnc3gusNTLLcuVD4bSzazPGuzW2dwFxLQuA2zf4HoSoeaZuDCFpAqO/XQcuAhE482DA8ojKihfapH2t5RZFq1ht4tk/U4XNBBBXIqPbLVuDMnojJ+8W066zBCJb/3jAH8liaPvCTfSo2V51smmvJFqMmPV14YV4aHNWu0ETdUZAWniYrQg6R40J3Tj/UmzZsdl7l2Pjr4nfQZPVgyIxoh5WpZWCrUbzsID/H2s8+ET1Fld8f5D39Hhnj7KHFIY6elh0jwaesxzPrsTa/WK2JAv3OA//coR5OE2jIrXANdp0CLGQVQjMPq+78lIBrCEJxJMiAfhcfk8E4Vof1naQO4LOUr3l2sSIi13JcQkhQg8/vYexPP9jTnCn0Z7DoyKvlEhfc+4xkee7qIHnoJATBVmNwGAeLnrz+LN9WnPuMrd2EKi2ihSLXtzJpsqVSYa/SYZC1+GJlyrE91/CfAps2u235oOAc933TYSK4qzlNXDKmyjNSFs7yT4hJDe0sVhOSJKccXNo+2X3VVtnfV5j2coxMgAMiG82qHzrpI/XO2QvsLhnvK8uQ4QpzhxT/uA1ih3b75vVFuMpVlF6ClTqVb7IhKTPB5u6PnsIgztS0W19nKl+SNVXRK2a8obpVcalqouCdvVR0fplYb1Viqg2EnZM4eDN3AamBOE64yntv6dlnetBCxr3CmV40GKDBkBk5OwMPfJdkiuEanAJm3UQcX5CRfxGyIJTb7VWxgJG7STbGShUClNj6DIn6mD011w4odEmC0ton9dx3MFKr4TVFt1DFe+2vEYrvcxCKJGnIVhRYblzpFB2ahbS5Yc6gpZ8DUOk36r7UOPvhtmq2ajxYz+eOZgJXQ6DbaFvNMsFCcdRfdXxKIIcfBFPm4fuEVpl3FmwaEVrsh5YkCgX0RFOcFAbUs4jJggENc6+uuq+hFS85pDNyy8HoV+ivd7zuK0+OwIIkp4WdyEg+fCShD2OFainEE4865TpiWau5aNWyd6pkJIRzRtovrT008ue8h2zF7uu8PnsfrHYapjYbpFtaamZynW/3p+7fw3LgGx31vd8bZGrkX5gU3Ntd9xTZPfiftkg/8+80NRIudTU92Y2NZrm7OF31z7wL5Chz3Qn3vHGp1OGf+5d27Q5VzIn3l3+buueLH4vuX8zzPL2iK4inv/Mv7cqhJrAsj2LEdtNrOZIMqhlvU8lp1pc2jQzpitgxaaoO5tIjHUAGrL5TKRUMBn04e5F30WQgvTVFA7edb2h/rmR5SU4VFM1rw9wltEE5SWfKrrB0/ml62U0LuxoKMX8XqDAMToyJa15Y9eQvcYldUJn443aa6Wz07D/cO9i4nofnqbAuc/luhChVWzIfP0bByAUOHaN04rhVN8lc6bqZjAxg5frfaHuLkdLwla7oAQwDnn8lTaLASK/NsC1SZb8bQPlPhdflQ0qlPRHH6/FeHmCZIwY+V+Mo7jK98tFwsVXS8id3B6IribZ4Ctz82y7yQkvmtpIv/3bm6S3ORYI9Bd0iXhX4slRDCcC6CgfoR5LG8Sum9wx4KQzRyO8FGsr4FLKLuMgCNP2Sd7lFpwuf57eP3PTsp/9M9rMV6F4P/q+pNP++ICL/3qGWP87+QA/8sh8Q/b/7+tbux8ID/393Of63z5753yQgXUH83mn53U5pDrhX/KeplND83+8R6HYqTp0a9dm+sGr9RufgYbfw+ZL/RF7NB/WD05VLIsqxm5nO+Th4XbYiYbm8YLFm3MH5eEdeP6j2w3w3bzP7195O93v+kdrH/Y/2bEkBe/UQIq4mC5qxe/o1elLjH/v5PRmy/IbYU/gvOI78tL1oHQ/v82LDr78YO4jPIjbPSTc/Qj02K0vHX2fF5G+sI22AuP3hfYh47wYx6yNbiMDI5tbfw8fvRh8efnJtryQ+zvYPe1pbKN/MZkO7bxCcTX/devAFrA6611VRV6RKmQSYV8HpeakZQQF4sNYwE553k+leeC8AvVKmxnD6d9/m49+85A3RjseZyoUtmhOEbEZC/hAORJCH0810rSl1XA+rEQ9dRLDDr/Ojbg3glEJts93WsWm8Z+w38S6da10DDofXZRAysM1vZKK4ylGfUEGC75icBVVdDu4RjRP2PvgP0pV9LwdFsGILgMhAGxz2tsp+kZCZMyTOZa6kowBtsxcd4JS0JhDxjncQHdvqImMOSRybzxDB16K/Jrxr7n/A1XEZJqRhpotmkznDYjkVQxcKjKnyJBYRpxdJaBdGVaaTD4fqZ5IkAMTsLaX2cwEPRiMUDIPqXwsdpHuNtrrqabUfykRDqYxAk1wBH3eLj6TYIr5I1dmp5J+XJN/vxGiZw1hZ81Z5ezXufx2g9cIRPbWAUvUCrSxyP0rLiBoALA1kFkiSC3SOwNRhOJyYKa9WDcRtDMcSAH4nIrHImzsalf5ZMdjr/oLTKKPpYV8F/wskv/yWKcRImgPhB/84falEMhvISUmnXMIm3gT5XIIp/s/xHRPd0Wmb/TS6sIG1zyNcjdb4dcZ7aSA2NT77t3kzWwP6An9pYUYMU/TVnTMb/GFhcQmu5sR/nHHzPDzyHefd18t/7uxBKfwDa2TuNf+2qgaVLzdFf7+dEHFVn58qfjbffJOsjLulZ/IdvjrnPnXyZ8YRkj/3gbLgxMtvK+SChLH7SbkVutMvHgDJUY6p6kVudhinCo++kIfPxxHP4MNd+sv4mvw8f40RY5yyW0I+HaAwn/puZZ3Mw9OF0r8sWASeTdvgs8F5jRXv+ahU3eMkGZP4qIwYX0smoqyDlJNh0zTo03zm9YiyfSDqCI0PxACxRCnAwd58jdG2+/3J6iZ9EsHMLG5gq/JNjjEFJRhSfAjvTMn/Pe4rl7JFSd/ccTcUQ78pdO45cxDLlGYayccSMkWYsZVmwnTIRZvTJOtFDp2qodhsuIHOQAEqDrzcJ8wPxVccfo9ruQzHsZC/Nm86eO4ltJwQneLwJu+kbz75xh3CoAeLImbs6S+N/AtY4y94c18xVvblzjsilN7XpV/FZuAftu4TpkZlKvnckqfSjtmC4OnzMAjCBEo049IOMU0i7HHVewLgOmkLKQAEB2CARtCxTRQxt6Y7d7ztvbHGQ5L4NK+SS7cgLgqAZAOydGqiw+HR4D0wgydfaSSzMk8emqtcq3GZtJMirFagCdUDkq0yRbLQldbDplNq/M477DHvJrsLxFEA9XrfEPANG6dCzwbgEDRUOagN51Fm5jE2R0k+beoYs87I3XpQG5rGwXznr3H57YDe0/rO6jDpk9Imq9qWH3z0c3WDna8+8263coso/pVItFxkoVwrXOWg9XqA/QqCvE40a+9z3Wnwbu5yaq/LFAzOtOc8W1r16r7tZsFZYtHWP7nagH9ouQJZauh2tPCfBbHWM2GQ2El5pVoTVGq4+fS2RunxtfdLrAXltQWajvIVJs5lw5tdNX7WCsGa0ytpxn51UCaw3du5F8YW6BSjMzwN0exx0Aafqy1UxvCfyKRaEbkqK9uM1h3y2Hx2d88TjfPec45G47xeU6Zyk/Qq+8MQpAeo3faSbyyJq7MNcs6C7U05iEhx+aFNWzmHA1XwgVUcx4qHj3llOTM0i8qt14VsjrV0lwgAVWaPA1l+3KT7E576giHClfRnrFbHefodazMK+wbb4T//kE626x8/09Uhe7Sz2nONxk0a00I0fvceA4OGzJHMmGH4KAyVXI8VjndSjWuGSdaDq92UVi6sqaHsU/vDj6Xr+eaNxMGRFAKxRQyJbvfgs2f8puthMYYjKaIL3WrIXps3ksBlW5V8AqaKrUZMYK3vxm4PNqt/4qeYq6BwryTQvVbvC508m4ykQyMqp28+W2b4IO5RzivXF6y8xZtBUWeH+n+SaMqeWfiUangXu1fxpzf2Qp619UkPX3jO6bb+DZ/ykf5XSWUNC+sF3lq/qojaItpptnM2iqlV/xAnVVAx3BqOsHZrTRGXPUzhfaqL1+5ZjnSJ5dvD5fz5PzXLGeAMMZuro26c1qg/vu2rzGX4bW/9VbrI+evQ7f/RXqWmf04wOYH4H1EBJteKqvvketpNsWfhpr+mPjXzfuLww/wLhLnE+nUVVNtS0MXGkwiziJkDFZH1E1ONNg2plGjOWtvL5fLw2AQ71+PIwD5TiwPl5T0Pxmunvwp5fw3dHXfud7dyIyt92e4Wa3o1CdDE/svG6c/uxjRMBfqww4pGQdN49uuiN4dDdmjvqOiESy+PNBoee+ZncBrupIE3yvbr512HibOQtgO2WN58Zssj01S69LLWcaV+Jo83J+CGD7Ow5kgrody7GN1O7fiL9OJyEUJmCUpmoTAtlwROLSKZvAwrKpKxhJes2ZfTt/sI8jTu9p8WUqkYQ3ZxASpx5+mJRW8duMRv14WBgR4dnCaIRkhhCfXpyRLLZI0HVojBEI2GoKD191T82G5YxJPuJ9MRxe9chcFVBoyWYCAm02yrivGUs7Ef5q/PtoZGziLaqvv41H+fjqcf/3808uDtv4X39oPa6PFF6wTnXfCcY890GjjEs/Pqitr623tYsLPmo3mJFsQXb9hwiJaFTG71c0kW6j9WFNG4D9bE2bNSRLkhQW/DGeEYmbQr3MkDKlCdG45Mjk8LAAv3//Af78ef+eXdvZ8KbBOvymiXr/C//etP9rHGIKRIFuPIu4Kbr0ddq1Mn1+YU7QD2LmnmX8OBepUun82FrSbYGqCfU3/7oxMpgLoUZY4UhBWANy7RwSLm66iilUcEzs/PKgV6DvGz9iTJmN4x1bcnOsBU1GLaA+ZGGVAoBSBoWvGEKJlVcv++wS+z5LdH4ej7f3kiX1P/zalC6cZkzaVKnHeTelFksCEyexVTchtpr5nBdmJMNLeY8njP9ZAukDSZGMx7d/5xPvenC9fXPss631G6MZlKa5KMYj9R790INtA8DOXu7uSGJPg8Kn/3zuQx948Uw+Td6ugbEzb6eN4vbR3cOiGBI0ccDpXZtXUlu9Kngzi7bWxmHVTrbppgDegn8/t26ONdrLY9QgTVZG4/S6cfxoUXbmnM9fTfqXawuF2ttL0MPzhWcmCIOnoZvnJUpMp/BBTCN0ejbOxs/BO77+63lwnMxwWsdhLtj3Vk1QEEphPiwI3NkbBLXQBdbFcoMNp0+ZEgZsCCXKU0OiYsKJDcg+TUtBXEKJw38RWVrlnCcGWKeSzOOGAL0t/PaZwFMah8b3V6no01aNoO0lbCVc+KKq+0WKMXzYmIlmNrMCf/IjTPenNMGVWiOu+cMizE63IpcaHv+wBLt7kyqpecQ/2N8ziZbp0tQAKSwAmLUkVW5Ko7C+U+AhE5nxdRvmnKbQdAJhvsvWHpx2sILRolV208/pcgoIEq13kqrttKGKHYW+b3ocVPNIEgpsZ+a3ShbaA92uEdy3Kli8LaugEM/tGYGmCP84Uc3ZJ2jLH2JJzFOSKe2Vk6lP2N6pcYpzvgY8/iuaoF24IDP8W/V7oNo81737wFPxQrrQqrOP5TRpWz1P3gWroXfP815Ui++G8lN2AK67VKjSmmSvFl597Hk5PI13CqWIV+ki96ezpNxjZakhp/WR2MVjxdGY1N4VW6ieMdG3UZwZ+i7yhmUhMOR253BbWUFpifC0KStnshjZUqktTEpGuE585sbWLrTMHLpaJLaxsTnvjUFgqUS89zzVupIuhNQa/eI+XUM9sO+q72mKZmCwrUxi50e7ZHhVlipZ65aqBpcSqxUy5Bgpc0O9H5N9EO2N+qusvPmgdAZlyXLMKzySFyIl2agRHkgyrm+Xg+zFj2sRKBeSdL2q+KhL4Atntqo+fGyx1OqvjaWD9qTg35sGWWCQc4ObpNe6tonpmTXRfxnnEf09NQBC7Fo14Y/r8/vuhF1R/uzLOVu4bhO5ixrBVT6+xIBwrfWTMUsLgBvyFep7IB6CZJI8wfnnHTMAwqtgFZ7mwZZFIvfam8q1qTUuHmV/mGgbqRC7bFdzaT3uVU2KaUYavCFKf4PTqBl2sJ3fmc6b+K592zu+1K5bpEOG9wbUtSt8NGLBO2h0AqYoiR55pTnYdk9vtgs6mqLwI511QfaCMd7QC5lluBlPM6kdeGs7ZKhBZpTVHwNpcYv2NhPxoPAi7d0yOx5A9e0/6g0tQxFfbBNzu7tUeYEw38DvBkBiMwDgGwB8Ku79q/DSD/eqEG0TGJubX+e/b26Q7ethGyK0dI9KrDzF5Z7WIfPtC3VHnOG2giI8ibnBlE6oRjLuRrt5UXAidGFvua2wK3Kmxd7WZuGbBgGzGGQdGmG2FqiPEFGuaBGIxRxiaXtkg5xom8p0/Pu9L1jcYRHD3gRKJMCcenaTaRkeCJ4KvCAQYIXHRlRa4RymA7x32H3/0jvW+zE19UI6xpI59IW4GaFTklUYASkcaMPFcG3U9Z0Lc6zeIj3/BXNZDel7TMyfjHjNv76G3QaSomv+UOejO7InPnnf47qgAHF9VQIdWpHqzx37dhTacEqk5OpaGPhXp+FHu+jmF3tMW2yWJqCm2wTrC43CCiPUmXJUru2uGqopfKp/9SWxvwJ2ZQ992/rvYSyOD7XIkMF0uF/TNvlLWqtno66Ez6jt9fM+nKQvWw0fNxrYYJgRxQypsVhscFVWaCQ4x1GW8dRZ1aRXD26DukealV2+PuRIJus9ZYFFRSbnZI5xgGz/y4WhyHlZLDNF3h8clXO4vHtrRdhWDWOMOqz/z+WXv/T+sT+efr0fhYfTamzA+Yfe9/Qtcb3pdJrUvmq/Ql9r3bCi7debH/zNjXUz7Oj4I/6jf7hi9JtEd38GXP/yrsi/cXT5SfbFv97K5GeVHv5C+bJ/+9TU30x6+ivj6/7jl7T65h/xy9963znf7r2+Df237A6/+/L5+C/PWX/K/97If0x/2Puyw42s4IP+1Qr+r5I69b8NDAqvWBftDtppi/tU/5ckP0669HLY03/9/E/x+Irf/nbn89t8WEPO39U/HvJbYF971cXK/u++Wm91WNFu9491/D/EN+n9sZ9PvXdlvSG21/rZ6uONdetWrx4fH+jvaG9sqKrMpGNRn9flpM0EYTTqgBvmMkun4XF35wAARtvQRzS4Yf3qtQetmZmeGl/1d+PKFZMTI0P9YwNjPV3tfR19rc0NbY1ttdVTi9OL42PpycxkKhEdiY2EAt6IL8KzTsElMFazg3a0pB4z4oDW1C8BEB1yS15Ostkv5/Ey5Xei26EbqiJtsqZB4hPZZ9/BsW/7h5PI58+KoxEeNxTwhFu2iFWPn/wf2wv1V6mUiuFBXyCg78qlOnnTZxcLQDekFNxOb1ZUPGabH96CKaB0f7lXls6AXDfGD9dsKqO2td8ZyTarswxzLcxLCqoSdIcy7Ug7WEGlbuWjdCtwgYSfJh+cWoV3VBuHgKWkcRJ9+PJNdwyBkHJNQxU0wyGDy8BYjv6HR9HPEtrCcvnqWxjyHFloYwVkFMeoQD/zlzDSTuUG/9SMv/lENdOyvUPMuNaS3kUrLRTWZ9Ba7ugF27nTgpAE7KXZ7oX/eksKFCZ7iK8pqm+m2WXOtVForsuq86uJuJZHMpr21gLkAIbvuPokfZtVRejLf4D28QIrNCyAl1A2ioMGgXaI9tkLGgyMpzw2X8Zn/llAGL4iT6yxQFHy2znHNPxtusY0PFuC42zA7Bbmh9EIAvNUZXw1qIGFfcq3Dny84jBtahxdLTO6hn9oZGK6kA6NNh4LzyptSUIu1YKrPXPCIHDjqx4LwH/3nN+8oyHNTY5pd63HoFxvW18D55TzqmboOWPc0PBda8XjmifB6te85av0ttejRETZ995hsr8xEV8sGW5WEmRVpIm4CpzOf/vnCd3KS08FaMjRJ4c4j4XrSvrQ06xVMKcU+O5FHWyRq1OwFZcXg5r373GQA+kHOxXOhWm22L8xEZ+nVfnKkNPF4mbOXPsuXMK9Coek4DSqMOUv/TieEQDXu0M7EwoChWOf9rXQpcEFlcNch0sziJ5geuK4g84gbHCErtLl6tSIhOeoAxwrLBYiFcr6mi65CYzuym0+VEHN1c+z4cDZni278faXaJt+/imzo/0MZ8bEfy2X4nwaGYj6vjhIJkRAnW3F0wX/83HgirxOrUAV3QDH4rcfwbOIjPNxasWD8RqBNf76qn33ZozmiwFZ/YECtG4DM61pD0dGhulky+MEflDbWAi1Scb27ATe0c+LmINNHXw0boRbSeBlZzxaF4SX7nLO5rxgaDPjgRd4hIuhfFSSF1ppU5acX4WX3yO908imkqZX8jjOIib32rl5qQJmvIxu2N2muGA7uMElMTvUfdxN+61oht0V8QvpMX2FnC8VrbMMdts2YjC8ZMnRVpioi1tKf0LbKXr9VrlzVv+y3vzxPLJUYZzVg7LL1tLWK1sZhydiMBWU1LXKGTUFvsBI+NvzgBhOIVKWA7gXOA4tcAA6GM+InTeKPE8vzBE3u1trRfsfnb+x9pEdU5F0q0o+QLGaqaZJejGMEHEYMj4kgmFQWyTplAVMOZNbbhwdPOL6wVg3Iu5CTR/WmM9L7y88AolnbCN1Q0ZxHVOdqzr6W73Co6y1XKLMGt4mXDr1MC2SsdbC9fGkCXNJHIZIqVi7IPHyzYG1L8D/KeVlWjpEtHT0Ew636sPyqjGwvHmX4liMXe2N/2OttSoM2iWryTQQffn0usUncWE9fFWdtl90FS2v+9+eHW6O3PpGcbgZLHoTa0Ko4VcKxTidfCOo8ptmP7FPDcVlgshm/e26FTujlqn9xFTlTGkWWuAPlCccRNmncIl3OmegBmj3urbnQknv7Y6WesNawsNk4gkqMIGNcQpCV2WEGG3wjTiGT2vOoEoHRm+Oiy886Ihc+Xr3SUOnu9WemXsrlZSs6iYSPmhFODRnYw4ilFsiA50SZdT7362Se5Gk9j3Dox5MCQq3Jv4okjXdk0qxglAFzF8GWKALv1QtmLPySZOhED1SUN/8jRLsgwfRg/PzQaDzIRn2vjiIjdUuXhK0DUX/GHLsDfN+PeCGx9OqvymPkgVU7EFfwho/vnKov6JJHgy3QnZZ5qPu5nwnjLWuny9pc3tb+tutZTvfp/iwZ/RfnrN+8n/YDB/je/xHZVuWaco5IeF8Zgb1WKs1qLqyyS4B8kKA8ZskjIzBa5Oartc0VTTbG+UDzlXSS+De236K49nx5YALhd2GCZK74+yODu8XBONbnMS3gwYTvS3qihiYg7hzipV3mbkclTkFAEOhSdNcBJ3dspPUbcSFEjq0PvJLb7aHUn9VRyoAC+XIQN+03YcJorEtwBWHXYDpchJMiSPsluqPnlUTBqClrLFRVhAOcMDh0+WlSFzWYKoFOXQ3+qo3j3AVvmZlw0ajWZKOluCVosAiCfrDCHzV42STTyRuJW+y5W+uFYklUZQo57Mum6/isfMsXo5nJyAvPM3MuOqKtPRO3CwCy0ru8QejcY4vIAZm2vJsV6pKoQ8OuL6anOLIT5Rb6BAsiOgFX/UYkUF5si6IU7JeNHxeuO4KvWnPZWUAAY40PFbIBAE8/fNeq9ZbWVRv+0NrngxmwK4jf0+6PQgBPRfYTLIT/6w9DjdBf7RQhTzb+xqTuVPjDaPeJJ4Kdy0WSG+8zbEoAPzvqTH7rvZzWuO5U3oBI69ruk5UGNrX0n8hsvLB0Uvpy3E6f3yETl/zeuErx1stpCOTTCLdMOdFgR+6qtPrs+xJ5q7PcWDBVOjSMJoOZNilSCz43IQF0IjwU4SZB7nwOJlHko3BiHOajddgxkHnZTWqgw5xKrz/1C0jMQ/zCgWag5eY8uRUfAMD91GdNv8LCLijjZ71VBBpcCSPZETskyrzkft/lPaX6QWz6b72DXHjOP9r1IaKqMXfSC9lZxvmeZ2lqwIwkmhT/Ah1KsRvxiNTeGH0TknciZAOQMDt/6kDR9w/LDILwNdvt34DgG/+5dFxZG2jf451pXEIDAQggKcq/TxVhLOVLuS+bHEQfyu6u7zBIoxPdpyXyzBuC4eWky+O7ES4PcTzlMOi0BalLA+U4vAGQVkSjUEY1wBva+zieIvDKQ6zOODiKIvDLw71jmenFkBgCR4h6ihvx+FjN/N6AU+JrIp1d4P9TYDxXx296cAycYbbT20WGUriRiGAGHKzZEdUlZU8CQpV6Akh5QFzC5xjIHYB7IEwJq96h8udQscI27UtPLQSsNMR7hVjoK5K0XJQPrh8koM5Bx6qAagiby+QLVUqJ0xRb1NfPsFbPVrlvLMFYBrKN1ORpQGkYWprIB/eo+zEfruBd/rDoSIIhILPv89kmUVsh4/s8aankiNaOvDOfI/+eb+ox3fkUShe5h3BywjrY8Z1jw1DK57majBzRD0TwDhX0MOC7zgFzusL5XNguzbk+RswfJlUEIfcRku5u/paLYhEozjaCG0IEgDa1aiPkPO4kL4iDB3i8PjAG8ENSv4A99SC8CF6S961e1PNDkDtgghvhXJRBO+G0q0R9KfWYUA5A3JzpXGAXl6vDo98I7LyKQy8BqxiNoYyMhnyvOXSPGWcfrjxWqqK5ZQG9CfIA3oUjyqKm6tchibMgOlVAOz3TMOx8kgc7xzoA20ELqMD21a/w4ykB/0vKeWg7OQIkmiJQKogl0iCPoFWXRYCmYPUAABL7iC5yPj4pISeqq6v1dDr0G/We6y6GjtM6+iy5rJqcD5CfSgL4116ENESiPN5DcPI7RdVFzBDgHwDTD/A74DpvRXJyzWugFRVQRZQD7QcykLA1s3oAH1rFIRE7D5KpkakQW/GBZj2+GVCwoL47ICaHOHNzasY7xsd3Vqs41cBz+/xGrTYXqajGN2V90I6TIYp0C+1sG30ozlYuiYZcTG5BSnaLbW5lPH+IZWPv9wudIOkged5kv6uUfGKq+yCb3xf7Rup9+Z7AF6FfniU+/WCuweJ7nu+tVaD+E7gia+wuHpwHmbbKwI5gs6B1RyYXr0MIckh8QRSBUA+C+P+QV5j5Cmuz8H68N/IYzCRoK5R14T5XF1tyBrQ0zQm8Qh3jDAlWnFEB5UuEXaThAfhVyGBDqwsLTqEKzGMkvJ9ItOLrm+MxkDsIsIMBDdGeDMeeYRUMMlSiuwT5vGc0fLLgPyhbPm+Me5F/QjiRhIPKRg6NoHHlof80FovTmILGKVginVJo4oWad2LY6yt2PbuIZULBZhk2YmiDzAzBvaFrVbJ+XxivAO43qO9Q6eARquzmgGBs927sgmmxSEXh3g+lqB7yPMnDQi497/AMwfUswNq5eMfFxNChtCMrRNR4D67DfSuK64nHh5ClVDG8r8csD+mgIaT/I/kTaTdyJQm+cwk7u1vTAqn/VfgC94U1yUI9gJmD2l5wRg3aH6nl8z4HKmqZny+oh3mDaxH9xz0GbSDn2xZMvkLVtoaGO+GibPCX+nZQcBRkGgReUECvUf2Ntj4KfJk7Z2utF+kpDrJ86BaM/MQYA1pUdg+nsinpDeFVU0wfvDDb5xlycoeVvt3xAUa3V30O1KdiZLoKGEF5EqB9QaRYDG9yE7B+Bzv3RNlULjIh+lhvH9CyYyEeL+YjFKgHD+Gdj6pIIE3v+BwoRfkCyMvb7lnCaxbPg5nDFWgH2R6axygjp+F2BE5MpE8S6a7XOsm6FRy9IbRMnOBVf2BAtAHkDlIjbM2YBaRHyHOgva0rB3Cg8q1nTAPMpB3gDwPLngWNc5J32kMT37nkF6+VYY4aWZSzRLQWg7tlpFGXgcoQDdAuqhdN5YGUJD1pcOAnEFvus+lNXYFRw3HgDWimsrCDvxdej0srpPRdVG+WMR6KJeAci/AkQEdkpLcFOGZAevaGXcTyZfIlIav/7d7DvFGaC4aJEeXfUDYVvuTgRYC3gU7UylD7eRYAye/G2NI14aodSikbqQN7Ywio2ABZ5G2zidt/yGo1/kbXvA4+vldRPUU0d7MroP1PLxTZYqbCdXyrQpLUsR3sNd89D3B44zHdnn+VD2L0z6wwGAdKwXA3DHqjwxZJpYFlIZUNM79hgUhB9xBgH6N+8isL5dxJ+DL6mcnH2dP6NqL8lVsXt9kNrwlo8WzAZjcTqaVYmRClY6fJVCTs4vBiEpVQm/Du0W9VMKR5OSjPzNgMyjjB5F4B0Q+OuOLkTgvibACz0fioSSuVZNnztwayqT2VtfLYgdbkn+05eaVLDCyjywK1knpmVvIT0A2OUYK3JAQ9nZ6SGafM8LvdMEzquK/TbCWubPXOy7k4uwTpfng68t+FXkZjDvMojS8NoSlSKG1SFbgbodQ+odwY2g3z/iAQNpeRSlqP1gQKPGONg/WU3iXInsC1slAOWsO8YJ4wncZBJJJzZb3qqizSGdYOeB9O8a+geJrF9QHeR42mVGB4p1sAbCEZJrDl3cxn6sc+/pTjI25Liilboo0esesbvsckOYvSmeDyIHO1AMltmY3bxPqYQr3aPj+xlXFCwkLVl4E3pz5ZDsozPynsE6kkqLP7P+R0gDkD2A8Lw9YAtojJMBdeK1IzkQrNK8erfs+1fKeZ+xBBrLV6i+I9IMV7hLje/cNPjTRAQEtrNIrRLsalDb60GLCzAFwbLVm9QGWDHCIvTOhk5j5r5fFLGuAVRDI8kHkYmhoA8bwecsdBZoTOAH8mnlcpLVg5pPbzGBoNOMIj2ldZ7aAQaCx4+9lnQTgrUwXCzcVvJiAW8MbMIcR73UNSKoB5LGI4LxLaAFwH/6ghSHZIgQcLF2dT+ioR/Sz/6DHMd4LCpuUYbeW6wXY9jMdW4aWS14nnIPu11FidwXsw36oixt/I1GS7zRIgVwoAUYD+47WwM7WeZAUziv6Y7tdRO8hlg4iGbLraBUK8jz46dLx4gXigVUpAqtSbYsCNTa5I/+y8QOBwM2S6ckNVwrX7wJBQC09GgRTxMVP8S84iLxyZrDup51IEJBb9JTDhwrOuQAnUmvPAT9EkHzHXlHdJXr7ibKTAvcDwaHA846sZBIbWZcBh26nzbYcUhoRr0WB5m5qn7EVqODYWE5MrBIy8ZB9w7/voXM01sP2LpkeTmMsy4ZWNhW5jDfklWFcONOPbaVBzhqd0qhkv9twhMl0TNP0fbV1Yy8BxJx6gGce/0BShdGGKWwyN5oEyBAEnWY6GUQHqe4JtpaEXDPe4Hn0VOP+EIOIGvmkmyZVKWd9v05VtIX+dShcrlQbJjO1FTsWM0xB++KtZRoZ6z6jaRfSWRptgV6vJQ5WI9GPzJyTGVhkeZBap1Oaq0tsFnQH7CO0SviaQU/T+W1tnXWzJPS6Buuh8r5CLnlCTYnJVTOLrAcImgEc32uCsb3QzDNxDf3IzlXomnRllsrcuEYeaxNrOHe28p5/IZB5bus0nB+M1mGr1kt81tqDHTz3mSIk7cOuXy6RMezFrQqEVYKBgecIT67Ml3qEmY2ZXgXzSnp1nOIMZ2K/HFPoCwgPjtm9LTw9cS6vCa48kxKEvWgNqxrvpDeSony6lJsFl4xVgfC8+ne1PKBfZYj2K6oxkF4mIgvRgrcHfEBpfCZSNNvvA/+r1YO8759eAQAHAQB/APs74LcrXQCsSCweqhXITA1emZeslpCMGlrGIy5R2vTnr/FXTr4HH69fzml4WUOglcnCfVIIpzNaZu7BEmNA3sm4iS+pHYWvI7/1DQjaHotHHAmYyfx3/uueRyEa+HYt48ANYJbxvdULW3l7reMAEZjR/Gf+A3+CP6fveZu74tzikGzcgzpMqleWtnKuqoWN+wT1+z1KzePj+OT8JNJbu6qWpN+e9HZr+WD4kR9MOueQftf026/qzel3NL09Uz6YSSe7bpeOkD5oNPYGrLr/0p6CuGz+AVIIuNgTxCsXS4ksq+571yxzy8Y5bJDzJgv2igtH69D6+smZbgUfcJsbnD3gEkP6YLldWcbgPh0Uq3Ppke0HDxgCnWs0AIX3X77Uly18CNhbJtZ+zM/PNHuDTFYUsTyLDbaNWkRfgwNeQL/Cy/gcrBLnaeH12z35XeC676Du7H2tvQrbSmW8Th4IBw4u3iouo2n2AawCjKP9KnhlgY14PAqDaMFIzXJwXoTwa1fuKxTWctDdIBcN7tr3+7GwAGwm37J9O3EcQOkIeL2B1lOM45K7cbKzzb1QckSRY/lNjEWYtUGTQKPAX2NNmcYZydIwnJ1AT+pPwYUf/LFkQLC6xJYyvRzurQKUJaDNUKiELH5GIG2kS7yPFg7/LRC6ncUflGM2wBNoCtBoYD0w+C8e9DmBvL7ddBsTerSd7lnpSHb3Q0LRXmJxV9Roe6lrQtbPgE6X1iwIEQ8fBFE8hH79d65hXo8hXDXnutfZMF2lPtp3Fhy2svxT8hLnuOXIsQnRD437wEaEE3S2RqTfjn+DJtV9RyvBs74AFKfk0BLXI7LrQuoFeZx1egRtJ9hpvF6KPAEpr6VfEFzlWG8LsJ0Atim/ViUmMrOAqxLFLgDxy9fe8SAHkTa3sv5i/nA0j7Y8EpFXrsTR+HzcxlmWD8x1Y5PHHM482t5Op3KX5fX4ZwdwWhKWjAVCUdCHVfntKmZWZ2KMRPpt7Qc7GxIYqb0ZqSeNcERH0Okl69RbsPHAtopksW8q29gi4Q9OVS+wNuY5o96M8kukLbJcQzJzPRHl2sbIkrpuYXuxZVj8OxvcfaCKTAUBVUl0NCMr6ryCfg0zMpzhQ4VkqhbgUJaUsWJvGxTuUQk2SLcywmOjFYYVSmkZaNvIb1tp3TC9203vttC74IORLgo0rFRdOdpSU7yS2gBvY3T/WOtI2CPQkQNtF2HWI96lSqGZJQBTS4GTEY/kygL7n7SJkmEAo/PceS8QPi3khZG5wj+lxPymF1PZAduUjLaFMDIdPwPtgnOcfcDY4Obm+ydy4DKI+Ua0qYiubM2Uayfh2qDCAgQkEAsXaI5+lT4e1TfhcRbsiHmUu3UMqezZzSzhZeHlJu3PsI+2veMV2LIE+gV8biWkSOpZTRC2De3O46w/eMd2yRIGAWdPzgzYOGVhCKTeAmXjZZ5dkfrXlnT4nPu3OxJGRAJut2qnfuhOrnWRW803FUPyADPsK7f99wTbpCZ9mztP6wdYBqddJPWd4yjOvLU1bbIIpSb8gqjqxh18TomZfSNpHC6AILCPUca7UVkneQZET6z8Shh3mR9fZfBMpHLH3Ditngg5O2CtCe32LawRHBEinyPVzU+hawB/R/msfweSf5C5EZioh2Rrd0yQHfmFMKvgLVEneMfovESmq4PxH2RzFfmDyGiN9TY/8pJBK5k1zfaqmrbbaGlQ00DbjDAl2q4yTsN4I/v9KglrmuhuGMcz2F2qB/jijCVVrOKzW5Svn2X1n7Hb4MNK4HiMT0NYqDQXwUUC/4JkuAi172hnDtDRvB6Wuhjd+g7KZvoE90ER7gznfpdsH8nuB1k7ANF61h8qg5pAZ5inREYyLW5JLqYDTnuZBlbmvNKaii2D8WDhHS4XkFF1ztTyb5pN90A2gDs++ZiINgYKBXVUcMbe2pmtc0AMPIg+dYc2870Wi+d/V1iC6PrisAE2pr7i5Tjdpp4XrCNgXHnllC/qTdyeXDHhTV3rHIPuV/E33CPB65cmCCvOnsxFVuABb5ZedwnGLpHfA/KR99XmdhTUx6lUoCT3hLFuOm9VISQK6W2KZfFGhCzg0uC8h3Xv2k4RyBkqt5WwsmPEzuNKcfH2Vspvjg2GHmEErfUVIbyVaHdyCPcO8AYgj5JtOWnFWVUZH+lQUc+HFMat2oOwGk00ixXmI5u1t6LeW9wrqTASGC8E6Vra60mZh/xPxg+Jl091zwCXU70eE70dBIgepLSD4Xoz3WUy+SHv2uUl9jWFaQCAtw+zKHgJGG89at6YucCUCFYYeUTGIcF28jBREB1+8NUNahwkufhJJ+TE2ecLmrtmB6v52YcyeU2PG1qK9zjNK92RF0+egbwc8tTW0OgOHtXSaF4E+QKOlXzVXhqS85miCx6V564tvz70taKlIpuC7I6w3gmHj/RQ2sG9WKJ9Ztg7+cc0xX7C+chMjsm0KJh7AXie6VGYDMK4JBoLV785Krkcn20lz4bYlZlheJuqgbLPbh05M+2dizmKzVp4t8LzlDyTPlOjSutj4JeBX4Vk4Bks/2Joy+bQ3L78vs9rrbFG+iXUKSRJsbuV+mNGFs6+sd+7rLDuMf1wppoKhWP0HeoCTmLMwB7omeG3SBizk0z9j0luDHBbn3vM4JROZWy+JQrRExINHfJe6B83kOJIgidHo9AfFNrvhvIlIM9pLIuAQmi38Uv2lM3I5EehNEtgQWE5N/C2rZgb+IPC6jAzB0yd3GoRXhBk95ZMSTK2H3DSn7r+or9KvZfsxZPHQghHa/pLSpWlh1Boe3vyP8XSaPQQZBn4NUGrH6xgasfketjPtX/5ooN9jkhHsSWuSE0D5nraPaXSaSqn3kOJz4+C9ZWJvGX4/iueA/zeUG2o+nBnjiP2ikm8jxT3sITPQgIxAC39nvTD9XbXHIP7gO1aPXrOMgvHGp4SphNh9TGdT1gyIZKlU+SUdM9SJ0zaubFNL/GA/PEa4vnoKAh1PGGFUijjY0GxoswWXTCP6WT+NqyuoXntYwPWYc4XmrQUekI7Og7SGvssLLpvxO8CkI89O6bYGvMbOfG301TfrPXrgOO8cKyPh9W5XhSudObRhA5oYKlpF66caxvvhOMuBGtCdsdeXQU/3n9pe9k5+VkYIfDEqSY+JOpfyMcqQN9PWxarHMbsvWQuqqkzy0s0FMfy3A7tDmfuDpe9V9bRXj/315rlzmYilfb6R1tuvsJT5JHgjH+LcrFO4Jqlulxl82w+fyTW8ijQnnXujU5mczPQn7b12Gxau5M73j8arxdjtna9Lj+1Pb4elmahoPNDfy6vUs4u9xC0dn3O1dQJqBum2X0GwgJzzzt04dXs2GxXRZfxQaXQPMcdwQge1kvp+c5LlNJoTEoqFT1ipJJZuSkrmwaqEwrErubllNwfI03pLElvl55JJeVlqnSeuM/I6gFwpL7m82kh4XhJ/++3t4TKQuEBeDjAd+uipkI5P/6NwK5a2ALwoKjydZJqUfvSKXfbdZG+ZJ7zuz21kC/uMw7yl/QJ1eEklkpq5/2DYBf8+RvzsN4QnjOP0JQNNMpMLQ3OOpp3qGsMpFWAdXYlywkIdF4bz/NxArVaU1MiS3lNbn5SXFr2ppV+vzKy+QgCkbkT9G/dLcKdN+ZF8x+Z/ylo3yPe6QC7SeDSmnz8OPc7fMKf+9cZDwF2t+oiPxSIDI6pcwDI4ZsUOHAAzutHCFCGB4C7AucoCEXVo2DIbB6FYGz6KBQsX4xCU+r9KAyMaUdhcV77KBw6uzAKj9a+jCLgmPMoIrZljCJh3eppUq5o6VFkjL+iURSl37oLBlVB7hYnadJtkWmDeAmysAjw8InhWKRJEy9ZHBabVOvow9FJlozFn8FvvOC42ZM4mXLEiaXPLU2WNCwB0VITCBcfmxYYL1uy6Czmw/NeOiULn8kurDJNS54e3nAzTyllTXd8IIjHzEYbpEnFKp/XgfVSOO2mINM6iyV+nxSPnAb6IOS6ButZRAoJyUjVFarL7YTTK8t60bKXhQQbpJK4h6b/jw6HFB2Jbll1smAhsxZiRacQNJmExfrWczLtkoZleov0KGTpeCjrj0+qGcXRZMa/fFCcaCkRgDnJUptei5U7vD7Vq/VlUciKJy1xmzmwVV8T9FP66qTlDhhoElc04GM9Bplt7ZXD2YWRVWfTeSZNgAQap83SuCgEPr5eb6KSx4nbWpsNnAMnAmOhb/FYnpmVWoK4zEk3nmhPxfbUou3ObM6NlB7nw/6Jw4Hi9YAItDkQI1tAE+VQRM0sBDrCeVKIrVp/hYVzd45wE8CVjzUCwqEO/Plz4F1zszqv4HlPsRj4ONwZonCKlQsgtRAyaw5u91B2usEGYnTmpbZZOnC9cdGdkYEWKUCusAPE+WMfJ47SLHZjQcrTI9ML6xJ6fRLwCISArYDoBQ9mF09xN7IhFAYMC+7xppB1JLNWkKjOySum6scZtAiQh4CTran1q2E0WgtWcY20jlU+3Tx5fViuZPr4XPEMSG/G0+RqLzaY7ftoNT5oZQ8BYgj5KCFArkkA2UIGZNx8Kaml5xwYZbBw8AiIipOwxqPCgSMnpUg4UmX0zMA54knFH6gwa69ifPK+lJ4PGuwPBuxRFiyEA4eCB4XajIYAatT5zSJ/OKvBcx0axVinVKxucTp1ealHrxc+W6/fK69dFe87h70xYFCCr+YVSbRBkhTJUp2WJkO6TBtly5Jjky8222qLbXJtd9sZO+TZaZc5C+6GCJH0/z1BvEcsNdDAAvcBAqh8EEHGGJKPQ9DBxDFOcY5LsHENLm7esowCEOPtf+/4xDd+8U9AAhOU4IQk1DuNPRvjWDjeKycxhBCTZMJknEIOJdTQQg8jzLCyKQJGSac7/hFGFHEkkSYlqZFF7j8rTJlOWJTijXEmnI3LHdhKUye/RO/eeIJ7A4GA5clxEb8xV6XBU52ayjqbMboAWVNnbQ6fwevNLwBCMMLhGOOCSYpmYFbSQaZHnESyks6p6RYrScsg5NjrB+GoY5zG51CO+Wpca8PTM4x087JSv5ramjl2XgEgnmqYRanxApJqj2E5XhAl2V0lHa+7TCMs7OT0fGWVVECsEthsqvPKsqp9piEfsYOXjqOAi6DZorlAdlxnYUX6m0WGyXAzhOKkTcZgcXgCESCRQQo1USJFFpvD5fHJKF2jJ4UuuNNwlNpDgECYr6CdkWwX6rmU9nw+uFcozVXq0HrB0kpjrdVBdPRAEAMYwgiFwRFIJhQzmsXt8Thml79uLA7PQ+Dl4xcQFBIWERUTl5CUMmxEWsZoSUZTzZozfexaAqg+xjCMwjhMwjQLOyzCMqzCOmzCNuyq9AVC5cfyRCqTK+h6gvVj+CS9YZLZMrUtvy8aiT2d2iU+AASBIVCY/+NIEoXGYFkHnlcEIolModLoDCaLzeHy+AKhSCyRyuQKpUqt0er0GoCIBzI2OOAOTxhY4AwhWMAK1jBgB+ewhwMc4QQ3cAcP8AQv+K2YpGXfv71xtAi+sVdqC0srjbVWBwGAIDAECoMjkCg0BssJ+Y+rFCqNzmCy2Bwujy8QisQSqUyuUKrUGq1ObzCazBarze5wukzp9nh9fAFAEBgChcERSBQag8XhCUQSmUKl0RlMFpvD5fG1goWWKrUGp+BZ2RuMJrPFamNrZ+/g6OTs4goAgsAQsoJlJMozGOBZ8xCINl+mUGl0BpPF5nB5fMaCnUmkMrlCqVJrtKAFD+QGIMKEMi5oC/5DAUOrUTXdMC3bIaTTZYZAotAYLA5PIAIkMkih0ugMJovN4fL4AqFILJHK5AqluUptYWmlsdbqIACEYATFcIKkaIbleEGUZEXVdMO0bMf1/CCM4iTN8qKs6qbt+mGc5mXd9uO87uf9fAEQghEUwwmSohmW4wVRkhVV0w3Tsh3X84MwipPUaFRW66bt+mGc5mXdbHf7w/F0vlyBWJHahBEUw4nnicSwHC+Ikqyomm6Ylu24nh+EUZykWa5I/+x03bRd3wCJRc0j+5h2cQEogxGT2WK12R1Ol9vLDIFEoTFYHJ5ABEhkkEKl0RlMFpvD5fEFQpFYIpXJFUpzldrC0kpjrdVBdPRAEAMYwgiFwRFIJhQzmoWVDcPOwcnFjcXheQi8fPwCgkLCIqJi4hKSUoaNSMsYNSZr3IRJU6bNmDVn3oJFSwAgCAyBwuAIJAqNweLwBCKJTKHS6Awmi83h8vgCoUgskcrkCqVKrdHq9AajSR7hq/PZxRUABIEhUBgcgUQ5JDyQVRqdwWSxOVyeSMIDNVcoVWqNVqfXANRJeLmuG6b1IwogN42HF+gMJoV8/Cw2B5gl/HBRrlCq1BqtjqIZ9liSxeZweXyBUCSWSGVyhdJcpbawtNJYo1kG25Z07fMJCImISUilSBVuSbe6SmnSZVDJJwTrlnSXfXoFChUpZlCiVJlyFSpVSSg8ORQGRyBRaAy35ee3SCJTqDQ6g92yM5ZguAQ0nXCrrdZodQSX29va2Ts4Ojm7iLikW30IDIHCJBW+puAJRBKZQqXRGUwWm8PlUV3OQKXWaHV6DUAtl1MIFVeYNakbpvV4cADdHuPljayPr+Pn7+cSribp5ZPi8AQiQCKDtJdFhp0vY6FKK+ALhCkqrYRCaR6V0jq0OggABIFLUoKOlOA6gMZgcXgCkUTeTFUancFksTlcHl+Avk0tZlMrIVcoq096iRlNZovVZnc4XW5P+EjTQOB+kXY6AolCY7A4PIFIIlOoNDqDyWJzuDy+QCgSS6QyOUWsNzq1RqvTG4wms8VqY2tn7+Do5OziCgCCglzaDkgUGoPF4QlEEplCpdEZTBabw+XxBUJM0hsgkcrkCqVKrdFluN00ABEmlHEhdcO0rpMB1OkNRpMZIRWVnxtpaSwt6R0sGoPF4QlEgEQGKVQancFksTlcHl8gFIklUplcItY6NdZaHSSVNdtdKP0FJEmSJEmSJEmSgoTwLFcoVdknSd81gmI4QVI0w3K8RqvTG4wACMEIwbJiN5wRNcct5oZRs96hSZrlyqJCq7ppQUZ1ZhineVk3293eXJTS6Xy5AiBoTLqGKJFDnnYa9ZjheEGUxDVbvO3PKE7SLC/KqsbX7ENiolHPVOaRfThs/nn2s0XGku24HqBSIGAQUDBwCEgoaBhlsHDwCIhIyCioaOgYmFjYOLh4+ASERMQkpGTkFJRUyqlpaOnogSAGMIQRCoMjkEwoZjQLKxuGnYOTixuLw/MQePn4BQSFhEVExcQlJKUMG5GWMWpM1rgJk6ZMmzFrzrwFi5YAQBAYAoXBEUgUGoPF4QlEEplCpdEZTBabw+XxS2Iql0g7ZPIVSlUbS1RUVHQfuI4ms8VqY2tn7+Do5OziCgCCwBAoDI5AotAYLA5PIJLIFCqNzmCy2ByuoCpRFs6SMZulu4nfJ2j9US20miiqN6patevMCJKiGZbjBRFIMlRUTa+XSR8yU/00qyqrehFfU2izbrsMmZKDEIygGE6QV0Az8TheECW5VwMqTqdyEGHZjttnU18GYRQnaZYXZVU3bdcP4zQva9VMm36c1/28ny8AQjCSMRNdJUUz/KsgdKZhogSxM4HpKs5Mwiml43p+EEaxuCkgS6UpSobDlF7mVPAwTnMUTnNstrt93U3ll2uzTRzUblMHUAwnSIpm2A3kBVEySVErbHKaVspN+a4YOIb7G3ziJM3yoqzqpu36Bkgsah7Zx1x2i4HR2+bjK3aH01I/f5fbMyNIimZYjhdEIMlQUTXdMC3bcT0/CKM4SbO8KOdVvViumnXbIQCEYATFcIKkaIbleEGUZEXVdMO0bMf1/CCM4iTN8qKs6qbt+mGc5mXd9uO87uf9fAlN9YRmWI4XRElWVE03EHzJbcf1fE7VdK+YOEmzvCirumm7fhgtkm237W5/OJ7OlysAQjCCYjhBUjTDcrwgSoDOSBVcj+Wb1ADBajg6PmqjidrgLC9Kg9XU0PFdqU+ZARKLmkd252PkqkaG2RdWfFjDbOahjT51GoFEoTFYHJ5ABEjwvrBido3OYLL4fTk9PgUytYhNLEjWWRNE/rRMjTVOqj3Ff4DBEUimVqD+IhuGnYOTixuLw/MQePn4U3OywhFAySsTTUBlgL8WY7KEv8zU+rM7AewpOAJZwtNNDLbrpqskcs5OfzMancFksTlcHl8gFIklUplcoVSpNVqd3mA0mS1WG1s7ewdHJ2cXVx/6yMfuuncefVtb/5rS5A8iFI+PC352GehrGSK2+nNNS0YABr2RJOtNiNGImAXOSlNIM8XmLS2cxyGPfqPIpshN/oE2rSxrwg6fhHmVK7SPq/jd2nmYqj2JUrxhK9ELABDahz2ur6QcmoiCGgaO6MUKaLAWZuC/dbH1RdgNtp6TgVucELHv84cdd9g/sSttgf7xQbxPMTmP8dORvbqAYl/iUoG9wF9s9ocGG3EQH2qUfMfGjvxjW95ikzEputzjk6m5Vj3uGjSZmx7Pt05B9jsLT0HzugZfPITJidLcCor4lIsKLNex0/X3d4MHmgIACuQaNGBx9fl/qaufx2DLvE12rootDX5IDQ9OjeVeUMQfGvzk8+O6eC6buLg4xWLH/a3XjCY1LHytnEEShRAoQEThi0VFRZ9tkTQ2VaFJRBwpViJL4g5/9qdh+Du0NPiHdv66xn/E4+FaoNIz+3DimRrKTW0GxyTT7GUDz4trTHYamiGmcOEg+/nNNKdnP1cV+vpRAS2Gl13s8ssyUxZoP558tFKHUp6k/F5QnYjbc38qrxXBtsK6LFzmnG18aJ/tYluOjwpY/rM/g7Zmu7W+unGW8m1Ze/BH/iKAA/TyawGba+hoRpR28an195fONmdpLtJ8IZH+J5obgofP6Ilha8HLzESRJ8DNR5C7/LZXi/hppdwrw8aVts65WQobEoIeQIDrB/NsWcCmiskynah63n5L4CPXAFIiLd3nCpsP//Q0JM2MhHV7gkGOOL5PUNSvpColFDuEF+Kl/iWxNSO3FLfRqVx8xj0GfNQxOgoBiPupiDChjIvINICVGoqohg4RmQQQEcq4iEwGiDChjIvIFIAIE8q46ML45GaMseZAECaUcRGZARBhQhkXkZkAESaUdTp0Amqu+qQQYUIZF5ELHejUTYXfQOlbn6auY+eOPZ465ecexZ9m7DPNz9jUb/C3K7N0pAhMOw/ik5DL9l1zy6RKqm6q/robhyvL7hKXGd19Vnf07Nltw4xRBeWt6O3rFPzWoZi2a1hywUuHh5cnJNEfR05ZM1c7p3P7bunafY0x+QoOazrI8qlbDXcn0VzdwshyuZvebyq7FJMeY/q9tmn3+NpoMahdZ18Mw11Rtt/GL3rxYoMLuyzKEwWACBPKuJAKNuhz795LkQeDPQf44E3qeZsXgQb2Dh6feGMAxftr9Jgv6OpzGRG3/GIgOcRp3rhYsIQEgNlWdtRKWQ0RJpRxIZU21uV9dABEmFDGhVTaWJfXAIiEVNpYl9ckTCjjQiptrMtrAUSYUMaFVNpYl9cGiDChjAuptLEurwMQYUIZF1JpY11eFyDChDIupNLGurweQIQJZVxIpY11eX0AESaUcSGVNtZt76QAEGFCGRdSaWNdXhEgOvIZrwAiTCjjQiptrMtrA0SYUMaFVNpYl9cBiDChjAuptLEurwsQYUIZF1JpY11eDyDChDIupNLGurw+gIQyLsIlMzZbqn90dgM/wuZAJGiHw03EkB9CFiTKDZyjQejPmTohhEZpDvoT0CtNoNnc7x8WwjQoacSLP8goen/3N3b7Dyl1Go2Yew43ACJMKONCKm2sy2sCxIQyLqTSxrq8FmFCGRdSaWNza8cPIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCG8AJe3dvgQQgghhBBCCCEc3NFDCCGEEA7tuBFCCCGEEEIIIYQuJESYUMaNdXklgAgTyriQShvr8soAESaUCam0sS6vAhBhQhkXUmljXV4VIMKEMi6kdnk1gAgTyviLOPN8XUbhL9vSkjHGGOecc/7d7cPl4JuyxXzZJ5hU2liXt/asCCGEEEIIIYQQQhcAESa/K+RPrsu12lRBnC+HpYCUUkoppVJ/FKFqTTHgvTDL//q5JJRi++ws2WVbsrEDlVJKqUNfM4gwoYwLqbR1eR2ACBMqlDbW5XUBIkwo43k9gAgTyriQShvrFg7vGhARyriQShvrvsL9PmWLV+mfy0Cv8WUX6nGmShub6wL+Jd/45/B3ZzH5BKTSxrq8HgT7ACJMKONCKm2s20/vlTbb3lm4AUSYUMaFVNpYl1cEiDChjAuptLEurwQQYUIZF1JpY11eGSDChDIupNLGurwKQIQJZVxIpY11eVWACBPKuJBKG+vyagARJpRxIZU21uXVASJMKONCKm2sy2sARJhQxoVU2liX1wSIMKGMC6m0sS6vBRBhQhkXUmljXV4bIMKEMi6k0sa6/eocGgahjAuptLEurwgQYUIZF1JpY11eCSDChDIupNLGurwyQIQJZVxIpU22AhBhQhkXUmljXV4VIMKEMi6k0sa6vBpAhAllXEiljXV5dYAIE8q4kEob6/LWtto555xzzjnnnHPOOefczwcAiDChjAuptLEurwgQYUKFVNpkSwARJpRxIZU21uWVASJMKONCKm2sy6sARJhQIZU22SpAhAllXGqbVwOIMKGMC6m0sS6vDhBhQhkXUmmTbQBEmFDGhVTaWJfXBIgwoYwLqbSxLq8FEGFCGRdSaWNdXhsgwoRxIZU21uV1ACJMGBdSaWNdXhcgwowLqbR1eT2ACBPKuJBKG+vy+ggTxoVU2ti53HwzsC6vSCyvVNpYl1eWHK2VNtbl1YElmwARjrQAIsqEtC6vDRBhQpP3HzxC9MrmqhxJnMYAIkwo40IqbbJ1RJhQtvk6BftcDiGVNtbllSDYCKn07l/NYyLqMZzMIvNgqBysjoABAln+Ec7nRmCQPWQ4DexxeJrwxIlnwG18GpIkLKelakmZlEmZlEmZlAl54dE26SZJEicZ6SSfRmLl03TdiT4go5+KJAPTNBPVST+NxllGPgHhO5rCof3H2gtO3ZnYJd44Pp3swivEspO/Bb0nCxO/oUXMJ1GpHx3TqcGoYkea+ly6LgWPTC007EhHcm6VtqipRnhVw+us4voxVPlhx3RntHWMBNSUwxoHHoYlAB005KUhrFoWSxhs+e2bGMwRRhkX0uWVACJMKKPO/Ev+reKPIeD+/R/2AnQyW72tL5085xlU7Z7BfzaNB7Q1xC4RGYNQJlcmwoQyuQogwoQyuSogwoQyuRoQJpTJ1VPbRT8GABGWneSRHwuACBNKm2wbIMJE0hkM80BycViC873o87PfRlvj9jHF+sHHB0jkmPf69OztwWdKdHPfPgZ0+Jf/Uitd++wHqOEPB5pUoEPt9HVREhh/3z7ZdfX5sWHyrMZVXBxTPHf5gulDj41n36uxSXj9febmsyw0Q0J8nTa3R1/FpEndQl0GXrtp491pFygJB56vbUOLTq+0Nswol9rmlQFiyqW2eRXElEtt86qIKZfa5tWQcqltXh0RJpRxoUxeAzHluUke+bEQmPLktJM2R/U26bzkxx4JjEmbcZCYksZtBoXEyB1Q/10hN13EzzMJ7EUQDLkb+2BRgXwWmrfpL5jZi8s+Fj1GrGlTiHmyr+VjuJIDDwAQzF+ZIAdK8gQMvbt7Mvtqac54IIBokJmxgvEWlv94ds6s29x+1XxzMe1612eTVSlqC/LCBfTmVVcxpOELKuynaOw0KUzKUn2lI0K73KJB2zD01EsZJH+mewiGYGH9j+fmzIVl1K0btzJRB3CeL8irGJA/6i1EYTWqH+AWjUpHMIoBHiJsfNxD1QGRQ68kC5t5RxsLWxrTWtg16k6tqgvRbaYLpNfJqfLBfpzN6w1cVTV5HVIMXcNAYWLmP4/njD3VHCIxPGTk0GFwsn2xA4KeByE5tHql7i8tIEvEhuV7wdJ0NyJavP8WDjz1wF0PgYkZDFSljq7qmODDESIlnJh4WTko+6ujW6Y5GRjG+LwIRJ1EhdI2k3wwkKHUsgRjJCJDiZ1BcLC0TQBJL2UR540WTnb1oC/Ki5kiUzAZmAy9Zc4WTzFLZBku3lqy51XIvg6dDbWuJyW5mKR3FiqCj/fxOdPGuv0UQShzwzN2KM0YY4wxxhhjjDF2IRFhQmUagAgTyuSagAgTe5jJadjjO+MEQIQJZXwPY4hHwaW28wDxKLjUdh7gMCiXehYQj4JLbfOaiCmXWsz7By9fkJmM2e9+q4S4yoXB6NyUDAxI2Ghe4IDAjaPzoVvAxY4/onld7KbOhe56wT54wA86nGRidAZ1RNNAY4xwnT7fsAYIMT+q234ax30KxK9n/UF/yjk21c4SvURv0Xv0EflR7ZvplY3+pd10T5lpUQqC8BGVY2CAlF11NwYIKBg+ieBaSoBv2ZMirJWyseGrdFi6Do6loE7q2BNt5Am+G5QElEttt3dqBogwoYwLqbSxLq8CEGFCGRdSaWNdXhUgwoQyLmRq7ErGIa/BuJBK76dlgY8vsMuYgXXfivMgZ5Qa7OQPbPprzOT/u9NkuegzN7QvUlr8jz14+y/rvSL+3+INteUbbh/C14fO+uX/WJHD+RaHKQ9VcH0iXWmAONz9IA9rV+34YEUc7vIwF+wJx6zNhjiabyMYogJiGSKARZSBEGF/GKICYhkigEWUgRAfAvcbXhzQeC+TVZVxIRWAG50gACJMKOMiWSFj6R7T2jdNFwD/p4URAoRSsT2gCSfGIRNhhxBfDA8AGjqA9//jz/7ZIFcR+ET6Wd3tV6dJS6VjBGjSZEyuZTFRmuZUZLBATAUUSMsmeleOz5+ZTqHTQdXZAOXTUXxS40G9y+vutDNHfZ1NWACJBYSTn3etlgjHwgSPwcFIL8ctaoY/eBYQ1hICuo56qX5s03U8wNIZeSdvHowMQOgINwBgUSPCY4Zf1EIBxV+mhB/9y3/5z0AuQJmwCeUDPG5liFS8IsU6JgrBOm2Kn8M1W+I0ztWvWxjyKgq61RnxGxE7HgYLJ57ONr/YGfYnCXGy4hQGu38/WvK235jxAGU6BPDR9lUH9qJsEOq2mQ7FjgM62ZCd4t4447IVqo4QKIZjPnPfuZvSihGXOqk7X8YH8cwhQK9Ifg7xTK+7jg16uRNx7Dz29KOfC68kHmnKEfQdEqO1cb5OYDOq2/SiKjydzV5Zhd7VCG4CJuJ+G/4rphpWhj7r7oduGxkCWroc0ahE3MeOHpJQGaUziEmZe51jA5z3gKKUkOAhxriQew4KZrKt4hPQc5lhHq20KIl0Sla9CRfjfJzAoYlliZiLzArxH24+bv+w4/RjvRFXH++ZlDcMv1Zmt2wfwczcrHzzI/bj0T/6eMqXc98yyAwMEAxYiOO2QiocH/OCkaeiJXNvPobBH2qjj2kMl0vxRhD/kzwIfl7x+71XuUy2zup4VDsax4Fl4obskz9MEH2pya/W2zvPvQf3Gv5YkCP/7nISxD+eElnVGjO8AjhWISEIgiAkRVEUxXS5XC5Pr2ptnaGSIKZXMgEc61g02QNBAMZJLyVJkiSlJEmSpESTGSdJAMcqpKCGJIjphUwSW8c95IgQRfGISJfL5fLTd+jc1hknSQDHNCVJkiQlBEEAGumlTALGOqbDG5KQbfpdVltnqCSAY5qSJEmSEoIgCEISbEiCmF6XScJ6LvsF9PlH0xtSr4sdc44sRyvL0zKuEOzm331J35k9v29x3poW1ZRd67tP8Wvui3y41HJPccz02wXNy36ZyysCRJhQxoVU2liXF2qV4OcvULFM9Bfc1Kn9/1/9pcFUgICon46VNTOa+per7NQ68THO/zki58AcYZQLqbSxLq8MEOFtWPnpH/uY/sNfmXEFqi8W0E/lT8Zh4ad2A8/Kd/KZH5OuBokmlUUxxhjjg1wzyLhYhBBCCDnoNSDChDIupNLGurwaQIkpfUkxcv2RffOhSX+2RBaldO/Y9EEQRDmffFQH76Q2D5+jcZ3flSM8IKu8kIXnAVc8dFJntbD5rKi4Vu8WSkOpirl3VnC5wJd8WVDPqCn7Rvzb8u1oj4/nXFDpZ7I3lyKvixTzDI9kN359qHV9qtOfLi3fICdWA9MMIkwo40IqbbY97bmQShvr8voAIkyoNsc90x5AhAllXEiljXV5fQARJpRxIZU21h3fRfQK7jfiYpIobYR21pTElYI/PfvhjH/z/3/2N/GMont2Xwo+YarAS8NZwSb6YT7Gaz0i4zuh/6OiXJqz94NUot3LXFN6RK4BhOJDLi89VnYJ5ae1RVvUeqJdZf9n1wRom8bERDHZ9CTBhLK9wEzeRxdQxoVU2szCrZVZul0WgCuVfNxmLq+HS+f9VULW2v3VY4xJVMZr80fG5cH+51/d3KGamU3FGOXMxaeZFgvBA7HuFHoDobfzpMZ4Sm84gFmceBk4nNZbPy64vh9zJjKNYWBwVKyhsiLYfFYGCgj01fyLs/GL3/zT310Pq/oGFjOlgiYOAECIMKGMC6m0sS6vCBBhQhNZl0Vs4PFO6LxGcDNOKf7ThJUoYGfu1gzYS16cuPfvNdJuCpzOhgc6GfzaOHrt5HZKR1Vul3Rmi5jqA4+r78S1nlWUiregpTVeCN1/ybpB+eVA9Lm4hj3LXqWVL12i49aNPXjwmlBYoJH9vR6il4Pzm1JY+Du4qVN4KUI3c7LO25JDFeTgfH2l5tNt/e5KKUCtXHo3oA7uumxPr5tQp3VMqXtKZ7eoyRl4ks47/VFw3en/VBP8Fn6zGzlfGgA="

/***/ }),

/***/ "./node_modules/base64-loader/index.js!./node_modules/scratch-render-fonts/src/SourceSerifPro-Regular.woff2":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/base64-loader!./node_modules/scratch-render-fonts/src/SourceSerifPro-Regular.woff2 ***!
  \*********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "d09GMk9UVE8AAYTcAA0AAAADSCQAAYSIAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGToNhuJhGoU0G4TTSBy8TAZgANJEATYCJAOsWgQGBZRZByBbOUezEv5f8bdz36NbW7MG2Yhs1BKZ/kkcRrtGNPOXtKBSev8pCEPGBirX0zMru4ZH2BPNqvE3yGt7YtKl89Z4TYxzLZ/9////////////////25f/xNjq/Q/c+8PMDKKAqGSpaVZWVnabtVvtnULCzBxL+uBjMqscDG6EeuwnwdCgRVmiE1NzDOjFbD6BW4yF67XBbDEXdlEu6YZydHkVu1it1psYZ+OmalYxOl+H6jrGiG3XhKre1f1NGmGi7m+Hu9tqLGLxrvXNfYzxAI/Ke1/KB5VUSZXMuhUr5dGeUkqN8MU72mQahg2d0l08O8XB2AgqRDSMvDGacJYU93L/KnfNRJzUt/m8nUex9N57L/5N8lVyHu6kL3FUgj1m3On33XBx394iPKmnF32f+Vhmv+y0xvbLYTLFrxBCCJcJIaqkSqqkumXmal3NqkqccrnppCkmKI551RlSk46yLN67OkYIoZa+eGd9H0II0hfvQ00IIZxqEYp3Er1MQ1VV9a1IubXUP/P7neGzIM8Uf+QWZ41wGkEc1VK6HD6yPax/b51m9kXnCOJMvNERjurZGUmew4kkHbrza8MHXFUijrCnbAkbm1McGrI1zdhRMcrUaoa2PYPNR/ueqVdaUOtAjaBGUCOYdWLaWDjNQI2gRlAjqBHMusy02znRGIwU79/gs4M/BP9DDz9SDKZQMIolZRf4rcze0Vx3osZ62o1KUUmzC7gXUZbdMJstFtbDIwqLWIifZvir9BWua9NsfDlCCZapFFs4kRzcqMQ2edClrZ+q3YChNyxH66kT/MCfNRYUZZLnlTB5JfZHt0MpRg6mGExjWGlTHOKEMOWUV5X7YTYERLxNv72XKd3AFDO8Ks6pfNL+ImkE0Wl72eca8p8UiLndw3BleFhsXg/P+IPvUMQzXLF/iQ2GIt+12pf4UfvCpVLrl3bQfkIRfeE//wG+iz7PsP2tbDLEAt2vih7e45WzXEPuX229gCnX2lWOIb90eYmuL3I3mvg7sRA7tVa/MzD3eowoaNisV1oo3kU963Y/4rHI45+m0F+oESnCUBq+xPi5HBaoxbisjJKmWgZm/U+pRS1SWkmv3+rUDwWYBO1Y4CC20vKLuf3f95jAWLEaKBun7qiSKpnbW0CUw+gG/ENEiRZTtGU74oryTJ/WTv3+PD+3P/e+3Pb29lbJiCqDEmFkm4l+xC9mNVZjYRV2oxJQEVxVZFb3eKED90XgYI6tzeuCGvq/TKMdyspChpLyBmhu3bJY3wqWrBksiRwjKgyiLaKmGKAikWI2aGNgYPxbb8eHGVNRf/6/Tf8/vWcNsJr7rGelK529MvuJ/5la66eaatoQASIEGCwwMOIMMwzmAU+8okfUh7O4MgDblFXpjJpbm8xI7CAMwASnvbBuJsZEnYJRt6KHkWAWKmLPrSfXFFUplwF/u7EwhELXDlAxFc9PMqhSUlID+gKqMb/8jMJTsfbkm+2e/XvsgDSQO6EC5VNRcWRjHAtpmeDd9scLbMREhMg6IRqjtX7nLM6kX+6Xuy/5wOqOi/rWpeM7NarGyA8YGnStcq/cp7qi4ar9+fxwvA8RHGZc40rwuzeBAFnzsJAIWjbXlsd0k94I2lEbhj+d6tg2/PpAggm0/z2/aTDsfbfDOn/eWoZSUaEmSqpOU0gqSupOQ8UlqZitncdeduiHgNfj4Akr2VD8/6tqDsOS+dZ7N8bZrk11s5QpVkqj00WlipDSRNKTCTJNgJRGAMoNAnBFj/hwJb7eO55iZMLBwqTrC+Af2WQwX2ym5qBz//kaSKuGIhDE1hAFOyhoyBN/rXfrcsM23OBc2QGhIhAWSP70rJua8/fQckqYpkjXKzx2EN/fy7u7571f0oArJxqwDhwsFQPcsVMomAngJw5Q11yo/m+jGDAllEALnvze7RwVeOHsJc9WACqgxJ50vo0dK8mO/AN6bxWy1nbIUgAVOLDLI8CKsLqKWuDy2krWPx801SzO1ZRCLRKp6B46wEqXdErTdSVgAFZ/Dyabe1OiglOZKvQtnK7AJzGSYcThdPao1fP+9v/f4h+xsGpVFV2+/77nAV7Ra0hgwJDeNWHMXAQhC4IBMCRiMBCVK2AgCEiWZCSKKWJIGJ8p9fbPuf9YPW/Tf20t517XvB/3+ujL8Ib1E9ff8sPGIYFegWNQyigGR2lljFbRelgryxEcFTKKKGDBSmCxkBcJSwjlwCqggOhzfS62T8/b1jeW2/CrT9Wr2r71JuA2mJhs+jaGFMnGaVBQwYQBFLAx0jRgGMBGQTARBMlKw4Ah0aOoYMSMGOJ31QnnTV12+362vh5QRRUU0Awrrt1/e4RZ7167dUlPdMLsgvCi+FJLEhtY0xzp9eXUZtQDZv0QHeQYckQBuqQXKOHaAampt2OJDoQjNwekdrmWwnUmuTyE7m82+0QoixZZ1tWBLRtbq8i0amCYyKRlnURb4jmFz6rVHKGXHCHFDpUaJagG5AynqUZw0AAlQFAqEKIJ3Q2gQQUKCEWAGkpQDeVwvXCBMUTK/P+72T9ZazaHBX/MYlY8e7H31JpuqinWgoKiICAgpRRLFDSJia1ji5rEWJKYokmf0jKltVvaZt6Zt7KvrneZrKClI0v+ss/JIeUTvJ3aYSoP49YGFOgg6NOTbf1fS/v2Vv9kMR9fbIYNCVPe2GbANJoJCgLGhAEYLkFlaWSHFIQBE9FBGGEwNuquiGkwRb5iimt5LnXxC1VOZr9uXeaS7kficKjg6pBQPdyzvfcDwYA0jkNprLrnDQPUDbu73dhTMw88BAGKQAIYkNDRFzjQMz+VX76C+2dLfpKcpGvxotIW4HK64Htvk16Qo3ypnTkIfxxwDLQDmp6gAAlB/wxvpiQMf5juCQzon53g6+Pgl04Gfq8zD6T3Ez/H7R5NkBEU08v247WertCcjYycMaWMjuZQFXPNxv/s+Od53fqYnUX/vr97d5c7Nc4Tp9k6tjIFHQVESpdhoogKol8QxIJhmkosjPSAyChSQ4zUEAJDaYYAEUJ8hAdEjBBCqALnwWW+8F+MLSwksz9vF3HPEBokuSMArnlA9rHQ0A2bgispKEp8YpVU6W3yN04VhdYAAQjP/uB/uykspSf7GyoAjtys/79U7dve+x5AoUDJA0o/QP6J7Eh6EvXDXlJrclz9xXZ29V4BRL16hISqIiWgirTAomQToGyTBcoiQalNUnQ3bcud7IU7x2N3iiRAuU1Q+m2CchLdp0Wo5e5Puee06R87nLEn5bzs3v2Z3SzWs9p0jqs5s1j+xWI/OfDw/9OahXkXIvKRPjtqzko1ZP5sS7bmUzOU0mxVrSgODowCIn9vi2+eoBDK3c5soRV1OQeOYLt6X+L3Tku6Wp01KZTICkWeL2nW7lcbS2ENVY8vwPvCAlEDJPyDTZxleRWmQZoTWAFt1T5TNSUYOWGQl4BS8Dz8fq6+s3mJryHa2z5+Z1giZJWsNUPICUKF59WLlyb/2QrmKzR+KudH+606hrwZ+KEQGzFZ2l3ME0ROtbRrV6PBRz+tpDOly2j70DvmCJM4U//Zq2pJjvrky85w1mRmHRKgZsDQMAcUMt0D7LARQ/6/pZVUtTUbHeUYADzAHEJgfmYGdOr/rv6q/qrpndHMhukLOVR1tdQttVa6kBN3ggdtDAzNYEtOO3N57Iz8DI0MCDVRtWqW6HQ7fOP2jEQbwj9v8Y8ikKcQEqEx5iTGI9zzGYkwDmuhh35ZSudXyzZ2XnqA+QAThTuKM3rKn8zVOoQADYigIHUZimhyouEBYtsHgUfxD3nT3R6O8IPQLqowoEAog+D5/tbzAzwqF7l2asfAwjhbVrAVtEkxg9C3D/R5+rxQszMHlxI/ACnmzxYChfg1ebN/2GnpP6rMwRshVJYTvUSUEIrs1Jt8Fh/QqgdNqlAC2/FwBA8CuxtEgQWe4IgjyY/9sv9ScIpFQntN2qiNIIjo2/eZ/20Ya9XYQOp6bfe28/X7gAKCT+rkk6UlobeHzFXPXiKoz/WqUgSFHuixLWUmIf4nW+/PgbdpHymT9stC1mFFEVuDILlQM4ulaQom58cnT5fSryOQRN+dgWotLNUdMiYRI1Y8LZZlOE7o5/w27PM/7XWH8FlCCCGIFRlkGAYRGex1ZXfbmpuQTaR3yzscIUgQEbHyy1j431Iw7wvpkk5SHEREDrlh6p300l+yp3v33itbVVW1aq21VkVFRIwxxhgjIu9X0JZhZNPVX4XnWIQYjJn6INommK0mk2hQGOMX4tpCutu3AAQA+7wkPPg3P6hRI7kY4K2/XsMBf/L3Sgx4aAAAEBgWDlQ/CJoNJQOQkFawAxLS0GJ7MvlZ6hHf3ef5MpvIkHlMy/35x5HCMxO/iE1++K8HTN//wPTTki3bK0JX/1n3HiMIFh41JhzxwJ8wWpIgRbYiHXTXT4Uq493hPo942kve8L4vXXDVbY+88N43fwIIi4pIirTyFavVaIBqQjTUTBud9NBfjFjjzTDPEqtstNUeh52Q5Ipb7nvib5uiMIeVQjB1TSztnNWAcByZKTCQcvIKoUkScipaNgAqRyjXWQWBkBqbX1RGWUtZC4Im0LkSExm3AIYiqaJlA0Wgg1KNkYAOrJNBTjSzdVHRhmLIDJ6RJY8gkiAuraptA01kQBK1gRUIEaWDzqD7WtdN96PORzdQN4Im0ywKooW0iCIoijaQhXbQHsqko1RE5eSgOjpPl6mZWugJvaB39Bmxw+0pbGn0dke3T6uBWLbS6u+fXfUOp0u12ZWt66lCezDfHEaYhWY/kRmJ5JBsyRV5IG+oA0HAo+EQMmRuhV8ES5ZR1bIDQMUmIKflQE0X/MPyrPpiXZyLf7lc0ktqUeRRQwcVAMDAQoaFCCOsEQAJEUmU0MImAAz4yNHhN4HMJ3roMMw0y2yxTIA4eWr0OOCcfgpUmWGZW9SZ8bCXxt6s/299J723vp9+tJqpFqqVKk7Z1B6VqXJUgSpTDnVOXVG31EP1Un3E9uEkvsS36I9R1hTL3/rFirDWWxYr0dpl7bMOW8VWlXXKclrN1hPrg/X/BJRMH4WKK6+6hgJESJCpWFMdiFFKLe1IlKVAhQY1mnb83uCoyx4Zd9eRp87sdsARs5adcNZlN9wzbtaSDbuOXLjzLzcEB0leR8RJILFkUkojvdQCBA0dMXqcRBkmzXLwrIYMHyXJ5FNNP2zk6HETpUybTQQ4sIyVyWQaTYGh0FqqBoQTOWJTe3D+V6Bcky6DOAooUhpYwcAFDJoXbz58eagBgsOhYhMxYoGLAFFkdPLU6LAFi4yFT0bLRFaJzMRDDImQAqmTBREK1BlzzA39FKiywhZ3COgz40ArUNIn6qE29dMYLdIG7QsQJ0MDZQqJV0Z17UiSr0pHTgcPaIqnTJWNUtJBwmHCgmU8rELBIRJHJ0uZKnUa9NkBhwGgYmDjEtNypJIVqIE6U49qaUtITFpJTUPX0L5Tlzp1GXBVQlpORc2kGYuuuSGvrmflfjQIbRRjTTIdqgCAgYUCCzEWcCEAAjxSKKMPEjw0QEQo0WMnMQMeNKhhCAoTWMMJ7thkhxRFdumxxymXxBkiTYkJ5lhlm5tkKNGkx5QNRxaom9q5J8szyjgbZ/Nsl3WrDhg2dsqshRtuvpX5Fxk3ZakVt7beiIGpcxau2HrbonA5FVjAB30wAzE4gKIBk4LuJpPMs0qJWrbS2qBFAyX1oLUDQZRE7uE29/MYz/IKb6uitlAxkmUq0ECpnPKJEKuYkiqorq62xUmRrUS1DshRhRQgQiIhcqIuetSBQCFhEVExcAhIGDJlwTJufKwSgYZHRiVJliJVGmzAYhHScmCYtS4dGZE52ZAjQ6at2vPQmXFHzFh1znVvW7bj2K0PgjAxFKiEKql+2sEjxkqSNO6EwyeRQjrZjRiUPJty65W1oyM6q2t6UrR87fY6r6dE+aZbbbe7lWo2bN056olUoooWBVvc4LWawiTIUKiJ9hWWqKQa2hSQoUCVJpNLkqkmppa2dOOmIVOW7bjvhXET5p1w0T3TVgydem07KJYkBDzoTb2tV9SMSctrWJYvMrl01TrtJuWU1LWPRWjDNpzADURD0yu7D17smVw+cf7G61OLm4cXd2/v3cXFRHCBAB+EIQE5qEFnjUHDx05dvPXCoycuvdLW1t3OwNTZC1eun738FAMmZapmeJ2TLrzxLc939GlXuc0TDl5667OfvPAGGoxjEdtff+S57374k19/8JmPf+7XfuO519//8sePRUfhc9aJm7idu9VGkNh65jwIAl1J2w6RLdY6SHU17nPgBZ/4MTgmLb9Ry/xRxcpUqx8T+D/Jj3/yuN/g//fM8j5uyJVoQZ2KcB59pZywucdHN20c01E/0gQmPD77oht39YfXLgHKtCLBlJx/FoHaqY3pPV8NcqmKbeOiW8L5OMeAlLsCYzFU7e1CWudi03YfIv0gJF7GmEs2N0YpPf4QrDzurxAuQjgSPfHvgxWNC7tHBIfughjwcPD0x37e88t46qTIM0KrWJw5GKsM3/qv9+wXZTl5QtA6GFlf8ivWefNmvswlZ+aVvNJF1Cj02lNjM6yuFWkHe9Hocn+pNwQfgMpvlZceas6QFsUw8WeZ9orHNVqKW/BSCCrZiL3h75ZdQYRj2e+pbOz6hqS0WBlDfXCSj+7U7F+E/QPPi4IW9JvXR4ztdus8z+hK61Nod9Ja5Ucpy30aVV2aMnL4e14xLrumlRpp5yafGK/LK8ueha/mrksjvTuw9cGBkb8POSWjpvj4MHmeX5ETi3WvcY2+Hcpf+slq8L4j2j+nucWuwUlb9XUI64cou4tMOYbGytjS1MyCk4aHyCJrZFUWeTM363WCVARpEpEpx9DYzKJeltPKms+mloGh1fm6eZ7aRU/Ju0nNX4+neppgUc8uFmnxj2yXGX6wq4b88vcUHTLGvWD50LlxnfkZl1bNt03B6VbzbUvB3Kzqimz1tlraKesuJJ+ROQHimBkam1rORNLC0FL0o/N4gg/2SHeeSXN2/bTW9Z9why98/NiqOY5Mbv1clfWb5R1dGKzRdFMTXRjUeGb624xjYVlHcqmja3Qnu+im3kSz45tpPbtPu2cOlPHsNRxs38Qp/qEPYKCw4GtM86ds9LcMtdW7WstIQUZLdZ97WtuvQtOqxeqZXsnS9i3tYd9dkP1woeGLBsqBxbGDkq3OJ0w0TUxNNppomH7S1NRE03SjWbYWGdKkSZEhQ5o0OctQzUc0NDRMND6hoaGxQcNUQ0Pzp/c+Y4j3vGE0d651GY7FLP3Z+fFjXGrK5h/diZvCmfnJfrymD0z9If33eRrtsbo90j8ExXy3G99y1FZfTvnST/iC0Znl7KXYO9+NnZ9wg7ILQTXnnNmt3z/CHggjYgfHmY4Pro2WTejXVtftCAcO5NpwLbiA48i15QKuNZdfc8PhC9/yxTfbZJ301+Wsl3MmRcUlRnERAuIpSgUuMGGHHS4wYcIOl3EAh3AQe5gw8C2+0MdcxAAHAKENtIAAOEJbCKA1qLkBfMGWL75lMBFKcSE0b3QAENpACwiAI7SFAFqDmhvAF2z54lsGE6EsUH5OaPG/wFIosvIo9uTZ2hcbwNZXOwkotXdwdHKGYJkcUShVqG8uGE6Qat81Wop21end3CNPt4OME5RpAJ63D7hyur7YwUPyIfT+pN8ku2rmvh/fifLT9/ObrsYpERGNC92crJGwlVwfmj9xWr5PBwxgepdgN141ZYdrp3vURhVRJqB8cLZf9dnXGF1RUei62tvup9lobv2do82+umzPtFg45gnofbPXXwGZS5Ck/4l31ZG1Zpjf7MVhfF4Pjw2rTtdzvRmo695tOZTtiY8twExDJz5aoy/g1ZfHWLVk0M68Uy5i7o4jTLDTcu20XMyNhkxJ5eR4jsk7EaUi02pys5mrLCUThhWVRudC5raHG+bhWl2HVKDPrjKOF9j3mgGKFi9ymQS0WMQ0VqR6aa+WFTdtdqJKat6q+qjN0apmetXQVT5tNVEx1Ut7qaRqzxhZtYgtpGOmc0WCT4Fv7l5jzp3gFMDqqSbzoHN8zo0FT08C4g1vGFojFuBBADwPuMceG10jFuBBADwPuMdbxueo4C+88W6FOEevf3ApidQtZVKc33ahOITVNMWSm+dK1m7d8g+coy96o48UEP+/EVu6q2RCS25vkE73e9hWNHjstgGHO/Zn59gpdyrbA8dpp5b5yOLmQpYMeKUjqulskxNS7qh+Go4jVEYDwyA6wsy9so2CoduLZQja60UgdJ+NJ3uoaVMxh2WjDvSm3mRVaOSZsP194KLo+KQgjvrUl74OaCsXd3xyK3AExSKFzE8bcxmzLhytDveyK4QiezNvFBOza4dbvGu933+SNg/und0QmzMrQRhDhIlGmc6FNEwVKxFAhIlGmc6FNEwVKwFAhIlGmc6FNEwVq1Y6YSHJAVE9IgUgEZUSEI1IAwLTBEKjpyKqR/XLuzAAIkw0ynQupGGqWEkAIkw0ynQupGGqWKkBRJholOlcSMNUy5yAl+gbIGZcQiwtiJlEFtQYx4xb+CEe/XzEyt/blY2f/jfT5Y8p8cyFZnmbpe2WLY2wGD+fv52FtF5qjd1sr+hwlXMFYqb+jMfRz70wQyGwFIqsPIo9ebb2xQaw9dVOAkrtHRydnGe++r+PX7bPcBdVjDkVMMx+gDJNFQxp6KMruktTMTgHbG6NRv81GLEQmPD47OMSWInDyW5FTC7lT5CRnDKGeIevlFbcTTQX3VmsUuAqgkrEYsJNDWHcubAcDuER1iEo3AvPlvRvLHWCUtKgQcOOSMmJQT4bUTvHrgisg2BAMHQEkv4ny5cEormrIhbiZ2JO4ImXkSGOLReX43WcRBSX4oNY8o9doP9EGi+SgHyLLAaDqcCKIBhRiLdJpgWxACGSuol23WSVRYmd50Lt5sgwQBcy8jnazWVl73NpO40iSZkPIM4sEJjaB2EbwGHXIBEJKCqSRRIAhEjyyKXRrBBSYELoKWUL569qfwpsCNKS98ox2QCvqMdkV2fL86aJzhRJw9SQ7BVIbIHmZJ8niua5gjS0D3flxQQTSdchG8vptzqkGWVTdvWp1mm6UAqtKTtK8HwULCEkw0Y2yMgpJW9RbQukqiwZL1GrYs+ybgyA0OUcNhxQPviH4RAT7rQ+rfnJKQvOewXCjNrTvrI4TqTxIjnLVs6oGVEraWToKlRVdkpkGSRvg6zRxRT/6oiFwPQLUMZUjTyOiS/HOEI59xLLEQ1KkIKS+FqP+O/lSK+9E3q9nd3vKjna0AwffcgS+AeqqUZtYL7YtqgbVkI1Kmebz5d25TJx1B1hJq6Lf+j/hjWog5cH01chtpi3m7Wb9Zt1m3WbtZv1m/WbdZt1W3GBK6TL6c/9oibJE0PEY3/vLG5zzAzoMfIU1nx99JbZLLJmoN+smgs+b7nf22xvM5lTPmvC5CJO50+LZuFKiDDRKNO5kIapaj1rg4YQQgghhBBCCCEAAAAAAAAAAACAq/QzI9IOiOqJDkAi1QmIVkyzdhHsCYSmdxHVUyTPF904R/CXnWoPtPIjce5DpNtI8bsqF8KvL27nfTwcbnOzYtWWqgdLElWOIP7BW+xNAa6xS9PMVzuJxaXhYyPyRAuD/9WUH5QHgMg03X/eJkExM2TuTv3x9Gg5Ysd67OIaTSyJTV6KsiHl3M7rfO3rylrfY93p5T7t1/7dFxu6tq0+f/I0n7PPpZM7pbNzbp13bq1u229rt3u3V1fKlXGVZKdYI4YCamjjeXR05Ss1PsWUJyMMGzHH8+Ek5usjnPI5OgdHO9nz8FRnEKHfOlFYonra8Sm/tbLjjhGzlnxu0jG/nwvZ/EluH9ve/xvf7tMpWIgwwBGieJ/XyBfyzxfY6rd0DXSokBo2Wf9ddy8f2TTDxJ4fcc+8w8cH2AaDHC3fwg7eeU2ZNTb5kOVHsj/r7svt6Ps1mIJ3+g23fiBjOnGHt1TQQDP9xDkM4Rcxcc4SjQYdNpAx8Uj81aAlf+EX3HmyTRVd2WoaLHLs9JKGjZhabkaIGisoWdq+09ft97x0hapNtdD1kgVVOjRyDylk0cUG13jCn9ooIEJ1femUAmppRS8Gve8tm/Y8AOIuZnjQO1WsVrtppynVWk8qaSqczr2H2eVbC+v7957+7Pa3F1+yViv4CZti7XbYWXcbKNF+2eqFTTrXTRuaH6Zgmqa35rAJ02btdOSEbc1a9ov4BhUihjGGiwt3e6O2DJy6/MTNeO7Omw+PRULmNkfukxjTV6r37hEAxRAZNiiytKJ7VLZSa0519HDOxCO+4pu4hs26KVOhaq36WUXpJheEEVVIWMZynWrgsFFiJ84waZYTDZ9SNkNFjZc6c3wpX/eCD3zrb6tRYCllVVp4kaVUqgpVq34plVZgHwo3fH2j7/aD/ryf9DHtpJ4IF9Mbm5TgdczX1KWKWuhARRtd6kFvut5gY8201HrHnbWryeZa7kSnu9G7rbTVQZfdtx0OZOCCHChImIdNuJv6QEMMP9o4E89wZrM/0ZEnO5XpDz7cKONMNPk0M8zx0JNGJuqxH2Ncxe5pPp2He/T/MDx7kcUYnPoD5irimN7x1+95aHz6p/+/D//U5eO9L/9ncOYF1V82GYb8P3/P4TS489r92t836dd+9wWAIcKRnJGGmhIa9MQmTXQIRGCBK2Qioxk9jkmMY+xYkIB2aMJeLUHm/UVGcCK4d5ADEJzfHa9aCwOr/3ulkqhvjPZCPfJKvlAEpAWFYm/aXjmnMpktRf8RHURNon/n2exUPFWaKUJShZgTGfkJ3Xn616cizX/ORfnOeCF/frquzmRR1520LmKo2bZz4xW5Ih8qH4syHJrj63f5fFGzGS0zGgwGHQfc5DVoSfmLt1SzurMnOT1XQkd3u1Ej4JePVeZc+NPkN0j61eU1sXOlT5BREh6+0c0T3OgXEA1kCyzwZFQHoxjNiKHSky2AP0SM67jPNPcuQXCK3utoL3mW4TA4MmOrF8Knnui7iDf+opsmtjGeovLfmFmlJ6njyKXTo0sZeK4b3gumbqqfuYSer991c9vGZZuAZW/SNYjdgNLRjypHiqBEPzD52d5X5nT7uMVBcP3bTLeYni3R7vLEWqaR7BHWlkDbZZuuwn6Xrgb2Mey4O3VSVspF9F91slhYawK1x22SRcaTumpkjGNvelwnSaIhUJdU46A1mg1ZgoXGzqGzeD3B0lSxjZ0pMvzB9ON6Cn67Cez54QeFWYpDBsDoHYqzr9q3L+Wc2LV1aXYK5TIIcordYFLReNFoFpS028cyqL83zbg2ya3wg9bPsk259LBpsuc8oUbOG+Z0c5z8r33dPrjOF3R7e32LLlzlPOc47+SAxXu7zasfu5a2ovB6ppvbmYtmCYvUyJB3POF6CGb6BaRXXztR8WHRE2XklBq/1T50Aa2aV3e3bF6ySdj+XbrTYudVxLbx8gERlPDXXzyQeVn5/jq3xgcuz0hzyun5GsO+CGtHz2UU/a3OV+xkKK0uuTB3U4/LhjY4vy3E/Xk0xsDlpptclIwFmYeFRtiDQhG41yjs+4XuomCnESa9lvsaF68e1aOcmz+kXiygOYmVlXQ0teUbW4sRSuZjj6mBtuMxUOnpi9ZZvH+rrkEkgkRHRpb1HIIyjPFMYRObQWAygo6d37h920Wvu0Z+MHnMyF16VE66l5KxLsRQ/QdNn2HXWBs2JaxnobOw9NmVaFXBs90GHYx0zYxewlD9haQ/PTKJYLbib4NmqIev339xvBHpCspHL46SV7JtBYlLVTxXilQFJVIsXHGRVIVQ2csIEgNb9nN9j68kKBTL9xpFiZJ0eARz7Y7N9WJ84FAsk/xWk9Apxbplagid1TXnfjqJEpJjJrblpNNyvbjsaVVLMlVwhxQndxphDhCVYqMRTs0UW0n9Ox0klXq299oii0iw61QqicYKzpQiS0Xdnss4tpNwShRmn0mhCu6RoiAghLfe5bqbMEMNSQBoQKz6oETxS3qRlSMUjUQqfJpQdFt8cqhpGxnUAzqFetU039wLwleWOq2GwBtcTROfhBlZ28f1rel4QEQf5IqqFfMOJaJvmeHIzzGHhO3zezvcMMzhUdq6HLNWXGB1lpvNVaqUAxZwp7jiTIeNlA+F4OKB1dtv4r/UOKXbDldWdFDSkGZNNvNBXaXASC4Tc30+AbNDjBmMbty+q4dQCZFCh+NnqVQukd25I1iYhELQzIUjAuv9eYTIHfKZwerG4LmZBOHYF6pQdDFA6voN60r7T148UW2dikoC+oRCFOSiNx6nEXp3iScjqiu/2im0mCWhX1yN1ZcBqpT8rvy5WdQxM0K+0JocQvTr+YT+XZLPiO7KSHg0EZr/I+iEosmkUVeWY4e+zx1xT2Y8zvwlGelO064mvJtzixets4ZdSzzMzgYrlvVPnYZHBqPxALwd//RN204Sz7C7pDtrOn8m79yVUMsOd3UfCP5CYimBPSa+TSfQyq+3uTBtFYKr5N3QY8FJ+0m2SikZLnnOE7bXuchUwkmyEY1VXCtF1h+z0FdFgYKyGCQrct7ioibt+0VcDXiey/83ASjXnZ/6ggBUV/2Vv0fuebIOiZaXe7cfLLJfTKjs2W3A1IfHnSn66k9HPO81r1JykBYtH79FaWddzmZFcHhhmUtdWI2+r7dduoqK5wQMm/TIims3qtOzb+a4hH+wW11MT5CWH0LKkXOKm8Pf71fwTbWKM8/NuKy5KlGSLRSRCrJJMvH4656md6uEvR6L5QS2ufDWUfvtkOtS4Mj9WKToieX607HPXuwdoGIIbgD7fqArqd05I49rEUn4h+fe3XdqFUNzp5Fz5umf4H/VgorgEaTX4LkRLSeVeO4/zaSrpkVLthHPdxqNZjST4eKgeXAmSNqbsG+vrZEkYlMY50+Fc6j5CTlxCRpJjCaGS6k8UVLg1sClQ1++6NXPXXMywWhkEIShIZ77WmYnsG4aq1kvsxVw8eiU571Ma3+wfEaBPHp95+RsQ14Furpx8kweRPxILpYIyWTU+qmEfgxliFXOcl8jvQyb5bWUA4Wn7IwWaoHD9oZCbVEgDgzcoF8u3rRhzJ4B5wuz+sluVA9YPsftM8KVrt7eqxjMz2X3t583sMQsAQP5H3FheyGWhTBQz3WHtbOYKjcGSQbNCvV5gr5Ghw/NKQSo+1GeNdArPD6V9weL3MMJcKsic230rz8bmt2sxvkeJ1zt8Ert7YEjARzr0jVZ4SrdiYFrOGUAp2NorWPY5gxHfI1ooHP0Df5/WQJ1oyRM0mE1jOuddpG1igukeMuAqgcNFaP3MJh1rnj/nw3ZnU37wegDgnfkUkGlEe+pwlT9qGbm7hG1tke8FrIvYUid4FYt3hJT+sn+zIo6BuHOZ1trA/UnbYU1yFKmBBCCNblmUyW3KanWIVmgiGk0f8X07C193pg/yMFKavJyHQGCLnrvquhJ+ZBVvHPIfjn4jOQ5cpFA+U41Xzg/VVdnstapT1oWsaIeGh+yYKUlQrLYutlJnIAkEGf4sMTXkmOEY3lCtKQZjFvGxQ3v3DiFeE10ZwNEwD99XCCuaAn4wCGvxZlE2/0GSUXNqXHxWrZ/zYBs5lRbhjZbk+OkrI4NDv6MAe4u6nh2I1oGTbXjHu62QJyBlVjFYSnyk3zzyNZ6FcQtIaIIx4iwn1JxzAyypfb1kNvoss+ylfJjyg9hH9tWHw/4qcj3aKiPG4tb21/P2+El3kfHx1qm8O4viJH1UiziOGpdGOxcL/oE4Cz8vKyoXlOFxZ9N/iPHZvHWM0jZAlv0BowORpyHcWDnhWMf65W7PW7AWFqLsV/rXr3E3uVEsYPDywIoTfAlxSGfm8LLp8Z7O3Y0i4eip8GIUXm7TB540ZJTuGWfWVK6ZUyeLvMwiu3sczAguzdSDMP0JSQ5OYyHQO3MpFhskhaVYHARJ+khQVNvZKxQNR0m9VFuChAjbu74VFZaVMNAXLAHz42PdZuntwWYMZ4nve8an+UqqgUGGUOpYUbMChBfQycPa0SxXCgac/6uOy9EHSkx4iGHjKgjZUa9uCcr10EvmrNIrmqYt9l+gV4T8NU1IuXVXEoZVirEOv+7Mw56fHvSldRX2eJ5KgcPX3c8hgSbHk98nPh/7DR0oKQwsePpfx8LMZksFs0IHusjw97inPBi9MfxPZXHSp5njPPbFtwObKWhPiSDI4vP/1PwX/xsBrZh7ghXHrdg0UCxjCWqLhzkzjxTTxpVq11PPduoWCBEYx670gUhipuMdGqfLkTWc/og6bNViNqH9DC4ymYsl3jGgjDF3LlDqhziWQluHVecKvjj9qHfRxYkZybwf9wQYpRpgVXDK0wW4j8j3jPOnLXt2bBPshlZ9aD3wpNNUuHKOYJK8/JL8f4GhlSt+HhwbFqaSvy013S2EiqvL4CKD5B/oDguQaYEECJBLno0qqdxEaPoImtKy3wLXDr01QuPyG8PQqNC5XF/PoL5Jz1hy4zlZ9pHNolMSoq47xTa2K2uO6CPYQDchq/fX7h0UBwl8/NMopDMNyLoVzNxbGU4T4p9CkpkkgVKFE7uh21osxEDnL80tmRs6+938Cq6IpYz8tgD7YCXZOrCz1pbHdb2j1O9YJk3TrLdU5v+FmDG+oIJmSZlYf8hnuEdIhk1kf1iLrX/IfvEA6xkBMm46v5s1fvsi+5NgbqkOkcFWgUSKocqeEgoG+bdGDtUz6wQ8boR6xcKn3NfskMIvyTBXLluH2efz/Bru7HIXB3KaUHq/Mxtfd6iP8jCqtsX/XJCij/sviOnJ+XYkJRQ19dmR1VStlhX0m4a1I7pinJjQn8EBzSqLOUMZ1DPUHu0AK5li77NtqNJdU5LGgmfCqbjGyEMu0g+53sXfYN2PSCyJEIxyMIVwQSuIOvYdMnVtrkj3koHund2rO1D60922tmfuOSx6fTMqMZkRqtHwcGvXF02uMweUjfjRd1LtgJ48qTk8gY3Y93XA9Kmm2wLtHtyIw9K5Jpm0OZ/Y2Y1Y3DKGBzfI7rLrrVfG+e3+GIjBARdF/ZkXs90cjsz0QxhSVrgWVhA551Q9utQUJYzUgcXqieuQlEbGahYqF9dCR0NumtGwC8fK83kg8J1/KW6TCs1VsnRuTUjEvnQe6RkXzTmI5WdyABn4bSnvVZRIfMa0KhwXGrzP6g/2zI7eQ18SJv1U+dTdCotwdtLNzl1dLhNX40Uda5z/vWjW/el5cGTc0U2CXJHHZdH8XxmNoWMMYdN8IO2SFMDzBAZ4IonMuCpjAyZe2adwC5w18xBqR1kz3CdsEG/ckO5DM8TqdO2e4jTz59ZtP9MYaZZwcSTucvPnrqtf0VaG1MQz0SAnMNLOJ5TeSG3wMgEZB26uTJty42fBevGSaIFUPqz4obja1ecJnlQIhZVjjLRmHkfDHNiRwuVMLlZQZ7xSCSdJ7Mb5i+3I+2RcuRcgFI59ra5d4zKVuaf10YL91HR1vGc163bEiiVJ5b8bRYdFbc7bWj1GMiZ4ul0wOXOsLYZL+o6a8+Am7fTGta7GWvezucgaPl7Y7VzPx2W/lmwoEXsMjTBZaOHVmveOZ3HZ+JY1BSImepucMIlrvF1WEX6d3SYbUaHAGSXpy+qWRqYIit3Hch/B9hany/Z6TVoimTrpxlp+wK04iiKPtprE0DOIKUHYPoikpJK4GFQMzhdgGOo1T9amtzNHJH1XKRTr6D9l4zr52Q+m8WEr/74+NRZmDdKJGkoTLF9QPhGGxaX7SCuuVuEIouJ3iI40iN3eMzeIQaloOU796hPwg1uuMrWfwYqa35wB/CqhMdJh7mCykZ0TnIU535XJsYqQgf/ZTEwieWmVNXc+v2qFdAYOgH1S+9GoBiBTN+5L+pfO/dERtY5y4glCc4ax/HUIRavWnH1i2wf8a965S5qdNkMnykIVxTmBrvRhiad9J+cRqEejiIFqQKrg7zx+fAYRn0si3LZve1AI0q+6w+jIgHeN002i3QsNNze64sgtTj4IFNMfGZx918d+R0iELGKp0Ez8bSoixP+q9tqpVeNGa/007iXwrJMg7qxylP78tXL7tQYrdyZV8boB3dPAGa5bX3ZqYPG4tUtCp5lMF1YmyvdiitlI9x/d9pJzT1+1s13lXnVQbDjekhC6o8autfPrIL/pxKq90ZfXjeV2Clw+8WLS1D43ajNfDHDHdUxdPi6Xvgvz8g6A0Veg4Jsn+NvCcGl0aGbv7rWu8mNa5A5r3tcBG+NPs4cI58larcYLlIMvvWlKxYf+Wh5VzI859YO8d8WPfAXjJSWo21ySpXE3jeSJZGM7obmKie3kyLUchGyfRFrXHbkmgelg6RiT7OOPnhBopgwuOGlBiAilKRWiuJl84RkxheHSQQTLtTddhJLl5hsKYJV1Fk/F/ECqpQi4m5cXWKt8zCTV0cH0pXaMnHL+H9+p8v/3t/rhxu8YUe4wz/lwg3S8rBe6Wy78p9EiUV4pQyHk0m+wKQOSi3sxEmJgqahki6JmUYjAk+Q6cGjgfKR//BA35Ns8lcrq3ybToq55LvyZW23gCWSdDfLs2IWES/cNbbZOpJaHZFF/lSiOClTwUb4XSMf57RIv/aynOOuizckhU/THtholrCib6bE12wWIujrHKaqICm/rxmCYX5q9jV+T4DqdGT0t7gb+kDENIuvBk6rXfhoocsykZLiJUn0ge++iT6jMp/o+vu0C5bifRKO6Yr5KzJHY0iHJUbcX14QywFl5Md2rZwe8+oKSGBuedrRNLyYgTpggl9QejKPiC2q9Q+BliCMCAy+3jLp7eXHViPjw7wp5ijzmn5Knj78qh51RdnNw6MzKiul2uKiS7oruOS+JbNOziR4NZ3hJk1mj0mHYRtWxsWyeI9MNfTYLh3OOATKRMZR2pXBfrbbrvaM6BH8VMR7NDSk4foiY4PhOyWWJxm4pmsZtXzUYKxfBTqugBzH1zQ3i1YlTpKLqsfcXzr3sG0mTSnaYnkrlSq4cDL1Yg7J+xLVsRzOM/XIACckn3gqkgGyO5Emkzf3umtEFgTlRB7Q1oUTLbXUWYIWif15Z9cK8tTFVMtSkodln41gOdp3mvvuB7AN1YNmTNWt5Z9l5Stkz3lNYzcHapLqHGT710lY/j13rlx0Hbk7Miqj/a/S9/GV/938yu9eOoWPe4DR/R/Ou/S4Zve+XGf9BFj8gcJfBMcpzqzV9LJBWdLtcZHwqnvSvOl4BIjXPUKWrrbL8TUfrDSCqPQRhwQKhmMKLLWJB7KgxL763oHypeovt7rio252eXU2jTDZiEQjY0E1VzOp1DoXCBnFIZLpmZV4z29I1Q6GLp0NylobqDtpS38e0GwT9AK7l+EIYcwFNrtyuRAPQ+X9eZTyaltuJj14/medRwfSY1loSAJQvmSSuhKoO2XDz9M3jK01J7T+eVwzrh5ZbmoW9l9i06MvpfxsXKEzO8vCe8DFss92W3ECc9DPJKREX1q3YFBLZP5aeWF3J1FQdrDmgAaL8M8ipy6UQxFY7/bZ3Jg9RsYRVI5X8LiYtFVcqJNB2wztYZN4JWMVljJWoIkxix0ExXNG3YBVDVb3glXMjGE/DbTcDsYS9Z952YCrteFFxiqZf9Hvo9L6JLkDLXH2ecIH4MH4oNDiu7A+6c8SlXrA7BqXTvNnBSyOn5tLinouL5wzGFwGDQ6572xp9q2q4UGRSKzKz1lXX7dSSibVj9bCkcrKF7bhU41Ic/I2UQN5E7Zzp3D40pmpFXi7quSdJW5QJxg73+Iyw1W2ntkzGBQrMnDCCMffjbhFptKJqi/MiCAIk8oKxZE8c68MYLUYYQw5pBEwJPu+zkl2B7aZEf9Dd1Uz0qfQpIKsmH2+mekDKcVDsYTSW7s7qlGSJWkF6Y6C2lFdUa4rvE1zoxqbqOamMH2wEMay8UJxj8FQ28JAnMNPJ5mchOknGON7zalBwYg+AoXoNyl6rolRoTVoHp7JCJABEayHWskgBq4Wi5bOkncHBUcWYfp7YNNcgJxK4rWUctirYRCGTKk0LEB0P8E/JewKeVOO2LxddrjcF/WG8NQ53+LraTkpEYOPbAkbIScdvyXmXFKSGSvbp3ivuF0/On8cwTVWsD7o2csC4CnnCGt7oKPdrqPaNiox/Yts4s2WGQI+50sjZ2O62etOandW46by+b/AV/lYt3r2sAClZWsVPHOjpP1bGcvhw7pKjTvEDapP1L5RT3jmesDrk8XnALUJHXVu8H3PdW5wa8jhfSYPxWQ7GMsgfiaJbDXJb9dZhuG6emt94pXQR7RXBbXIVkvfhNM1py5OY1Qjzy8EG4LsGIWf4wlLoV/8KonNJ4aqDrUt6OqK5hK/gNjrH3A3NA+8lLx7p1RmafBhD6jKaiXW4542vPmPvVjeEzv8rW4HLUXNw0lwrKtjE8Sv3cpM4VqQyUJyn63IQ0psCqN5A4TLB6g3jFKgwYhr9DLiQI5QXHv5WKyK1v4Z2rm1fn5Niy2a7r+T/6znfCU7byHStGCHtZgWrcPXHlDSk2dq3tjhTAqaa3Jp0RSy6cA+j5lmf0YjWtkKQkLU27L80+7jX2rO2aK1Piv5ygpH6aoJ32bLsX4V+WM9J7UwSQ64rMoCwQIcJEWNshAFB7GCrVssJA9WOiORqgzgWmU4/JGlTr7pfepRWWF95MvTpScR4hKPWNFWA9ixcrSN8d67xqtYKyb4jaUbV5lVymJdTbp5UD3C68r8sKETTz5crzJu/tewVQ6nFIawccGcuneRFhYHKGTHuwd10Nck3mPBSs5VBMgYVDgIGlHtKev3wDsrzXrcXr33sN0Wk1mgMvpsnqTW7O3zRkHJsevVGOpoIaj2XuqyWTVfPDeprjPZVF1ZNYO6bNoxN6/IqdSlhN5gcegRaFRPbcQj2WCIXnO1GKgM1EBoTDUOqxGxOGWg0UxAvCxejga3YcbbSL9aUOCuVdGr16HhxURukD0xlTFjKaCeRd2axX5sI36Q1peaplleF2U7cpomW+gCZCjnGbvVt0rwt/0U/JAFre8ZnhuHBYNik4TZb9HOjYKXBc7qjw/lqao2Dffyr66QiWo4CouNycpTy5vDsVAsLB/K+3RL3W67wJ0w+vwtEStCQ8WO6n0uZA5olu1+0pTZ+ux4RCGOaFLIA424Q7ST+u9RmLdIgn7KLHErgIcKrkSMhc88uJcI3l2iI2uiPIse9PW7fb6o3YsmbNI9f+as2SXVvIrAOYr+saw1dDYiixgU1NIZPZu9MKvRmIxa7UnjAsbhqwjUCHmtv4CWetESbkkR9/3iQwoJKUPJDwC8HAj/z2sWtB2t3Zxj7sC7N5ftkawpVpIww6rzNIZnjKvK5ZybppXE80BnUpvDGCU347251SOKPeGTYYIe7SJHBTtjgwC+kBjU+TLIayX6nZNmEhlPbQKin7KHGQ/v38IVB24pqMFrC+4ZxTKrv1xLOsTDWrc4pV08nUSPhIaLepBkbgYbt0QVBS0ejeWiGHoqKImKo4F6hXFPwf1I1zaZujePUl5py97nsZE96/O+7z50IWO9pXr8SellKwKLFJcbyL7YvAlR0y6PWswOt9mccM1gRSsqFcLcP1dLxc87N8rRjnBz49LileGNOVZntwUud4XMDXhV+8zZl/WXSjZm0/D0rWWNMNmcL1PBtSRfJHanluUUMhwfiRGhxfFS06J3PmZpj5D+CeVxERqSYwOL3H0Je7v1P7PfCaGlkt5I+jMjk0MmkNivJJIgCyWzDeJRajA9+fyf/aRvMVYsj90emjf633/oimYH+r1woyfoCXQEJ+xYyQOMmCXk7n4XCve4ElKAk+dXEO4pWfsx1eyn5FHt+dW0rBeOxL3EYqwpk0q5ZrkQ/9Yr4uEgI4JLfjfgCk+jRq4GScXum3vtavaprXPVg5iD5kynA5PBAA9LqVGppi8DKj3TMvtSoJLuHWD6Z+zmBdQ+RY5dABR1dzNyRVAJB+XxqudJoVRUMjLYY5YDbYq8sZyKmSEVFivXtbSwahXezCWzlE/6NcQk7FXgDK/3zAqq4sqJ1KM5LGYHWbNmgRmzXF4jvemYp1eFYCChF7uLR5MSGpYJZE64PsITKvVBggEWvs6qBJAuzHqJ0XKELSNqRIu16RzNsT3xccPt0NuKLWs/SuX4VQAjlSh5SQ912ZRjbh6FqdTFhN5gvSetDmaAUBQc+II7oDLwHMoIBd/PNaJGDC0R9VrS3yhOU2sGFk4g7pAnSotkEtw6/SxDc+UjHtB+8fJ42aPqbIdLaCivQU85VFdWiZksYSj94q2myQ3MaIo8Pm/1qAN5Bmpn24OJj3oyIY8tESvJ2hHo6rA5Vz4rdwXT1VXFCTL1L7YHu3oobvHDWKDErS9CBwkPNoV7++23A04zqJdf9nvVaDeDoQaR3UN7tsR8cdB45qtn8jTKTV5hkgU2eCOWm/NMFaQz2RRoOWeXsK/kzigZxlgPskIRPmbE1L026gjxh0ZV43mdtcr/v/95MXE+LRsV+nGGQm1iZ3gfwE51IEh50LbF5AGzjDLKrbXBwqZ9Y/ze/lPyAnYlSmUIdFZkX0cs26j4EsBZ+U2xWK/PwCHVbNQrduaah6YDq8VgwDXPeRSFDLK2B6wNak5CRlyCoDyvthfbMrLpl4t1GYU6ryrCo8Iv4GSFeu9VxFLjj4RPuFB8/8ASDY6Mc6oylbD24oPzKlembYnxsY48RTqtcJbhS+XGBtVc0ygmTy2z+MCMV8V98E8Qxctv0I9CqODOydS9+ZRiEW/Cz/AWoEPh/6JuLt3E1/K2d2dD4MYTHi0WccyjOBbMfX4xvWDccwYp3G/aIyR6Gg3kn4fHu99y9lascjsZLLMABK4Ytc7A3CFCCsGn2x9v6NVJQp8Y0hWyy/PYQ+Dp14ZjCu++UE/3cvEnrnMegvkQh/C6OzcBZShIXfeWcnStbalHbuACbFAPH3kCH49gymTjbYWS2mcKODxNmPfWKOzLMvXeB5L26xT/TfiBe1D+qvUiJKbrN2igffBNZy9Eb0nYFFA2LiheWBE5PlAFIV0D5w4TE/RQjT/PK0ZIwYa6YxDUdWSqRVHUfQijqbB4zrS12XUUQtCRax6aBjBdrGLwfgvAuvjuegheN+T0MLOHmb2Yf/UB1Io7m8eWp1frclye9qPTeMNNXeH86XEnXO9vdDdglBllUM4KVsXs9c/F4G41V4J0htdMziFO+2Hg7N7NyLS2wEbtowLkY0KPoGC4SID3b+ASXs47K8a/5h3ASgXdPINSOcgOtJ14pnASgZkbqurBO9axzeqSCbRqCc3Z0GilwUgzBHownXrLdr/RQG4PPm8bX5Y6t/a5WEfbsYt4yxxyxj938hRc5486QhgsYw0YnMTJE/BZLrPyJ/XpNKTfQDOq8Cz9PN/OSydrbcB67Ne/XUsHJRcf+nDV1S7ABv2FTBzeniGlfSlYiNEGrWMDlYwvQcpK8rEEUNB5w4gTefUP6UFXU8UMS3iYHe7aiLJXJTQfT2Nw/K+6wLUT87yDTKOLAl0178zzAskvtGXwDES3WasmNDSdwQGRni6ya0dkN80+7u+zWHyheoTNGSvXSGvG+5moyAy4+U23AArD9NoD98CEYRok8TMoDA+Css9uoqRS+ojVQUHned2jJ+BWJL3Dm0UA8/klrwKs1yIO43QSaZnly0f1a+WW4XUxDey++DSBu5hsOuCyYazlGrgJSRASzq6kCo6aTN37gUn8if8bX5pSqYIbLQ2nXBUxlosbY3FttwlrLCaCDhS84Q06ozmBE5nOePa2mhINEr7lmgr93Ycyr2z3BkIPRVda/CznL0Vgq6uzKyjs7/um8VP1I2XgfBAJ3zQqMBlgPi6pf4E5iuCZjicLtMZVN/KyqhlIcee1WHqshQ2/hlK8BHRePC/cgykQ1w1cHsTLjKYBXS0spikDgbdccd6Szn/c/IsenIwN1VGVfZXRldig/6ms/rtSKCJ1Raluj6TYbBc3H4rBAL3BFbOK5dPxl/FF6fo+4lmJF1bu3xAMMyRFEaOkxTwlyMBjmPPIK4M0slYFrBPQh3lrlDjwikJHrTFBkHEc0QalZdl3Erif4iTOo/E1ruHDS0zr7drxjbdeb2oC7YNy70+DePRRpoS1PnC0zlbcrG0Bi6kfXUg+LIw6V+Q9L4r+1K21h1apMZNhiYfBXbbDK1iulwsm67wyGFkieDZmVyZdf/ISJq7wzPLmDzzIV+myhIb2GvS0bHV5FS43/RcUbO1J7R3aEGagj+BH1WTma1wDylZlYtimBNg009MahKGmyfOjo5BVRlFZhwKvLFpbiCx9ATV7DHyWc+jDlCvdsAyiQKRY2p9RZ6qiibXOLtgXI024a3GmCpeoHpE7lgfB2apCYnwgI8bT8IpvOl7owmsaLSYFSKCCx6EYsRLB9jQuBKbgMrejhie/8Kxv/68hfsO7Q9HveIm+BLmRmQPJGOufbuNqDf8RuaLguBmlV1T0gD2fK7osEC6n8id4nx6YO74vBrj8q4cfgVbD1AtdXSUwFnhOm2y8yq1sLoZ1F/b5WkIwNBfaZvq3WLd5opRYOab4GpsMqJy9TCB5uJdzbU9M4frohXV0ad1GTkf3tvDzSwib8kHoe+ylPzccDqElYQCzzCNlHrGlYpt6tYJAbMLYdxpqvsMRkSRfYUHgMT2ao85jVfQnXO2m9MqeDSaUacwydLj2WzTRVgcpxt5ouNIx1qh4WBup3E18rSoenkjBQPI5vPWFEz6eG5N1uydOfrzAd+USagyspsaw0fqStXnsH+03YCI2CP2fVWt1xKyUpUnMJAp/vVCY/15EXoFnV3oLogzQNXjpz5jBCnn6J0QWSMiV+qbbNqTQdKG8hFO9dqkCEOZOqVUph6UBa13AXSRPGnSQSoxHS6WlnUBWFFyFBBhr7mGOCTlxHhkxV881gf5gheqtrkf6wjUnGTTgaGhfTRfmd0d/xpU+pDdgynMqUSWmJyLDFHobQ5d46oX2sncoxVofaGi0sX7bUA0f8aHk3VAU2Dc/5brGq5K9Kyn5EC9Soperw+uTflmVq+vsVDaYV/39OZAPP5K+xTE+PIEXoKr0fT+iknA3GrxrHiUQaOPgpjlvwBe5axYDH9uW7lkrpbVZZWGfUu77mEIsxDqXKmBDkYI7vyur5BOCN/AsFTzL1dScNXJB/IybZ8Z6mUBQxvVSocRBVlCtSEcSBZrf26ePzZ0cJb6IzkqJHy1iTREcnLYkNs75S2LDbT8+vlFKgxt8XX9E53Jonq+PF2VHlDofS0B2OT6EAAIcuot5xjZsbmQHttJ1D0e2072YhJ10321kL3a1bzn20OOPHcS+27f/0cgU+q5wiH4OHMVh+h1U4xiO0B+PYGr7np5wHBp7F06DE4e+P3YmLKbhHNwywCIs5TZwCZwPLoOLcPtDoAZeCszAFXjpG1ALroa9wHV4lcdugxuH406YyTvdhVm8b+EOfFDhAbgLHw7ugYfgPnzEI5jdt/qf8Ag+f2EuX7rwFDw+POaxZ+HF58gL+MkZWY9V/PQ1wgDyMnTrWzJAChgFDAYYaAf/B6zAEPh/0A0QQGvAAt3BIPDfQM+BHqAS8OB+A33BRNoQHgDKwUDQCogEUUALoBiUwgMfggCUgGhgBSRAv4EuYADYxBPAWizkicAePAmQ4MlfmIzpYs3PVqIroID2A50Qx0MrI054BB0RFyzQwP9gGRZjNW09qFWAA9ZhA5aLy4AFMAN2EJfPyBK0hLgSZYirMF9c/UnVARMwHIzGiEbGYBxGYax4a0bGi3f+hz/4iBz+v9tvm58RQEAKSAf5oBB0AguwGE1QG7QNtAe0N/Q0fQ39Af0NjYHGwcfDV/Pt/Da/JwpAlIE4BXE64izEjWIRsgDkWshNkecjX5PelN6WBiEXojpQq6O2Q+2Nukqeg25DL4neGr0d+iqFGxRuUrhX4UGF5xTeUfgSUwJmPcxemBMxLyoOxS6N3RV7t9JLSu8rTcIuIOpOtDfRVcpPKPcj7iA+mXg48TSSBJI2khVIziA5i+Qt1Wkk83EBXA24A3Fvqn2qoZ30Vg0PaXhKwxsaPtTYB781fmf8Uxp/xU8gawLZqmQ7kx1HdpWmFzQfjvCm5vHkK5FvQn4y8kuQP6DlJS3fkk+nKACKJSg2pDgAxZEo3tc6iHJpyh1RXqXtNW0zqfpQnYXqWu2Pa39B+xiqqdTrU5+L+mNZpBGg2YbmYJqzaG6leZbmZzQT0WZA2xPtemh3oz2H9hba12gnoKsCuhXQ7Ud3A9236OaiXwv9WQwCDD9hmIixCTCugfEgxpsZ32f8AeMgTEczncN0LdPDTG8yb8t8NvMPmGdwhJc9lfOUy5WrlWuUG5QFys9KqjarSlUfVT/VM9UL1Vnq15qZmjmapZrjmmrtcG2y9r62Q6tL9MAba2/svXH3ptGbLm++4RDGIY3DCUcNjlYcFJwvcOrhhOMcwCWCC4rrA65MXMO4rnC/wK2C2wZ3Ku423Kd4JPAY43HH04KHiOcKrwheA7y+eCsAdQANAVsBhwAXAPcBf3sr4+2Stxf4aPA9w8eHTwmfET4ffMn4avA/xs+LXxK/GX5H/KH4a/GP498hQEcAQSCPwCFBGMFogkuENAkFEGoj1EfoO2EGwvyEwYTfEfYgTCA8SviACD0RPiLaRMyJhBApJzJNlJ+oNlF3oilEO4huEGMgJkMsilgxsUliB8QfEucirkfciTiOeD/xXaC7QGxAQCBlIEMgTyA8UAVQJ9As0C6JOyTYSIiQsCThQyKGRByJZBIkEiskmUgak9wn5UIKT6qF1Crp26RlSFuR9iAdQ+YuGXYyImSgZD6QaSNrQ7aM3H1ykuScyOWQmyQ3R26N/B3yiuQ9ydeRb6PATEGFgiOFQYoPKdpQLKe4SkmEkjglOUoJlNIpHVE2oJxGuYByLZUXVHipSFGJpDJOlYnqJ6q+VKOoLlPdpsZETYNaCPVr1H2p+1OfoSFPI4PGDk0jms20xGnl0fah3UJ7jTYVGAAYzwr8ElgMWA0YDmwDPAfCCiIOogoCBbEBcQAJBsGD5ICUgj4DtQJNBS0GbQOdBV0FPQO7BcYAxgXmDPY/WDlYI9gE2ALYEZ1rdGjpsNExpRNMh0hXhy6GLpmeDj1nekf01enr0jen70Y/nn49/XH6v8CB4DDw/8CTwAvBm8B7wCfBN8Gp4L8gbkEwQXBCyEDoQsAhDCCMIT5A2EP4QQRCYCEqILogJiDWIb5B0kC+ghSHVINEQn6CDIIMhQyHTIP8HzIbsgayD3IB8pTBTQasDHgZCDNQZ2DEYIOhOMMhRp8ZTTDWY0xiEsWUg+k+03Omf6D0oNBQ9lAhUDioXKgKqGaofqgJqEWoHagTqN/Qd6GZoV9Bq0ObQjtDY6C/QGdC10P3Qc9Ar0LvQ2PkEgAKuA8YwXMABCCgCnSACXgP/AAWVIMW0AsmwDzYBsfgJ7wJaeATyAGFIBhaQGcYCmNhKiyA1bANDsIpuAL3oXJ6xfw685vM7zD/wHydhQaLaJZ0LD1YXrKSYGXEqpT1fdYarAfYvGSjx6aQzT9TA9kesgOyC2LX5z3Q+34feHzw8yHAhyMfVX3s8nHYJ3GffrC3Y5/N/gcHKQ4QDoscpTjKcszgeMVJlVMTZ1rOQZz7/PfWf01c2Lk4connUseFwjWdmxa3fu6M3PN5yPO8w9OdFx+vct4yvJf4uPOh8q3ip85vgT+C/7wAXQFNApUEHgs8E3gp8LvAXwL/CAIA2A1BhoIaBd8SrC44WzBJCKsQOyEtQq2EtgldEXoE8xJGGkYdBgHjCZMOMwBDFfZUmJwwZ2F+wuKFlQh/JfyN8AQR3CJ0RBiJcBBRL+JKpIPIM585fH7nc7zPIz7/FiUmykZUpqhaUROwnLBwWBNYe1hP2BjYXNgh2BnYA9i/otVFu4seQwwCFPQY8SJRpIxsUQTKRDmoBnWjcbSCjtBf/AhzYkksgyHYDDviIJyCK3AbXsC7+Bu5TujIKyJMtIgFcSY+JJzgSQ6pIt2EQObJAflJ71M2CqQSFEztqCsNoF9oBi2hHXSO7pJePJv4N+INxVuIDxKfIr5RPFH8jvhvcLfhWOB44CzgguEq4FrgqHC/4cXhwfAoeAx8IXwPfB/8IPwo/AT8NPy2BCsJThI6JT7Gs396/3D/fwU6wUawEyqFaqFFF6gL1j/Xi+r19dn6Jj1Bv2u4YWA3GBs8DN7Ge0Zr47pxy6RgUjYVmZrN0uYkc4qZYvG2+FuOrSbWVuuFjd5WZH9tr7c3iWziS5FHFBLVxPeis4gX+8QRUcfnSC5M7pU8iLxq+Xfkm8n3lR8hHy8/X/6Y/DX5JwpuKWBQwKVASUGzglYFHQrBCmEKQxVWK6xTSFZ4qAioiE+RvCI9RTmK8hRVKKpSVKvYRbGb4gElN5UoKglVel1pitIjZabKTpTbKndSPqQCrgKlgqRiUwVV5X2Vj1TGqZJVNaNqWdWO6leqg9WoqFFTU6hmWy1IbaLaBXUW6u+rD1H/Tf0/+1AarjTqamzS2KeJRpO0pgRNfzW7a87V3Ku5X/MvLde1sGlJ1HpT6x2tWK1JWlu07mj9po1Zm5W2bO23tCtph2mP0d6gvVMHs45XOlZ0rOm8pxOs00Nnti4WXX66+nSL6y7Q81KPoB49PXt6jvXq6TXX66M3UW+jPnZ9cfo69T/Wz6XfRX+xAU0D2gbyDKwYVDBYZPDCkImhGcNAwzjDo77S+/rZ130EWgR5BB2EAIRohAqEKoQxhH2EQyPiRlSN9BuNMJpstNhon9E5oxRj4cY1jVOMX5pgN2FuAmei1wTBxKgJoolTExeYYECmwJSZGtNk2syAGTMUc2Fu7Iid8Gv8Br/NNbg2h3Adrs/fcQfuw1s5WQIUiU4CS6FSj0R1SDmsHM6OXEe1Y4Sizz4wK20WbhZrdsrsDCIIURXRANEa0QuxALEIcRzxAvEP0i0kGiQtpDSkAqQzc1rmkObQ5uzNuZvrM89mnsO8o/mv5nct3LfAa0HDgqWFM4s0FsUsDlkCWVKwlGep3FK9pXZLu5ZvWua37GA51nKj5WUrDFaeWvliJdvKkpUTq3xW7azWWaVY07YGtzZmjWRtTYo6ADpunZLOWofR5eradSTdhTWttZi1obWrdbR1mfWg9ZH+rp5Xb60P0xfoR/VXtgVtm9iOt03wt6bNAxsGGxUbD5sSmw1WY5fFLr9ddbsDdlftXtijtydoD22vzt4aMjsyGNkHORQZi5yA3IY8hPwN+Y/9cPt4+032tx2wOVB04OggzkGLg3YH/Q6vO3zgUNdhisNehwSH0yhgFDiKKQoaxRalwxGDo6eOXBzNOFpGZUSFooahRqCeO0Y5tnZs6/iD4zjHeMdJjlOdPHBC4+SxE5STd04sncw6OXCq5FTFaYLTJKepzkycoZz9cO7vvMh5ifMBF3QujnL+Trgz0Tnl4nJlucbdgm6cu97D7wnzjPuy+cbLD+SnsoAsLWvLZvInOUhOlEvlTS+719CL834/gYyT8TTPmOfMK7pW12mettMH+D+W7hYv+tCP4byL97ADX+BrVmwlbpsBhKA4wOgAp7rWQshZr+uETvCGWtgib6z2xg/JCm8O9+ZvKRZREkQFiwgTsd/bhd5+7O3X3v4i4yxqhnezvJvj3TXefe69SDETvXfJ++U+MIkb54NvSn7KlfmwQekQH9300R1prBLTpcmU5oG2NlpLQnJbfdrq19a8aJcuEPFYpKVP9SJ+1ngfdORmODp3hgFz9W5JXGEXPGIUuqskkaMFcswR8tP9QHJVJij0HCFYvUuCK+xw1XahDKj/msScK6bPp/mcCU/SBDSJ0I9F0DHcAMTyAR83JU71EQ4EGsEnjGw2nxKCelNvx0ipDJ/2A4yDOI/Ub5TaEHqAMo42uANFRG3NnPDygWaxDrhN/BXYWSgHJ0gxJ0NnbsRjLaHWQCfJSLKsxcIhBtaSHb0sRfubgk6GZgO/YcM813WyhaGFDDJTDcQvZLH8/XmJFYj8KOxHKUbBogW9H7jVbIXBm1DyqWPvU2G7CcG3ltGrXIEwpx5+hFLSiHUM/FjX/pSKY3QhFB7TygP/EmJRZ516QJXmwAQppi5UG4kfBU4gGx56LC1Kwqkw0mciFW8IQU5dZ2IfXGJ86n7o7BdnEk3Z4tCDw0KpirVndqDZS0UkD0M+FmEXLCX4rOEiHsW6/swf2+YzCmNEFHMC0viAeul2P3WSrJAXTU5MqoDrzrnF6lUpxojSZmgAtSp5qy6VRYdSNmW6AgeFTvygNZCAe4e5G7EcPwiWgQInZMYrFNFqlWboikRcKXKA0zhwP/YiQONDQE0kr9VhCYpqyCGAoFLItUIrewq5FmhBd8ihTER1s9ck5x/l5htWcAwXS4IJh/WmEHyA1BDwpE5nT2PJP+lhnj3/+xlW6IfB6qPtyV7/cZqDLP0L0IE/eJFqJerg63rUWxm4NU+WfjoyFOA5eAT1rWvmmobZ2uROX4kM4a1mXP1O1OgNJuLCTO0coaYxqg6Fx7zDPRYeUeiLR62udTC6A7WWU1ZH7EIQnJbxCZChAc664VGB5IIRE3865Yh4EYsLMKP7fJ7A0U8UrvxDGKWfqdm6UGAXQUPx+R6JsGPhUMB2Ksol9YAhnrCsF40vedO4aMtUU8BIrQve6lMzCr1kPnO/ax86LlqL9pV3xKv2QTFbwh3t2waxZMeu73dqvunNKgY+d5ltL6/CYMMzwmEtKSHwMxBFl6rTggBHG9j+rT4ZNrhtoh82mjWRHh4R7bFXP2xp+ruTDmHEfdSp6vzrjDyCJIOsZA/RcboraxKyDsIqAZbqNokXCaDNlWDPMJexUIuQusR4SsLYrBGSJSG8JTDAYKqEbA5Af4G0BSJpFIJG8LGL8qZ2ghDCRbhPXSAbKpDAhJwy1VWGIMad3YNVrCkDj3HRIhAoAXGaWfQJetrLombezM493FOmvCjc8Z+UKiPVyuSebr/uYALrAmCA5tODoyEnLBkOHpgHLmyJouhcrdyqooW9XEujFxvoyXU0WCyAT9RLbeRlQMy3QsmZmtUX8dZnSacxVq8k0hk5FgKfoeQ0Sk+fgMtRRcIZ0TudUQLXK0wrBjiCLKHp7mO+pRRZ/F5NDGti3t9pFIT3NDvgA8zJND0WXrQGEMDYhHLGAzP7O8RSjLVb6gUGPulnyehP3bLZA2gMazKDgyYJ3Prmg5s2+4dfTiRrzFWEZXqn459YWT8800slhzTBpoIjYIrKfe1V8NfQIUODEgjusa+IWktPfgfE6vDK/dv8axcuXdB7QZ/EdVelUyY2D6GoH5u8rJF4JGEh7GNYzlj6HmupYwlLGbAC6lxG4gsJv3fuOEJPeAetZ9oW3K2oZTPLfYNoGaFGPOMmNDWnMZPFyecwmkKoryhSRW/zCflcHY94S49tn2mshlEFlOvJIR56iuD6hibi5nkB85tXz0a4axXVXSY3QpdZqZgLea9O6UopAlSKTMN1EpPpnM7M+bQKwdICmwaRO3M07LWzM5X+rjOb4p9L4QJ31YrqT67FCLxMyyDybabUCcvk4oihNL624+Opg2MTcOQkvXjPdTOOQL9bfITMQ0CR+/YD1roCvEbL4Zq6uSxKnIQkytudsekhf52byGB18gapX8ga94S3cr72stHO4XSKMe6zVcr1mlJ3HJscrG9ANgUOHq7RPD7x648TzoMgn2w4elzkLF+8arX9YNOPWVmBkDGI6j5a51MrqRiPchXrvArGWQCt3TE98N5vFXyMPtgbC+o3ICo+/N7ZmXqgCgLM38UOydLAmSLmi2f7z8YpOeXq6r1ei4IZ2X1ZCZc3Bb2BYzOWT/V3/Wh5z73g3SycSLmCWjAauBEIJVZKCoLpt/LhSeIZZx3YxET3Q0D+JiVifJWJTxC2FQyaV0irZ3RuLNk/sj/jy+x7zOKcBf+t5wGW7rv0KlcjuanOJdwQclmMv4ZUxzRYDe08KQimMBPlWEl1WKkljwFYLlR/6hw85J5DXPqlhimwwf2LJXsWMNxBsFEfmEalko87RoCFzFBMkJgwrDHJcStXYba8SL8RBl7sCMx3X9NVADlu6VaKEryVhw0DT8ObOe2Y5UaKgFvzkruwGYgtu747DdcPWNe4qkQyWsGCSqxQAvccHylRmc7ZBOz8ReAugJJ6qxKvaQ7aIMy3XZdcIJNOy7WSCnq3wh9Yd5Cil6hYye3kSTd4uY/tAQ2pcDM4PZ4Tz0N2URKWHwtL9kh8cuxBGliQXX0MhRxd7oum8MrF0Fy/3FfsWiruglGFFZ+BH66KvVTlXp3f6x0Julz++HWkt9zHck6Wp/Bue+tIRQqA6w4wvXpxagFnCTS10ShIqNz3UFcZlGQWs4yzXShEMggsQMRsxFnKCrOHJk6JO9GeeuSaOzlzz70HCc2hmwSaNkfUNtZBVQXtn8KN7qTb9Fe7JqJfH8E7N3CDjn7rPedsauYMaDwfXQG+qIQ7cZKvckju+DkkkVojeFWWDbgFE4JudSeJG56sEKv2y5BIgH01YYE6nTRmhY7zAUINiLUGQ9A+uKbOhqxBm5nw9M3P5Tb1w1FEZ3sEGNqPQH6wJZhfV0zySfFceax/fo75nGKdYiTTaAYutaOVal7qobEPU62RgYxdHmIjcQGXus3EhbrUeWzpkulQXd+jHNNMdwDFK949g33QoT1pw0hsgcy6OJJJc+ty63JDTrZCuIZ+qOhJ+sgX0fX8FxeVqaHEFdDwinMB/ht/0E7sgbK6bFJGa+pqaE2c6kpMUgTJV6Pxi/YRVzc5Ms71oX6tzT7FVQsV266oyjwdDEU/XvYVdzHx0oGNX9Brt/uxdZsW2rSPhyvUVusV8gXp9Z++RnwfzJl43Awg2j+tNuVSvMhymDOHJQ3JMGkYhuaBmhudzOzGYjcXiDvQXNd05M3RB+6iBnxPI6IJf1VRkbmRXxk7tT1CncHHcsauoWK37Lc8vqcMXlIsMdU9YzuUUmqe2siSz2PCZ8EPCUUEDzhXtaL6Vy5Am5ekcJkJwdj+KGXsPM5KMSuPGqiutjFHe0kl9OYMUGc8/R96PENbGMPZD5Y/tTqPk2Loay6lTqjkq9xIJ7bUgeqIHHv73LShCwWrJoKbaoMlLwd57FzAjYbkIMlyjqfS+Wu6HSWqD+FklzG88qoV1UdoNynHvh6hY8vMNBtK4z4H1TIUHvMAZcxg71AHfPiv/FiHDgbetZ4m3Iw9MmSK0EgjfsrNejCrllrWKzR2HH1N3DIHBiRJQDHLND63Sz9+kTX6XhT+eOvXxQ2Z+CMJ8qmngZCwhhjxm8OCEzN78zoVyYhgeniEMThr4SehcQvH3Ud6+6J28D5k9eR2wpc18osNCxiCN0sAwzMuOZZGjNLVe2HYrNT8qs88jbpmS86+poUoZxg20M0KJXSsc1Jb7ZrVmOsoYZBFmsVaX9LXf74pPermNjcUbBajitwYEdEnAK9aOwQeH8uLQbHjCz4HWwLlFnuS9tgGvk1k/jl2S1VXK07O3zi78iI5aWl8C1UA6ksB6pvYN0BZTT4UpiLyOG2/6to9do1eOR3/wdwoH+AAalTshz1+uLBSibnh75AVQOvH4n8jx2P0ipIcagg+9X6vMcLHzsYmpNK+mGZbLhacGMdLT/EQc7uxDN0TethS5zqMe09JvuAWcyY2KpebuO+0FEbcR26E4hh8EJPaEvLkt7UsgkREzxCvrQS9QrjZrexCtYfI8rMat/GajLXM6sBn7OaMeJEdi/JawfCFVOMc912MV3MTVeqRronMF0YzvFDkbcGkj7VcZ+JL0ogv2QO+HTCLmhJYz0CC6C/ypYTwIjBrgTD9DLEnd4g9WQP2xdgXjwatIxUm9nQOVSm9rI2sI0fIOmKN65ynyI0JTfNhPb+zFr/5IqrjrqQASgalAEoBNATQYPBmdKbk9B9JZfwLDlAaeWHoizNGPjBagJEPjAdA5OOA3FPuthwj4NpxZ5UriSnF8h6u8mA2lpGLOYgu5str3CQnc6hMIHVM6JXPXy1KxkXDON7eYJpMU7N0qcrHQZxwm97U0p54LzcIIQARnC/F0q02FcawzrEdrvQXVzRhF+MMlhOLHzFpNixwy3RhbD8h0IwnbMUxmBIz9ljhnE7cRlggdmIyClH6E5YvLgRyNc/R+mGgwUuLXAYRc5EGiXbWOX6ZSsv8WTqmgksfbn793eA6OZsYy9Bs8bAcSdYkzv2LptCuXSj+xeWgIYfSAC5FsMjQQmSaaqxFBvM4JhrytU/3HbPkq8BMCY8oVAzwKwziYk7qIqvNRezUTjrzK+72u/kBQscVQwNFY+2qEbFpROUcbqZ6Idm6LIcvNj5RVXNyG6Tr02zvelx1zfrLRMSITKcc96bCPxVq50c5tui0zHAuPD/xemkmYfNQGs+PUEOmEVD05LVh1+i69v5/T8TVJGF+XJ0t+jMjyoMG7c5K2UxUj1PWZNdBITItHWZZmhA2DGb01SG4EamvWTIAPicKhUXk1bfDeOwF2oZQjA5kNlQ+Lv2r5FNALQ3eIsaG4RQ4xz2eXiD4RhIiQnjChL3q8XcbrO5g8+x202tbRnS50f+Po8gBZsORp5lWAtLMCq/K67kW89F7q94a1xdI2Ngzvav92Ni0cktJzTOU16fO+iAqP+WOk3Jo2KeINsrWwZjmbovQrVzAUBvzZD/i/JKX06XG6FqMaV62YLeiQza9aaOUMSEkEqLmagvzVkzSTOBjTnRPojfytaF03LQ/RaVp8TF4q1I7QEdM2vVP1QBBk9JA7YysRCZsa7/LhuT/VDMFTxtyYjGA+MxpS4fj1y/U60ELJRiovFba5HDQat6H57e9n6mKxi+k80guulTacqhxs4wH6XxcHgo6tX4G86Ki0cGArqIium2+2EF8mh3Rrkmkzbo96qkm+Ut1OQb6cIVky7+uIMOAG/6WoK2EGL67Sl0LcSxhYNyAYTwveahwQMwgy19WO2M6KD6vQgKti23UHTbWaezqlgm8pQykkxkUBaALiTVS/iXrMECJYBVTeRpPx3Q8RLhwdRcWBIieyzGEhJVJX1/orwfxb/RBrebOLQzEPAyBcxk/tP2aTnhP3xyrZTyL+e0XD8/G4D/KbzWrA8Ko9OwpAPPY3Cpg052xuVPAZinjb6f88ZetnZ/jFqkiBqkKGF5nSsLPyfvkwlrxFW10I4YWkBKiJXIsGYBiEvRxjx97u0Reb9OgQ+Kb7XstOeRiSxapxjz3ehgo3L6X1uabk6x8wu9PP6aPGg3w73qFua4QQvyK23UA2HKWf8Z5td3aSevG2vl5+4TqVopwWXW5JTCEuWwzgHu0fDpLDskPWA7q4WDlHDHnb2bPosOGx8yMl8xYp+Lx44y+BUArrjY8wEQR/WbR9U8gYJLa4j/hlFe9vJjFxvqHZO3t/l2V5BUH5/gqULl0rL6WhmKyvCbLHzjaNY22AEsraIRgk3/l+sxlSFrZU1Z5vijnKvYoA66VjqlX7Laq8L0056icF5A/mA8l+J+jSZTbYyGuDuYMnl0IxYWwllojvsfXZJRgJmkgEtIKlfGKthEXJW8p4jxXwtT96Zy6W7esdjIEo4M1xJzexC8IGbAxcAppbQeTyOign+G0dAxaJgJ368i7q2Yt+45BdtiUS5RETnQgd3Dm21KqEVdhiD5g4NoaRSk6k+PEmwSCt407S//ZOByge78GQzrUJnaQ16SbDJNuY3hpceR2GopUejKNZoBQ2wpX8bvIxdSqJiVRahEZohcIDew1xglsEOjOTAbtRgLNe4Sdu+wbB8wXpauqMnZWqi5/bsRvbpTvDSNtNrrZTnTDnVlu7wE72pV7bqXR7aOXipISUhaj4ol9uUDSlRWQKyeic7QS0Upr2bY+tOyNEwnPCAdv5hHAlJjr/wLVLwVJSWsc/2UWuZR2qZlQvRU3uHBXbiTTVdUXN8AlHqsYXpq3GY03pOsj+LYb2K1mQa6aEtwjh8E8dLgJfok6+Vno7DDGL0G1iJ7XCsA7pG6kC05pjJCawP26R4FaIiTRpMZtVo/aHVMNjItdlDg1BAI7X5Yr810Ev/m7D1iNCHthdfcDKv6jO7p1f3avr/ZWbnkrt7or1d1d1Bvx2Cuz0I/3nNru9Qj6WauipDYQW/c4UEuEREhrg43+IXiXqUDK/qMXMPzmCwC/R6TwtfpD2jonrZ7PFFum2Gphvjb6tQY3t8amFrVKwW83qWQegs5obXDpLtRoJku1pe5C1n2Np6BxEbJei1F+TG+iwJV6xAN+fE+DXIWWjtJOCnp4gFCTy7cayVnuRC8VycsdrLdOMAq7GDXguHn/++rKM/EPtq6bv95JsAbbZ8fhE8ZNrOVPRG3APvqIHZ5QRxgwdCzAQi9PTU5GfunsRnVuJ56HqTu6JBTEzji2WFfHzolj1yrDCJjEYbw1gjo9TCi/NY1BmPBZa5PzXaDb9ZaSsW3NJUraTFKIiCp9rSyg0jLXzGdpdBeoRTgt1MdyIL7uSaCe3CF3aL3VqGHga4xCjdqwaXwOTTaNpugzvEk1vqXJtA9emP3CqLYa2cDlnfcYZCm32D1hMXlYy85ikDVxi7sJrH8COJEtT9gOGpMoNY070ZRMo9kMfGe6TSN3MioFAzWtOR+1ehpQVg0ZDsWMJaydxFDrxZIPtA/6rEdk2PEirGK/Ow1JFJZzE5zXqVprUHpd89Nany4sqw6BEQ9kPRDxMOqAzAAHKxHizJB8NbuuXXyXraADoEZSYFl8b+QwPY6HCZ86VTBAqXNsajZDqdOY7O96kDZkFpVMR10cE5qP4JqJwy/BRF4EnZOXbKR/tKbQyIbSqZESEG3GFKIkEie6Y1pq4CDevpuUgNK5JAfUeZtGS0PIP99W+5D3WC68GDaJ44AhZCSwTTQZXxoZ+2TAm0c4tnOu5lgT1ZNTAXBRRNrUuOSrblxiXjVYGVhN7IIuxI6Ki1tdik2V8339Ei3xCe3ZmVx2Ici/ehjd1625ds//oGfGUVgo+ickZwYyEzJvaaOsrbgWA+KZlyLIv25BbmhH4nbHnC0qTcxNFI4wNtGmQFkpV4UK8m2WEh8Z8LiN6yQG49+6oDS0O8tGZ7NLsXMn+mt88jcOpzXpDrX1ELZKEg34/eANN1DBQzkqNRtkbfzHnh99JShruagIV64/lIC5T7F0Eprnn08x8NSC6TmjJtOwQy+QBHjp1d0dX2xYvNWFz4ZO+/yNpwg0oevKi9CTe5hB7U5JGpMUqzdgogKvohyvDnRXx+WjEiodRk64rk6I/p8q3MISDMNiDBuMSvGPer44K2aFBT7lbhUAIH2y9kE4wBv6hveYyshxM4KwI2M/vfNFUQmZyz8mk7IrovDmYugtIOQQlyHKYFwGkSKxP5XDcPvPXSEZKzESKzCyT845VbJgzMZzTa9OMcWSeYWHui9BSAMBwc/BolnuX8a+jDN7BN5LWGtOLFN9jF9OgPjTx6YwenLSyby2YEq56jVD2TBssONakhgCs5iwdZGInbNLL85eScTmRMuNlKA/SafUdzEyNHAzgtkopYKEk1IM5zs0ovcxahATEnxmIibol6i4jA3nyuuIMurm3pZWkbDkRRLDzuzp6eDCfWp/vihs9gKlhygVJMQytoxNEdfQR+CzFN3+ycbd/94ZtJb3X3NKScD5NArysx7FpH+HcthUxW2kIeLO4sqyuzhWTb3DzplszNruwkvCuSF0EHKILhhyxlv0Ci+dZPMYWa8riRJFEKEQBTBCwRwy4aP++JC71ed1IG1v8i3eBeSu0bpRGRckklTSSKWc5F/LenV1ibUK5d7xZUocRjztUppYF+ByyG43EevMSv7YufmTy3LuQVnw+0qZpLKqRHak8yt27d16Fyvsa1OS16yPX9kp0hpq+DQhLHa00IUChUsY8FLBI8pcuErFUidY/UkFn+4qcUqhBOb0xFIi6ObNb2786jkY7lJ1HiF1z+34A1J2vA84zTULRgiYRH1fVRWtPnWf+o5Ex7WcH8AUasUTo7aRJ1iMTYcd7NVygLpTx2j47Lg3fQSg9d2EzKaie7ztTA/o7icrbxIchG+5zxFWqPu+1X+qDtu5Q9E1bO82o8Lx3qZ4BG/1qR49bW6aMla2hCEL7EVT7Q+9pjsGctWwxHfsiNI0o37EyKG+PbSaf0Fk2vlkz2NVFq+IZLt4TVX6KwLTVT3s2g0pL9+fjSa+a2sKd12QBJnAHfsP32q3TOmUqZ8tZuoo01ZPSNDrzxxOxHeM9Zv8Iy/6yTLTZYzeJ4eNox51PAmyH3kkUq1P34ncdcTnGYT6tq5kmU15aGu0Zee5hRjqd32GLtL2HLNU6TpgBvXV+JHD8uXJCnvEXAZmGoF2p44517mFfwOxCJT3quNF8Uak0Nmc013LyCopA+Ni/BZoc6QkU8oUUWSjMRSAmJViGpHJiftSOSoaPjvujaoBbsVhAONehMlB6d9s44kooKN11RPH11hFFWt256a70r0bN6/Pmbakk9+COosEdLxWRU9C7vw1UWjd+b7A+bkwcdHahhzUVIdhSF2VyoP9e9ZHPhlEPlF5AnqZQ49n5fnU2CE9ejz6CK25jAZxVn44nw1MoWaAO+4eNuxQ2kViT+IcaqwLXywG1hrVFbQxKPLDKUxe4BMvhnhwOC3f7nYg4qKHDOM0HcG38UCZARX82n6FMz1/s1H42bBcFNxLqnEGRhsjAPuQte/QOHIkfUaIFyvRnhTCf0tM7MRE964yYELPe2ai+aR3VkRxPp9EVz46KryzAl0VbjgWVPJEjM18Mq7elEjSZITpW71cs3B8msSOntQffVjCNeJD/Kk/9Qf/o6Az8EsIbeoqo+mqaNkBwp3fUSeuY5JrZB1xUid1gnPAKsQjjZUHiGhrqMJYQzW0iGgIQ9qphjJqKLX686F9/RO+3OP4hTUv7mw4SPK5Y+DL++vKc/O1a01NW3+r8BMkRqdTG8NuvpEkOp0OIklkEJlOp9PpMN0j8UYWcZ38aDj3foChMdBIREP9qQ9JJD7En/pTf41nfg9ChTxHjUUe5Vwjo6kP/ScZTf5JfKgP9bn6PmH13CBYbNNwj/eyzXxTD+L7gaYwZEN5LbJ3WB+mn7GGWAvBzBST8aRdR+ZlfB0Qar43bYGK7hgwEkV8AlCozlAIgfrUCBvVYJ6kBj6cqgcTm7lhweTF0xXu+SQ2uowmK20qjaKr5+kiLlJXtcs9NSWMP3mMsJfaQ2yKYjIH2BlLuttgdSq4AtKFBEa1M2O3rgFJcbk5YKKMMiDzwQLVncXQR1MSoqRvX0GxOpVMqe2iqEcChrTxzM6UbC1uNIfJGfyigrGlyr8Ds6s503+ApKNaLeQT41Yy9u9yecu+hIqdLDBQxJ6fPfC6FpwuTrmNizQ4A+YKv4Vafe/6eq6VNlRQFhQlop2E6VwOx1y0X3zwYQWz1BTUeZgFtnbHe0Rz99mpJVaVZqQaH05/ppZ+iLvnp6OU4WA54RzhpQ4tViiatbrmp8wzA/XTbrjhoBnpJ9PzIacj1xudq1Vb1aMd2GwSGWUCshsADfZlcVfuTKSllya6OlMhze2vu1B/OjBScVnLuce3o6rrGPtHn/ajiN2eEMmzW85DPeAqzEQLws69naX9fysJJsSpQAukRuVqjeqqI4zpLJ4dJv+K3iHDlwnMBJYFfDOPShIi9RBRofhQpMJ1Ya2SM/pg38S7h/tM2fukiWSbUvu3QCWY50MZaPjoV+4AQIuxO4xsenK3zo7OGAqDTTeqRw0xEM3TMEv+DDx+0LWoLwZDOtoRdpEh0oW6UZ0psEL0R0fChAMxpOLB8SsP0Dxh+lPmpDBU4IUHyBZu6Mx4sCqX2/0kcDdpbGcqLINgP5NeM/taOps9O4RQTTVhFli0yXa49xU8SKE4lsH5wf5kgBphgwyTbhh28MjDLD2JvvlDh7zuQ2lYKvrl8mOkl1RC74siNnRM97bB73wGL0bjGtGSEtAORK+YfX0xfeAs+ykjSLe+3s1EQ4pA4wOb4H7oYvLzIuuypQALNdEROdFVNf6mmOitVJyzATsCvnJQ2x77VqGZ71YN0n6cWlSJcZ5dbD70YScMvjdUlMAXvQhe0T3LhI7o0GSP+gqE396P8DnkSqcfvCGDyGhX5ah3LzyfjO/NoDbAH1O0ZnBih0eUTkgezPrHgF7gAyfVn8U2XYwxSFlmGobnJ55VRxerEJpF4kUt3lRXnk3Wg+vY3m9+/602GZlWMw89W6R/WcSptFEweQICN67jtgV5E3QsPU+PclKmk11I6GpxvlpcDk6WEnnB7wAbdGck3y6ljbfvxTm6tcFQqz3vlFjjOPJpFIxn7WlVtR0+xvj++IywaKYsmBPBjjV2U4beFs3+OZ4lTfqw63zFVOEaRT2Ew3d0wgWYQ71T9ezSdfBddeb691G9o52GEKoLKZwogEpfdbeq74I1vwRv9xqlIf7QytGXnHJNuG2eAk5s+TqMiznuipi32WSZd8XuFt6ei3VVr+hrb0Y45ObT1AS5mLfaxXdvTD3ilo/q/iRsCdxdXQLyw6UDVfiW+ExJyRkFdrAAuFVZARJcG+RTt25dhwJisVZKcroKM6yGcSQlvIpCy5ZzFZQg52inxcMLVzDLsZbSlh5XVNFqSw6yRFzuX635X3w67cNeP2PpHVeBjV607jj0NMNhcJTvlhHerQTBKb7Ybs3t52cSX1s3AtyWVxtUKVW2HVtXoEQXwp5eyIKCYuQwxv8iu0JYgHgQ0NWt4iP5zvx9r3xyRm84W3Q820W5SMAz2dw4vEQfckvJJ+yBf913Y9GvghE7qFIacdlHi+w6NtFsaEpBqr+R1be2FWYmFB5ZqgBWXPvznr3xfIFjMt4U+apDDRqoBg2XMDiklBOX/ApTYKXeeRS7cIh24RCyg6Gb3bdn4cQJ64DCK/IOXrVNy8RxYcv4R4ny1/mTFGpTy7SJXedump070/rJS/GsWyyhPKnJxzkihnWDSUqHKQck5Xj5C56q3ee+l282gJcFd2ja+dC12EF3PDnSywWwq/3L5QQ+BvSCfaDxTmaxkhl30EQ0E+B6XVP04flN3lvbcfyUVZ2eTfraMglt2MLxFQYDucGPt56fj7w/HVP1NyD0h21FuLfaaZLEpec25WHJBVGKiiSubgzcPbagqAKseRyHpXHHh6qg4+ygVIadAixpjIuNdllX9QsaAnp/Fcf8fPS7fP6jw70XmyBiuB14E9PvI2NaE+rrf5zKL4sKyBLWuCMreSdOUzUxr8prrq7DDhFupYSeUmd8091BKntq7EqbltZzGrI8rqNdFxF2Cdb+oFtJ838V+Yc42tp4wdYGRO872d98PuvpVjNOIQurXYMr6LFcvZbCztWmr/Vt3eiyXhv2Bx7QoS0R/uxHu98/1l95FvT4R8jkjaEnu4waK0idLJOhPNpENyF3L5qSsTFz761InSCpD52jyDb85O1Z6Upa70QrMgZipA2d96ORQpI/pfiJW8eZUam52oAF/8oWY4U7HxJ5LVxNb4FXUodUcMUJTKANeX9Vnx50OxB1baT2VjOHo9kDZMx14GbTArQecT4NJO2kSGguDOy6NQvcoSjmqWN8EHDHI+gzQmIgDBqb+sv5ks1bauKOda2zuO0BPGIg/UQDhnsKjF+TvQsnpijDufsZ1BRFArz7KVSAyhGEGXws4AdjcYApuBCynzbDDY3ADV62L2uTLpYf/U4YoJID5Ex1pbSMr7es2HuCLiHexJt2x/8rxu+G33uvVMqVXoH0Zgwh+JbuIxrRqDddkmbDTkq1GjJetHs6G4W7QfenbrujMcRGbDSJ3FzEjVCG5L2U9ep3ilR614IqqBVo0NHJ2Q7X5KCplDzII+SkCqOrqE76N8OjYZUq3pUuqBC/2YteBH/aj3BRY/+HGaptiMN/2HK3jKp71Oob+XWttJwOkYusfsI1WkUMYlA7phfImr4KvZz9Jwta8d5mX2Nf80yuUs1vlNCZqjNQ7UB5FCNgZWnM6ZLNfRh4G2DVeT7Z+OUty6wdBM2jhzf1ed3eoN6PcEMbZTwRxS8IBeSKpsgLfxSj2NqUaFv496T6pTchFO67IVh+8z50w/LIoGzB+ojnYft//6orjPL2u+GWTSG7pzsw6sW3CwmZSTBc1HJ9uGEwNIy4BEZvkiSSRBPhV04Qp4+nnmOsh2GhyjZ1GeAAJk9hoaY81pR6LVzrHY71nr7WWEZS/mYWZH13zr7NSLmUmMALcQmqqa2nfCOaIEsaHiTnOVXOarhk9dy3Lmjlbqw2IjumSDsJK+HIf32ux0UoRShKC9c7/aGxV5S9IuaM5bFNtRCTfPrU0BvlBLbtkzIjdx82k1atL/E0sEPGH0IeZZWX9W+hnFbbyyOIUm+PQr04aS2JNXpQnLFXpv76TRCO4FVyYRcRmIwhisGMUQiMELKJiCfp5z9YemiGQiE/SrHXxrYZjfW7nUgl2h7+3UaWDZJh77/Fasf4tyQeaz9kxbgV9+V8kBVmnh1I9Oa/t+/wTow6I5Aeuyd4kBi8uynUR5pr4m0+jR/5TgiWTgAyRoiaFIJ7GVWvENwSRPje8qU/jZVSTDukXsDg3BBR4nbMXTKuETh5cAOrZohlOP9hwx9HE29Qk2+Kg6H/uWUnRCYcCJ+p9MX55++K5EEh/G0yRYA+Do+RQT2YPJTavosp1IXF6gE8cKeQwhHA+VrcNE6DwfPZl01odXCKRNpCqiOWSfxcoEVQ8OJ8PJWKuRL5Y7loici3rCGO9T1JptSF0MWwX4zXjEUoqHIz0RYqFAdUuavOyHdCGMhb21DyaPh8dpfE9921qSGkHzTGAepd/nXSsmaBzytIYStAH99tge0Q0hOb2W3BRyfKvwE8wvk5fxMeVGjC7IETJZ+h0dK3f6pwzyeMmdBnU3wX3LYumT7fLHkLJeZS5SC0FvXdWhylZilT4SkNgJLSKxrFSvOuTeym87nUl1Y/qNCQJAwVe7YhYibIDPbNIiZaRqEHtXqjWD4TxkQIPrYvzgpmkLigC0n1hwL5N0pcS89j1A2o59BK7YIuxC64mqgiAX94lllgXU26hNEXf7aJZC3vUajM6P3OtQ1whEH6PhBDX5mxGfz6TbsBWKF6/Mf9FXNlUymbllwyLpnnDSnCeHmHmggb60edFI2lpxQtlw1VQIEzZBjRsuGGATA3zjU2yttNGuihi+29Fa8yLKaOH/GSFVqB91hPZ6xeD1SQH+YmND0b5CeddEijGlw41lWI6lIjilw8PeHWH66fx0Ca1rAJiRSNbgHOymrifx+HcZfZOPrbIp8nUhEj6BPqoepjvbVkT5Jdds3sL0g9rT4ZNhaOjTvSQgqcq/+Ei6w6uHUr18WloJ7pM5dhyZ7RYnAFNr/XOHhCVlgmVM2DAOMgJ9EeGgAKZlQNgupTv5afN27uFmCsQCyY5VRzHFdXeuvgxnXtHVfwjqPgVEw4oYMBURFHGPdNvTKhV882Z+wvcKuORVloNbTx0CJxYbWb8YREfXIwYPwoXSkoNYDWLTGAOfNsD+rOWC2OjtBXIIYCkTjTvNN/4chXaA8uY2goMO1nM/BM5KeCKfAgKlegeUQQQCrhvFmDPIXR+/+BfOkY0FICYkb7lII4dBHzgK30xFIyrNrQGsUqBiFbop1djqsih338CUj7aETXyAQOxf9ALsPRoWSwuCK4exTeEgvKjaPPEqO5SbfyiTJa+LVhqxNKPlDOrLfgHGo4cx+ayNE4r7lCymR42N4EWscItM8S3AmJHzs5pdRtoXN0bwy4MXjna3r6bI+pnYFOkkFspQar7AKNtnaqgBDyG+Itjt5/5bdOJN9gLHWcyw3P2PbCCoadjAvYCbaP5uVQgcfAD5b/UnAWQTfGbPFHiwAr176EvskumFANMxksDiU+TwSsFNmLM9d3ggrGL+wgrLSvy7VvhbnPbwy83HfUejxMf3BVKx5Z2uJJKbDtupYRPxkU9bPxgH4msSX83BKusax7ZPnaA9p/hv9tR2UWP/f+/AbYqk8jx/fz239BfbTYt6rDpIafT182bz1pm0qpdWcd29xzInlwhciZRN23ztrt76/OT3E7oFlUXtAu2qddE5wv4+GS+7Z25t6+i/Fo7+9nbF5aJF4rwfG/ed24y4IZ2YjZWS91X/rqB6BcOCMtrmGp1t5wb5DjXTU3f02PRzvRXqb2aGxM5tCzdbmdVuFkcbFMli9HoVmOiCNqeSFm6OL585oFBcd7vshTCjGjeP/SrYr1O3XFLkarPpzjvI4t7n0Psua4XPQYTVe8ZOOmhKaKqrqaiu66Udf3KirML72NhkTA4l+55KuNZLFedNuj7fOd81iExUmGL6yRtdARxbLT3qfqjeTLwMqT5Ce+IBGulGJLE0ojNuxXULIW3lGbi6P44qL3JCBkHcnxxC/PVFgWXwXpQV9CUtQHR06lQqyVzmuQJJUyqtr4y0hsop2Tmku5cKrWV/jw8UHM9bCQvrH8pTDLO3rSc1rpvGTnQntgvgZ1r9hXii1U3Y2/hF6p/TTfexaYKmSTFs5Tkq/FkZvLxZJtZVMjCWFZTHN240e7/bLW8Usn9AP1o/pM9E4I7cH/TBm1up+/AlV8OV3btkz9V7oXydf3RMTWheED8YDV++WJhYmmqX7Iw12xe+yiof1ozh0Hod4clwueo/6qlxzOrq+pKW/d2LuksLD0JpoQ4xCgM5ymvdUAoO3jWbRzxDZ4W2KD54k6472g3oWIuUf5haUMBxSUBggU3mNj/vdIPGRO0iXBE2saYaWymQOr11TC6g5CgSSPQAMDUQEnYesBis7h64XscA5ukh+5KSKWbo9oFGdj2Qc+pFYlFyYsnTgA1EEiFirxkHtgX381pm+o2VYQydG3o1sWhvYjeqP/wvHD63NwC4ex7yFGVVpHulR+2FN0Be2XvexQOyVBdN6svKWWrWYggLj9EIlIsPsFwk8oequE0Orde6O1fXWIDnlXnJddtIbQxFRqe01Xv0KlZ5wraqYoQ8LvjXlpdY2L5W/eFEORF5MrVKoNuYXhCdR6/CVhw8DnBh+0XaxpUcKADmqjCaDeJGy6NsKGNsFDUnsdmoZClJEayqXH06+1M7e7cqHxeAz7rpLNWYpGPw1Vp4DmPAVkoOCARI06q8lMpQ/cv/tw0/4HviI+sO/7XeINMWV9i6oOs3If1yoOf3AAvMQGWOrgIbMdXBI8UdeIK5XNPJl0xq2ExbWJLeRydvHLVh+KPRWX0Xzlzz0WnkuYU1ldV1PRTc/Wi3q9W5hf8jIWJwIOL+WSLzeQTj10x63t851LGEJn0pvCaR3nogPxszHQgn8Fj62WHpq2WfxrVNWXy3HNQgXcS8518iYTGoX+jw1eXwR7BWUPz4/DvEK+RcK/3JRUzOIkuHXwve1jvYf3X2L9Y6CkpLyYk2bLkiMRYyB0gF+evNpdzFVH1J6HqC9j72we5jrhue0b2zuu4Z3HKjxkHKO16pN6bcJveuB23QOga0VV73Qzxh/mF+818Ea1asHcu/enwVu8/DOfQXxSx3PEahRmHEMSCxk8Cu65xqWOcg14yQpZQ35euq71QZrvfclp3lIXSs0t8luZL0dCYaQQpzip9/a7teDd3EVzM/CDh7IuE870C+h8th1Y4N6vFYzPlrc0nsNpCCUON/M9I0j8tXYBsrci5dfAh1NOf+3r5vfUlo1Hjk/hHU26szH+AQMM2BhxNOBB6WdGX+XgL75Sa1Xw6N4htCSF8r1+ATGd10AK8tPXx5lxjJnDnXIF3g991ytICL/A4kYO+3PeAyJaegB4Y+O87tLqJul+P2oOG8NAGBg3I13z7wW4EThVjWdKHPKIco73G1HaqXsY3pnqNIOPd0/13dfPMPf4kjYYGuCmCbx9KvBAd116+9+g/X0qvMA8rs4oj9ivfKt7frX18NcTJBO/dpgySr3owInhtOpw3kal5P2yXLeyUIp+r1i3fu0FW897805bbu6t3FYOZQE9OViUPsQaVh/G2bPSnp7ojk0jsIhYkb7B+Pjb9BZC07er89fpY4VMKosFCOEjK0nAO5xKnq2/j0dUHRX0PQycjqAeXBBM/FdotXWknApiGkeW01JBz8BXz1FwvCzKv0x7MyJUVlLwkT35n8PxJnxEkq9IgxBa6VD8vCegqkXfuEw8osREdwjvPY8UhuMdCyvSc3K/2DBypEGvVM1N3O5HcikIhjof8HUjk7AekiAojNXVpFL4wcycEvrj7xgaTHAWYtUgA1YatdqZyQUFO9Oysr5aN9aP05HPB5/+62nqvA5Pf06OL1EnYwN09Gi4TOvIg0tbXkHfo4IHJQv+yv8lsZhQFmM9VqlGgIyb8JYvind+0Lip+tp8ep8HyBcwHnZ8iYEYg+PTGCzOzMCGwtuwy9MQCbVM2tflZX0gSDzPdWZjj/QEqfdy5YpIv6Q3VCRxO9OgHrYFzOkICbRl4r9efHPG/j7SmWwB6oqV9BYck1wrVXJPAWq90Fx6ltQ6HlWFmXG2SWKOrVVBnqbUVgcUs1YFZW7CeqyLafT3iHVwhTSrIuniva7VQDzCX24SM5ip2SOnsDRdwNIzrOQYyjDTU4xpXlCjTDYcC9fs7Rfu3r2iOjvr6pBqPxrywzlPhbJ6C9+QGI8pKxx7wNN93Es9tsLM6yaEMAmZgWSn9kAJza56v5/vfb3u/ep4AsG8J01xU2NjmRLCioNvvpIA0zSpzNLXof/Uz7fEKlvWZKlxCkdPM7kWE1WII1bForWKNWNVrGo9dmT7iNndEKqz2AAv8DA/XiErtO4P/9DFxcXG0nJxClmfqWTBa8hxkO+WZHiyQE7Md4ReNlCucn6I7gbiE55rmFjWhPssyZztQTufh7jk/7LSALzkArv/FWgisTiUGs3xfEbVG11wU4l1FpV9zTooJmr1HFeeqMFIT/9v+Rg4HKged8DNMQG35krLC3PcuoTTWuA4R2sx05sKwoOn2NrtDOfQAekwmFk1/H/zMLMgKminpqovYe99l0LI/ZyIt4BmWQe8LqXLJkHOkScuIahKC4XKHHo0utuN1GAuvHN4vwcUdoxkTY51yVl6Xa7/9HQ5HExhZ7KRbb6N2jJ6dRZDXSsKnFyaiYIU4lTwT8ScWJBpfcsSyhXSscLAD38zdlwc8lmwGjz2AJZg3JhdZ4j7fKcRpBYIgNXb/w1ErIwUGmnvwuD0NENldNvOzzuw4GPItjepNCwLDpxbnr5uVyekW9/wh6hRyuecSBcj2yTwhPwbdeX0kgzdYDZalg32LFV0WyA1/weuIP5R1hEe4te0Tj1J3Yk1R2FAC2boOWX5J1+xs3ITsogdjpz3nPNwbi/ZYy+l/a16hwP5l2pGNIOcneKOxEbAKq52PfXPuCYxNEd26dVNu3d6zmO1XjPKS+dfsQsrc4+WLvW4g1jOXOBeNDw9C7MLiDgBW5JfWH9BT7DvjczQ9ugnjRjG6Z9b5RW0bUtEt7Nzb0HIXkY7LlEdaD7swZexABco3eQZMsGgzQ3WBgyDpW5ZjyWK+HR9GKvDIgMnql5iR05DmO4p/DL6G8seGv1u0fWPIGwSMfjA8513MhlSspn2D+LGakAZgoQErJUfNFV8w4BpREq++h4gI8Zy/COnrP+3N+FfCVuMeDMdOCQ5y3toBMUkaACiHIuNJYdmo97tduLn19OVmpR1Kw4epo4CJ2jMM8qJ0B+XQ4E9aEOwjDszFNAu/tueXwrzOZj4jJxo8GiAf9sXXHW2BqGicnYdwQYXklGjuZmnsGYTeK5HwVGjqpzkGuAjpicGR5zt6fOlNIKyKuxG18pji7EiXGA1RAv8ZWTIWengY4EkreiPasa95Fkr4vkJbd1C6DPIWXPeFkAtrkrl3i+LK8yaQ3gD8sSKElxZf3Sgx4xcN8v8FJQPQPeZzNbCV3bFFOz7dP/ecHuW75Oh4gb1l5tRwxut3d977/N7aei+c1/4n/QQUtevAAXQexdIIN2t8f587TeC5MCZtA9DUhvLy6K1z96RUpJJSiJasHKsCg1cADj+qcxPQsQs/ZLA9tf7pX8quJEnD+YuTh/FyaEg6PfuZQWkpuE+EmLMIEhE6tzcOZsz4jXhnTc6K2I93I6VSbgyth98k7FnjPiV8dMdN6uU0oadKKzCgTZecnQaL9KvlMVJiNRK3Gib/BPAx/qV//40d0j8XQyLFQ63SbT02Ab8Idghe/wOWC9LUxEs0++93XQwyb6d2SQxvFK72AAbDpnumw6Kacw9kiERM1RXRPcdpxbRIFy2An/IpHrIYds2zRrniHI37+JfTZLVY+Ha2/im0fH6DJhqZG50DSVbNSMDGz/SXSnnD2AHf9X4ke6jagAVqof4H1FtvFlvjznaMYtDT5I7jfYF23YtLKTBrYbsfs63E/nTGIfaAlKAf45neBw9VMokIoRrJYKlTAOlNLGF9kcaOvVwRri6QjbrvLbeRXzoWBQ5FtPv99Ab13s1SLGetVhjvnSaRTyCFK10+8enR5LQJjKaERy/4QiviubB2Dqah1D6cv/xBVlgKN+DJzhnJcY01tsH6CbBoF47aI+/CCVbRXQXabc1cXfIv5RU0uTpUaV+wUYpIOLjqQp2Fk5whzEzqFDb2TwV1MsN9H02WtqGsAKXVxWMx7gYxi7XVnqYvcdbOLtg0LEUlN47Jqh4dSYxu3Cw04IvrIKghRBu9ff8yNzGvCrMbfyMfbjd8aJJu+bjBL1j8h7HcJzeR26f2M5HDc+j2/e3HOrSGwkkMtAwnrsiLbGI9Pm9t+1PHVBmlmzZsWPGivffdzrM5vGP1vhJXVzrf2VClZV6aqH21qrjEtSlQm0oqd9hO2gH7ShuIFRZ73Uodcv4BV1VrgHowooe0IXdSCF01TQFtDUsNAy6yqUKuspJFYAMnQ9d5YSUesJJFfTBfBxAH8yuALo+5Dx0fZDzrqtaugr676bEfZKmOagiSGcjhVBpqBTC949gGkhzsIUa7V4I7j1P+vTfLb/Km3T4Gkj/RiXD7835yrfQNtgEC/IDlELZSnOQfwanZdNwV5SvZ2mOyAZw+n4azLL8/MqeJfhr7FnQH6YuVPq+pi4oy0GeA8ZzAJPyITBHKwWXcoGufA/+jM2P4NZokt504EWV+yF7c3TxV9AVUUBrBW5P8LUSbQEz8BVodbYCrQ6tULcCA0DrEl4mblYFtIqtPmKrj6SYRlJU42hto5UZbuYQN1fIYODTeM2J0cil9Yl73R8HoHbu0sYg855z3GMfeN4g3Cq0z8hp8oTVwtSNT4iuCrDNJRYEyBfhjNjN7DBHXho6clJ4Lk9ij5omEXvAqIVGtTKAlERgwG1UwGzZkVviEpiN5m7Xi3Tyr7W+jVR/GPP7gaYi68CF41bI9Z/sWV40JTPybHczN+zY+0dT26qCloJUMPHjmRPJNirgXF8MD2tbobem4UTIVZFoayvV/3TboCYilXm3xx2eSkm0cY+Y2xFX8T3UxvGETXt/N8L41SKD1CXnnCINjFdPPclZkTJxpSejgq5KRX+gnC4du7onCH2BP0QqHC8rk8WDNwf3LVixw5P4nlarnZUJJ0GDBzcPSbgjaPOYnYIMpt1FpgEaxdRPd8gGc7F7bWIeQsGe9EwGtLGIp2fmCkLgjRts8yzFe/WD5PIHcvQSFUwsm/G2ZLF57DQy2X4hh8I0bYXKLNwy2/RI/zgvEA+AVLrAV2pfayrEC58Ka0U2V0CFKhu5ij3eRV4KJStoJK6T3FHwyELL75hKvw//8W5cJyUVxgcPSVA9WhU1uz23zj/aY3tnLWPubtX8I1sujcID95ZAsQHlBjzMc0NE93ec3JQKwamwaKOBDICVRXArJWojEonDMxvxTkbHDMhlgPzSjuvLtbtNZ0TGUFt14OCy2YTlLaLSl8LilXASkMNHjGwdmlBw3jlSQHfpTIcV7q1ZlZK0yrO/Ysw1ZvXs2tXqO7MXHy6s8vRFqVd3/3jtgrX7PMqOPTiOSZGH7mslmJJhwgqTpZvSvlQYijsvDJAPYnDBKTIxhIyb+NjJGFbyxb19dexJMywfbUc+t892h37A9YfGUvDO//GmSQGm9LnDacdWeDJ2zEybGEHNm/dSoRj6qPPhlCjW0wss+aN9ysCRLjRuMWWPGtszKmHYGJ+lxbMudZ1/fYIS9+Q1gIoep09Yl75OAIpiBNBailXB5hUVksIn4Mmzwplg88XxLQF6JZmADAvQx9UBAQmCmMit5J9YdJjnh+gzyko6fvGTeHYIkpIpyZfiqxCetmowZ0b15uIkQlBUC6GgB00d8GJxTjT7cI/3gJZUqJEL+6x79cudb1ikphjtzndN3XJJjqXDflN0Tftwc2ktGit7FGmYRDXwgZwREWZwL0klbmNKZYYOKYpBIoBlhJeIX4/M7lsQIj7n2Ik8ZnGRYYKGCDFMSrDGx095lDpPQe+I60kaYiLW3M3RNb2G61LmBAixssmLJxEMfESvQ1Pmvn32Mntli/IMo2rcR7ANi5iPr4WSdDNgMg2HSQm36ED7mZp/30FElIjrThJQqXP1/bfMqZWw7LeRVz++OQQSyG7VfG2NZErCAn8oxrZYjvB7VdRgYjmhL1+3Ty9mUA4JEjBnFYu4/uGbhYn2nuqwJqHd3Tqrvygq1il3WJ1HLBVxcTD8bMbn84WYRgVrW/IDHNR5lUFKhiHVSMQGXywEVy45edkJX+adPgYMmxiNwCU7WCHoJ0Z1bHPAjl588V+/0JNSvMB1UuLtGQoX0ooZ9qjhX/FFTcVHTYkc7Rl0er43yMBCeUGG6/0d+4PSFN0p93N31hvopSm5T1iSGIHAUEAsLvgYpt4mn7JPy3oxsuy/rUPi3N7EzCoUD4+jm8umijECQgzqDOQEnVAy4LkHOTzYpfI0ZJVd6e4la/+NHV3X8M5rOica1UcXWLlmWwOvzpXVlwWlHVjCbnbgXGobO4uWVMcaPOtcYLD0UaCa7n5AWcs1vTVwpP2cg8Vn6m/7uifWgvo1kwEl7b7EVYSUZMRKqKLbd9xOz8auPKmy9Kx0wNexhenDdZU0EhiSXy8Q6qoo4w79R7w2ZiW92bKkEoLnvu/TsngD7NkozLq/Bgs8dz14rgZAF7JlYxoVCrfP5UtbSNJlH/+I9Fzl2T8czCBLXkwnyDKPOFM5RdOkEGuCz1sice87HCQ5iHUT8oquVjxsjac+rsgxdCdT6SjwzHk2LI9UECDZUUl42hL6iIYFwrP6MPhOBUkVxceVL2tIymkfY9gxSq0+mqJ5+xCBa4ZMoG1MJmiEhcvHDWGVJLsQs8+nMnAbWvmPv7AUVGTByYz1+402g9aHwXI2iLsxKhWr747zpMS/fNCoCbh5DG8cL/QXR8uTCm55Bf010BM9eKzQlRAxaN1+1gu4EF5nPxFBiyDlTtiHOAZ9dpgXhuQuYgnKjf/lKHR6NquNp5LLCb1ftfE+0B2fc0AVOX2GUmMxWLPx7fB/f1W9F8+W6+LdMJl8mmYdEpUTS+qUBnj4e3QHvvcX0nsxUqypLuSZISKN0fevoycBe2ouAR8WLgbWxyg4EiglMoSEMpQ9HnegC6fZtYOuSxEJjWcU5aWajU8EJxGX0ZPiDLgdY+MdpKqn9Sm046zZrbeWJUlQnIMr2iAETkS1A3m3wvyyh0Q/JXPkigbgAe/BPVIZbrEyHvsRsc91LU4OG2zX5Co9rlvtqDYeuv18M2GgiEC+eTSjTu83GTHj5E4bA3wpTQUhgpYONfeXYfwwZ0kFAbN8+9zcArwGT73+1AqZydY7dhExSB4qj0c1cKLywrNWSNaP1yK9KGufcgYKJxx0z4oJU/uydUa2e4WAu1cCt/SB2XF4MJsQ/PB04r8v5UK7PXZfWDdNPHulLHNjnbslG/hETk3qOCHLX7YW5667SIo9j7AgkGfY/NCB/IvQ16bkHMifLbhee3elcd/OthSfc0wjCZJBaxwRC3SMmPzNxaHwYbPGlwBdJuXKy7OAFiRDbEMYk+/5zJD5ayyDGjjx4AwG4eIigakOqK3YxSc1THGqYaznka4aMJ5PGubmHz7fPEVIJzy05w/WTq9GDbK9DD0/C7BOQvWg+P7OsaeSc9hYIBQOEQHCPh5Y3D87AnPyWckLDydO9ukgcpZqGiw27LkoWN+UycH9FLuvZsFeqR99w7u9TSpZhPVZn16pygJry9pV1wz/4B8Tq+cfIKXaeiQ85fFX3uCJP6TL4sEVPkhRLIzKpV0suElrC6/bdXW2AxhvLMzA3/KnIsNpH4LBfWZGyGmmA7Md08F104C3b6Tvn2pOdfX/cqCOnGiqOZW5wxIb3bbCNbZnPOonQgSMzOdcPGg/kn9r48+cg4aXXCIkDcFE7FMWgDeWdU59twpO8AzLwaSd8nxWcrZa6tAr61yzlxpyqgiVJHo+actPE/u+GPUFENaaLqGnb7Z2DvfKtJj5ovd8sk5kMrs9uLScGCVk5WbHTMBoeWyfSmmgPPeaCOdNoYMd3GiD6nFVyldS0U2fYCFSBlHUnOje+Cn3Z6+sGl5sbTPJPjj+INTdnKdpbL5tMiRtCJlYAZ42pvqXWiufmkaLlSc9Yfwe9+e3htoX28lfq0GzhJ/KVbcWeQ0oNsnlcq3YifGsjf5ONwyIDjmacdDvY1OXYVE5ocXg8erV8vs2rJLB6UPoRGmjfHYLKamj5nYsQr8yV19oATcfgxFzU65wfsAqelMu+LQ+RX3DFVUsHRNuErJl1MnEIYqJxMtmiA1RBrHnk9bl2oX3OWK0gE2Znvz0fWoQ/+4F4NU8ek0sz+VoyF1dscZqGJPD1fPdNToMRcL2NBI4d+PhvPXQp8lOmQAs4uSRSp1VwPH86yVYtEc0fo7wkXv1oDuIVb83FwfFBWCgjofcX7a7ACmJjVxODNzRnX1DEPorOS3wVWswfBJveWiDxTFGgwLi48XJ/GqV1EFx/lQZFjfEidjEIOZ5jXG+HI+q7l4A93qTGePqTq7TaHH0TJ7/zr7ycJlM6qB60FKyTS/M6g6VvrtPzi7A2y1FWmOWQu+pHwo2ocge/GlBbPyN+iCuUrBUUulRVUErTLUmc9HR+o0jvZpQZ20zM5rl+hXWoBGuXjjz89ks6mGgJZtjl4okoGi1cUgBJ/uJGDTDD82qqU6XckkoBrkApZFWtJRUcl75ZGJyc0T8FGeyOAkZUtdlWFRjNEEjU8tZRRX9y+Pb8vsWaXBkB6vC/K1XuzzQI0IncmBkx7/ooc2xhPT5hYicVB5ZWJ51oLj25B3iDpkYOHseuv9g4UbB1FOZEzgoHawoDPaNo7l2ssLSziUKSwkApTSplQ4sM3Wp4cRjYaKaeeOaBx9jSG3USNBK+60NShGMa7871n0dBx8nV5owAoDZkDlnLwFlIHrG0oIpUpdfe6Fpit964UAdMkDzBjRDJfj3q4Z2htP2nwguQeyt/XWwm9IEkLHgmqTJxTW284s6r7AYTmxOAGTE+gItIRgU0z8PleR4Hvs/uTpeGn99Udg95p7EXgiCWrJt2Rsij8B5mbieI+YQ8Nl3EfIGctUkkgje2N/gMcBBwwbOehAFBIdXG7A5gumADysmHlnR58yJnav3bMkM+3n1SUlPVB/9Tt/NrjjI7AeLtRyJxqh5Ezt2huiYsCTy2fDqkkRIqUAEQfJ0KsFos8gkckUANLKD1IR/1+m3cdAZB9E94NsFemsuvphSOlch9stVGuF5RYgA2yz0jOe+jNgDgYYSsKmqGgncN4eOCV8i1wVrSFAdErR/3i7q5EQEKpJxTUYoV3VwBinpNnKjx7C71Xp5HmCFvWAVJgBXQEKe4JE0wgUJjKm2Fvo7phJw/gvPLwx1DVD89u4H0yZ2mFuUjARL71c/EZa6dyVE0PPOyaNErggStLwFOxo81kHNe3r2TgDemRPBZ0Im6Hu3ya12k2gtWKykFzm38V1oVcZCaQfYrKJzWKOb9u79Uu35drV9l+CArbEhvIZkR0fLEK1knIFyqnSmaOXImG5es8WTEgjRX8NHHxuTMHJk4/Bkj9/GUZHMSg4buTBiNo/vRKvZqR8oftbE48QENjDrou46Oa8O5O2TCfPLrhPpSuKklzZgLe8FgDzU5sokAsUY9NAR/q4+WbfoFr3yvo7Xs9L1vs4w3BkT9UePW2et+OZE2iomtpnDKP1QeDD6/TbL/N1BhkAPWLuDEV+j2oHCO9PThbLZ8w+SqKwNpQcM3/yuNHuTtcOCpavdfKXZzB+uqFCrqrBnt2t/KE6dOlqakVEs3jO+PrDOCvUGz1JM37Ph2UkoLTOhCA9ky+HQ9iHF2OzsyuqiosqLbzpOPVbnaRIW5LkerFoVCnrpoAL/6DBN1uNYTg0SWHZ2bgmW15BSAuYsQKs9/XPDMKuQTc31r/qwRwk4lFbMVdCqmAXHNCotQWp2k/RzIG7+oNsbDNVYUOACcGiFuk8F3RaEHCYcWCNbrQ70eeGmKH+qLyC/To5L1oOAVUFNLa2sIw8lr5SOusxvvj1aPGnlHw8sOQTeAg3tmeLgdrIj1RJy/4TmzMs2LOAP9NcilHlRxBp5c1WasZgWMa/QVX8hgUp1N5h5vfOqhFPkFbEdQQkWyP3JjIt1Rv9l49KcydkEPLiDkFZh5M0XymxjP3sVdq9pj1+1vf15y57P+H2KA3nuMiJtMiDFccTWEb7xzyo2o88GA6Mj7gacNKTdcqNtkLL2hd9rLZpL6HF8zIn7wOaZTmLfWAGuApBP0w+Etj4zbeVG3yCRuSTG0VxkRjK9QjvDxzYuyR25Og+PFpBKAO66ZL93ZMxnr8PuMhXYD70HE4lNZE09gbzACwoBSMF6cA2IYne9yDGAckqB9G1CbGQtvIPsUrItdODl41MHYXRip/6KTIrD58P0eP6PU8LRMh7ULP+a9fvVjcSmQcl62B3GqC+lGJ+wiPBGe2kLU8zcUvVgLR62QFkLXf97Dz8jxtwY6/SpCIYLjZNkDpNbc5HoqyWnYNTgLjySNXEV+j1KcsWoRATZyb0SpNhadzaP0lIqLGWwRIRIoJAZTth0NJVQxorDRIlCdoy6xRjHKwhlRNBYeTyFysUCiWLiJl9KAIu3kXBHwP0d4S6U9bJRvP0N5kt6PP+rI33gkQeBvnow+TaYd443EmsAF8GCNlcQA/5maUpoVDjkjTgSG4+sc3ba4JqNXsth7Ju9dOWGvriRKhfgqaY1J1dBlgL4YKCXUvQLitj7cHEkVgozJMlGpCsbN+wcX5BBUTGn+uGxuOOJMug8J6hQYdcQV0Hk0S5gBEYoa4KCbFxD2JWcGJ03xc96CpqnU20YNdgKSJyRQMh/e7XUWdBZSmsOOd9+zMOJoPZbtJTCPfdf/3xTV5Ly5C2Ptk2Tf2mlFBMVjAfhDX57UYLX43Mf2hcAlmZOzk/A7BJCCcIQY0xR/mjvx4NP0uC+uvh4B+4Au2LjcRvEuoTH5EF3fasTxoeDhcs+NuHv/Vwf5GwTdCqlGUAS3IuaBKfktuw5MhaU5unxDr7hbRqclSH6JdySfNLqyDkNhW9NJUyM7J1/eMFBcHvRrDHxGfnLSMWBbDXHXOHq6ng7cH8Q9RGhF7E7V0SnaKF3KcXUhFVEl64oCWOK8bM5TrgwuOjhbEw+MJI3dLqO2TjgxIkrNg/pODQISyL3IgO1j6n5drnW8Z82Yk748fos4/9Yj3tK8qEkCzuB5IpmsUDrJImJQEqEA8JL6DyWnI48dvXZwzDxhFZzed2wUaI0nPraRBI6xBTl37GRRD+J3okniXyKIqHH8w5NW95n6DNyXCnt3KVD99gS9oSlcEhncm5eTkNL7bJDstynIn3Rc0jb6QUp67qd3Q4ODXAZUwoJyID9SEBI29A+eIHum+rzrPoT9dPNJtqBC5Up5hwrc02aiwHv+lsjcW7t0f9mv2fPvCmcOJI7if08LvF4m7q9LgUzMsE0YPWYa/LuZLN4ifg6TxEvWjDXxj06X9cSKL3EiN/Dqh7VR1BlDbsjxvrsA7sQxZYBycKC0TtOmc8Y632m+5hD83LDIZoV8G7nCnGQyuk1HKRKWhcaCmnDqrp95BV2Pfr3UEiZkH0oN8eMZPppOfVCFcEYLhxEFa2g6zBUSiBlIkpyPZ+TYTS9id6IHL39la6YghEZf+kmeI/IjMGPbkf+g0jfPeGAEmWcRkCaTpQeKG1HZOvonuHwjHe+A2MsOEjFL5o50mkWOEIQf6GbQ+jqTxfkoc11m5znl7HkyTWLnU12iDTv57M0HhIKlkvl8uxMoGElJNrN0++yEwEQJGz+OGOYIrnLzxNotZg6nEy917QivL5TD/t9N0wwDK/8adSMJd4ltdF6AXZ39HIib0XS8ylLhfSuIdOU42JQv7lQ/TLBPbTtBvmXVkixsdH4ArCxu0jWLDOnGag+iRxPlERTdAInMFZHmOmC/HVnjw0sup89NcW/C+6fBZbljcxMwuySqBKEd2Jfvz5oEeYmwDtXEI/p5gUBbEwdN2LjPHY7ulMPt4cRuOQRtztjakKz9eFdQI/LXUPbspz0H3WZn3oZpDaQcI2xOH1QrhsoUksMMpEgEn6N+2U0jzObb+X3fYHJVfHyHBcO6G6Qv6sRGnEoz9aMpkOWg5r0hqQG59TxkVkyJFMDRVqi4U+GYpF6H/B2pCZSG2ofMsy7ZRjQfHN2i9UDA3WHk+7jOZeO0JeW0BVcqLgy15yMzxTtaGP1LvfCEQECjKIJOThJoinJhDuMYd5e1P579rWVL1xgoKl7IMVHtrlc9N203+puV223lw0zqscw/gZYLXJ0GZcxerJMX0sOD6UQCMCeIkuXY0mdHbASkzjHTs7LCnbTEReoEk4bFPYDMLct8YocDpGagnvuJH7kfY8/tSum6Ckk+Qff9G0VYBlW63cJFG9pLyymPeWwDd5WO+xx6K0jHNGN39+t2rQ8n8BZgkCtNAqiSXuVfRVHUl7Ou9dUXL/vJ3yOtOHOmIyzQoF0vhcS2U9VyVgneIcqslW5Nd1SJZ9POZx4yKm2EbYKaocLZDmlhiSv9JUIJpdseHobIptMDmGufkE3rWgyaOkh1X7gAXayafCekxU/MwHme//6UHkE75wGItc4Ynb4R8TFOwUrknIccmvpsErcaLakItKzc/F+Ol9AH0858tvKfZatEV6BGUN2AeTspnqpbtpxStrBeGnQuu+zYoVPrVJhWTeCFInJk4C4iH77Je8WL5zin3oKXJ6p/VbC2y7BXPKy/rFjuGROKa36g2YbcP2huvINsjm1am/8sUFnofKxoXgIanfNtDy3m0ruPyF/+DTsvLxgn82dzyB7OPFuU6HPHCpUjrUl7oxQwJ7ppayjysiqgsv30dNAlD6OxNRzHoecG2TqBVafdthL05hwFItp8XLZDv0uj/3su+X+/QlcJ5TkmDc/84o+z+4P8rBcHhkXTPjTLm3IFA+kYOr14ryd5bWDMPHgN4FJTxFRe2PWkuCQFekER7R3xsStwk+LO7EUs37KLxZHEd2G8HMmLPULKASuGUI3LXG22wU3rApLou0273WcNA+4zhPZc2BoPBJ3QLZ5Luras0JNSg2vYy+yqEKsnEQl5+9rZntpJm3rIS2UXx6lafJ7uT7R42LZaFfVwkrmtLaMC5k59VZEf+MVEJux6fhOP0Arh+ExqBbLC5OHZGkmZiYbL8WeFO4BXs34aWXtyRvUBiv3XemmFUdO4qzDAEqVg4N596bOiG8d+gpJnZhehaGuIUB3gkeBT7LBQA+VbHaveOvYEDT1FyWnPLo7eYiTS9mYnpgscnRJRvdTpjQ+n3HAnuwSUpc0C4wslC9iKH5Y3NBRvNPfmjIyU4Dpv1WQzS6lP8b+9ayd92SG5IbkJ97KQmOh/I1bMSZfce7T/MI3X+zGpH374Cv9tPfR3vJI4bDYHyx30fG+bWKgMiofqCA9kIfjFBRMPkiS8M31D0/zOuZVCn6dFwbJp5zcvRpeZ2iZbboXYRO+MI2PDbWHoMu7vL91xluAaYKTxgoeHpyw+9/hks1WfvSe3prU6uSL/RqTdkCKgrcPcwt+0sqfxtwInATMRlSrv89rQP2XNTKUVMc+rDQoN1A5VYBwo5H6k6fo9eHijPJsNnmWEQ09XyzTonILr8/miMitUS1M1pPH5jNSltRNbLjR9hwkkL54eoqr4ab8u3mDuEj7Byu5ZSJmrqn8DdJ1J8nPfpXFOSfJT8ubLGzVk0cXsa+byOJj+fitEhh0jdxzjykLcz6UuPAECbVDBgb2wlL3WCcSkgUBurloS9bnRKzuFRdKK4h9oXpE5F/chDmoiuSNOIo1T2qG3LfyP+SjW0G90FnDBDp/tIu7d5gDjK1BAuO0WGc3TmPTEE9FLQprGntXOrHHKmNY9KHExewALekAkrrM2INxl0wR2+GWGcGYBc3iS81inrndmoGNAdpGXtDYGxtz7CgKXbVTayXX3schXP+3kMsxuhG60Pni8KTYjFY2LA66glSsD3l728Luo8JS5swH3pyHwu7t8EwVQ3kMXfk9GwO9UNOInVPqe/hCGwo/FOAIm99KsW0mOOiev8C4MHQHJbHRobNIdaxVdRzVxa0bL2zczBvSsSMOn61opip0udlYJCClwrf4p/v3CypW1BSsx7GFFDWscYzWV1Z0eP98eMpP5lamwb6eYtCaEI22oR0zQ1cirhOD1vF8s+zlt665IgJ24SsRJkfuPNVaKuE6i9o0cp225znMRgQYu7h2mjYWMcSEgljXBgxMPpHvGLv0YLLbJE4k5xQxJKEiVvQNTlR62Fw71jQ4sRiRj4p3mQqd35Pk6xm1mGGioxvyVVlKsZubf/jWw1Oi4uZIaKMXOjkM4QhD2IiFDSKc1itIeIMOL1RpAQJNQhp4Xq74XcJT0jhx4w1ytnZX7G77Dm/yGMQ8rgyZftyx22qep0kZvE04Izmmnrkuot8hBe+QPPm6G+8S6HCfVo4vcjscMyeLyDudrJ89Kev6KMnqnaEqwhfWsb6zrAeVgj8kJ9R56yL6C16CTE++7sop+Y56sjtyZbwQg8tCu5TLBiHyJ4vIF/2Slva6Pn+cj9YqjjWMy3oguemQjm9DrpkrJ1biQamNw7jlcJfn+AF7tpyvaxYTEKW4KHR6KEMLzaIsnxwZlA8hIoaUiUzcgNNnhTtFRDLyDukQY9/Bb7BATBbUjKgWLsqRqz2m0mC6QQ059sH9B9tjhQ0uzL15RxWvKt/TQspNDuOV5LQcWc55HQQ/cjAM6srxp5l0elaleeGRwYejvj/5Daj1mLtr8t3r9cMOTdRtWWSGuGX4G7eGL1p64Odey1rGdF1sym8vs8Y+E66+8k6HPuWmdpx965KH23IoqN6OUx4dm11ap8jFEHeyZ3vOnr365oFnebcOV7ybvY7nB2otOVAdVv+wrpL7YUwK8yueYM3FJsTHoD0I1oJvGgMI9IBABzusz/5rgvfGLFe1DOWsAAWVVaEOOuofF5P7q764iJaGVQ+LoaAZ9iCRuJhzZLNEOwTdeA3Yqhb2WXiuZglL6A+ZL41fhKSNEy79WnI5Bugt/i3Qg4cRDXUOe/w610rHjPaXuvVRXyjojTgTG4+sdXY6offlDciq5TqsORytlmFFffYpAHZKMV6yG5JB0MfCI6kxjiZcXHNgQzrBkhR3iQM2ogOKMPDeenRCDB3mhuVK7BKi3f9g9+jIeG03Ix7ErMoRp3Z7TqgOL/998EMo+gMpxi0QZfsiTcQTIdp+DwxqXVehikPN6p8AphCQQgfUmVLP9WvH9l3bd+ya98M8Us6acZKP4AGZc2mnLTXPVs2yiUI6CsQa12aywe7C9Hx9R8xRfeY+FAgH47ymC/lkoBP/6Cl4JLjbUPTVDOVX0FFCYzCwY7gas3qYLShUwgrqWEb8y0h4WjjIhkdCzI0FWY/5QsbZHmFi2fgGP8Qr4QWbHXFxlwenYTvi5XhQdh7bmpftXqgR6yepTOXQM3SqcYofhOCegBJC3NiAeP/0sK9XbySH70jTxovRhnVmh9Exrd6YWxwXYoJlivP257V6wvfYGlYcqPirQD25SagfCBpDmeRENS5tNvAQU+eMkj8X48zSqFowvGTQohmKp/LWb14/ZKjc93vIH8RaT7x81h7Xcy3g7ZtWf2zxLyygEimjfnM5MUMoz9JRacOgEMpImYDpMe3qt+MRVowWdwDFiNQJRIeRAN0zYATk12P3L1suU/bNUjsVTRgxvux8C6sfGtmdbs+KAhy8a+5pGZRhCmSekZF16wSDGPwaTfRJFx8lE6OQ6NS83MZGg2385OxkzInZ6rtq20yENogtGzNmKCZGJWovjjBPMvFQcEeOyEMxaCXCQA2d+3M96BfEzkPpjl8wHNRSiSEKVDIsQ2sHox2ho+UHiW86fHkrfmCGhPpUv4thO5/oTCM2ZokaOIq8mG8D0KVXVRR/pDUETjxvZkiOiKnb9TRFcxAjlMNyBsODBpG5EiO/lpH4VAPOw4mlgpHramS3L1lS7msMH71k8WhjIE8FoFrIZMVq3YotFvTw7dQgQzOWolazUoYoR1He2sFHJUYwS/GL4FNNfDhTfskMYHxJ8G564k2L3hozLBlr9EtvOpM+ByGEZ4FrfVSA6PO0HoAqbg/R0wzF3qB9dZz4h/bNfIh9VT9Q3CKaas96zur4VYrjWr7hX/lXN6iD3Klm33Ub2tu77Yf334bmzj4Hp6NTn0hL27unT1rnzvX1ctnpPns8E//bTuPa06dXr4p76DV7u1LTam7zuHxD6IsOAv+KPBeoQIuJ9hDACxOve2i4o8tuQwHR3lBlvuFHx/t/aBTzNfaB/3buoqMg9dlRgrT3MWHR59KpwD0LUOm0eHC6vWW6UU/ukYGkNodONQX2R2kYdn9g/R0eFa5lSeJII7EKNE3z7UdNoUM7bpp0YD5pNGefSz/gn+/SOy1naCJbp8IfX2rQx7042v20xvkYdH8qaQdGPglpLiGeDH4xPO/WyLGH/Dezk46qR43/q6vtU2DGcwVsIZxOIuj1zvmlw8sZLhsNk7OJ1osMyqBfpscn6tTyyw11LGNLeiS9+1+/uVXsXrFXhUyGNUrFpURb7C3aGkcL32vD5Ozgqq9XS0CLrpZZ5JbMZJK/yKynGDvuH1FdVN9IBHsPAlFsziOcw12LT2nPOsf1t1WtAHM4scxbP+Edc3NOhvTJqmiX+LqgHmXHI0cdufuNvKbV+xeHkK1mXVpka5Bv53Nj70b3MTsc7RxSiFXgtD/boh5xY7QWgzuSqPjoM4KjuIlDxCl8SEu2h6cd1Kb78SA/hTKoEsdDlcNvfYBV8RDATBzw335T98CT9+yc3MOWN9MQhs/YbcceO9rhrA8dUL9vWSi7rJ/7NJusl2CFPGmeKh8fx64F8kP6Zv3u2+V+OQexq1xRes5gcBoUZpqG6d5SR5DqydjrzZsN+Zu2OKni28f/jkmSq0gMLgjzgou6nrJuvATQl8qgTp2rVyKlN0dh+ADRYm98SZyDzv79SPdU4mjOZ+3PclrqUtRzHlu9T53q6S991zDGBdL/fwX84WKCZC9L/9TOdM+B9JTgAL/P06EzmaKqxLW9npMY9550CgbBU6WHzxQbzM/vZaZ6KutdlTyMPI8au73X1Pmg/aInoHnIBnjYfGJvWuvKLdcueFhetzjp0x9eUWJrhYeBDLfUEKZ53ukGh6zq/UKnZhtpl5HhsW/xznEoSGN3tajwfKj3ftAsGaNUrMzP3+4GU9f3pSUFNNJITJwQ5q3hQqlfk6HzCBXJ3la1VfyAcAQ4BlLEdMBBtLlwLCKHxKncbC6cPeKKI95MZVvazCQm8VjEBK3Zgn2RUPyUoU+uwvSF6h2kPY96hIkhrzDV8xyeXRhVxDFfxty1ve+a0Mr/qqjFd9Zi5206pfgjpoPNewtpdsaaSm4cn+PAEjNs/67B/xKuDqyXn6mz2FUFcdbsVEWJpmeA0r2hN07CKBZMAmdL4NCbzUDwOh7xnLK+3FRgioAtQUE13RH5Kr+ph5+1AxmeEy3e8xrThYowvRZT1gMeE9D/YfbXEiicIZ5GNdNyV2qZksRKeKKPjWBGb1pyUEjcGJI9GSXRm9XYh35AHiyvn/et0770jeYdILEfFMwRMc3TXe+NUESpz9hTdeEZ6s8p9oJoIhKrwEPaWsidA9Qj7oMa6t7pWjsQiYoxg3P1hfg6e0BwOekBD2NGwqOHIO261MNv8hFz2jK+3/YmU1DLM7RmG56UmPaIL6Q3EuNPPeRuwnkR7wBjqePEMI32uL8H8V2FkW1JYUINIz80Lbcd7R5xVUSv0MOl8tWvXKSvq9Q1WIgORioV/EFxTtxabpqrWF6Gh3H7t3noXeLaSaMu6cXNr7/lA3OJKV2vTRrFgcMybpnAfn9+syktz64Iz0+L9YryFXXzV8+dFY/To7Ib+ieQ/cL/KwJ3GKe/4jMqoR9fYTr47Unn2Zf/eiIsJ2326oAfpqNfiruq4Lv/ahyF9Kvimzo+quIwtEh0MM9jl8RLkLL5iATE4ijt6qRbWrLc5Vhn1eIZOMn4g3cBbDqScfHEdPU8NW4irU4s1YUaulTw0xBNLfxP5zi/ObQKE/xXe4AlBQ+lDdoMxp2f9AeBbLLC1DYHM72fUyoXG0OnlMhdEgD+OBV9bSjFpiiWlsbI318MD6mEe8Xc4r2tVMeOr9lyGukx8I7m1LVQagLc/BXdRNoL8pqpqHjp0qG9HNcR9r45Uv8blEsZbJlsPGOf9bYg7jPM+g4KR20L/xrNKxMcj4xpAuNheNQlrfFgarzByiZ+xfsPpFFLqHDiZVSQttcFzjLdxLhjlDhGFLcDqTslPmoLzf5J8FftAsvB110icPO76yHLxwYTFZwSB3+NE0UOXKgCBgZrevcUxwcgCiBziSiAatgxRsaI70cuIPml5gnRYGntl+Z+O0fMHzPtrktoc+hoOoSB3gAYwjIYj8dCXc2DYY6W2V08tgJVFZnFX/0CkxaIAm/OHa1ShqRMNs42ZnUTpMoo+AWnxCqdVLzamLdXcK5cb/IWE9Iq8P5VhIkqk+7+4K8ivNKfzcaXT9mc7r9CqK/sd8kfdS3R09/dB7g3z/8u4itLA6YZ/0M5673lHeJf0XzvveKwKKFMWv4XM3jHMhAJ/Fd/qhkH8R14IFH2W9inOwlBwttUE0cJg3iBsZjzTb/edRVMkzugweOVkJcyW//CUyFkxBpf8+r0fmOw1wQhocyPZyrm43oGb6aFvPpGC4EB55uXYQPHYDksLz6nJitI4kUZlcTZmYNidbPRQ4bPxhvzpy8R1jGib6h+yCuE/YYSywJ5KQmpScCQnoBQ2j1Ad8adaMC0ymplOckOgTDLCtU/UcpOliWU6c2EgQz8kOmJ0EQMeb/4Yo/Ao+9z6JqG3WnkO0bxG9rcbrq/JzAhQ34jBHckRRNS3gr4RK/FepmIXikv18vLacG9dpsQF5fYjJWfCU7L5/R9ifscwFWMYSgDr/0guARzbKawxFaHFHpOFUkmjRvIo35v8b9mzLRzS3SuCNiTSXznfWavZ8ayQHpYCZL0VFBbW9+Uo/e2I2DFO4NjKsJUwh/3jVcGUHbhSzeHmCPnBRjG9AkMfs4/9sknZRhx04eZ27j0L9TGO7DNhMmCT1332nYwfj4wDuaBIH5+u94jjJ2bpDnDsx2GFMXBkI8YUa95JmppOmnPQZVN4a5T+gifw8r/UClzaP2IC1dGWoUwICxgr0sndmrUGTsM6CfAiqSrfYpS3F+QBVuhNfY7S6jFCbR2sfW2vSYPpMOi32zje4gGJJ3Tmd68lVvsL7B8qphzyvlPh6fzD9uVXFBx7vAztAbvJ+Y4tWoIte4Taj4inEydnrWD4cG2k3Saoo6rkyQPM0VRlYrysN795RTyePQpJOuC46mHYwLqhdr4ivBjnxa043jFhx6hw3PHsGaQhBS3NCzGmvMFI9I2LZj5wlZz6jSAdkiWun53DG+zl+VZS9wvqtiuocyZ98q62aSFFh54ZfpB/dsPV8EH6tnTwl5hhgbwtANv1/CmfY58S4j3rSFyJ7qzhpQgPI/aLiypeWh8n6kcqpPjnl/3ixFBj8E/i+Abjsccvt3elYF9h671rd7iB+bU+5uOdCF+8tIBJfRc67U7cdpykJhD4AQ4nn8hNc9c2LPE58iXXZRdZOOfmlyP8gef1rK+E8ZazNLC6fwSqBC1gP67A/3xH8I/74WZ/k3Ts9bQegf5MMm5OJX8qhKLDMgrEdKwMezJw2Ng/z0Bo7PeXHHMwYVR0Kf7PyRwG2Zykh53tI1oAMFrN7a4H3y3ljMw+8sfR263RPWqkkhOqDY+agG51qnmHqaVmTCNEzRFta2amlO5u7PMc/PAqIeRC5dQoi5DDD80OFFN/Pd3NH4hNyQjYuXpjOAAhti7CwK/3uS8WU93Nq0KJL3MX6oaHOkiJ2rgRHHMyduP9GBJ06PdpklHn19AyIWrcADDd3+bgDH89tXkIG+//CAA7raOFI2ps9UbSeEyLB0Ck47Zi2q3TiwSfVRobBr95tcs/Qnzt7NPtPx6NP8gVHIlWNfp8cvPk67x+8Wq+sP6uXEtBERzM9+dNx+7cPQosrm/X1BQIRdpGLYbiYq73uqC8xd/Sukj1ripPENPprWNRZ6nuWhDXtvMQaWhpPrQ1hW9upAtkf1iSn6J1u23uRF7jCQQpDFMSHL0TsqitUBvUcmh7P1CQsxYkC3qAAR956GaYv1cu3/uvSy+KprfHBxNqBk115bhsXItx8CQXUhkVLg1AH03DL8z3RWxl0avVoxeyoYrFpqVdpwdCjJKE0QKnNkznT6J836Ruv7py0JfRcDPk5E6rCZF8b+qeeVCwalU5DkEvyEKAB5zyHZDZwH2He7nJ92y4/qGLp8b6Gulny7VQP8lfqsdgwxeqUzCS4JjOy4XjOFyAc/+qkBgBynx5IRqLfO4cXQwuaC5KWMyjJgbN86cYEoZTChJEiFh3XtcdWDhrgPmWTmgf9r6pVv2i6O1kGy0u10Cdm+mhFbgJ5xpYHUtYHTxwO9l/aQl0hSZZSvA0JAxZdu7/1CX+59qByYBn/nz1D7dV9XM6tjidGyiO1GpPjvtO8X5RIiXIl6pYOvdaQBwbn+jeln8Q0TRaErdM6BrkGyU4JP0SNSXIV/5/KZvsR/mINUaaZy/+J6+y7NwJyvztWXO3heJ1xZfQcMgIr6KFIiHedtyw9/hCw4vfOtXF+IEYxXov0hI3faI5CPyr/4xKglWc603NHHYw0idsZ6NfAfBWBzo9DHYnT+2eH7i7FEcX+UzCIv+ScKi2r3TixpuOrPXkBO/2FhjoyjjaZqtfBT6jthpec36xev6aQfQRS+o7jYKhIsZAd63gYQk4FgxiVSo9WISN5AaY2kUU+lR/gDrWnwMlmWMTR7/MdkulgEWOnU+0Xm1LPeFCTzMCPq743db3pwjIO3sOwf9VPCZsYVmVs1q+ZS3JiAiSBCoB4m3TUQdvQF0kMD9bn644mHmcZMAO6nEDSD0qxABfZi3LS/8Ll9wWOFbCW4UViHhlwBoXit6urLacpxTI1yth/nGoTPsjDyeX7QfzEsaZ08Lleyn1TtIjFVBO2wDEIUyVPdd1txUs4KO9AtMqvcQnaRTEl9dN9/wISYv/Rx0YG08ANc7TCJ8CYoFhxbRaMEhSV+4VZiMt4n0Qm8I/hFJJLo0cQdvAXeRF0wJ/RrCgEAuHfUWOTYXu1AAk6C+PJIh/OwVw/9cDNTPV15m0EaYwfuPasO1M6aX+G8fzW18vu8at3CCLtnLZTkYtgeJjA62+ODqZdPffOLOgoYgRRiuzF35hx0Mk/tGE5Cgvh/42bIIrl3jtbtx6iKwp5DwyaAmy/HL5eYLwoXT+N03/ruhUGBfaCglm+zyf35Dj4j3H0sSaz1m7sA4QIexjGqMGFNiLGPt/pFGTDle60SdkvjU2oWGH9G8+tp1xxS7Ru8srjuJcdZOP/Rb4VXZJnOm0nGIML0xmUHM/wzmeO+qWEjDOq8KIS4JuXFfE1Nyyx5Ym5ZrMEnkUM2ipNICWii946Fc6KXqFSWybFx4bWtU9V3MYObxXNvYcDY9NadmBcC+SL1KoDYQ9zb3JjpnAyiwtH9RBAVFYtINq1bVJrKgSO8YPai8oHxqd4B7aTPd2bg6iBsaH52+UonlKyZw61UavcgJzkSUHn5CJtw1kfvrN8O0nUDGhAFXptf6RMD51DU/jCe5L0qV1V/0AL56AjfdXUChx/17D2BAHsnuAdyfbBYD3BqLe7Ce/vHmkYe1XtAdZqpeIdEHffsvxkS+VfR+tv0t9SSOspzfqKfAOQTGUR/2osebt6pNWnd1rsQYrA/c+ugg9cQ606lUQpSl0Fi2hkezrD1ejz+UZUehawKV/koOChC9VZBfImra1VGTxe42mydc05gC80yUnaLTUTy4Za0xfyfRP2JMlbEWXIIGPVym6X3hGRgbzb/sRKI2NcSscPrgHw6nl8wwVGQkU5lkP8nzNKE25F01zV0sPbB5pU+XBBferKPQvDhvwVXnCTHRmKLurpyv7WscOlwvpuSCRZgHrhDexX/doyOOfOv6jZ7AHioBcYZ5zRYAjQA7vgK1g4Zdd9WeS6rDLGk1rezwXUIdx+tHO2YRE30qbu8FFxu0dxoEmjGMuJMYHCwTyvah03OcncKb6lCkJ9pfoeT63vb2rqbdRPzXn4aNsEZiSJBy8BmVh3YqO4ElZdGMb2S8G72sP7PzwDieXAwGZC258LE9fDjyTrJzMa12aRonvHRL2pVJS4OKoNLnrmlJmZ0IBDK350git4mkZm7vRqc5mu5uWBlKehmSICHNPcei519I8+GG7OtmLEpjVjvhlhaogp9spoM6hwsYq/1gbNT3RjHzZwB16v7FtUsuonH+xguy3J25lvmG+K8NIuz/RFGa/2mTZlyUcB7kbTNHCjtzUuTC/z/yI4dAoPjYtlCIFs1Egfl6HDqxGVRfOwJ0hNgcYH8s5C2bsIgFBDsFwBNugbqFnH7YUsm+UR7X9K7R8mEhLbwx5JshI021NoS1tc/n+BaAP/nxGceEcwLXVxZRMGr/tIbLjfYGR8q6nzaOVdN+xY7ZIcYfYTAlud4uVETRAk40Ld6J4cqww7NhVpQfUNF+NXr+91Zvr72X/dahvToq0PuznqLAWBBeMLwI/6stITQ5RZss72WejKeKByKfO2y1Zv/BdJkz4HotPuIMu3CQawQnV3waAcjDrPD9YnGs9RS+r59OOuXgQNKaz4UQLDXBCFz8zdcIZDIxFE6OsVijj8gJpXE8AcjJDXjBCp9hjy8NYljODzt0GNv7fE6kQy8dXFAQte/Umx3Ul8PlfNEMITfxD+N4kio2jWTS1DkMZqphI61KRbRxhiXvcVtiN2oJT0hvGtOGuepVNiGRVMZmTaRexc5iNj3N+P9NsLe4UC0Nf0oveYRwUMxgS3LTQCN5RaCRYevJtkEUCCSShFJxg4bx0G+U4hxjznl0moIQalDUxMG0Mu/UzBv6nLpbGUdWyr3jpxP9YaWGDKMU5+U9zNW4Rq+RXaXGssgBjXfuhzGTER2zBXS/eBvQrQGVgl5vxrjDS8GIPKXyFMVH/JfzAPnntnXB3LX1nK/MOYGuLQplwM7dcDdUX0uVS+D47q03USpGUR3RQNzG1cCoxUEUF5Qa5vOmzMw97VLpPPc2ztM5VOslw21w3GDWKNzFQoXM5e4GSxhzhSbkqh2ed5L0AxFp8Pfyzsawj7hCrkAqX8RoF2EmpYEEp92BcQOPZAel9ahstxEKhEdDj4/z/wOLlyDGeCnQ5KLqnFpbhpg50I+vT2IKGnA16q2YZz9FcttIPVLO4VoZ+VsSwdl+EORkUVREtrniLtQ/kuNhlHvBuMIFq1aKtXtEEc2mDDr7Bnjg3m8UIW7QjZCduIg6IXJNDOffM4qPvJHyB84mKiH32xC+C+s5Rotg8tM3xsKz4Lv4SiF7kV5aQS+Rl+sVFTSu3aNWV8tn9QP7eQ8o+bl9Bq890VsEbgQ9o3c7/R3LclaFkzHs0PCA9gG5XtioiaaglnrDdIOT/8erjB2A/eh9RF+V5IxjfzTcwJOYHY5vmq6Q+RhH9K8TSOp9/wms+XjQoHWneD9DtOhUHOmnSg9sUYW7Hn7KFANYa6A9lNjCm9jrLEKrkzdIpUWctYB55zH/nO/IgQf+L0Egy2keFBXq3XiK/gM37nG/E0L9WbaXDIH/6W+oXKQ1iTgV2kx60YCJDochOBxHwOAVA9I5hUdKP4RtxBo5amg5h/ZLvtOM+MXCMsGkMy+nHbg7dEL35ZJY6xkMf/Zx4ETScQd4BgSGvuPrhrAmN13kMVFnRplEwqC4QaVKIQIF0WIRl6KsfUFDWp9mD88MZQiOA8mzec7t+Y2aeCHHGRovEX3eFMAurIZFNb4AGFD38Qb5V0s3hLCP2L6GiQNG88hjv2RxKjc28LrK7Zko4EieScQVvo+GFUvb7LkslK++mUPsMVwDVhL0MAHsibk3YY7jB7heD3R28tDu9ebVy32XfGHdp20UmtCcWRRrPYk9cGoMmCUscxu3KWCniidh5896xi0yLKzPsukM2/keQoKP/Pui18iOImNdZB9zw6TkkklN1Zh3y9VrdXrIARoslKOMUWBxzruHGlSZOEpIqI1mAUt/ObKrZUDemZ9I4jIsWWLHM52jsIdN6U+J2ULSf941irDjfprXOXIUbwKa5lClcWYf0T5mZpwgIHXYYHpTXkf45HdDel187Rv0OjWLfSOf7Uk3MIFCM5qYBRRrXXyWMTKmMoLz5mCRCYSxzwIdntyQrafY5YKtPYDyNl41kB5bwoalSwmDsVDGVXQT2nv99bj/W2mg78P3VyndRWVxG2P+bsYNpvbT5ALSYfH6FTScRzD+wQf6EK+z93v+Kv5K0EAThsUNE8A2STpN/IH+U1HMWQBthRtbLDwNMT0p20I/H9dAEfZL3MBC8m2VOIdbpKjvsxWwpw5m/G+muzTKojLvdhD8wTZRkgIc+AEJCFD+wAkLjiVO/flNakB8HuZyONyDWQbYhkGzbqZozRlUaN9RpB3syJYji/KqlignTg9PeLCH64THt5jTIwCDVrwJ+HUQTg8PVd7rnkDRZgZjVwfb7Kn6NuYfFSpI5RScmjtRalL77Xmg7tWtY8gK3f/9G2K25w2Mikq4ooRIHmeQ+zNmHDQmqCFjfx/DLGIEU5d9cxyc4yRVizfO4CyBhcXow9REEtP018z5ILIYmS6a1rGXXibPH83HqYr7y0cbirPdjpnbE8C0S0g2ksv10V2e1fdwnoazPwfOxvo2DrVcL5BgUxWGOVITmovrYrHL+C57smKNCrQj2aC1waYqvheL9TE5Po/BWUAwb9Yzgz2mM2w3gHK70uCBxv85+qiD4f9fI7XjuJo8ac63fvzbdjyQ2PGNODAgZoib4dXnuQQLR3kBxMOs8JmxNu62ecxp1goH/YCpFhvPPwqmhF/jfp7AIycNbDh/I+5U0om/87LEdVplFxXjfMS8uX5RagVOmlg+/nKyLvQnekqx8wMft3WdxjDdU//10S/gPKJ5qkN3/MChH+1vOZHS7Uu2pzdvU/pzU1FouI6U+/bB2JgeRsbNlVk2Y86vv/DS5MTqDJ4B30be32lVOrN/FM+MZSB65VE42fd3A/pJUofJvJcFxw4fRe36qaSTDr5vwCQQZ0CuXB9rLCgcN1SMwpVprzdP0SSA1xIycPEmUza4izzfz0ldoNeYTxYH7IO0w6e7a01laDmrvuPCWLc/HPQWRzqKYpHFfrL3MFclvJreSkDQnRzZPEt1ZzSMjMl0UUjnaToKSX15QdwRWTMC2QMeI458VYSjhvwLvUy9hhGJP8v4noNrd/IrSmJhuWDGsbfDU7pmoft8Uaz1CdykV+zn4ZPfMUrgzHfZAhIS85z8ezg8SHpFnq7gShWhqlEnRzOjAv4nsd1Vil/dZrXQUiBwYVfTMDD7Opm75GemzCYQzrpMTgsgZ1QnsH9jiYTHIsWzNhef/GqQfTBDdhz2Zr5MjXKPXwFswBkgumMEKBxgnt/h7Vv//i5Ea208Gv9AUjWl1JtEiCnaW1dAq5bQQmkpBiqKBC0Ey5dNVB80yvDKWPp7fUGeCTgKbzUdoq4m4KSSrOwtC9undPK2t4s4WZDAr5/HS+l0e429SBdORpB2fQOhJ0MMW9RKoCu0CkhZ9k4DrsmhOGPEryofSrEmKaUTD7Vcbu0PxaUMDtRpjVbZ3AYuUHw9u6LXHUeHCg4DqM6/D3//ZUHHw9pi0fjf5U5opS+/DCyOw1sEdvYW8CZtj+JKDc3rA/caZU9gOCJy6CDeGdAwa7V1CDw4XFegn8ic403s5rK1RSO2+YH9w+3Dd8GuwfpEPI9z33eMcXTUDxPHJjH0dHbVoDBW1sLzb09YzoTOVigYTpiH52TWY5uv8ruXegLAyDTRPSaCTJ250tPdTtl7M/9RUaTm0s9uitBpLmGJyWdcLDhZosfj16fqj+B5CXJtAaMZJLgxqwIHoS+FM3kR15XU5gxknvywhI1FwN900LybY8LV/+WBC9vdhL50JEoIzLIfLedNHkYh8dgbq5ptLpy0a33cq+vjtKtW/nw3ajPn/IYZbqecvQf+UV6k5dLPbowwniyXx7oYcCpZSsZRfUsUOQDXho5q6zuT2h04Gc3HUYpxgYv/s8fiQdZ2WWOlDJWKt5ofN/ucUTJuEcu2XJwpXgL0slDk1OA9bKpKG3nQt13gzRdkIY812JMJepIQs9RyZZTllemqc7MFItQ4Jrmn5JRyEzSof7LgCECYA89vzPlh/fVqslnVrL2gXMKxGaueELihJ64gy/xOA/QsuDa+dMbqrSSqbFRQ8XWYq2uFUmKIBx6cT6JLfYaBGCpySzQ3f4aJnwhRjoFFTNPzYyXik944klSzfqSOh27oeUfkhXI4oDAle8AMbPC00L+7Wfuvjvqe37XuBxAmXyDhAEGZ7CPcIEPYLxqiqTSZLA5J79Z7eOk+q/IO7MnG+SFGOP5kPrWu9cYKX46Bn9wRrb1gZam9YhvW259PRbLdanep/9AdXxZZm3mEddNoCovP+gDWEEKyshatFWUVEvoYeYTaWYR2fFlUGoLHBa3GFkAw7llx3nc151VpM8HbIKcezPir4PvIe7tWJJfGK7BNoA1dJ6FwmkeVdcfn3VvWb8akkE+Mnuunk447A8gfX8BKGVf9ajQ251RpfXu7sjuzjTxb6NDiw/c88H8SBvMd55gAKx3kcwjiPB4zK88a+zkLHOSuhQc6PFBXNu7u032vMwsgLdi5OBi83nxCwL7OntpThzq0xoGuDv43ryGbZ5x4LbcboAkv/D4AhV3nDLt0g8Qe2FWXQXbRsrqyYJkDZ3uNOW8hkfh9ru0XQCOFVkfek94mH+aPL8LfqdccN7I1DeCDh3LUMQtITnJhHvOCt74YRwkttdEcsOlAZSZUBSSeH8kpKRiTP7NF5MYWi5qWhBvO8HbuHBkT6KuPiUnfzvtjkD+RnLrwwGZBx3FvwoaW6fCkGSucE2C3qMkElrvhbuhl1hrm9OXttUB0CLlb2UEQO2uUug37DBNC/tF/oZjwAnbBz36jYUDXWbpWhaLDSxUU69JzratJ57BHQ/34H7h8siDcsvwIAD00wHBHpwBu9Qt40de8+/26C7vTCqn1pSdTqlJyAqJMMeF8uDnZtTEgRNU0rGhzysBrc4JVNZyFMxwMg/k2qWwdBHwHMzzq5vbj9gwy+K5fWlrxm+SCVXZaa42GC+uNiBziVfC81mboVthaZ94bTQ2xbBcU7D2rbPAvej7dDPONlLS1NnplWsljlmRQQFepYMYcz1krq6aVFunMe60O0IaUqsQiLEZM0wdaJUztzz7NK1UZU632U5hlapvFVq8U5aGfH7Cl4wGmtlkNfwBeN+O61uSGkSX3F4HnRej2zTMZ9QcC94z3/3rQ3SKJoDko0FoKBWmAQH0pKwgNjWIPkggZw0k1HXmEOkc/Q7KGp+rFslhcx5Fp4jwQJaCvhmzQeyGixmHKXjg1AYcRkk+YlwODfL44jBmoDTY+pucQR72rM5SSQD+5SUw+M/GVyYA0v4DU42cZJT+0Z78ZnCPWwIAaM1EddNYSVeq5gSzYhegmdJ6JXqH8lGnPi9EllnZT0x1wBpNpIVfNXm+9XqXO0BeM8HxCuxwYJMtdPDhOnf1nIT290ypUGpzbcudpSc/qT4HxHOU7sMuEC2s9UuhFwRxKvAtQKX8rAe50cOeYLF1aSoBWiNFp4DMHVEjNyFRVk3I7MYJdzyMEOf4SS6SiRUEcNOVcQYr8gGMgyp2/eGAOWcRpTXsnc2+7PkUhhr/n8ouoJtHLidckT9TGcxu2BkrMuqWXiCApSn4/ocZ7BAd9zL4eRQa0nBoNPBEVpOwLQHpYqvhn2Y3O13NGQgHxCT5XPFTfVilOtf0T6sWc5Kx4JZpqtblNRNb+W2HIjbf5bydAvd2Ro58jx8gBM3sYbFOHL0G9YpWoWG1nnIcMKEWAgWFXVrkfNPeYFTGTqYBZVXEjgVn8z8KJQoexBcbx9fz8VpBaQao3MbtwUZZRKPYaOCLBTcgdL31f3Fc6oS2i2st8/9eQYBjJkC8UDO3aMLkly0hAqTEvaENe46QTkxqZ14ZpRwO3aMw6VmeZBqRg6j5jh5t510tn7WlAQvsT0MMwrF8QXDxd8nVD2IF/OJ4R3jYuZ1xBHFUlXjJtnbFbB4UwbC0xsL59EOy6+rbtDEckODp6clyEBl6VOBt2vSGyo+sG1pxk8g4xoICXR19iOOwy3PclK5ITa+t+nhy47DnfnbFheYGDBqoM3eQ+bIPqspqKO4QeJG9SzSO0LHXzBbRn15CdSiuWmt5sXZD7Fw0XZapW6AuGYg+yghtu3IP0NhNWq/gmud5tCJRkR4u7lqkC5ejV9pgdWodX/UOwTudYNKGVKpGKnbhDD5D4dn+T6h6/eoOm1MIt5ipKhFLyzFaCaY5tpSufKDS9KSo0ZxJPqyKdq/boFSOnaMwwjueAgVMbgjvRAXEstAjy959nXno0COublfHYJEZzfWIHr2A38ggvHfzOxGAiG+PUerkzHawhc3my+eZk6YVAXSgn2GU8Bm7WfJ6VodbusjqKJYrSgOPkUW0iS8j319j5Uo8reVUsa8/oXV2bzkVkZ/DHApYKUivP9fQ4lwt1WmQ8dhWfSOni5Q8VdQjURXJ8PoUz4NG+r9MzFer9eBWWqD5Cx2NDNCyyw6S6B+2C1Ipz3d1Hq4UyZVm89bwdtKL5E0qG8+Bp1ZcHsmp1hLN6hex3DTKtnxyh4v2m1sV35zf3m4zQoEwzeQkQ0c/TpJv04Zvbj1nxzhO6Y4lzA2a4KSrkbcL2Ka//q0cPmtbHYILhdr0gvufnt8pxosBRIz34mlKLJX8KYPx2zUnmLzVL0iKgmOJf1bMLa8nFsDktyC70nfU95dv8AuIvtYMHPG4dEniG3rmT8P1mQQuEi+/n/1B5oiZIAbFZkcPuO+U8QAo8FerFr4YCJk7WbYRvK9lgF19p6S15XOhMm6hts0KT9QXDkrd6isQXn97VNgjB33L8x1ihA3ypSRFTHxwS77rvauO2dnJTr9BRueqiBmoLCY2EZ94jIrsCfBvU0lXJhXEpmarQ6kq8w3Ah94+PEsdwnhTSu1P3ztlf9s8W1zNaZ3RV1+/7534rUGioLi+kqUrTRHs3PIL4dep0WQxhxVjJklbMDMeyMMhemSOE2u26E7IpkGUHdCIFbtc8Lj5smt/LeyyOTnQuDXfzfNfGrLXuTjv03xiyNeKNKVMXbuvL93ApFV68+ifYENtQ/foHvy/Gc2mjXNUKTCXiwkzcEvKMMDPV9vXO/MXxutxHrdP7SqEKV8gPFLT/FAOLSUCYX3d/6GuTERv8gvazOe2F7sYisDRU5syHGPd4y0WYP5s5+xfkrAyjsP+EkLn0RKgrLqfUaRNh5nCcHY3b51b1l/x6F961X0Sw7uQgkLvI4TlAHOMM2iDUY0zciP3xUqeUREENMShpREwUA3c/ZTaue6JHddywKK9OtZwz9lWeAR0oXfeewy3KPS2nrYrHLuKqGEuIhjv+khhPq1Zaqm48jsf0PPUrFfE4ayzO/zQ1nVSg1FSTq2qjf8dZrUKLhO0jVU+l8CNuUfuUcqFMXxVvvYhrUtYTC7EiLC6+4luBpyn/014so6VKVKdsJYY+VPiRT0KgPuLid3lS9dXBbJVpXxuGpl0xPw0xAGOSbDcRY5KIAXzANFEspiWOCetJFm/BYbIuKFsdq14lIEhhRTfKAX9S3wnpqxaUR1qrN3+B17iP4Q1sEPuFnupHwLFpD5rsUqTYw55bIbioLKWOcZR4vWKkFxH3Ag+oDahskIQk0KUBFG0bdSS1HxjPYWTgxsJCQX6p+yTjUSmsL1bGD5/DNEuYCOUCQyQ7jw5zQFhFQkhSsIedBCFmKk8OUwLjaFlhaKsLSNwsKoocDAyeFo/qkpgJPHR8fShLp99m5UAndUOZzIXd3E31pla5+HGY77PhbDc3JCCs38rzawAwfnrzq1RCzliisyPuKKjPZ7XYtUFzB16b5Aw7HXarW2I7lMFkDYajIOJGO/555kslqgaVC3VD+RMvk3nTpZpSsQ9+9Cf1FTSS0wakv+9v5MBUV4lrrW7vKcN//KEHaRpQrW9uFg0hMjXQ8mftYfftsJ0JWIGAybqUO4klGKUChgqmUx2FJgH+ZMAJqESy5A8nulZW8E4co7YYMUBf4Nb4hvvrAZYfHVlyv52FjJYu3Mn6kNs4R3YJK7/YGK/5gLymb++woA5+8nSHWZ6id0042NLuWZjS52lcWpUvY0y8Hzx4sI3XAljvhTmcsDGl/0ZyN9XjBWw3ytm/Y7NRF4fqN4nMlPBlw7l/3aHDtc0Eq44tFtRWNfnSdw3GoWPTmi37qG2m1+XN0nDzzgCli+xUNWseJtbt/UeCXVcykHW/+Y8cM7zAtcF/FdQbtysTi9sORnOD5yJVoOdODl0JDbx65qvXob5tX8OIyP0n6/XFMiphEago6bgpkQch3r36Q2oNxwlB3ho/9CPvvwSNn7wqMHc/ncSlnBv7Ama2OS+sX8eZi/Fuj+ylWgZqh4aSlqxvaJ5BQc9Dbz4bT1BD328g22hLXIzGXJO80J9lthF5zdrqQM1S6OYZsMmYWsobuQVJ3jptND56u15hFz0tXrniabxvs4UHWvy+dxGYcgg9MjYZN/lsPGT9NBKZUEsl4y1KJ508GTHDW8C/H3TwFazQfyD+n2mCjzSC5v/LZzxmkJKvlwd6pB+hyqvSbrVSjy+I5nVwyjf2HdOvOaqVKeYjKDy3du38wTruap5qmFvRuqSVvEzRVkczItAkQdisgIFGJowY3+rm7L6vsLv8RI4xdG1vNBEdjNlEdpF59c3R7BiLnOFSU6QfqC8vVKhpH9NNaevwnl/fmOQEVaNBqEGoJHQkGxq8q9JXTdhEWFI/UM6MUvVSOekhRXm2xr2pLeCaVYGpTAKIRzseqmWTA0JFpz27HUNzFE45RmghlU0aUZS8gdbDqOjSvSz9AIbu5mtwGZcPGsf1Qnli9kmOlBJfYfjYcSqo5lpX+WceTDrK5i6osc4vIKfrvYMHxJjzwq81Y+mYU+kzU2h2GfHFoPMsp3BVFGmaqIVrk10bN86VN6oPF0VTRDUtWF1Ozz9k+djLgVqgJk/ZKkibSC4NBrwT4xob53SR1Kubai8/cwkMLy9lIDahvz3pIFKa3P/Wvfjlbgzufv2aLcSndy6O5r19HPyOm8qNM5H6jENv8TDT5S+9aUOH5Cl3Ph3nseJhRomcw9btHnDIoLSAVsLwxOJRrUijr/SgbXNbVNu7k3aJUoO3euUkpon0XsLWI0D+Ncf8EmTXoKOrg1126BEVsDdglBvjMj0LCOGGduEHzWPFw2OCSk+ga8rHbht5bk5JkeXiV215ob4r7TZ6l/0XvzGTWh8zTdOfvct/sEban4VR4pXyjHS960cubpX6a0ps+HFf9a6idjcPo5RU7t6QfTp6COw2p5dfkZzDPrR4zqBGmcSo//PDFfqXZTUnfSg+9//nwoT614Ko3yj/2MdIJQfKxMSg/e9k+0dWAz0OkNQGYqnnb3ufiVMkSZiM67lu4Of03ws60BJb6ih1vc6pHlxsZgzNOAaUeSdcW3+08yredVHnRBN76TY7lh1VQNSZe4AD9sFXAuZiYh+vb3aqcEwv3QmadolcEedjwM0/nf40hWgVf1o6bY8lItaDbd08a5wjjWlNmMQMk6PPlqOg6rIanKf7Cjw5+WWCvAFOA7BDuaUB2uQ7UUiZ9APKCM6MiZKek14G+FBn/44Y5XMIqwQ+zKGh52jRzJncqO0N+0ALnP7qxaxzZWkhWsSiW8iThkwFMXF2lw3Mn7v6dau8sAtxwEhNmR5kT8pUUDLbJBoPwQ37L/x7+lNWM3faJ006IcNzfhqJWTxd/uB9ZVSG8Cogakz/9bnvHAYJRL3ZJNd8Xkzli/HG/guHkKxcFtmeo//xTJbXFzpBR7h3a7D/zTf9154ExfOzVcaJqPA2K+Is8MF4hazaikiNXL315ZIdHMzWp6tP7Bh/er4Ec/sGw26oKCUmE6YwcgwSxsThFoTMHh5sAqnHNe1RXyHbUYzZhc/0bQF0uu+O54xaOYxayYyyrf41QGom0C3Pby4iqbv+66F1g+JOu3Jj5BJDRKSSpBAP7iaKdjzwmBGxSTZoWADr2w4kmVhQ/X8NofgBr4TIiS+943ma24IJNYSKvRx5vy3mdB/boCTGzIUDyygOMupJoxkSgS/uMtT4ShAVZXtk5ijMkQms+gm8PgW9iu1IjRQji9EmI9K3ijyqY44t2UB4dF8oipsPotFYGtnqqba6XD6hYwHDqyCnKmoipdwYnfOLJs7qDwLYP2hI0tyYYPvRNq4WERXAhDOLVVUp7IxZnqUj5LMDyet2uQIHRbz/UXxGwrdzlo/82w+4JYDccqTGHxpfvA8+FPgfErzvqICZlohZn7vnMgCSQA6o7OX/WCI6QEpTU6fmk5h0ysuyArmMRut5L40S/trlgDt8iO+z+ydadau6pLORbd3E6Ge6iOIriFDtR/IE4mo5eyjVMU9z9S+VRHCMoFrmCjWVkR/tolF+XMzwUj1LpjM6eSFlBekFNg1K10iHHXWSU+md8+506XGU5owxVjgBbkcRbh/uidM8xu9nkti7lca70c8G0grwdmh3lVY3GgD15R6cwVqbgPG4KeW87hmKby6zE8zqvyTK3TXs+XBB0QUMDPVZUJV0hTunlPnGq1XFHCc1nWKEu/snrHmKbVN3hFM5T/lHRIi254fQnGuth8RPHdLiCCGNa+BIzJ37gwcg/pncmTqvzEd7RD4H37nmtlvkz7jnL3qul1g7gSm4E73x4fMMOkawT8y4DNutLcDNXQJOPSDMFuZMH9ZuphD20E7hkt/smc14h4AqNIXscq+7roE5RWqL2AgRB7ERjhPgcHYK83GDrrmZMX4ZlTo3mE93zg0gbgzKz3gc8KzkYOu05DEIi3CIG9/Y2ZCmKRhGMOR2uBk+0dCLFrjayqVVcZ3dpt/LdSd22NQ00zouTmgmKtTJ8o3u8ZQ2Z2QkkOffDnXuDm9tw08FEGGvXhBlmluywRfGHTJ6pTovN1KvXQsxBAOP8CdjqqgqZLeZxrzY/T2s4BhbK0eoBLary1KiqjsDj93xi8iDUVpvLX4zaQ1MSBVIbgiUZCFjhdfa0omSWjH7Ox2l2sU8w2cxFugk0OZ2opHMBpfkmFHn5e8CSVBp3fCA/soNQFfm//T9On/qQNWHNCeIonffOj50g5+mLtgIuMbAa45ZMBIF9EfxgS/KfyjZfMu9phudZ1x50nLbeG3zpARUyOa3c69s+ge7okk/kDCcqbhB//qWG056aiYKGqffAbQFZ9VTyVfZc8XioUX7IwuJq+5S95wmiAtpokKx68vnj+UBrFOh1sTLQPxNRQBbDuIE4kXOoNdAPPranWRTR8wDhKgvhgowRnTERHSlB5a5oTn8BQ1VeJFcDej9E7H7IEWlpnLelV5E3nlQ2zeDcbz9ia229Cn1NukhmxiWyoeetU1SfVhNl9Xk0zVclXsQWUh2kdYDI3293uRiV187iG/AN3CQfEd8qUVaFKjCIkZ+7Gavx/Mk2xY4Gl1PBfhaxscVBrSFyiGAUy3cI9xOYglYAo7kILHQ0GAoCf1z1t2GMDyWfNUPvwh1BJyi0PrP3yS8KiaG8WFbBo3zLCOTTHkp2E7/foFFMU4ri24qq2LCq9Lr16SzSCXu1VBH7TGPqvR0SvWky3BhMKN0CtN+nGfDoSBuOoULw2gPzGx45y4x/eSbkXQuVzcppOMaGpWLcCGNgnsS0ORKkBKZG2eKmzuU4GaLptVvUStbmhQ3d9itrdOrzRFs857hdPnORn+FFWgMwXAV6MRKJx970e482/ZXbreGFPp25JOQV9ztHihxEfpzw3Gl+RHtS+LeFIWHmQTPdri7S0SWjW3zqI7rm2sntJdUQm+O/HCGpP+9hWc+8I1yxAEMP7I6/02Ksa9Zrvpb8lVupJNbnKC67XLrBguvvNpZtU1OU21dyYtwzinAjZpRjticjFTzUQSH1lX9hWRRpH0/qU3tLL56/B8QJKLvBtpbeHqZTnlHvt681bUSx2Yu1RTl03MqZDfcncJIAMW+qSGTkXZcoCuNRrzBObTtkW4ljRQQCth7cX4ZEl18r6pixvnCZbymFHiVuoevoi1l2VsbncPyobllfWIouse/FW7u9oW46teWEctQ3cAzq1OftgRS31v1/ThDnPp/aOL/oN3t5cHDZ0af+kQMlZpCQyqTwj+E217DC1kB49KnaII7GDmyDoNfm0oYqnBIZurbttuwzlh3h2XJKLHOtAn2xGEsg/6rT0/nQ3V7V+Wnh95Z0A1+fMuN+7z/ggcbH+WkZIpSIh2jjK45Yt3C99+nybqMTzpNyJlI3ZmFU0J+z33rjj223UUkokidaaWyvRlJlywtm/GF8CPZnUywa7Z5whlwUmksmm1jt+zIZLaOjnW1yTnsYsas6h1LQyuztEhkysZOjLrevkeWm5u4hS2TW6aWK+5wbZvcsNuC6qyn204SwaobbOkwrknlJs/OZV7gFy1UKqEnIpL8KHmY736MEE6/WEiuFBh45OKHfsWotleO4yik7qIPSQWx8QVr1V6yPhIDqCfCiB477NRGtqkSc6ovaWU6E9qD3OcK4p9Gbr8SXHGZyn0NqZSle0fMgrcUSBQgXbnCK7thiIsRwuUXiynuh3bbEkT1PCi53NoCLQCJh3AlOYROlupgcGi2aAzpcWw//AoyurCosqDR9uCvVGdCpNCLiEBiE5CRCBGuLA1dePNUlUqkPTRmiSO6L40F04e1pi6Xntkst86Tnt42z1f7iAUM9mtvpVpQMjWeEz91GZ3DJHQcYH9WmshaWnKBwWuhVd8G6SZrOtu7PgfWc8I/25xJlb7WrDSlxvYsHKJO8lELoc/WLvI7sSVL0TZwCG2Lfe64EkjjKreIiTuXPgGwjR9GbMlS8hEuDawkS50sZEXWGC3/ttI4am0ts6DWAUKtZRbU+tiCmsssuGOVBbWXWVCDUS66Ssh5hifiPniAF4Z8uaSBZJIEzAzkkszneXKiv3hh5/R+wY5DPYomgqekJmWE2Ijbn6lKX8hj/aTF8oN6WqaLYhVMU+253WT1Fe2WNKSUSKbguKQmUjzVznMQK0/UqpuUhGtAi0ALEMxuky1bO8jUXLZ9NuASmZj0zK+1DiT1Jy40RSTcS4SEE14qSPnjeEY8M71hIz4ShJN5uebx4Kyu+u00hUqx9YcTmhnHe+Ek3pPp3TgyJMrx1yV+nFjAOmzKjaHefTbDG0gucSt0jK5HfEDepW4VVKEYWBtMrRPtr3svYowparEEeuVI6xO1fb0OIo7S6pbrEjXtRYf7OJzWdaFWvNhglG0H2CZRF5CPgq3qoeSrmojPPiQCu3AeTajDUWPMy2pnHiA8g2IMbSIv3E2X5jAH4UlpvZTMW3APXrL/eA1VzfrLgUgQlU5Z8VIRkUq1yo9zJHaYX2gypmxWyw7ojdTaVw9gXhv2s7tj99LNPTay/Ws60+L6M1eeMXjlrKud6eQ1VTQd4KCREk2Hf9VH6DuCOa9hzpTJ/3rGMYDXTuplJvL2mzZlGUCG2nw/UdAAO3+hMDG6bziFKcc91tq6gjCI0jnBsmgPrUDolMI+y6I/dvspg7BhfZuYkov6SngDE1ekzAfOn7HGf6VXqxqG7/Rj4+llRXsan6FcpzlkIZlObgZGu/CBxKG9s8NKXdgZ+hkuiNBVPO/L/u3nlpSJJ7TDQ7XvZD+DTrCr4Q2SpVDqgyPsNH8GE5u9c92JN1IkRaymjqv+Vlskv6pvN/BsULeRbgkcs1uRmuG/fbDfyf/c+AjO2iw9Dr0889DyF91I84Yq9yJsQHAy9+xM7audqppCMsRHacf+5moVpYlb9NKIycWLmEM4Runzj8trae5aoYPY7b+iWUAj7wP24yON6FGresEuLH6grrCqL/4csFpasEmTuAdoiLcXuxYkLGEMOUtu8lT9UCwDha93x8xQRB8ADZLoKOfy/zQxtemv2F60ZERbEoME3l0xUsRHkVltBb75FjXJzeiIumOW0u7M+weJ4VjwhoD76rvlZgdCbUiuguegLnuAksG0aRQy+yS1yb3Uq5ZnYw63s8UIPzKiTyDDtR6oe68944XuPMn35YL2p9ta8hzxIjuIFxERN/RiF/yIaId0oULEQolp2QqA61lZUxWiq9jCSLE3lFVVoXzjguGPKfbu3RqHCNETPdGTNqKnbV5nSqIqSiNKoJSYO9FQDH2s5GvKA03J15QWLZyngfZaYjEb2+6do/aRSv9eDlbg2liz/VteR4dQ+C3Cquzj1GWdsqbWE6kZaTbM7/24bnp0waxnOsF5HfIlt6n6YrzKkX5GJXI/6eZqyJGWdacso+Zg7h1A2glPQVbwYhgxYs36DmIuqLHnt3NldhEKq0qdLMT2DdaOnitabGphCFf4RdM1VdhgZqCBSEjrnspn/H1dVi4U8qQ0fFkKzZuPQnX1+0nvqUEW3TWFz3ANCRwc33Vg2w3F67joZ7ZyKU9oiTLEXSxjVdw8IXLL90cnJUQLJQ7OfVnX437l7YP0Nb7NkdxL36YW7ZeRR2x8ssZpmqsoGQvskltKprcY5MIy2/HlqRYBPw46B44TbxKI3lZnY/NObTUPEB5QhCEdjB2B16SbDJNuY0hDbPheGkKUczKNZr0FxO4DuepIJau1j3f9CkWoYy/Iv2TeRynzFV6ngCR/M9mvBEnULiNHW07xJa4uU4NU8hs3AuHy+lx0l9VmXFOeGspDQ2kzPFIVRgKUxol0ISenG3U4HMRAstAIeB3gP7heHlbdsj1BxL8WevVVevNC0VwYB05iQk7iyrjgSItGQftWvf/bpowVuzY5UaUUlpUVnxN3eu3oxvQNOwu2u7X7Cg+BHI9bsMK8+71iiWAmtM0n7j/7qW2uTjgn1sl4c2GJYJTX2Va3eRqhjubeUN6Vfk7WiyZlboxsGEE4sz+FBIsNbrJaxg2E1ljwcD+/SMPbsLN2BdJFq3kyCDta30VCU6nRlEeacl8L12j1z1li+OBUg8aXLwKGOPNkIGgXsyqq2RnuWUOj3FnaQFviIxoPa8RGagN4UQp/CFcIexj+ZNAg6G60/XnxLh0/qSikJY9EPcQTiHgY9cRre/strjmQdlfRQ9Ylmgql2Ei1AO8erq2z/ImtOuNJqH3ItGds+xPXHEIE1ZeR9EmDU0rddRglH2wi9dv2hMTT+q428sxLtnRGZ9MPAzedtpqtblseSQk2e1M5PTNIzZEWK6NkG3dCVZyoyCDFP2g7tlsIJyqGTeXv0WzTaIom423qgVKLwYT08djXhi3uixvuY3uDPn7lDXtg+7G9YT4OrPs/QaEpiVJT+Tmak2k0jn7TQbLllMn6Q1A6Tak0Uv4MOgjvlwPUqMsrXi6RIZa0tWQdSzSp8LkKXAcp+Sq/cOKxRptSE3aG+O6wPe4dLvGN05UBIPj1T8fRkOmQkn2M5PBm9uVpJfPvoToXb+u9+FKdyXirBEp9Sh1wEGbdWFiyzaXYZi+lpNxInO4n5VgHXDqSFvlM9qmasWqRsa9H9IALiQtmkDjic0PyWH3CQbKixRdEXy7TX6kqJF9dEhcJUzWYFFhN7IIuxI6Kb2GR/mrTKT6hF58sRnVRAzrIZrBvhVnYwK1/k39nzY6RKaYdVP59uaZR8VLsTk8shp6lnBr+6oRpb5PQuPitt8hOEUT0cRaVy5id6BvDfRWhK+UiPZVGr9GPjZPTM6slz1h9Swt0XUNVivUKmR4i6UfM61/BoeuSq9TfT6NOi/GqJ6TgAQ4UbAhiJAAW334gokSOcleAitrNLdVxmHt82IF5qWYDU2CqdXar2klzMSfr4fZX7mUnCT4J8oAQ03uTX7AMyudTFBWgtxyYXRqd1+N9WJ5JqrxemqtDzf0lNUmepzw26O8hyDcv833qt/ictYSUHGFWZEPz2+NFEBce/QyGB0G9tb4Picy9EArv/jMJh9nlcxXdhDIuzK3qgwpBBAVOeSFwnHiyTm4HgnQ1XMbR0HAgTiK0DnESLoV0Xx1CmvDiq2bUNn3p2LLygqwO8cqYZyCLs7wL1gewyhvTOCii+9ueCQPcDCdZOdToJEg9NuEDEPVzHhRIbmiV+IoQ00VMpNdOEwDuYbP1jxFYRd0Jj7KWERWJBUZu6MjeyHIMEA2NLF0D97E0NBRItAitR5yFewFNPoIwWmCIyAkc1RHCjU7T/beIYyLjx49UBJIRmLGv/M5BvYdmWE53/KSTW8b2mzex5+Bkphws5suo0dIjdi47e31iPh0r9ASXrONnoh3P+3CqO1BPeKUKiGu/858JnwjqHvdQE2gsduQW4E37NV52YUqoqWqxSBjblplJq22qIAJ3HoZoFH7ebQ6ZH9GPMk72hBo8jgYzo6L4M8pwXsBxXEaLuEWiyDGiQ5ZLTFr3iE46BcNQzG7IJRYJtV4dR6OG2AFv2/3prcFoqDU97Ugp8/rnkOMZwwQ2WTDRB3yF95izFxjbdG91H7Am1KM929+3BeIBNEogucuYtaMj2zQqQdqfzNAorXVvJl8+bRAeSeb9KTSNPs6mMhnzdu74kP2YUXx0WyBQevZdrvvnhlXWw9v1k8N7r7Q7q3W5gnaTXXS5nO7jefa5NdRPEVTKlXoZr2AfD7+/bbj3+CdizLEuT62AKj/lpQ6JC7L21sX7++h5fuvQiUtV3OX0+pGQhKYQxfzPlukVMbEXQEsQdXqpSG7Y2gJJysnB9+yBsOSL+cfLg6iJV1btDTVHr4w8vmXGY8H/SJLLZRhbK4WOUGcSmFpuPN3JmY2Q17iHipJ7J26+Hnx54bZxMLd+njWVBv+MYB/eJqwEHf5rKapJP+pFR/ixCtRRUnq2qUWvOjSTNoqjf+zrP3j13iHVR+leISX0oLm28ySX5N//xgNw4ANAADnwPQHuC/hy8lxkL6MdTSIZUppP0bPhKdD3Ln1yqKZ9lAd6xlwQQnZhzB3EMEQ9lA1yomW8+n5B6/2QTJVvbvOaMVPf12aiXFFsnxvlntAEi2FTCPQevCMD6UkrJNROhdiZJcwVaOsnCybQFMRjZXl3z7NLrGfC0ho7SI33BzJcSVEz3kZhV3fYs0bxdNfHu51YN7nV1XK15Z2oZRNDr5WzTd1L7AjrYxxZM97N7n81WUff1XBAf4S7yOU5RkAGv+DeD3V0raxFqK+ar/YLDu/wrSbg7oZfSl0z6Rh3jaWUGelHNtTXJA0uF6GTqSux3xfbRQZpim+lcbZ+wTTnHvMNc14c2l1ct5VBBZtHOsw9IOuXna9CuDLMLaRsP2330g/QluM5u/MYSjMWwgthh8Wn4uT8JShXFVmfdTSpGlpRlayUUxekcq1aXI9CM3f5jMZyR2RpXNltm7TOWDhBy+RBORx17GRTfmprY5eL0rKzM/XnJBwl4FzXYGZ4w6l2JHWbUIAdminhpW67fpRJ5vyxCklF9TKZ5HzAdj1w3XdiClf2Tj7/ZrADKjHlnht9rJHAAtWDyOwNLG8y+f6tV7vJRCRJMm6663XxOiTEqZI37m+SQtoixdZ6CgWUgzIJaH8GUMIM3PGCwxt44dz7bT3g1wO9Uxwr1SRJspALsKDpFK8nqFJQ9+zw84nw2pw9ND8GcwvAZC5n+nFKyCc9YdDinJieKdu/fZS1/wKFSq7mKGHPdRn1EZIZ5vPOyYPtHPHBpeWup57Wj83MlEr2hES3HZnGIQ7ktDWSOAMDoxtcIWyTfOHjDj0QT115pebvHfaQFnJldW5r0+713d9r2w8RBwNoXeYwGoqz5bs/uRqJz414QuBy7efZeTLVHiskCpiPdOHypmjNBrNuGgBPekoZ4JdiGZrZ3ASzHNPkSYIFg9FEfmzdcQSE5i4/D+NeZ8LSuQISWy4CFOhHGwVqyprWw5dwCujE1mbeK7aIgW0LSPyeuFcCT46N3v1HiDh1Z0z7USsOqUUaYvwDJhi4MeJswKPSjk/o1cfrQKP1SIzi/lBtZITBnZs/d+zrnWpwuhpWMdAaMyHjvDoNTger8QJ45gHIbFUxnUEzl72aux8bCDjn9s2fFfoKZe5d3edFs8vLq2nQXPvZlhGn5hcpU5gMWZHLHAY8SIaHzfO9BXSqEwbH00KfK+7orDC/8bb9CXo3TmuG4QQw9YqukN/fHXvez/ALdpabhVwr39DMo7ctZUPW7Z++bWaZ5B23W9PPJ8NrS27yGZyW5c5ko5M4UlsZNFWWcyOKN64s0il7OC/TjnNXb+/L2NlKwLehaVYpvWi+vAQp4aD8CO3hfUX3kdUOiGreGPoWrjCfTtZLDwTNiMe/9e7VNelsdXY0rmObBfrFkYxyzGdVHK17XTn9I0UjGI6jxKgZNq8yN6rh3KCTX99/2G2dQ6gxEw4SYwDzVcE8x7N4j5ZNT87Vay0GnXbafAYjnV+O84r0ym3dOzIE1k0aoiuhGW2UAWzK3a32icjheqRkqxcMasy4Iwsyeqfk6VVmrW7acPqMmkxnJ2e0DJ2tj9u5qmJ/+QcsJLJN50l3DNHtENh5wzb809nuPX0zAv0Do63+3Pz+uKWGQSna23RhTldv/oxjxnwaM9ijaACY1TIuEXnGeQMmOiDHf2uXQ+S3UurmE94AHbTZb4kjSGcEwVLmDdjp0O3WXg1KWwhKafx+5Gjqan4Vy09DoG4W7ci2UCWBng3UmEFDCaRHmk16rPFOyzMrzVrdjOHUaS2Zzl6YqccS3E/RBADrobZkpySLoxPoodjBkl4kyI1ScOEiR6PZhYyKY1A3JdPZ7HV0DE3+jSHEnILE6w7hYUSPFv/KmffRvMTgLQL6SdlmbSXgzD14gD9pgKL9FN9SShavcIYt+FP+TdvWa+P8R227C/6U/8pcSBtfLDkC6x7PWWR7q2CVkL1HZxtI8Nt6RWjkCHtcQj1d6h1q4yx1z0fqqZN+rXQWe77c9jIEtRKcNjy/6fh74oUSIZQHjwi6VsYTZY2gI0otzqCH6w3cSc/hFG/FpBejVzPiNLHnUpLOWC+O9bWcAh00AJTdQNdRn9eF9WCi7KzvSZ5qtUozt3UwtnUh2NiVFNEgGHqTcGD0EEsIzGH3S5JiWgP1dTxIl0rEcmqdEXDhNxQoEwfHDRhhDVnz5+C+fK13LmpzSOBk9gcr8bxtSae9mahf5K1t95Do/wt0tfMQnzLg6xdH7n9qwFQN9cWo9MtKqUacTkPvV6r7zLJwvykwFSxJt3WvolCfTinfaTesCYr70OlcJbfecDrKvn/1PK9sF9Ff5uSkImXh1FiPJdl4qkMspaEO/9x+KIqOsEByZPE7UGMLFmvoR6foJ5Ybuc6D+3Kc88jYZXl8PjsnCTmXuNX+vzT0E7/PN9GLd2nWQ2i51aYpEzd3xZr8AtpxTVTUhAKTgHsd9eBoxh33hRGXWp+nLj32MKX9M3S9vmrURt673diIuSAAF7XRizWgMSf3Hl3HP4JmwaQ9P54wfFMriinLY7HzuFU/nHT42ogXJWCqeaTNxxdERVuhJkPAGK5iwu4Q+KNEZ8oJRYJHAegCKn3h/lSnBQza9aJsn+WW16HpemuQUnLPTYAVtTNPuwf2QSB7sk/7NJks1zX0KOQELVeKLCGnRroH6QS2XwNmk9oKXoV8Wa/lS3rV1+kjoaCVeMi+Y2a+zPCHbv7Uk2pcLNYr5Ll6ZjwDyWoB9lpXE0jWoWYQEQKKlD9ry8yiW3YlmTHvxlh8xMbAxOMhckHtwz90tFaVXYNt40MIoVLNhrjmJkv2I2hClXB8lKRsIg+TaULPM038+F9Xc6jRX8xvPz/S5lfyZOZKCTFVLTIDk+99elGPclTFLtXmTNzvY/Yv70UQU2qVwahkdAejktFC5BGeV5eGyl2KqrKtBLhzEKVl4DQhNmdXu5a7F+/gFnNFPTcZm+p9/YehV1eV1DK2ljfSufavMIkbWHPKt8LbYIvgbuARjb0bvJeQkHojJL9AkcdAj0+8+F92rmn5TBzcZ9WJ+dkr4se0HXJ1zzQ9I34nDXRM9SG8y4bvnmaVUG27Ef5WrFfbVNQYl3Ns/XzFOJL3/cQ6Ue9u+x/Bo2V4z/BeePSYKrRFslEL9NSPoHVwpDbE3qEH4kEEhfHQdckNnTlmXDVGJkoZOk2hByjdTt0BAMBTt8XDvUIP6IyiT769UmM6V5PfT2+lqNAY96d+FpgLc9hVE8KUO5fbss8A6yZRR726lvaQXfTaWvoRKFoqV+lra2g6JXbnj/Z+1lQhuJG0Sq+UO1PeJ1zn8IFuCOrl1orMhIrJxtClwUleS58h0QE+/e3xlDDu6lqaDxh5WYIME9dCDHXr3Ueiuhlse0kbDcp8/IMxu7f/24jHvXWCQjm5FEDB3mCojM3Si2LF5Df2aXWBcRY75gR3uxwxzxA3wWGBe75wsflAYhEvRIJkEUGU53NUm1/3DEjqzGMjCLuFb7nSZOoK91DT9IxY5kdm/HcX2X0e6xtoSiLLuQg+17YbexA/H5XsLDqrVR3L+MjsDIeYila8IhvaKvsSuL2YcnHoXHCH+grBdQ/Zsc0tgjdlZbz1AvlOLwcOJR10mMz1S9/By+ZFp2FUxH+GAMdDqLQ1Gn4o0dlyfMEYlR4qtDh14NyCbYuWPmx5jHhnGezHdT9VzWvVku7g5AtvB3EAs5XrBH3LbxqGdrYI+pRV8diFgXNP7I7HUAhkFiGy2GDaJAE7c03jOmBwX+sabW8PlurQhJ8lOYNSnSXHFwp4DLx2frZ5qNwSu5YtfdbSlyKLLYAM1O9z1leNRj9o8TiCeYalF2G+Q0vFhP3v1UP7a0X+1fJY7CxuNTrYVWwTsu8lxZInDojMnL93UmgNg3FdKc9ygPUKqQyTggifcQUk7OKAYdPUiVV6fdP560f0YLv61RGG0CEEOGRMTrOuAEdjyVglmY8oo1wPpAA4B7JmGmuXmcVH7LqhcxZZBezU64Qph58Q48++xQw0LmDR8cFTeNsD3Tyq+EewRLNKCgpJXqGL83E7QL4qveIYv0XNYoM3PK/W2C5kIINxXXyAXKb60PeRgHlMKAWvBeqTapzFNBqy+BuhKxYvzo97NlC90IB8hNzhwcsJ5h6gxynQDvSRAUp9DQMA5AuJUYQTdEDu9Ym/PjY/AOFU1KAw9KKF1YsXkNiLMBzEqB7mf+zV8tLgm24dTfBvy0ntG0s6AR49HYXiShY0529oMLACAN3ctTl8N05OETy2LSeWiyZAhMqisr6I1Ev829Aqhf+Y44CFNSU/b3ZXRVs19nTt0//cFwfUHdofWHdVy+KSeOEfQMkKKKAygO4Fp8F2wTfAtg2EutVqZUvn1I/yEGr6wrQdjAgZ3RZob+VVsmVjgLDskE3DvQO27Bghd4GG5JOXenlTQSdFOWVFLHYOndcPJx1SDYTsHMnKpWtAlERAATNbpCj08J7t8E5iA5tfrByBuZA2dbwI6rbTidv7U/F33KtdE/k1g15FGpH6i64aWZf/uQaq+fTLLpcCE5e1Z3nmJM7sD2vEj6fiybnHazauN6Nu7X8dfAFhLALdR4AeZba3UuZTVcW4spHnOJP4++oYcRGFLLqrHUsDK6/hFtvqGZklpBXI+loWO0kyYd879dA3daKYtTEWm8It+uGkgwnADmEVpZXFaEcho6xQMjkDyTpHjs+OeMisGY3YM2Xeeqwb9lrAhtAEG0KyYkfvs/NG/IbjhlaDFRqPjSeEoyvJO+zzNFyRK5lw4P0L4/5aUX63IR6/jlv0g0kHnP5sOu6W8wBLLxM/ua2wiJY+0Rp7bXeiWv5GdmJzx2OjF9RJRN+wj9ari96jWaVQmYu2T58rZdBu+H9iANdpKnknhSlOPQ/e2ukL0UYFaL9anJBnKKnLW5trHqaSGj6rnZ4ua1Wm4Rp4uWdMKcYTLScuihUjanLp7ExAofzqm9nXKSzWchIV48yH/VnkNBvhTkqmQdP2mJvhIIe+zzPCtDkXVqs8w7sAIpnNXabPBOrVMsWMLdqCmnaMfTjEyGh5Q6j9W5mryfMkb33wvUJwh0tsqXY/xsVLMecxbK7qJe82+m4huQkEh5NemS7CqJWmQxxPFbsmWBWZMVQjD99LipUzOeDxZaDO9dG9Ko9sJkQueI8gC2FXMG/fyIqn2r4dHYL39Yp46zlcKhfp6RSKIDtRiYODdA00ElySSvGXzuLs9eZ9QxKBtsiObmrzeouiBC5amhlV2FXKt4z+CwG08NF1OnrQwmpIqwob/VGkU6M7OJyPInPCM4uDLLuXLGYAJ8QC7wyVreWhM0ocz7rxvxqeTWc515OZfTZ/8m59OQG5/Z2ElY6Bk4dffYhKRoVDEfn8kgTKCoR4CJauTMjzrRjUM6IhXjakQ8CRi0iNFLq8jJKBCFpIDDhuMcc7Vpg3Mh46+MWl+AL5Ejc+DVlaPS2cDTVklXYS8qZzwA+NoqDoIO92HMN6xGIPolcarIZj6PXlDDs25xM7uPWP+CRQigTFvIA9BQI9807tFBpZdguCyPMcRXUqmuJ3ah9n4wLFWVqOlF43elcMqc37sPWItciiRm+uEnBRkgEhR4jxQ0GxN+MaQZoRf09KCMFXqnXetDftCe9cZEF3w0+e7vSV79K75hzi0W6xtsBp2Y0qI6+uzzqu4Zw/fcCdhd1Rg4a0iBwQctJHWokkXB+rVLsh3HXSxxMo1u5xrRTQxzhk0KIYimhjHQvO+zfzdsYexN+dOo8QFtnuMT4V0EvxBOg2jxV9d+n/OZT3TkeUNNi6TR5GkWBtrKqDeSAGVcEA4zmgsgEzTOzZQOVdiv0KPevjtPNXkqsKPAhZP/OU21YLf1EK1BMR+Hv5cFPqaLiJaz+M2N8JGZ1PDKkgsGDaumehhkZMRPdtSOwIkF3HFHbq/eMfTpZiLixtmRxJ4k3+/SlIV5tLWkoJvWJeFYlY++ladrAJSMbC50czuyUtwcb9q13GDdv3phbLfoMwOG7NGOfV9q0ashBWd7TFA9AVDbwIibpG0CRawcZS7zMd2Kx1C4PU0Osz+P0kHI0xFmLhoEviMvQjroWyD3Z52g1URbkmelkoIVPmCci8ZBz+SIKlqpLvt2tiNL+2IF0C5ST1F2bmsufunpQiJCIESA55MnSMFOQYodK6+SubxmlixW5Vw33CgCUEESEfmadSCbmkXLIkRMRNvs4YYCMhh/wGc+PrrHdn8vfjoeSOinYXDd2106O5BOJvsSzd/Xk27tzySf4dNElGPgJF9vuMZz1C8LBDLZDyhJljdo02K6GSY1RxiGmEl19lRQ/CvpF9JRxv1Fhcorxvv+bLgBflo0oxwsLi8rgSxVmoV/gKhzcuejyB/OFZOKK0LByUoev6kd2Z5wlDt7F1MaTKnXqfvSuzLZQUF9XhXA3WWXJgFhPuOMcOOkhzAvSPozR+3gxjLRUu2Tl2dq18MMdYbrmcc7OTP/dSut5hJXLXLwPgFK743uUVLtyaI71Ic6A50ETqSDN1UzeLtGi9vDc9cOUBtGcF60NTIsk3OXBBej4evyW9Qr3mOOoXUARSwB6iK10UgS7Mltf9FgmOFmyQWJUAUNpuLZgDn265sCY1UW1zZxEV3eIwNHpd+AHE0x0eG+bmfpaTyPglBcfyxtcnPW7pPnE0jkKCR4IxjUjq0mjw9VDvfT7OY8JhwVZ/JogDzyiMMG7p049g16gJXyZ98M4fd1fnPp2Yqd7z7p5Mv898742DvUsfpswdGl2F/PX2HtRxRH9VEvP8S629f2/ymQenTq2frv+Mf1j3jntU/zOyttPUAERLFljilLNq/MjTeE01N0KscdY61es8SyiqpMrq62tT5RXG1/MLruDVvA6u7y732jxiHsRj53Hv0d0t7+Fdv8n74A7c0Vu9n7qt+lzP5azdkvtMf+tqP/Wm6/1u172AwnfMQEDGp2hjAypfMsJdXvMtztNputObmylNfTZHHG2caWcz9QedOm/P6JgnOR+f5hmqUKw0+Yr1u1u75rb/c1OIfIovmMfMs50880ZtZ+XdbGY7++X+2WYGfAseEQa+kS55yrwkxzpfYs1DUactlfWVoHo/rTdL1oIywyIsyT7TyVuJ/fvQhjUrczD/MML7yOB1noYOPBEiSppf8iEH7ixNcb9rDR4zafZ6+36jSOSCI8hb8EX3oR4VgyhBSjGfCJClWEvhCqnJYziMTz97X8ZwC13M4pe/Lpe03lzr5XZbKRVVTbWsDtXbZre7kz3b2Ra3viv7493v9TR1WG/q86mc9sGOcT442VM9nXP/hGc69na2ZWd2a7tbvo07vtl13cbt3AfXvOjmd75OFSb4TYmOlVBDtyXJka9UlXrtBr2QTAVZGtKLGfPWHXvkzLhDbnjTlEUP0mPcS1Sip3qmt/TW3i0yvaQ0Z97C0TW6m5xfVd8xppdhA1pwA4sbw5Nz66/2LZy/fuvnRsdXZ1NTAYFX4AEbEMKQg3Fb7TbuMeB+oer/uUate9UbtO5UP20+m6jJmvZqA9YZPXH6Zrsat/T6w+cs32b+GonBD5jA7rHT956dPP/kS2++f+Lio8/FjNKcdewat3QH16miyBIbfrS4rJK6LRRAFuqsQnkv1zziwC0v+cA31QJCoxOy6jdrHR5dvFLt1sNjUoIlVfVtRRmfXDQZSCN7eQwQLGykGPGTZJR1QhGSSi0b4WPGT5Y6Y3zB1z3vVV968uoX/lzlAgorsbTqa5wI8je+kRfIdHzQ7QG0NQ7QbyUFjMkUGiZOVE4jj5QK4Fmo3YzPccDdOIC3QZjTY49Nb5smEwa97XftScc8Rle94krDWKBJqXqaHJ3McGnxl3D4qxdOK00Gqj0WXRQxezBwPABXO70W26hjKozX6i1eRaDHtLH5UEVeva3EFh+7kz5GkH+bHmrRdCydmpzU6yw2vW7afgrLqbHFf9fq9H3zGLa7W6Nm2df4jjjqWVkoZsv5Q/lTQZpCj3p6PV5f1OBBy6pM1WYpRxmiT/OAJrSjCX3B7kclL5tE/bE3v7T2gkJ6GRX3ib5ZCaX6LgJchIRrjptomXfWUVaBIptLqejdvIHUgbnMY1fO0ilwp1LIarm6OXjfRaicEt35oXBxZ2hAnz2MKAcXl2clymi9Ypbkqgs/b7Nfp9t+8PD5UjnyzIgtcgWc03naQ+0RuNGhabLF02hODF7ByT04yRM46x2R57k+9Rrf2iC7lMN6PO9BvQrv1ywB7+odFDhQFV06KuD24xWTbiONdQrbpbbDk/JWfAHpx0h/mk0bQVkoYpUFzp0iLecXvbBZ2hZOLKDORcLyoB6xgW1GqNO7Vv/8B/0Lxw3s2CwldMZdAnX5JfNF/WXOsZm+bi9c7w1bg8cDM1ZcpV7Srmg4CisD0YAvZtLcLVJnAjZXmWbG6mlqMsxvDdvGCH6vHV5iijhItCJ6RVXhgTiwCC36gntToHbC+SRRZgNqSwneGNkFNYbBUSvCzOGcPi7NHfplHmFGY0V8cqlfyApvjyjfWh6V2OMp5Q0C4xFc3pa6bZhwC4KLMJl38y9AWb+EPSKTqFaTsr0Dyf/G1W2FEaaAqQljnZ+MKFcPRHVpj+6IHpTCRSMkItMeNxnB/ZEQ4ce4UULcfN+7SS6C4a9ydAuZpRp3fFlZrtMXRSK4zwa3LCDlP852e2FcsNndhKd1X3ziE/3tmxnNBz7bXdiDUX2vEd567frf9ehs4qzBt4jnSNWLDfRSUM7+vHJTbiOKO9G3SIHswagegHsWkOTkEL4KHDOXpFKLrQyjev1fciH65LxHP9jSJ0j0VODqTxQZfwKu9dHsCKfr8YMezzncKwd2Iq9HVG5xD/TRSHQdjZPNqicc2OZfmRAjLtcpAWc4wiIjrsBoNEaW4YahECTN/kgI5ejjrXWus8z1wIPBB+vPjQgnpZEHZefflsVC4lfF/fmUMqmdpx71/vaR9q8N0lESE/fT43dFDAH0TmJOBD/1rS5lw/ox6yl4Pq/02VR3ZTcI/sFrMMKVnpnRKxjD0tb++Cf9q/qjJ5PdyB4QEK9VZMOJ2pWrUxjVnkaNWA0OSXZiDclROTwWZLgOU2MTidP1u4Vya6Ts5NXEA/IOK6+HA9PgxoBHfTbPqFFB7YxN64rtyJzF6kEl62lO6oz1Nf2xCX9QgFXUsDQ5cZ3+qWewqDeF8A0Hjp6yCb2vUaoduV0gVPQyQi1sQOpWi3oKFI5NuiYx1hvqMR08dUl5Fsnf6CR7peDg+H/d1h2e6T8RhDHBkM9/PLjsxlBL/dPn1EqIOlR0bclaBj0c6PE4feHdq9D2YG3oduVrUzYVzqAZLAwknU1M4KxWBxtqKlh1iBHRQs0eWTa+KHULCj7l4i0MbwhX5d+uzRbOTQXBRivtA3egFkKfh0eUeAgO5/unIVDbYJ9mM+/kfwAH5oFH0seVa4R430P/NlY81EDVIIjf++7tPebkMAR3IluZbFJlTFGlscaSj9v8Gj7uhKoipU1VSi0xs7xyTTqL2/v9isIaPAEDvbrPeyfYIXM62D+t22ajl7rtmjCCAprmT0ED+/6bwU/BNzASPPVrSoB3De8P+Skg7xfzw4BxYh0tHVgx/NGprR6cOQZnekd5GrJ8zoxYUTUQM24Q5kbQk2sekcwYsWS4RV4wU46YI2syz0f+bC5kxQ90oJZHxPrwJwNl45ZdvQGGQvO93R6nN7jfj7bbouImMQdwLt4cugx6G5O5qJAJoK6DaPNjbqBKa3leurlSY0ONcv9z4lYas5Fbp43CX8qNmydEmvKVmGckIb7jMXhuoYLTPLA1X7Dr2A93z955AEPN9/9MDB3Y4mMJ9JC/3+N1RjQh1CaFpwb8AfddotyRWWXb8kt61Da+cWTEIYPKkXgDHgwbB4zQr6Rq11KMbFafm82XUO80hDuPjw2n6U1Rlx1nfLq/CkD2L4lxaZi3VZIYZX93fmyPZfKpsXmWiwSIdbMSUkgBVTNX8nKtJhVWmr9TUCnZ+EMv6PbfydXDBk8v2zfixqrG/C2rlIDFpVVLHovgHMNyfbloa7YWP/7cljaHewHb5PUcdsEF9YnX3FkQ0U8focnCj7i6RgxVW0AAwQZRPRBwArVeIFjEhLcE4X5br+lYLZPhR/NowHc6oSyin1pfzjicbEhnHgDWsRvzGOAMpp76YoS7aKyTyFAk2s4oqDJLfHRESBnRY0vRFAF1txB1ddESBdpUM9YkzNjaTU8NETFUZZvI8BqqNpIih4zJDFYu+rFAKH6sqEQm1f9YsNajgMWMwj+Wrf25jHVtv53Ca3c9vUZP8QTVGnQ7bVuPx0KXKV4ljTbjf21lSVazVRPTS27ByKP3GzBT3vGA2P018nPZI1O/hpxoFWKmtqRNEq9BoxtAiJcsRZ/w40RNs4UI0noe0ckSkVQTqDlhkxIBDSfpeELGxOhMC0nb4GsZadj9j3kr3D5rMvvaPB7qT3oqAjQe8rVUCDFLTkRYQnuE4q2fF+b9aubFeb45uhslBWQ6hsVPgk3x7tYQXIQ1zks2KTxf5r0OkZ3eObkdnIgFYa+Njmwfvn4BHujDvTTcEzzhP+EaLhs3LvoyQxqjM9e84+uRYRAmt6+PLfHg7OHUDguP/xsRXq2QHVDN9k/IjVf9PMfrkVg0fDQ7HtgdDg8P98rsPkU1hWOCLQGHKnYFyiBOEg0JHd7G7BSQ82DKxsIPQKRO5ee/KeKKnzJbkcmBnwKdSCfyE/0p0INFjPqwSLFxHCuZeRKL7YgS51HlYg7EYIg5EPthBBgVDsSUXCaYPC7ZCKOAL0759+GWmteA1K3idB3kjUy6EhjvYdGSdOK9a47/uHAUKa2xR2aesEyLzncEYKTDrTV32y8/7pXibPP5aYl59eXU0ZWrPzjYqSYl8GwdSW0O/MD5eLK6m7PkV4/dRq8eNV7qJXE8itmdfeZB9WT5pGnelxEw1ntEMoYwuE8CCJHb1hadcXCxaHUtCh1ERmUrM0wX5LNRHSgfASlkbmPxY2xnHewh4f1FkTu6zfb+gqpQahuLu8WMyCGvavezF1vPsbLWbWMh60CTngWnLNCXz1jbD3LMqxpyhbio5C0BGAAaPIBAILEHC4idBF4APjKlytDxdC28pugfChmrogYYqOfaY7rlKh3dGGCi6CFvrzfgC5sDKGizTlEjuaCKTMbIWGAskEt2kTF6jafVS6LywSU4ZURWuzGG0xh2oxdgEfgn6uawGR6Zuuf5fYzAtTO8Xnd/63mUCcGKn3fb1c4RLULNmBrUXalcRAvGrXVHMbbMJwaMIpMVHO/H9DRfdP+REncyg+P9k4MaG2hpsOJEZgoViQP7aH8Rt77TPhilLyKFEeDxNxrM81+pvKvRi/gV3w3wE2jp73XhIrP9gquntu5kuiI6r2fq6llYMislUYQuITI0dP3UarisI1Q3tntf9OFCcOGbsdMlsGvzDej+08zQ2Z9QJ/vK2LDA9yi+tq+9vaxkwu5cvJ3h0L8TiwoLIRiB5frzgTHbBwcVM4DVL25vA21JnQ5O72KSSfTsvLyMzBJVhmKs7qIFQc1qZZZ5LDMQPBaGK3xOi6fTOxrEh/x+tdaujaT8agYX11TsO2Ern0vk5f8t+v0bW5PRFVjQeXz9TtTYDJd9AsHapWaDTGTUeYFNQEAYN/8qDpMT0vdBgGmhWZOXdUE3bwZDYEncLO9m8WE+47mW68BDFL7waQUYWjCH+R892dtF1KtLevUx3lN6vXrBnw7irh0q8M//B+n+E53KHyC7kbmdJpzlF1w5mvXqenfUw2Mn7upHHr8EE8T3TkxoV5ujwgBR3x7cISSbMMbMKS5QrXyVt+zRomPOz2m/HiIlDttjqaVHBYXlFVZdIwnkojtAbfSKciKind2vN3G1icfZX4e8/skaVoHAGuudMi5Kcv2Pzo/squs5awmpCo3ayb+RXnX844fJn8cD1fdyFOPz+wthiVn+MeqcbXgL+I5UFZPGP6PTL2b+Z1SxwLBnhRTHrbtZpEy5jcRzAsi3g2yIEjuRmWZSZ9FyEY8kpd6+Nt5ef8cezrSH6m1Tu4qj98ksWR9Wi8NoA/Her+Hbo/PmVl6wrZGFuDe79F5v9rR+/1lYTy5HLG1Kn+6Lyb+m/KEjyKI/gJFWMIhhCxMNSpJGTJiGvmiv0uOcO1EKayu8ClKzUypHtXz6mY0lWyRxfzPUq0SuPcC3QVmfXwE19lNPOlzDhozqb33yri7mYlCPgiv6TELQJmGMXohesl2L5dXhNedxeOuBy3rWixNR2lUc5yP+uoYbLl8tJbj1Zcw1YbgHh0dCGlANdSpe03wU90+epfTpPY6UfJOnywojPBF3CE855T337u7IgzQHQehdUi7ZGmqs57kKZSws9q+SlALiH+Y7vr//Bbd13/9cvBde/JHlYf2bDDzZldsE4ctLdprjxOefd9/cN+hN0n/F3CEk/deK7C2d5t9HIoB2+sOPIU1MYDxDHpF+7A9gAgiuwiF1WxB/9FGpYNmzqdLJncCG2nboxLHLzrpR0GtI8HMSaktoyV2vhnnmjiAjLweceGYrRJtEHqGmvyc8ZaoYeXTxEbueuhZNqCrRYKqbT1xmJtJB1JRAZjwLyTRkmOtnZFulKLFLfIhENSgBKGfHDdVzSiHJD8ku8Eg0pbzKgV33e/P1K7SWITW6zNuKZAVKTyvlyYw7VNH0ZG7WWYmoNmuHh2gdcuGX85aOZdPKRWDccvPgbVs03d3UmGtfWRHK6UeNmTvqt0bWL3zG+3fti/lr7i938o4ilWOpn2fV7vYacCJL1Dpv0CeG7RakDDNyvkona3XGnI0MYR8amBpk6lA1hSuwKEUZs4DlRFceFlAPTw8VsEKBoGnTTB5byV+CHDRTaWrecCwjc1558Txb5C8fGfz48gFYoThsAX6+T7we8f/jWVIXWDBWFZ7Zv+DCQbYETZVmHNSr6jJBZ13BDnvtmtpCPdwqLyjYIZvnuBeaXWatrcc67cJlJntamTSzPiWzHrwLXrwAgq2o7v9x/oBFIMWGYgVN3L+PSvqgonXll6w7S4Eg5pLSuTDLF3NYxOME0ThS4Yg3rB/J+0KzSIS8MEYRS+D3V/Pli15TZXMYQI9aHB9e6Xr+7bDQbpeEUaM72GaCr4BF/qZeEEn65vux6ts/MeMUTsRyQdA0sI7J4m4X2rh2OBmnFIgCBCiLlUavKLUHC4g9GIh2Ccl4rf4WVdmlgqo2auBa+PaG/51dDw9tvh4PBNb/fvNB6tD5qd919VpYIy4vr+AoxQgv/Kg+praN1lLiT8dz1tzlp89dhrAWMetYH3mdBLq9nLkp8eff6w7PomcdCTh8JSb9mFwG3uhNWU46XJS1PFlkKGUl00heEBrRu08l/SUSNLFIvygpK13jaLvN4TP0jkI43ZhYuIJXREDgmjP/+IMeGl7y+Cj0j7+YVIc3NOviRrNTRfbTwy/A0KSLqo2L2qyu0X6xOZe3gKAx3noDHTpuuxBGUN186wutvE2ypl6dsFicdot53DGNlbVq+F3wYVwUyVGI+rtO9ghe8wqouN9dAoiG6m3rA4BSx+r9NCrEcO7HU+n7j0bJQsg+kMj+l7qUkm8/yrr62p6kOMxrHA4W3XkkRz5UqEu8m1iK3dYU5nYcJY9szxHRIex508Y/nuIGRHoXTOBCfkvMdkFWqw74s3Rffj3C6k0Y15etLxSP39R7qaKkSL/yY1d6wbZbct+AoVMf7toytdZGUc0phUrVnETZE2s4MVgsiX0tplqdyvF875vkuT+4R4e3BGY94On3ewNBfQApM0lh+uWZAOYpyMGHqoWAFmNe4cOVkrFCa3l1vn7SypDkRNW5WDo5bUDYSS0DExzGEpR42Lm0vDTdtzHH4uqxwEh3EFToeafPvquvO8M03lxeB/NiOiTou0IgCYIEBJDCAXXHnsPLLRwwraJ98tQ/w6OkzZsbLWVTBef1ChHPtfNzYYPeUKT4kceBZ/DW1Gb6WKRJNUPSwTHJ7bhCkiDBbC+qPkSiJ/c1vTaX8byesHcCqNgvipeEKyR2vBcB56s0slr0xefOlQQmmKcQFXxHLVXqP2YwjGVf56gD0AWsGmoRYTPiJaLltemsyrE9EWxw9bbS6y8zZzEWqQZvtu6trrMJv/+y5Dw52merQbsZLv0ucoGk9J26Pw2eXJwwdOC8CgawWiheYuOZcsd00nkfzKPlUm7n60SRBLv68UjzGCPah9c7xGb8NaW8FzrgeIDs1E5V5jxeJBNIlgvu8lyoVEL9e9G/l1zjc8JENhF+Shlq22TykHNl34k3d8DSAWYkyMTfG57AZ/u/tpPoYLKfDMb9MOcZ4BN2WpmJUq42zR15ifVbEnZumwof3xs9NiDVt10EbotlW65p8v5xKgNV9XY++1SWVd2L0V6xqtA+CK9Jt3rXjaYBu+Yn2Nezvy0ZGraZOMPg98Sh8mHHuZuwALMN5rgyXGDfz7P8DH2y+W2qLuEO/UgL8daNMEreT220rm88QpX0BjGrqyVWX/kf7nsFWSMSf1u9PysYV4vcmq/2txtXjYzOTMK8YVYKQOf4nC2zSoLyKgQ5iiuKDR5JsaFaGoQyyKhwgihGrwLpA9ZtfYL7SYA9eiIXDcloVfNnq3gGkkvFRGcN2jNgcdpAcm5Z2uMzRAx0+jdHOs/i+Evg9A+RxEm41hdxhHC37O/HARkHcDN300U8UNiododHIxWPx0Zy0eGIdy/6SKx2L1/Inj48TRVy5R940gpyBe1iwTyvlpSyvkZNzeBi6DYq/Fc3o1IiavEJ8byhxlqeKy1jYXb2G5+26EVNBB9kkHJYbww74cDS9iLdnI4g29Ir9jg43s+q6uxQPUYzxjNjzrbP7LaetfoTt/8p/F9k+I9ivM+McnQFvfiOxFpcU88p4lQRgpcpxF/Gsg3j+KY8qJcOyzOkxSDdi9DOePKV0imviIC7zwRCWWx+vDheXbxOWId3mzHSjIRGk3KfeF+vEHKIFzmpzqqxz7nXJt5PLMXA2+p6wDJwXU9vFS0Jil3gElofcJXGWFsIp/mQDqVgq6u1oZYJESZbZ/38eNzzMcUpseKg2WrhHJjl7bPCtaGgPYJhAwjKe3yxUUrXwOaFkCGdB382UXu0hFdkN8C6hHJvhxGFqn77ROqZfz4TMJtx+ubBb2JL3TVOHWdfvKfTBuFGq8bgFfXBkIYiyvaXE9yDEsRVs4e6TANhHioIxPWte1BsK9WJ+/FkHkmdlNq2MJBK9i5b0cYG2XZzXZrDIj2wyQiH0XILeXw5RgVeFaWCyjSdgaRj49Ht2L2NEiWqqEBoIfEnoazbGIN0xNI0ARt00pK6Kh6xRNXUhLiV+molOv+INaVX4RMPIRLzEKAgWZo6Rn91kMookDQhfn0IhsSTueO1JSBU3pnzIyP3P7F27zcWU7DOb+LsneU74YT8ZKGaf6JL8rl6rlCr2HypK48C62/c6xjL2MZhe15HczMWZl7cb7YaAAjP4zx+4zTzji9pxXMYiFFnqwXrePnZ0Za1M9DZYStbOqeR6Lu17+h+vSes7teg2JM67PfiKU6AWvXiPUJ4+FL8aD7muSVeWFW2IRimoyRJjIYbOepgK7nS5+V336Yg0f5ieRZPx6Y7b0lrBbln3hkxYejjufxH/9mHLEBLRreWNgGqvJe6HDdtQ53aGJm1nC0milv+oofMbSFUNMFoMrYc1YpYj4b48uViQy2BWJLngE/DoHRnvsU/WbHNaZBB9acwnoLoNAlyB2j15bFILCxQLfG8InoA6jy04tQIcenBh+GiJdX3PNbxVHVEBR//jOm8cV5Vrw5bLC6vxTLmmcZrmQkpUJ9+2J7PoOEmMiLiUEBiL6tGiDmsd8Ra58ohz0X5/xkEYxmJHUSjSLGK5Cx9T+SCjNnIKQTfm396gHw7SECUWDmkeV9ZqSdOVoHH8upOlZarSMZCRLEjxP7+BvXzcHN7e9bD3buHp/r4hH/xlW+pUS4q5wejEllh4h3mJyEJMRl4X10yS9ZgvtOWtRbDBraCgXNwA9EWS6Oaz0XTbP32fsZEBoRgYQNt+zi8+yoB8iDeqkWD0zN/HnBi8aGcu/aG0WdSE2QabEzJzgJ1H8mHa6Hk3N1V6qzyXWqxdHaqTm2wKlVz7/YiHF4OrAYOltGCVbMzd/TolX5RwfIAjuN1+A3UExpRwZ0bDfy1b/8MsrYFOtrsOrJXgf5GoXLkFd4uD2pQJYelM9n4fz3IuphO4DeFgEsylfl3ybsBiFUusVqHsabE/TD5TRITXDiQW0gsN2ILeevKImJSKwss7ZBQ9yVFgWOKX89ZwSXt+5HyEjmrUOox9vrv7+rzI1ABx9fmkvFRl61G4K+wxoA8d7/Z8hy6GaBfUSPKDo0GHWaeW/Cza7F3W9Fz3wmR3FfDHTNnZ+GXpcPg6ZBjllvyh8KIX80p02iy/8fxgZ0jYMpmx/8bO097GssYvvRzKCmeysCBi0fg3txhXupIxGgPHYAsh4ZBJFukRjPI6liJcg1XHkt6fa9p4yijGp/F9WkGQo9RTZam+GgfFFvnGv39CZQpcIXh+5lQwrjQ4nHYDiaVOU83Dpc6KHEx+2BUXanxOBLNXZb46outNhaGi387Qj3Wc/qxJfGhIlFhx0ppWQPLG6/rNxvb1tZohy9s1W55CKa5YiUHE9zpfFp3QUrnx3ToFx6sRl+H2+xSgF+nllE1t0rE42vlAklvu0VkzHqCS237ETjLLXm7R8XV55IHV/Dwa7uKWB7SKg+Nryb06mHDN2W1F7IoHw8URNHtaMf7lqRc41lfsia4lIfaPpfTbhqVJJ6LN18u2ZwX2tLnsy0RA5wLGlt2r3+uyUFFjI00xn9xBFEWJwzwBgZ7IO++s9FquOoGDohzqz6GMlP+21A5TUEiJhNcHRBADQA3AiYHRgpCRjCIZDaIkhaitzCVQqzsI9bbAHFKiBohXj4a8U8DJAxgSQEkPWCZveSqbPVWc1KgHsmRsxaJcnoJsAYD0iijRf5/uMw8sGU3GAAUnOkr4oQIVSLTB6AoB4qBQFEBFFVAMQwoRkIxForZUMw1h8sjilgJFGuM1kXTxujanJS2J6c9KWt/6qpOS0fTU21q9TCP8hag+AAUn42+5iw/AIpfQPHXnDQHvZUwSYghGYlIiYSSZS5PrnVVUPVvD68nIiU0I2tWy1BFK1TbG/lkoPQbKAtAORMoZwPlXKBcZtRhO6rrdlX37ZmhAOUJryIwRla3aKRJmjCkC0uGgDKFK0v4ssZZDhHKKeK4CCjcgMIfKIKBIhQowoEiEiiigaIlULQGiligiAeKNkDRFiiSTwElKgwMfh16N4CY6ptD/vvQPtlw1AUNG3gddya5DDL/lWg3OyGX5lf3ewR0iF/e65uF0Xd7w/IQRMjRvz9GjAJDzJ8jkKDEiAZii+9CA6et9oQGAXvv+WzQ6tHrSThUmNxDKaSoMT+UhkeD5ZsYZGixw3rSMY0YnJxfauddcdN9dV6dffgvI9wOvqG9wBQcBIiROXf4+cKVqzTMGJPMMO9syX92rb1YZZ1Nttlln0O77ygAwaRe0jcuhuDng2z9lELQPjcBMAY4AquwEgdiP+wlde2VNFLeAQ8CiCBGEjKqvd11rZety+MCdetK8zbehdZdUe4BBqhVwDp8tdO+P3Z7pfRF1X2jPvHC8rqbtf06dPKmtL77em4TEBzDmN7/B890T2ljniVW2WCbPQ457qwate567IVV3vnil4YwYhGPVII6K2VefLpr1pdVVqXqXeSS1NUACcRMxVr6Xkfd9FEuyHCjzwK33zSFbWWa792ZXrrVahttt/cRhi9Ng/i/FhCgBdryc3vMNm+lWJqmUXWX3oY4rkkzC9c3WOAyb5MZoU4nxPEr78Y3z7ZXLWDIeBAWJpCWbPAZZpZoYs7Moq6azkWWM42bsi45v1V/+hV2eRkU9WJmuS+k80P1GTRAU4bMYoSBs8rQiReTRi+/vYIfraBeTv+3l59+2s55V9x0X51XPvimXlMkEiNBhtzndwh1VaNeT/1VF6I+5zOiTn2lMjtZMYupc94rdTnroZ/MzjHSWBNMM9ubSOPGtzO7/aHWZjvZ2S/BSUku/3RTslQv/BvgAuawIlb8xCly83Mh7XGUR1NOM9j8usRMMs82+1wk5wUC/Baz+zMvAyRJkGxITWoczBmvU51o6pn24CwQ5mOoEj/FSS/TcCHSbkFVVdMl03RUZIwcF3DWyeqmvJPvBPFTUj0b++pIU5JUiVSCYw3yh1yZaMfY8a7mhRWZ3Vdqlr5Jh/4CtrckMmiAMWLLY/762u6mMxyKNwP0QIQBKy54EUAYLYiTtHuGcHt+4nuTTykbd3JyozTPlpIvv/pNJe8u0E//Of3HRY467aJrbnvomWfe+OSHvwEqwJseIoUs+YpVcDQhjXrztxg1hYnQRHNttddFLwPEqGyUcSaZYa7FVlpvq90OehtZvOC08ypb7KrbHnjC0b7ZIIcxZjGPVYE5J02Ve+Z8s6adbgahsux9jrnlU1DhReslHAioH4AU9lKy/9mqbHAAJtXBE6Z9E7+PJMwqta9Og5/goyKF8F1UjEF+ULKLyVne2ea2IhpLekhdl8AlC45zySccWXVwtgWNNbnvnYwX0rQYk0b0qod9TVtvkLm9+/qWZhf3vTSH3r1/zZh+K6xOlNBZieCKH+xxelXPxr7e+VVKix8UVpvBXiR58SJyJ1e4w5TRB2ku/9UvTk6crY3n7dCoHu/12LXBt6rXwcKJFfWJrt+fca7NrLHN5rHT6hdvTuCS3C2P4B/zIYgIWklgkylfqU56/G/9LkfV3GS/SU/D3FTttGPJh8MpQz5tVPvggLvm1+KVT5/0cE0T8784XDg5BDybCbPiggfP9Ct40f78hR08fr/aHQyAtw2SfkaZVeD/S2e336GbLWbAsicggiVLyCpr6MGxJAZXP+Q5LaWVtI5iaTMlUiql0T7KpTwqpgpy0Cm6QJepie7QQ2qj1/SB/kT8X15GQdlSvZS37MKKVKoKVatOVapVcg3rpNSq181yqmmsS2MX+rAXzXZn/niSORl13p3luJ3t86sey9G+PK0k6nnftNvKGZfc8Ivv5k020bMImWR60eLt+dX+2t1V19vpbvbh7j99kz++rRd0XydSVddDGVp8tWwrZ00MGDVt0bodRx46ddJ5V/2he28O0WzYayZYL7UA+TDlNNILHjZanATJ0mRIRB0gpIY1A9OapdmbDhVA2IDHJgBvAsIIEsyhI0CSMgOmdDPACEUmWWaHmwRcdqrAaJlqeXi0OHoGT8g5yIg7DTXwGoEmqEXQBiWaAeoGAfJOkwTS2DyQw1WLCq5qNUJNgshazGmJ8kBif4AWg3GMZlIBZUZwPM0cGC1kC8Bm8Ap3iTcpe3xpIXzmLg0+haeMy7K3+DX+t+QderAk/VZtVa0BaGQ0cSKJmKaFtqPxhMT1aGlMDefdEipJ8H+3XtZIqHt+rMgBMwLdxeKF3DcgQKu+NN4M3wSad2EFg9O6eRkNzH1k2gP8gVoTDZCxnIXzKIef5rLz3A720c4xtPgp4zQgsMxpXneDDl0s/Lr5uyOKlmj9gu5lyP6aAzjokMO5MeUmbrntjrvuue+Bhx6Vx4u8d+TD6WN/xeBjn6P831qUar2ch2onF2yqVtenLrrqpjtv3/rO936ooQPfFmXxXcJIeFpiaZaRiCrSciuzCqtFZc1sbdaF9aJrzMCvDTYmVombEi+bYiEJ2Jwtbmu2yXY7kogkNslSkjpnJ3ZlN9kT+VXSavrAr4zsndiTKfsO9mvBhruQrd6ojE98+d/5EODydo198c4bdfiXN7c5tPUm9P7Y9nZw2qparFF10/fHuoU2jkfHT89RQuMPIsC6bNnUxkwuU97bULDn7XjWnzcVZ51XMxlv4K/BWFYKMJSjMUTEE4nZOMNIwZORU1LTVC0EOobNRjBm5Dhy4VozYc5flVqj1aGoJ0cnZxdXhyYEy+SIgiDVvmu0FO2q07u5qw3bbN+8w/Ow0wuwS7AQocKEiyD2MqcVLm4eOC8fvwBdUkpaRlZN3ZqGppa2jq6evnUbNm3ZtmPXnptuue2Ou+6574GH9RGnEdx0y2133HXPfQ889Mjj+gSmzlPPPC8vFsmCXALtpweaCS1EllZiSVmPbLCcz+yG2VHD1L49g/3p4k9AlROgCCWtYc0ldfGSlVc5VGiVgHKgxtOWMU2nYf/XhOkQxwYsA7Mj1XpHqiETSWxW9odqUYQqEDDWQbxTT2c3q9o8v4Xf0JbMbXlGZ3k1ENIyBdFS7nDROr8MVW8iFmpuleYOruZDUcKOyeiD5HFlZ+VNRSRJgIaWhBmg0By3zKa12GssbAJtz6GJq9YaOcMC84TREOYSHwzMBrNjJmuyJMz1hdnaYjkjyreMbKtO7yHn5eYD1YdZk/crsFRlZkLbdvx7JA47IRUHaaTSoEFMF+K0tVDGw2Ce5jVMoRrZpQOggmxkfOE0HGpmRrjupId0ejGYnPmxrKOPqLTWRdsnno2tAJiDzobaiGmAxHfmQ6yr2djEAyGqhHHulw3eI8Fjraxah0YiHqBys/ktE/Pw8xr4ZkghxHEnJBmz8KaJIEF9wuG6ayG8aCZRDmgExGzA8ggQWgw0dROyBj8VDPX+a9BFVc+iOKJemtRAaVRpshBBMatFro1v2py1WH5UYFm6tyb6vGwDibwDXuU5phDM2kHlrOoHxi6avB6LmcY1+iStqkMMyDV792k6EM1llQKj1Onoqp0I15JZf55E46PckcZjWlbMqvBM+hXzeKs3QMdj7CZLLF2VpCPRMU4HJWeRy3e8cbWKtFWv6J4qUxh2vOLRdRN2DgEY+pLkhX1PrKFyhoUfpOifOvJBA3QFWRLDCmfPBFvSjjDScyocN5LyEjGNaKAubXCZ4DBxs2QreaBftGnlsccLliI0gnR1lht3CUw1YA6Bm/jx6uEsdcIOIdL3eh4UD+CUWuiiwFwqw1PRhHMtxI201ZD0h34pK6dINOkhLZW8mtW4phatRjO8DhODJlTwys9PAURRWr1lpHG5AasXsEDZoJtEMTrgbQ2ux7wmya5USAVb3deCslW7aifTuqRmRpg9aW1+wn4Wlyq6xclJnCp3Bj13cWHiYxJfauJc9Q2/4w/8ib/k70Iz1G9hAzQNGqJh4RIRKWiQQRZFKEGpI6PrQW3QctSz3mAwBEMxDMMxAiMxCqOb+rK4TT/3DQL9XyQ1hI6EbmIGwpsQ/0Ny0EAYTqKoYjGihSX4YWbHSv4t7zvRD3ouhinGXcwk5sKF2JHIwKVYGa7F7k4cSBxO4sjEMeLUxHmIC/reWLIBm/RmV+LqRl+jycCs1Y6mAyUitKNsLEWP46ChELoofyYiMmVN2poyMOAaWxRSN9IXOkXCj8bqOuHlXC9SoRlKYgVkKNzFyFpLPiJa9euaSMXKsdRJojKh1wgZgDokOz2jlG4nSW4QKJSiRcq6hPr0r0SRjYb8SgtbV/NguE1O0HygqCHioFT0nG6XXXQyozF43SQOKrzdpFn6nIhAKUDdFmpjmJDeJvJu0DYezNIW8gKeUC+W9je5DTpMHIeekIaLjqnv2o1tSSm2DeufDBLddzj6IfFOnF9tbZElFTcjpxG1BJBaTLUTwKbLegmGVaSgsaXYHnFaqYaxxd7F8lTwR7/OTL89+zR9kDGBxh7rMMclc5D50YKSo4TNhCVMvZE8tlPFztTBvHXbvHKsXT3tuGEmv7Sg/T64jHR9JHleuJH3aE2ipNT0Uow3+rH93wg9ydbFpSGlsuNUxs27eHB8hGfvorqg4IRxbseYzkSDX0YPGHLdul+epPBRO2pAwKY95O+M5gkDHjfnY5zHpU5I6OBNXnTejqukrhpcf5ggDUCmz3BFpCN55xg58oVl7Hjp8GXxL5sEv0yuEDOx+ZKpIUy3ByUX6Jk0jQvtmzsDRcU/hpD2a3na5HXlDZ+iYZzOjAqL5DeIDoBCtDVyTNljC4hXB7CAgzv09zYCXmOZopdCPfg23/lTuRpimK7MH/GXwlvS+iQe/cuAtfTmAMGLXVF+vTc9+ahvKUBMeOSKuNWDNyTXJoIy9TSZF7BYgDSciVGhfhkhnJH2MsG92Kje/LAVSFxBbihjuvmPnoIOm49rCWoCNA5jeNnpjNGSS+1i8wWBwpUCpTQL0HpSs5g5725wy/tgTjHFW4s8XSIFhq01ccfbumVKuxuSPHEdPiBrJ+ANwPGnpw9jdEEi8b3M/cJO74hgLrE/suMEXbqwiVZF4eNPgupuPWYKFsE+zbNZf+Qk8Jh0BkZDxOWe3KUbx0Lh3VTvixABhsrDcsGfVxXpwLt6hv5uanAjwrElugnCJWDUADOFBKwrwgc5q6kYi1jqV0KUDk6fSo/1Ai0R5jadZ5StDLDtDX+p0niJvwzJhyk9BUAZVO2wWObjoN6sbZN0ClHs5qzbDI0TVUlppQGkM4JXl+xuWSDzYQ24AFXAJ+6WTW0eT+eTYOxTG4dNL4JqVEZsaKnvI4YIqcolVFAwM5Vpt7DWsSKA+wdo09OKBjHoicH6Oamcg/OhO2/hJpTkzhu+cf9dFEXTio5jG8E2xCwfSvr3fTl19vle0z3kT1Om+ZO2u2k8ZREAPj9jdpgV69iM/VrRkJP+SNNJGLq1A84G2Y6HHiKF7tLkrAiHN6KprRpIv2XJNew7m+whIYPZlqW1QJpQ/qNiU177D6jobhmZ1CQGMZU4o34sX20v5yRUIudnGjH1/1H16o3dd2XP4vjJ8DUoms6CwJuhqPaeLIev6RbWsKwGJtxoYV5OCgl0kgxRkjPhy10vGW0CJYLKnJFjoywo5SZsWkA4mKypmZPQ85smnE9tx4X1vrn9nm/KV/qTlBWOuCd74QwZ/q9EbfIlynfSBVxUGUNZtJyKrcr7dR6t493vBsCsAbkmMAPqHinGfljJyyuMepVDgP+ARPixKgOiJ0gmOMgTZ26tjI1nmdWrI/0u924q56fE1QNVoobIOPDpDXWNwKs1Aeazx/uKXl6RyDW4wki75hWQNT6sGytEIvaXwR8Il5LDmm9pKf/DGie/AF49mOZI7u+G9PRJQG5ILqn3ZNrYZmSr9XalltbQ5XJDdajf5qUId5gh8xTStAPkccmIW6LAObzAs3EAxSGDxDwWZuADdAB88z2v+PdrNWdITEE1n+7BVXJ0HUxwE17qxuVxD4HNIPQzp56BhKDfm9w6Iw1dTfDHyTONXVCsWEyFW1yMuTaVoIMj+zb6uemcPCOKtyD6owQ2UkUdQWAyyOeqpw5iJ0lU5CF9lu75dHL1ibkqnx4mcHUPnuSJseudxJQ4uCcbZFBFg4sj9NGkjEejTHrmF2VWs8+T1c4ZbQSlXikyUxT6lTaH5cWdIjVY4IOhJEJxE5WxdTdF0ger4ZUkZu5ubvmXpn8L/ZEZrPZrUf7czgQiYS+Rbk1v5y57phrzVTarSq51h+no7Gblks18RGe9EFZdWtvoGjlCo3FWYbvGiH4zpk6OR02uArTKHaKXH/Z89jnCD5iKcMi9x0i8smeec8L7WNwrbx0gOjYpBs/gcSEatXH+wKoyFZ2jqWCq1SxPQnE1eyMpEyURg4juPlWhJUhXrw3QTGOd5vmqLuYozWg3R2imWFE2cSCLVfmpHS8fmAu/2/HTzCHicCNpn82M5/gOD57FH/BoVqabonJN9j3JYOIQe9hXKEewHGQ5QEV4Z1MtY1wb3jEXOUXpgTaeOIM5Mr4SaUR5CSIPfxETihasAxT5HErlKHoRTo3TzuvVQZrRvmR0nllnnPgts37IH6qsOYId+IIyns5CtuPpkbGPIO5mjKOSWI91OcY3v0jmfNGyW058XEqvZMcmGyRZYCvhTE8ivqC8FmSE1687b+MdZZSOkx02gXu0fFOSShn2nl6iEZ/zcXqTCUGnzLdteAbq0lnj1bKaLjM8jD/xhKjUGbo51ZkEgQd28UHEL3ULfkyQTY6hsjcct41Sj+/2gBoBzdkP9T7Fky0NWPrae2v8eeODIV9Ny3AzcrfRKORYVfHmn3eMbhbMlWSg5fkONK8O84Iq8AMsXpx8y+BwsNbUmcTyHx5NTF+PA/geGOMPbSQWMrsEjeSM/fIkn61j3L1ck/cXmiZ7gq/cDU2D8WFqV8PD+o0Xu+iwPnzHS+py34+6c7ZDnnE9DSWJy6t8vFuHpqZlioU5iXPT+3sHUGcTPRzcGzrNF9fTmuQc3JAFVmq80bll16bz+yRrFep/w+3sQ1YFA9HoFg6E2EQSg6sRLGQ3KF2sPfNxvk30KbngIE83x7e1oYWbbQ5mfRQVBkNn2g5L4ZhTYjtxoqg1v6Y3si6AdgQKBvmCAzxvz+X4My0GtNXVOH6TI740U6mIv5ksWORtwoF+GWZWiRWo3Bj8D1Ys00lIXSdVQPL0QeOsaSDTobIwrx87uT5CZYSq/yfvHL6rk3U/drt1PE3bf7cUH8qOu3Qeq8IektOzX6rVf4Zshcn0D6nOD7LhkoUjgfr01QU9iWSbPGiXRVK0eVgDbUbymNgfJqJsZw2Hq041DkPzdq2LrG9QEPQ986KVLF9MegwfcG//Ud0Z0lZutC5RyeKviLGjjGi8y4DzjWPS7+p6YCW8mUqfwU/D/DsCYuCw7o6FM4ryWEwQLDE35w+6AufkhtsJJosmTT0doGQbMllKKi2YoyrYWznLwkfnkqSuS2aU3IFzNF1xoh/VU7jAfYCT6pwtai52xvWSH6K4ucEDeyN35TznZceoXxRT6u+agXo8/jAOp4OkvpXRniTtZ9/26U6HKLj8eFlEnxxOZ211AjH/8S8BlA6gJHknH6pxPLAC+jrmRCIJwImx9vMG6eF88TA5Wlr0Nhsndk6qm3688auByW1BlqIrBMHp7bJa4eYNrJAISlSG4QyeJert7t6RzrTQr5Znl3Qpbd41ZA+gN9N8VgCJWg8RmynzrxvWRaiWabGYida80zdtoHaP5gPIUjx1ZMvBZR2gNUko7LgUxMqiaZiUTwyfahld6WvLykLRm9wZLi8n/MS4mm3+7uDjIgZCrKJLFXw12s5lDnPTYn5OK9JF0i9AbJJsa3LDkvUhNXQDXJFsCJxjDbkIKCBgzDxL2op14lizzEu2vE7VLiAGOEibFvTYY3aKBgXEp5mt8PEV9WqqVn90LWpad9EGeoXRjN0gTJwSORPb62w536zIlHJFNM4MKi1R22HWlUzaRWjhvI6VS5RL+SGwLrFrn0BAZiVt6xRrpoC159muI4wWOCQvMorbcLIZ9gTwGBs/ZgZmfEjttF5ju6l4pB3Mkzlb/sF3q4WcqB68/0+/B1ukUjMFoNi4gEX2pRRtuhMMC4ttnCmAdaG+uT4weTwC2iXPKOtdUU99009Wig8tkjNGrUEPlHf+oiQDIjzHOTmkCbyjmIMiqNCGBVwgb897kl6P9iPzA1Ud1/4MCaafPm+TetxsZkoplwdUStenc2wB8aPyfDdpi7+rTD9Bdc/ZaHWfOOA5XN3ZOKAiJpsBjvcqhHKMdVH77gDbhHG+8ydA8wld2Fa/ohKtULUXINhR1NjLStt0UNGSSXsCtBgUxskOxLsySUkKE4r8KBlZnbRUYHYLwdgUar7G4OOdOLc2QfstLsdRZta53/hW64cpgjHodZFNi4vbn0GSdrG9reLRO60lhR0pVex+c4E9ZN5wmWHlFwh/DRTMgTxjjdpLDe+sGQGf7Xvp2ez30SJfECdrJa3frSZglb3fCMkdymVpnJ8sH1bsEw2T5sudo+o+o4vnWvon2FKuwKTUTfIqrC0lYY5pGIwzDdgkEs+In88msNurOW7fubgjZJ8OxiW4PZqGTB1olqf8kp4KIfZ3LGgYjFV1oxlj/875QubiYBrwhsc4wXwOt+lrBZQkEKtwrIqKKzvjEfw4qxnj+YEFy+s7olFNYJETb001pWMxUW3fAILEawT4kE/TCanBkeAkOYiEzEVE9sh+cNlal1ZAqc5kmxHVCrPmp4gtcOawvv8mkInVfODJxC7RiM00P5M943V+m3ypGe0NCn42HIFGbjy98zbopbr95vGGjc9FIBB7zOGz7UR06xRHfkgnf8eaTrddS/z+hxwl+8MtLoAD30TL9anf6g4Es4qfFW6SgFvm/9R8yoNNDnLryn03wprY5dgoXEVsKc0RN0l3HrSyFFMxKTIYJaCz5J/rF+ll8j685FuI5r/Ds3WhmxdSusw9ue2wMi2Nbn4FjJKpf7sxXCJPnbdIs+j/jb/O8KY0I+C9SvLhgEeAustm6SeSMsPks9YWMDvbmdC8Y9l9VFxDtYPBzU5/wTW9qHgvZdhozjdgHHeDWDJG55Yn/CDQIhiCvES7Lj5FmAdE4k2ki9+egYHmbda53Y8We5TTWoLmNfNYSFf0LIq7bWE2wSVKShRTUtDZRX02+02+KSQ6GpHrEj+puS22N9BuoXBtfNLkojDbsnWkF7xuHxcW2MCyeFgXTfTLp4wVfwx6YM+CH81H36IixvqpdwfuZm9/CTcVbF4FlQO7CvfIrt5DL2mVmuy43cwP6os4em/2+jKdgeDWV6eXkisSy9k9xtbFlCpYHDmVhlqfJzEVhOloBUv5yOY6J/U6t2Xd4VBsBbiA3w1L2j6Di2jBnUEIACPhTDlQU9YQ+a2i45YwilrO2tyazx5Z9rep8Q90tBq/9mUs5hQGNj1LBf6xyiCqEBqGA24TMFotHs0ob7upUroiuuTbZD+Dg4ttpXHznlxhAUqFykZX0UOyMMuxgx9cAsHp9CqWZiu65Ri0TtC4Aul7Q4jj9OHYTRf/0qhFzWcXhM5dcmS8ppdg7MMzItLh5md4mSE5r0Q41sDZopbH06QSViSPNotEKO7mgBvbC9AExUIdZG4VaMtSNhX2QRG0AUHTzk4ipGtt8cR+z2ua1ABZ5RuuzAXkz91qTSpAUF3CnFVrV57WDo15NoFThlLk46xOk5gKZ9lUjPWVjfXcmDOSVXwa3YRLNJ8dED7f4mpFHBBfSqgX7hcNuQuJ+PeeM/hH3jr2lIVgtyMSb9Li5Mxcsebn7XVYVn6k+51oYHZByrO3G9uaqq8/2NepeQXJlm5zznnlGPAwvpe/83HqKcq26fX3cyzFbVOo+JvPEMWDie5vcpERAOd4XoORMZrYoiHlJgAzgrXq/85ia6tMPRVlO1UyRIUechrTiqOgrF160U+hpyZUzs/TYAO1jIBcxHA2ZteD0W9mdpuBkgJBiiOJJuZnYaMTjzgeHx7MFGTYjgxk6zOCO4gQ5jgKO9DdbTlH9bZnSXqkgzuptjE/ijRav1MQZ2EKAqih1VtkjKn4B1Qg94lGh9yUR0a+C3U5omOF+mAAMGM1DmeLtE5YFanyLcAtL5l8SmQ7cmZ5WjZW9B6qTNyj7SrGH4xO3mYeUPVWZ+9Xv48qbW25vRyxFpNXF253m1nZU3OzeublxvUD2lfCV45nSiuJgOEcICV+NIF5qK1ZpBjRBwZyC1EvyfAPN7BTSjDxUQHoyzbIJwSiPZi0JiGmDskwtDg/qjFL+MngLvkK73IfyYmXhafTmsr1JN7JnXWDldsulwXmHqD1ZJ7/Nu4HuBXOdjnwcU+wMo3nkWeSCqoHoOSOM1Bx2Eagrz6kJuFKvZc4PyLIoGxuvvi01m0BPlEk+qgqEA74+/EtMVy5C/hEjkxJoRUHApjUhSfxoJ7b+QVnDYmFHBGs28FetgW1leLAXd9opeFtHoPKB4bJWXY5ueTtGF2HGw5+aFHXtfEdMsdcpkuOkLjAIF+keaFuK7TB3zdm0+mA7nVa/2khHAZV+IQIwziu2YbrzwifcuVtSdpQPP1GNJHVZn054Kb9mOQlYc7ewgIZTWKsnNKJOicVzH5sdw8CmtePiLB4/EAph6DZsG8wEIbQGrNFV4pnb03NMsyLQ8n2+QhNq9AtcXE4z4Hkw1yBwZqJjas5RhaJgKGorTFJBzvBTnbvKW2CkUtpKRXwyMcsYd49GoTRlI0chOm0364Gf+cMckMEb6HqIVlTRnixHhIuC1fE6b4NsEkEabYa+6O7hBa8vfpykjPLNaPcvybKyLs0MoxZrPmbMd/p3huoQFpJBBWjt9CJ+Pee6sQRXrw/SezFp5wy5MUQOxCMu2ewrUnBgaDhSVd/Zm73yIwsm7mcuUgJmWZaMJVRXRP6r+/MhDg6LmMxkoxSHCvWZOTJkFtbZ0KuurAoxQgMtRUB0w1c55EHkD2L7u2TZzYFw3G5c2WXMZE+WYHuHAgtzL1AVwPkaYeRbLmEM93IW0H0uX90Ujo80JQu4gOlMaF2X/lp5MO6NIn4YbEafzFHO9NKlcPInnwEv7ug2sUvIauvDUKxGndyOyfIIBuk2jnWF5Cu8vvcjbZs6/TtyqmCQO6tV7y8j5BVI5eVhHtM6IcXvxAZztMucoiCDpVtjsANXvR5g5lSspFmtfhr5Kfsl4fy0WU1wEG/Vr3cc4h5sHjYMI2CpAyCkpTJpVWloBJwF6nMoQzAplohMRKuS1nRzhGBO3x0iJqP+lJsY980m03u2VW+difrQDbz26VXqHziBiImOl5iO2Q7iQ2oyQC1NmnVSGPrgJ3AKpzSo+SlLCS7JMm3/98T2tSdRgIKCypZ0T7amRA/2la7QTWHK9fHbeMK3oOp1PFlteLgRGsZUbMBKTqUOK6fU6nagxTmvAR8HS9615T9kYSFY8FqmYpqzdz4r0XAJea3/hifKXmZh0obOdokzH1FAptCL7SjwCs4UsNkXVjxdWOdajfT66lFbKGiPkRwk00GKkSFz5BP1B7szEEfVs9AYUJL7O4f3Med4MCBE5+oIfY5HWXuFJs7w09F1lqai6sqoQCpXMcvKq78/Y8u65XNCikc535cGdCnWeXVlQmhtdyrowFBxuOgeu8KEOAISps0RYkEIFLBFCQH989CuPGyJYiHNsn3hntb6x3hmUb2yS58ldy3LVygrc/Sz/efDCczYwYvomtzF1j2G+APxFBzTTDARk5vDBKEfaTjH+hl6LGlTYq3e9utgyQRTMhmmKu5VC5iKlsp0sJhFbdccFq0bw0yKdfyQJudCc8PLJ3WLfQW/rlcHJGN40yw5ciMktUL7sZ/dg0gJDx6zO4m2bypp31ZhyXL4pEFoCPHCoxwg5VdoJj44u7kuT86yb8id2YE6tvXP/xGC9MPFHvHK2LtbTXMpI4alONAwlHNsovSTyIGR7DOFjfOk2PZqvLo6Z0aVz6LA9NepaAOmC6Li3bW+Xen8KVePMnCk0WrLoHi3EfSNG0nz144VSN7LPmGUMe6tjtIy0KyZbjJ7fZ2qifkjqMxT2YU7I2YJpGlHyVF+GzlaO6EB2atAMOulNgiRn1b9BZdk+4ltbYjn/BXQyt9b1D4GOC+4G5SeiYSSJ++p1uu+imetNng3D/QfWWXiNSeaYvPrOvCQe6RMGAJ8a1wA89CmpWl0CuID3/9KGPZOPFlYxYNe1Va6ZgXiaFJCGEKJmCn5ZQVLxqkebRp6DSMC//KVm1i+uLn8pXOAcLAoBg3L0GxOQAKCEnLKyqrqmtqyysqq6p7j5jfuIh48LE1OVweyNcSaOvo6ukbGBoZm5iamQstRJb+92etkllaVdK8NTQ2NWdTcjETHNEn5RmYilRlWEZmKaEQ+TCf8zVnuci3/My/FEYSJEOKSDEpIYXyKqtr9RD6oIcZdjjhRRCXiCKJLPK4xxhzPOMd3/gnJnFJSGKSYmsERDsYAhIKGgYWEWIkcEiRISBHgRIVajRo0aHHgJFkNiUqrfSc532lxstfGSVqtOhJJZdyaqmnlU666aU2D/Mob7uxfimrqKqpa2hqaQOAYB0IFAZHIFFoDBYn8SNZY64Ut8TrQHFEEk2XwTSxscgECk8IESQq1FjwwTeFOnMvhaDDI+pooo1b9DAqMFIAZMjhUBKMjJWesCY1agTy0ktBNGgQLPWohShpcoRqzjisr6HhbCC7Do2mLWRLGXXk5pLeYOvROVKa1zLp0t3QAlk4MYoYOCuNgAYP/FJid9CrUABDI97Pm7DidHiI1LU1qalBDhE6fbIy7q1sGKEkX8Y4cTL2eH0+++ujr376KzfAQP+pMEilwf43RJURnjWcVri4eeC8fPwCaurWNDS1tHV09axs27FrD45AotAYLA7AE4gkMoVKozOYLDYHtEg+7sUK17xPs1/qlrY6w4xDw7PMtoMd7mjHY+eaZ1e72e3u9zB+5EAYPOakJ7v5W7jFW7rl2zrd6c9z3vNdULdsgaAIDIFI4vKFYj19IzM7FCWKJM9uWkZWXkFJWUVV3ZqWnh27cAQShcUBeAKRTKHSGEzd3jGXxxdIFeqY37xcvlFHG3f8haz+s3KULQ8DyIWElIxKJp7DF+kZ27c9EwoImEhNh+xMJRs5mwux7Ksp0sAKEBrkaNHz4nNLY8jX5HrqcpgtYezFDllKv1Els3AUVhncvbnIZXfd1DOYX3XI+Ud2NGbkaOoqDH67sEA60STZURND1sggn0uQtztWHzlWOaMLrqlqGGWsSR7Emylrjv1Z3/KncoaVxdXDIc7lEqe4mGtc4mqe8Ign+SAsaaoRt7YtEr8lWyZn229v+dt3++m85TtA1/1vK3Tfyh2isj/7mOS0nbIRl8DoIyopgNgtGVBkJQcZeSnGRGnKSKNTepBF7/SmiTf5SBvv8o0uPvcRmBKJFIQkp1KFJXo5IhKvPK1rVxcxdaxKfH1rkrbypchf5dIVrHaZile/bCVrXL7Sta6zDuuwIh3XfeU6wxjBYABIaBBQsDPVS5DvI7f9bQtoucd3dyVndc+E20b6wSrb7mHzoI/k4zu/tOmT1d6w3Bo23V66hcKywvLWO1W9C0xzs1vnS15CWuiXhj6/OJyz0EEdrs/yAINWh8q1w+B1wv/rsTsR/CzcpaLfC6BAg4iuRmpktOeswEbv2NV+fypqfW1Qk/wNKmtrtsHNbaFRd1zp54yfrYTrF23ao8v2u/ZcDgZOea76vTs1/ajzRQEY8AThjR9KbnhGy6uCuMo4ASomdrKN6r+mhzmdnZGebmVWfNgFq4/uNlT7ZP+txan2/w6n17SP4GziXRft4K1YE4eUtNto1yg6dPGO0ujOPKLV6/nCpI9zxV4/jpvgaiTmIcCsgy3SZ47Lon31uCW+UfXVFoK/4zrPNuZWA/ppr+b1vJm3827eH8oDhJHD6ISPVODoADJ2ohZ7UYlToOMs2LgAIYUApWTIsgJEdgGViyHN7SDJfcDk/hDlgT1ysAbAQhDCkFtqZCIW9nHRifUflEDA7WWQCBKFXBiFKJTCqEWjmRlpNqyRCKPEmJTP3OewYKWEvSQ4qICjOJzmQmMzc49TXLZKeKmEt4r5qJTfLJVowxvJCP4jZUJIhkiRgSJTF5iueqPoc1J98zzBsNPof9btEjM9L7PxfPm//yMFqv2J4YbbWO54TMQTz4h57gWs2X+P4pUGWne+xjSUxCKPgp7rAicHRRTGoZSiuHWNeJULqFJ8qkqnb8UJNXDytySiRREGrCqqrgM1UZSk0VJnVn6gtLP9IiQqNxKpJhoNr6kmINNcUygrVVBSeqVE002ifUCoRiFI5yuhit0Gfdgigu65TIAesCAo8CmUNQhUegY5kR29cD8UoF1H0D6q0bHHOeGIYH3014oDUOgHhGgC5Ppp65eN+Y3J/0CSAeDwXQPa77rRDUzkJkcQbCRmVzAAIcYCcuNs4TEnApaKiPlQqajrqwUaxP7xnLjk7WVydNbng8aTsyF37/GSffZxAvSeYccDW155xRvQus6Wb35pwo4db2tIGOWzQO8lluKKW3ElaE0s6ZKGSg+ZvOhK0TmaQ0TXSxwjVo7ikpEE4BiJR5wjKbkkBQ+HqSngFBn4pMyUlBbeXKJIjkrTqzTyzq9zm1391r0N5vG1tm5j1Zzmhl/Mxkoxx9HcLGpenGnF97Qw7iwCa8Rin9b2+GZ1xJ9OWenCm3oSTh/VineDTJtnVdsqa8EWWYetsn6xtRV3skWLLQyQle1a7GSELO1KMbuFLbMHG8Z+39D+1PoHUrdBHEwjh/G8VqetHJOXTuSk//F80umczhlXyf1/EzuA1rlkp4ZFjLGyclWIiMsmtSySTZaV20Jc7prcAzG5b/KARbL9ekpkDUJcnizCrZiHPBPi8hyt8hKxeYXkvDbtTd6mmLUq4u6dqUM+bbKHekpmuVpivvei41jl09t/54ot9fmR/DUy88+kEZMmkJBmiAQAmUVAYjGQXaJBVHqPlPo0SUNCGZKNSEDHis3KkdIb4QXEV2YiUGUakk3WAGzV2NHiWbqyYwDRiePEDDJrOdKmdnXeYg8S64COdTRxAgl1duKCr8q1rnEHifVAVFIivl5IrLf9dp9qdahfdUqAfE+B1R8E1yg6XX7Kx198HYdX/Oovz4DMhu4mYwqbjKPc04z1TBrTQOf045vFnJKak5SGMaXBktIru+6+tT5byt7C7A2poTPmdWm1lc19pFfa0kL6u9vUO13vvd/3pK9Y0rM2sku/axDPR4+gRvwW0Q29bXurKifU1NFkiY5eLNystkV7c2ygwmkPZ1y8NEbJJzlzKXZp1pq6WW2ahiSyP6RqTe3aAU3NQKvcWbctOKIEs0/CEX0SGRCFDoMdFmrFUS3BNyQS+xKpJ02mRMXzqtEVQ16y2HHwSS43HjXAIm/aA9QssdPDs/oGGUK1RiYTfFUzaeYAbMcoK9OyZVZ47q/byNXWbvY48qRFHQw5BGBHqHaCdqcAOjPreRc5u+wKF3Y0GLdNx6htCeil4MUJFyVgoz3I6FjRzaDxcR2o4nElVkgjUhGQpywoMwmQZgNQtocoO4PKrhVTbpPlKqDOi3qqYIXAUkFIDVlvz/bmmImajZqGWjIbNVvqdJ9WTnT0DIxMMqWwymKW8pXN2eX4SQo7VlZ2X7l8We3xK09RHDjKp2KjZqOm0WEnOz93sN07ulpKN3oGRiZqNpkugp6mykeOjxwfOc9uZpZPolJxVVwuj+vz84cMWUFXeWqvfZ7Zbff1sLN9muhKuqQPOU2MpWsWWh7bsR3JJSeEKqaYkuSSE6KYYooZoA2IVobUIYR4EUJ0RKcjxIsQoiOMGcwwwGA/wFCMRDUA1g1ma5dtkD6yeQtDADjAgaurTac1dbEIcABxID69DJC0krGSrognniu4iljiiIgjPomKOBKIT5YijvjWimKTnIgnvuAeFOWUvmm4pGmRyhwNZ1TCKN1gMixHTOBD2lKb2It0PTiy1VYMMaeeLrWlNbsX6cdbcuUor3nJp/L1ROfX+XcZLSDlUAWqYu+Tqjvkhqo6Yz2+mVkiv8wvaXdntKsw7Pr33VrdR9I/6/bL/dbx1QY//jL+GZCxlBQCzVFq3C1dHq5dspgsFlPEZAlFbC0+Z5uepp4ISQJyrdRDFzd0VUJXH4Rg7OqASgGEuO8KPRQmvgvlIcShUYZqTcerpKHSUnBaA6Q9UGgfZDoIvc5CqXMQ9BcMegSp6sCrHrTlIG0GtgWEl4PxKsijAlT0D6Lnu9qoAaskiJY6Xo0mwVBD/4+d5rFt4isJE+SDfBALuvFBfhB3HJ5A1LJhk2xZbIkOW0UiVbGua6dXH3QmH+SDWNCNH6QchycQtUC+DYnFLkG8hO8SuFU6bBVbpSJVka0N2Ora6dX/LyVhTbI1ppsY003IrmQDhCHiPox1p9E35aQwTaV6kdFkNBktBegUmqlUGU1Gk9GO+GEhtrSeyEFenbmxqdkR4xwV9ckyKsux9Ok943654sfaJ83M3U+2reo8S+fuQrqgLmQgjQ0xCzBqLjBBQIhnG4WE0bzC+uGFk7iIIkt33zOeVAx+4j2noxcSO72TLlVi+n0X0oI8AMQsBRKXahcD8GUhPtwALXymIVr6T0G0z1rFGDTKlwStNurt8YsfgR2n0UwzuW7nhBhRul2UDUHPSs/KCrHSS4JYYVbYa7MwThmcbtADQwgggDhlcNoZAogzIAk2xBn5yVRjpyGoqas8Y+eXiqSiJlW6gTpjjE1F7WqfzDC2Qc06wHhc+SW6S3pRCpVoZbQ8enRBF6W8MrdUhhYlGlCiFUIloBQo0drKLomlMq4o0doucsAFcEYr0YJUG70VPzYFMDpQlxQvkARCpV1Iu2jRAco6g1ZnwDqHQn8i6AJiPYXSM2g9h9EflCYBzito9HZKMQBdzEQWQ4b6P9/JRGj++BFgycHVHkqzFCFECJGlyAohQhQNa5hKQ6Z/NMQjUC+m1kysAICKMW2HYjBZ9l4QIoTIUmSFEMFUGjKdXRFCA1AvHtDl07l8NMsVZmKFWKEAFHa2KAaTZQ8Atl71Nb3qa5qzzbV1dHXqEqwMHhvQhs/XgiSQBJKANqANnw9JIAkkqXf0TI1deu9MNFOJStSGSlSikiiJVKQSlahAbagkSFQSqUAlq7or4Am0OAIeR8AR9IRyTxD3THBP+PbMbiK4RBJZ5ezuTCaRKCQKSeXs7kaikNwopB4KSYce0oHXHmH1GM3oUXKjueyxY3SAMhrHHimMRtBjDHk9YNcjcx6xMpyTzFGGk8VNbYvSYSeZsGyCtyBPJsO5ynBSR5mrDC/DEWROZRO/BXwyHMFJ6OrkisXJcHj+Ch7Tf1rAblmVmC5ve670o7KPVI5abOiXuux6Xki1p7Zty29Kv/FojB09pZ+pUCm51ComtUfe/qzzdqgn/+qaXwd9pDiil5oXay801uU40lCJ9YRFv0vGxUOIi33CxZWJzC8UyIOPG0wKSWGvc3End2jiNg5GU8UFmXdxPI301HnbX5gYj4zPMim+6XY16TrFQF+m0ua6pBHVCgTJIc1ZvQ4/J24O6pXR6/ZL3hag8sIhy0U9UZEBQ5SyWZAO4qoTKndGLPKzTqjc7SX5Ku8FWV16ovpFknJBhIla+Az5j5WkeXBPVKZI2SxQhywP06QsF8rXG/KodeiaW6TRIBR1aFgjT5E1rMrTVTXJml7aPqWtGqEKHZUU5h77DhuThgFEtx2UAYU14LJNEqmPJjfw7RedbfJIPwGV+yKn0ui09GMlCwqCgkhMiS21fdeRURKZRCYpVkFQEIkkMolMSrZkt8hTi9QaSRrvjTPq+OPXH9nxplAojlAotGiJJRSKKY7QpNASUxLTR7Kzjptt5AV3zBx4GKQnyprHqBkOiw/s1ixPyGTXRu2+Zh4GKZkGzA6+dHoyB4OvmwFtmZsGwtXSk2eX7c52qUvkNZ+JgLl35W7Zu/2uvbcO2gM87Ml8BAyA6MnDi/dO3ZOHmG4veroxJQEE4fVj471f+6k96j7364Zx2bLxu6haqPw5m8HTQXx5IvCWKqeSaul38eytq1+HuwO0HnupHknT5Q5zbKF6qQrVGTYfH6Oi2rL9u6gSlRctOS8tvcS8yguy1E5k+gB9LuIgAJby0qmLgwDIBtksyJw1XENkpANeaSYZXKzVA16iUyMPHl+D+TuLGjB7VdcZnOC2rlk1B0AWyAk25cYEsY1AaaeODrJANlfKBKXHZ8c9bWs6yAbZwwn4+sCslKZpouwkf4masf79JRpyzlboIIkVsb5MmkqJlTFpMuuagtSFz3q66fre89ZD0/rtbOveQZ95QBT8zfcjs95Ev3uezHsZffh0KEgzGA5/oUA9lwXO9RxUrbXAakiFD4VJu3XYCwM8jkEHi/+uojAVPgvmn/4cK+afAkVzPIX+6c+3Ovj/p2Bcdt4NT6kIUnkfXG46wjkbv6e0FR55F2pz1FTKzp7d/9qoKT5pA7cWFBMjsp4N1W/LFglIbNq4zugf/buNRQz8tupJIZ4YWB6WV3gK5cHheBXRYC7MhbmFn0JtcDgwF+bCXENdUAlq2/nsP7IFEBAQDEBAQIoUKCAguGAAughIwQXUYxUNvhg9ieZynpyzxfdMuhtybadzOU+8brvcxaDXmvI93e/U2D2nrXhqXpK4vC7nafmuFzj3K9S94NEfkxlTpn9ibAwJAIqJ7S+j4itXSJGhSeDIb9Kn+E1PCZudyi+dOpFApXw3DEoFKvIYoqKSvIq8kkr5xn+Ud43odNLezQQQOcmVjSkczpO3mLZhPdZHVI2PSRpGMT2LiRlGWO9gTMYwimlYTMBe7blmnnRhhPVcnm5hPku0sB7XUyyX24oLQNsOQpXGgloUsE0LbdS2gz7ddfch36ZampS4WoJUBv5Ou7RLwL6NdMh2bZtdO8hPCPNam2/fQdpBe4jLtYO2jYTHTrc6AP89Bf5zbv/Q9EXR7xnk91TF7xnA98r13KzmRS+1/Dv/Cdxx6jON/xIFO+rdhC1L0Dee0cpC9Aj748u7T3zZf/V3M3+UCjFVTUIxLICZMmKyBYRwVDqYe0bmmD1s7uOdAQuuztxO6Ja5W6GCEmPHiJcZGhMGGfGyS1OtUjPQi55aELEzLItPpc6g0qq0KrVKAwVDgxUGWLg1MclHGBSL1IZIpZ+HEsQ4vgD9JKh+2N8q2cf4Qp0Bi4vXboqHBJ9+ejlm4MEZgEOAIdBgD4MjIpV+HhhKGH6BqoAu0BOeBDUNd9SDXHUDZjj8E6GOYfvQpPgY0mJ1zY7PNRFbGRmy3OnGuXTFO29Vbixv0olKqnBCoUL2DvYO/tXwrwYAMPUkDDuGHcPOvxr+1QAAhh3DjmEn1HGkjUeBthNbLpVL5VJnqVwql8o15ZpSTalcKpfKpM5SuUwulWtKZVJ5Jo1BwSjYFUbDKFt0mMC4eAUrqAsP9mrtY3TxBlhrnCUBpyTFwy3GtDlpwYjIGH0yBosjEDFkDJGMuaRM6PxieXHoESTzG92r8JxqwZPQJfQSKz9NUs+IR5fQS7xuhoU722cauevb8bJ8ah1hrqdz0dLmsv7TcOU25am6epThEjPiuerNDCIYgmEkDCGQnMKMLdZHoXgRtXvRWB7D4e5h1kJNIlAJQizUyo3hykW0ciO4kiTpQJpMBye/pbyLBRBiUG8ahmG4kcqMdq1y9fYe/Pftqsz0nAZ0qEmP1nKr7S4WJE0pjFzoM59juXIRn/kcyZW4+AGfYLOkoEqTLmZpFP5bV0qbmlZJ21rIm10tXf5vT5tqqboP8QlMsFZSUKVJWrzd8VBklU6I7H2NGMw7yCvnNtsn+wECiUAiHBDOSAQSIVKPIgYaaACDFfhQz5CgrdMHG6CllQ/ielSBXc+cINY3MGxEGOwaWxSWZKcNdCQCiXBAOCMjskKkHkUe0BgsAinQ0+mDVbClaaGuYbCldaGubbClgUFXbOWD2AexWE+sr21gaGQsqUdFVPVsDLUJiY9mLC5HaG7qZmLRjHjMU/shzhonV7goulAOvA3ehkCwlfGIJCKJSMLb4G0IBCKJSCKSNL26OrpKGUwqGYZgCIZoEAzBEEyBKRAFgiEYUkI0CFbCEEyBlBDcFikJjlJ7d9AddPfG3XvQfYa2dW+96wEvPXvU6snC7tQeNfmgOwi6e+Pu/Qzt7N56J02maGaskO2B4V/u0ywhkAbsoJ92wuzSu4Xdr/racUEsweHId/+79GurgOIS1xYBoXXW29BGWKKvgL/9s/+rT3r+S8DiN4CTQBQUkUjDQ5QgShpJI2mkkR/p/gvwK5eycnErt+LfjEWBK3HEHxcji3RCFk8euqwb699fQ8aGS4iNzQ1sXGiSgyO5HMXV2OAaiKuQXF2VHKgdmlXywxSNaiMc/Y6ITlMGxsAYzA00Y2AMQAdNrbnrCouMIuaMPDEKopOiIGlkE+cV6yj7GQNjMDfQjAHooDVXWAODRM7Ia3ktrxWIUTAKgihIWCObKNaJaMc4dW0tY6G5oQEH0jCqpTD45L133nrDUWq49i2qYSf10nJ1+mBP7SOOyuw17TUBBsBgMtn6FiwVS8VSYQAMJpOlYqlYKlNeB3QGmLhFBEGYIAhqamgQhMAEhaCGgGwlsFJLgaABOwNGBnQMuNgMEfOYpzAPaAcB1QKe9UeyZohFb5YJDyVTqixSeR7mc5iZYU4ydCbTEEaYm12tJxGIQASEEeY4IhCBFHIpsGtKvCSyvMTe0rfKxp/7H9BmNZcZZ2+fjbNltqOFryFrF7Ib+4Yjgld8ghPmxEpwSrASJQuNH+Wx2mlG/33WhmaZ7c7XkEXYN7QZJ/CJ6xds6BdU8IuVObEiVlaCleiVZKGRVcFpwSs3RRchXCVQkRBhkgsiK6QSQZI4iak9KTEmhSCxKOpQml650Az392BzHCdVnFShosqRT8OKxorGKhp1PI5hiBIlyqdeCRUq4UFzi9aB6hl5KUzmFUPcxpr++GJzO6x/wGR8z5RKUPvdpAqUCizpsuTKllsOsMktG9LWXE+VKw3rRJ3oT7QSdXor0U5mU65wt3WiLNkxojB7GNmT+Eu9OJbJSL1KjnHgMiJvEnYZLiPpchntWYsoRQSECttg7wq0NBoGvaEi6tCICgRfiIpoDPQe1ehgCfSJpZo0KhAkpWZAbyitVaYRMNgAvTczAPrHeAnrX53pT8erU6nz9GmuJ4x+dRa/91xb5+voclOpeXGLki5Pq7bpm60vYOjT4TqzOt2a14NdSXcTr9PpeB4S6jVO4KZ5piUdrxnu33/E8h3gk6yF8BCws2BchlViyvU7BVyBb7QBQhemMIVREAZkPsh8UDihKpOsXCHfmVYJJiU6r9RYKknAxKLGwsTmJ42/RAHAkSfaE+0J9fRA1pso2uzreJvaRDOxorNIjRgaMTRiYJbqY3oNDUCD4Yuj5+YWttrsjM2eugFCZcqRK56cDE+sQNkyGah4cKfgiidOIGUcYoBTZKuBovhjMSQhjWPTzFZzDpfhcQXhCmJllS5cgmBNgjUJpqDghYjt2q7t9lMCVS2J0C+op/SUntJRekpP6Wk9TdGUsLBii0UJi8mKxe60hui6Hg3oiwDUY//8pQeP83E+zpf5TyXY3E+VGB9Fd3OlV4+fFd/NedMbXPdzr9Tcxdod6cYv0nF/areLdnQnXZt/+Kh7gp4wPlQJGIEJjBN3H57AbUTA+1Af4DcCkA8oniOAAh3JkKEB4AWIZkiYTWWANyBAEuAD9A22H9VRgti8liUGGM1cE4B8cRnpsM/Yl5gwxAY35yOHkQMu9drmlqUNsccux5Y336Jaj3Wx/a0v5AEjbZ0Jrs+ujjZAhFFaVNNNsu1z7Ve/4dSv6p5iSW/S39b8vaZwhXT+03UaZjYtKJbKkSCmOLoVQlNemvdXnqLWNcrSXMjpWPgra8NwNK6embXjbd0P8Mf2JwQFs2/8lKsA4LgvOk9fauMksMSXonpbRJQ8eAkDIgi6fANzu06/IhX1p6V0cI18Z8RU9LyFg5BEhsDQwp6zoBJfmMqVUFeaY9CxYRSJKTSyY9/5tsT3p7pzUhpGvqwaOmgyS2Qsc+DCJb5O1Z34HxktEz/BmhAMhS02sXTo0jb1vRKV8wq/iZUkU6FKje3M3PD1GjRp0Tbq/L7oeh9qtC0xe+o1HgLESFcx03WQOhgDZmw58mhA3nqlcNFwUmTKV9rqopGaGnUjmLWK7Ky/S/SS3fYQPVbPcQBWqNf/XRmILGWaYBBMas66LsyWPTd+Qnbkn57FYp0EabIVKld7NctDj06nH8EkkmWbJfdlGqO6mD8XB7jtIfqTtZ/d/LnDAUgIiCzlaraxOQ6DYMKcLXsu9WqrHjxAuFhJMhWqbGOr1ead+hFMIlm2OchjoM6fS9xG7zkgUJVVu6uAQTBhzpY9l3rd7eoiAEaUOEky5H6r2JcHYACNIfeiL0f756a/B9dehoIethPSUxpwcvMtHlsKg5fUKUK5S47TAjtJTlIjKUhq5VS7GBES1/S7gtSx5obPLYX6JqVPsDSRlgSNGIv3S1tijS32OO68a+6q88YX9QEqIaFy3Q+onA9x72h0mndy2wVvbqhFtl8ryz0qF7PYqSk+cHpd8gl6BTLXFWoDX+wif8j+UeQYy6HbazLMB/sEewUnBWcEtwVvBv6uK1k3JEC2x83N5ufhfks3R2Tf8F1SvxQrHv+gkKUkylSsi35GmWKeFRAkyXB4PdaUYG9qwErqteZU3T9FmLpJ6asfQ8PJvNOUndJzmbryBwZStzW95OBzjgA1X47kXTCXPV/w3po7E3tBuPkZsy456ZTTzjgrUZJzzrvuVgAsjDGBSUxhGjOYxSIsxhKsE/7XeGyZpeDmBwPqsfRe9ce7ybxbOoFIIlOoNLoug8lic7g8vkAoEkv09A0MjYxNTM2k7BwWLFqyzGmFi5sHzsvHLyBoVUgYodteAAqNweLwBCKJLEYRp9Ik6JJS0jKycvIKBlLjzlVV1NStaWhqaevo6lnZtmPXHhyBRKExWByAJxC7SN2NCpVGZzBZbA7IhXj+eU0gFEukMrlCqVJrtDq9wWgyW6w2u4PleEE1+j86JMkKqqYbpmU7RipjopiQjfN0DEws0/GAYje+hl+sxsYowmnnoNH1NfQXY5UTHEbFNkW29DDOA0AQuHmHMWFV1QNKPbXxThaHJxDbcxiTWit92ierVEcPKH12bvBviBa9ymfj/MjYxLTG2ZgWDTaMaVXJbEx79cvGdNRCw5jOqpR3p/8vfp5/t9AL/B8tDQtPXrz58OXH37an8gqKSsoqqmq81gKDG1UGZOiYx9uuBLvLUoAfg7ojs6smum6j/e34Y3N7fMqqdnW+XoVwZPXPtiJrRQwndsu2Q8HVPQhODJlBhhllnEmmoUJnmVVmvcs8iwecVitraqmnkWZaaQcOEjT94MHSSTc9UHUY6xF3FtsngHnihU6jkMPVGafDWVfFrPIYTLYXXEihYQorXFhlaIwKWzRDqS/FFR8ufAkiKoObUqpsOhpVc7MGV141/15Ol4SJEidJmizX5GnSpkiZKjW4GgRpv3S55/GOu/5BVJ8hY6bMWfLMK+98Ckwl+fzyTwlc5UClDRZaZLElllpmuRVW2ma7HXbaZbc99tpnP7jyCdXi2G5vIwmOOOqY4494Te7sPibrupe9fBptstkWfwS7gjjs7kGgyjTEyanGDlZWiXXVk2vbBrtOWndvdNUasKmV+CBw0iptU6vzvuBKfnaQ87NAxlZj+5XhfERTUKVFdpDQbtm9MNwlnhmFWWz5toEt05lboEsyS8d3IUb/Z4dg3jVQAWA3a2yywz7VTn7zu5KThoJmWvtR5y8cV+Vkfts4+7vGnfM3IWH6bBn1Mb9iy66w6lrrbrDxSK1G6eewhGa4IwSnhGyTNtmR2Hva9oGkPpLcJ2zZk5IDqTmSlhPpOZPRf2TmQlauZOdGTu7k5kFenuTnRUHeFOZDUb4U50dJ/pQWkJYVGNatECRYiFAYYcLfCAi5UaTPomBFixHrizjxcPASJEqSLCUDMLVhRGn//+CRpSPKviWm2sv07rTNCatgs19JqfUqg7tsdxI2+5eceq8zutsOp2BzQClp9CaTe+x0GjYHlppmHJnda5czsDmotLTizOI+u52FzcGlpx1Xnu63RyJsDikjcNx5ecBeSbA5tMwg8eTtqH3OweawsoLGm48H7XcerDO2QrpD+gkUCOmOwRMsCJwjfAzOUf4NkWMTDg5EjkskJBA5PtFQQOeEzIIFzDcM0LlN79LpbX5hgc6JmacbX/49ADq3zSK9+AvoIeCc1CPAOTkawCl0jwKHBbMP0r445dPo3xG0dl02QeY4gY6wRjBT4qOUygcui7jBcaEdVhxwUnCSft8j7G8WjADrspeB/V5adKDjwIWTM4e8u+pbouLbwLZl2LazA726Q/akWEFI+lhri4cPjb8pqrVWaiYKKbZPzCfRB0/h9N0fKPS1Xb780Qpf5ymKMQYPwASGDBFeasHRi6p3YdCBJvqua72rfX3Hd9Q0To6ewb/+s8FGm37kYw3JmQkGGJ0SBgWZTkWZZnH1OE481w9lk+AnDBFuQz8Xjb92az4or5ZlWc91dmhtOf5+MNhxwQG/XSPCIVoxsGM7NOxcH6w1lj2qAmI44uXxj9+0P6DLAzZqhy393ziOeK1R4Tvj3YaP7NdRsacNgIxqmgr2pVWECAGgEmrNtVLD3u/Rynz5bayxRdsEPTq5ZA3erjb4uDGXr9vu6yfFY0M8VcM4vxnjBbJs1VqRbQOdeLFi3SYnJ2coTg11k4gHRgIucjEFUS1k/caeWkW01rkgtjhjTPGuhCwI6ejKveypEGYQc4qzJo1BHUlTRh6bsIedUIBvzAhgp3spHUqAeIATTWJ0bIdawdcFgGA6LVv8YtKgFWvdaOv/BSDVUNp5QI8BoAFlAnRuxMxc8dKQ8rWHQXhNhNOWNhCIG2jVN5T5HfM/z6JfeuxOf+p8m/lu5/Jv0JSdcdET70XLUbi9+TeyRhtpzI2e9V0/Qn78zbp+JvdX1/0xVP95jsLz+D9kgA1JkiJPJD1bx7z2yhvvvPVXYwyiEYvEyFGhYiX6aVNNTbXV0lUX3XSPseWduZfC7Le0lvQkVpxBEmJci836kZrs1V06p7nmW2l1/FswMNVorGmoyE3XIrZYbrMtSfXYlZoIIZy5NoTKNw4UHDAq9rUfTuPu6iuR4lGR9Makozfv0doJI18ohXL7nH+1q9wscwB3OOKo6vgHRYgICcERMkJKCEMklIMGslIJaGcBUMTGl1baGeaYS+564r36PNUZpo2BfhFnjtUuu+ePjJmKyziLqqurufa6Gmq0lbYCz1n1UFhC2p2pPbgASUreOkBnskG+Ot3wvpPEzjFiUkpqmtaJTKFca9/43b9W2yxQqHipvl2xzc2gfkj2Kquppba6S5KrpfwKKSpe3wACCbIIp0KPIQtWnKjiM2DGLj4kFDR00mQpUqFBm649binD3CrWsaexdm6Uf8tpl7nCE551edNvzntpUbyvpKatD0d3ix1z4mvlcnt+ilyQmiM1OvGjtfZWOK7GPXU++JOPeiN9H8n7mm2VY+76PZ1Puiyktqba6myw4ea7D/Qfc/u14Q0udMPsvvoExaQVbFyWB/u4UEuBk5Hi5Ozqxt74KQuWrNmGebywjO016GK/LatKamiijQ4iZSmVT6sXKm4aJU0eKG8YMC9XxiNiQor3giqmHlygTH1N8id/GGUnFkH5mgyeAr5bFlW19L6R4rrZsBCTf/O9/7vtlkMWfl5+eg35ddpxAR9uehbYGct6JHrZoUgze/nGtfWV/T3Ym7RT4vE4Gse9vMZEu9s726thPUH7JuvvumX+s+2/6cQH5zfqIrrPhj/BL8XwK/2dAe7FqE0z+XPA/5EvDwDP8J7c/i6/t1+AgWHenXXi+gQALxvDq/G2eVO8cq8YhkEvKAXFoSjkwDDn5XKs/WIpTcMAO9Uy2uvYP7qOW2WQYz7FZbxEvk0o4p1yAEDcHzpsGmmlQ5KvU1B8yW3mfK5pav9D8Scw8LUjBudTfpXVmxLdIEgPi5a/bXxRHtQ0ADpYPJUeE9XFHTstzuLwBMamDvAUWfn93+ozleI5KiZSGZycXaenh0Nn2dcrZu50J2o9bk+dDh83NWL553pA7+v1PNXkWufa9P9yoo8x2JknS43oaYbB4SWvpteJBrkUFh0j5NIUj+uosy43CSGUMMI7qLCVyK3d+QrP2tD/3BQze9CBc83bMOvP01DdHS/6xCuvvfHWO381aLRhvNuyjxRBLK2GYNV1rdrYV00N18f3amNMM5ZI3ovig2T/pGqSHgD26BqkaQa87zpkdQOKegCl0UBxD6GkR1DQPegZO11joVusdI+Nfr2kT8+pio+K70grx82g+BmaIMO+Gx6Gt2BkYow4+VGJMy4pJibL1BSZlJyBzA/M7DRYEKRrLxMbQ7M5Mzb1ju1ZsTs7dmbDjqw5kAP7s6eW97fjeXA6H07kycm8OJU3N4viXl+460mJPC2ZupL8yMqQ1BRCjG8Gx8vCoJzJlwsFcjY/zuXP+QLo0RMmJ8+ubDmYY5+LL6mU/mHp/WnlYOqlxpPDlWxM2/8kdI+r5kZruXcprqk0OpPt5JwJnfjzRpy8rMuytrFrzymHy+MLhCKx5KwN/DwHipE+qR4rs9LnFbbzXmvfkQOHjv0gTTWJJUMKourR9OkGDEOmEYtjYw4Bea4riPIE/vwX81EoiTRircREaiozk5srLJSWWl3MP7+Q34uDOP5MwqdWZs/26cXJ2XJBmVzF7ih1V7l7qj1Q66F62xrlNSuYx1skWCZapVvXdchzzHfqwN2up31vJ/6uDT87+NvK0zbetvWxna+tvWwCOGuAq+5mC3ebAi6WVKk06XRBgiOSxMkSKcJEhYbyDfSDDepo1dIJ0A3UC9KubRRqEm4aYRZpHOaTShGaOx07jpbOVq7W9jJfZzzPD4rnUXgel+Cl+ZS/BlZ58Hi+wxij+21r7Uova/2MitNezak0TsMmGbsnbbXTXptttxu5lYYitNhhP1w52HXlmneiSrfX8548IdtH/jqn6FkCDQZYEo0CWAr3BVgaPwqwDP4IYNlXT39Y7puMzPJZIfO7InAbwEr4W4CVUX+AVdBUgFVRP4DVrpvI6muDrWeyYTbKgG4M/DPAJvgngE3xLwCboWEAm//d26icA4mfg9BCgINxC8AhaBHAofgPgMPQPIDDb2RyRC48vXguQosBLsbNAJegOtW4FP8F8Dh+D+CJV0M2T66n8GMAT+NHAJ7BTwA8i1sBnsNdAJ4nKgC8gLsBvIiPBngJTQZ4Gf8D8AqaBvAq7gHwGlEF4HX8MMAbx9/Nm+etZMm+7YgCAO/g/wDexV0B3kNzAN4nmgE+wEsAfIiPAfjoagrDy8fl06E/mXyG0clwn5evh6w7+wZ29K3v7Ox7P9q3+5MD/ew3Z3Z/N6L7h5v96S93+Nu/7u78t8rfA/zvOf0M9HF70E7YbDCM7Ax5pJMAhm6Nno3CbP7aGAuNLeOHKkwmYBQVE02xpKmmesA002xmuhm2MdNs23/7OOdgcNCGs/DHj7Xx+hPeTjv/xbAd/hsOwf9vlyxg1+l/CDa1E4rBCABhg28QPpiOiMHfEDmYhagj14lGmIMYALFhLuKAiB/MRsLgfySGeUgCKjnMRwqw5bRbxUUFOGlhFdIhyggrkAl+sXZrudiAIBiWIgeM3LAdeXDkh80ogKlz2IIusBSGrSiCrTjsQQnOSsMulMHXNRyOclQqwoGoRKomHIxaZLqFg1CHeul3m7wMQKvxL45E02WOPy0IR6En7nqFY9AbvT7haPTFQ79wLPpjMCCciIFYDAqnoBVvg8MZaMPfkHAqhuKzwnbKMxLhIowiwuhwHsYQYuzgYow7/BmPcDMmkGliuAWTyFrJuxdcKSDb1HArppGz0g88ZoBJZt7cl3KDArNv7ondYIq54W7MY7L5Nw/7DcqcfPOQ36DUwvAmFtFqcXgcS5hl6c3TfoM6y8MTWEG1leFJrKLGaeEpnE6tM8LbOJOFzrp5Hxt0WHPzXuyBoxdcdaDP+vA5NjBgY/gMm+j/aKbYjsHX2D2Gtbj6sBv/QJIj4WXcyRwvDsbhX4Of4KUfaF+Xgdwr4RK8SpTXwjN4nXpvhBfwJs3eCs/ibRq8E57DuzR6LzyP92nyv7ANnwH6LZyG31++3wNrcC8DeziVARw8wsAZljOYhhqGuOFyhrThMoa8uIJhZ1SwoN3agvWWO3rPvb3vfh/52MI+Ve8zi307331RtCSvfw787381/fTTpL/+GgwwQJuBBiobZJDGHebc1HB3NmIa6b/7VKP2QO8R6InZMzuCE8mrzo8yjxbE6MTqZZmBw7JmU68dEq6f/v/ByNZwAQLtb6e0wmUW4WCR3IuSLlosj+KtKZFPSdae3ee/7JFjjsMKrOoY7wr5KlIi6pQ+8cqc47cNEKlRm11dENdFiS65LL4rkrprb/fs64HkHknpHnljkoS/A05aOr8fcwqW+FuI17uBQsuYohVPdYlpuvJMt5ihO8+Ni1nG80JcEInnpUlBYjKvVspR7jMVvDYt5pnOm5V9cPLMARzmxiLz4FylB2/PMsBlZSyzCu5VfXD7rAE81sYq6+C1MdbYBNDWWGcbb+k+e+R69gK+jwn4nYwtTiHgbGyTiKCk2OEcQs7HLhcQdjP2uIWIu0HmHqKSv+x/RkxqHPAYcc/ikBPn28vu+5O/Cv5z+6FvIsR0M4SZY45I88wTa7754i20UKKllkqyzHL7OHCQIlOmUNmyRTwlWw/K+L8y6CEsoEcIRzSwkGgRgV7CDnqFXOKAvcQ5HhUI2E1vUUAgOI4kxm0lAceT1OgrDTiBZMawygNOIoURVQacTCpjTFUBZ5IaBpA6nEUaI6oJOJu0xviaAG4nU8wlFNxBaMwjM7iT3mE+mcP9ZIGFZAkPkBUWkT08Sg5YSY7wGDlhFQXBuxSMiykE3qJQbCMMvENhuIhi4QP6gp2Egy8Ij4OUjBWUCQ9SNkyhHPgD5cJUyoM/Uf4gQwpSkJ9bCJhIRfArKoZJVAK/oVKYTGXwOyof5ExFKvJLKwEjAaqCb6kaRgNUA99TLYyhOvgB1cNYaoAfUSOMAqgJvqNm2EAtSKNW2EhtSKd22EQdyKBOWE1dSELdsJZ6kEK9sI760In6YT0NIJUGYQ0NIZmG4TD6ikoiwKE0ggoahatoDBNoHK6mCUykSbiUpjCapuFymsFYmoUriIhxRIIraQ7jaR4uowWMoUW4lpYwmZbhelrBVFqFG2gN02gdbqQNTKdNuI62MIW24UXaQTvtwku0h7OJDK/QPrbQAbxGhziPKPA6HeF8osIbdIwL6ARepVOcS2fwEZ1jN13Ah3SJXfQNPqYr7KHv8Am52Dx0N9BZxO8Dnc1oOtDZ+mrW7mw77SExQ4cOs3XT3Wg99DBeL72N1UcfE3SWJci227sk0FygcxnSFkDnsmgQ0Ln69cdkzayV+dlgbbg1sRuDtCXQufX122S7tcNOW/V0jHNDTDbrVRhZpBlqcWjUBKhZsxh2bcS0W0LeGmvkTddDaMjGbEKBLbYoss12xYYNK7XLbmX22qfCqFE1DjqkypgxtYgeA6G6AUYltHYxBhFJYMwbYsM8zpw9JSTETkpqmYbGugSJumXI1qtTpw1dumzp1m1Hjx57+vXbNGDAtkGDdi21tJBPHIoG85CQlpCQrKKgWOHEyRA6ugZsbAQg0CI+PhIlJQqtfra3vb8d7nB/Otox5deTZR5Hg3He9JZJ3vWeKT72iWk+94UZvvWt8X7wgwl+9GPCYJ65bDO8JDFL7Se6n8RzgeXafhLPAZbbs4UnAqtuCBv9JGljYAFTT4Dh8FE8ePufBE27igykTcFH+Hj7Zj974latUaq5XiaT/VciiDcA/P2fHXPf7er7J/hGqc2WW0QYk5D02pAFSiMOoe0+4VdSmvlec9O9/TjJTJT/w8vV+PpMiAzHIH1rDQXd1HRys9atpXc9kRYxH1c/Eie3GMWvuGgkAMs7E5VvzeXWIouTyDwB8ZmWcq6o9Otn5gD0eo6HTXjrty8uHwcjwclp6KXALPoqxpslo495s8iWkNzkQnC0egubOvZS2o2vghF1tbHfP7bziUYQG47X95hLadwkAvjxQHx5+CJnAO+FcHzQsEgS4x2aLpyFIBw/m1eFkjAM4UzyksRFHcjeSKzGVk2F8b0BsHy2Gy8NuiBNNhGgcw9fjwd/uysq0IyYtN6Fb42U5cZy3t8bRKDucqG4lbdN+CbrN9RzGLrOXQCMgDC3iF3r/W4k280V8bJvfW0PcYvYazXQJk5QIPqrLIFJUEuKFkJtJN+puQ0HBbWZRrrVmNy6QmBrOyuET6Sidyy0Owe99eOqW2Az3bf/BD53sPV6sFBJC/G2AtoM+LZu0240FeHgyTgXupUYhJ5NfBmjPuOOSUEv1KELuiUDt2ieyUlfcdVWWurnJBxVfCA3gbt+kXmEKXL+RoPPRjhthb1jW+o5QUr0Qe+0o6XY2ptu24O0mMNTRNc1ARkVabadvioxZvcr0vFN2cQ0s5+bJm3kJucmhVbh3K5YGA08LBmDnhk+O9+MG0IG7FDR0ZyWyxHGYy+lBJg36eVPpyazUnG7akuqRBqOycYdGA7mn3ZX/pvQ9f+lTaVe4e1k9P6E5WLqvDVehfNWL4JwxCYmgl7T8MaYpN+CVvRF/2SYy7nTIFhNzgJg39HL80ashxzR95OPZhKy4ZGa6oM7NpeDSbXKHYLV2rvcWhx0M0SncPamJ3EwCqz8a938b5idWLWopBMw6D/Muo7DWnO4d9M0zOpDrr+No78RfQRS7UCi1bj9keeaqR1BkVg0H3O1LPxM/6VOQanlCFym5sSL6IFADcFFaLUaLT3RFU12LJIMVmPPM0w3FJ/LrndTIaPi1WhwDmmZcqE46yuxGkZPcDRXEGwUVOiIIMQdW3RGCWVi9YtaDEA/NCCDqkuMTHlbTr5N0QVcg2ZxCPG3nIWIBSMxFVtjNLbCKGz54JwxYEZPrX7j62S429yczEfSH5YufvuMsOyXix43FawdEMDTTeh9CxfrUAUS3HQNu3DGx72ohF3ROZmzpjl8r3iSUL9GpaPnQmLZbcMw0cwxa8MD0XAmlG3Om0mkvuOgi4tbV03rltLLegbfciCNOonHqUnbGpNxiggEo9E16RSC/smyBcdu2p2+/gmo9zZ1APUQEayf3IAOn9hDg/DvA+c6oBhIll1c7lvhZO1ybKgddL7xZ6nwVIPr1lBJeyDH1MfrJBrb4kzQiTFJuMHl5E7IaKePQNxp1nr3AJR1dsJwdEpARJSSPCvKLaBzGafxqDcwiLQxfBijzyw0zEM+4lbeDFQFxEPvhlCsb/PB1SbSOgRcBFetxU3r8bYUrf6nuQR0GD1a01HZEjJI7+JmtLWOQ2kB8YObep2CL3GEpudQvokPnLN4pecptXQRAR3s9S6Wh7bzQ1iX33xuDjKTdrzDuGgFaVPBQ15I+p2Rpj3mIxOKY63Y9zxyaqC+goRyCT0SfK7fAzVD9IPtgiV4KXjI9n1DBM6zxiVFaSOrhp+0Bt7XMTObewxdouKRaHj4Fqro7iLPc5Nxj79j9xxg1HLPoMotCugGYPlRiQiDCkAUNQjUub2dCs+jSSnGuzw5kklZrHCjfS9txbv24UAVbHoJ2z96NWKfQOdxr5WZGC1lkXakb/r4CMTz8EkbnfsEhBphio65JpQ2m/8Oy8JtOHoeXhOCOX8E/2eiFm49nWl4jc+a1feT0RsAdKmNzKL3rCsiFPlmpGVjPha/DelbMz3GPQQXmobY1jtMLLk79Nyaxm25fG/Hc6cI4Wzc1idBKjyPuNDcLPQ0+miAvlZIf3YGnjbqnDYsIRo9FwYwNS2H2J48FS+R2/r4GMNpcEuppY/b64QNdfoSdOaUHqBu7Ihsnp/eAbfS35olyVyFZy6x80mbAOmHhZhVPHOXkz4olDMIdRgR7gmhA0FRXuGmqRJyhevt0F030CLMBHiD6D6BQLtC/Cg9ws8iDGeDcLLRnBGkpP2ROBC5PqDL0fbGTbsiDGh7oDI8fJF1wEc+qtV76+dw4St271CJcBBc1W5b9VwqmN+wF1binvgv6kCSRmI10uUOAjQQBGkjiB/eIP6fy+zWIGjQA2ixMECnHrhrukHD7qlE1IlAsz4Yk3bcfrMGuNfk2x0JK4/Lw9PhuBBs3Vfoy+W53B4868O/D6X78NUH3xsQ+/CLenpSMKHMZdFNAvSGshYI1y1Pn8EcrDfcxH/mmJYI0w3sZaOLmjpXSfYRFY9Xhr4fTf9HIb/YqHS6NDkojtFNVoUTLF3LhJhEqeuLIMwQRQ6Bix+ITxjhVsF5zgH39KzWTjTIQIsnXSCOT8e3Y4qdBMUOgtyJIUJri+tadMRu7yX15jZhyK17wvUTrxXCtYgNLnqLAyQjqPA88lSMVNNwM9HEXoQG3/CljaXuCAaqEJaQ3klFQsv2/PRamYn2wmm4lUT4eA3wPH91/QT9YHfUfQA95PvmHKd3JwT6MQwjBK6Mn2kuE842BTS8VqSdRiUMylJGrmpV9GrVoFRz7kYMfgehM4nO0HOvQFjjxcK00whB6mWZZEVRfm3QeKVbGI5/N7AE5ZNEOGQHCQEFNqmXHIAfPEGlZ7AZ2js5bP1Tk+OxJ3Qa7Du7Q53uE5oGRvo+9j2WUmLPAOL2EDZ0lL4v+RIaNBSfxEUGDF89jDGX5MNzO/EazVG0euo2MRzzdWwlVbbtXMPeiTmsj525iJ/F9FyFySh2zaJ7EGPXtTc2Wo1DwR2IOcqsHk79701yfiEcJmgEQu1AGGKsiD/2WuRIBlpP4rXpPVzUnmfjuPY65rDrDQuccknRd5C74Fs/MeLk7d/oF+OHv/TB3+38DYzDyrXALj2MDoDIKCWnhPWL5AFp0VBrskmpuTuZEHJVBC8Xey0nPnuOcyB8atdOFplZQl9BDnXX/HtaM2KtcDxrKdMjdAaI1oNgNvjz+cXtl1GlimJwv5H4mJFPy6eO0ygmyPjybzIY8ZaJm5YSfJQ3xISM1KgfSbQvcsh3qYX6yIdfTiW7t7tNKJE0owQ/y/fZWnYopRK7LtroblwTiehJCqr9GwinId5Syh+MkcmQZYr5OE5TkiJFMcUWUqYU5TXDoFW4z9J+O3zOt7QASiU/nh7pRyM+Q8cYwCy0DzMtgeSwkbizNbVJ5+Bcdc2ULISve2ZCmMx4XnGOQy5IgCnaGQyFU/E4ZLGxK8ygSOaxwlQ2g4KVXCKHjKahMKZTCM60bBAQYky6pHT/qIQKEq1AWc6KhXwYjgtnNFnQYho4eZMIRwuLcuwqTfa/N+3A40k16jxNuak3Az8Rc6RG5NUUxR17xC1Ihlwbgah41uVigcTPaYnYujFIPSySDq+jxadchQkHpne98XJw1Di/RgwfjWmJdFJGc/aWr1sTm3lLXqzhkfhkDnVF6BGQgu6Ivp0d3yaLhXEG9NMMAXAQS9iFJXopIgg1p5E9i48h7dEE1QOusl5NnNtHkWJOp7iaYyRtzXqfOGFWgYuEThy34ZxVFASxUUcs3CJsKYasmSOWhLStFQAHqHv3pSmLr3FCQMKjDLcKBZUgHQVZ9CnoKFPJWSsT1dSA6gFaGWOWl5Us1pfWP4LqiWKpNwA="

/***/ }),

/***/ "./node_modules/base64-loader/index.js!./node_modules/scratch-render-fonts/src/handlee-regular.woff2":
/*!**************************************************************************************************!*\
  !*** ./node_modules/base64-loader!./node_modules/scratch-render-fonts/src/handlee-regular.woff2 ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "d09GMgABAAAAAER4ABAAAAAAmMAAAEQVAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP0ZGVE0cGigbxwYcMAZgAIRCEQgKgcUwgZwiC4MaAAE2AiQDhjAEIAWOSgeDPwwHG3+BJeyYl7gdENHurUmzAzVsHOhh8B/jSISd2KQKy/7/c3IyhoAdplZqh6Utk+oj1HsNShmzMFGcGP1+gk7GO7yoUK2x3JZx87A6dFA1yCVf/chlGWOJRFXoFR1Wadg0lX/uwx8WljYdTii8r3HbHkctTLVRyrCsy2bDwo3NnWabaYnQZ+rzgikXAe7sKDLmyUP9Wvm6Z/YIFOC4A6E5BDLlkS1b1mzJkos6FxCWsHzk7h+CuXWLbEYMGFFj1Eb0iDE2GJUlaYOJ+WKiiIGRb8a33e+ngiKL1XaQYCUJzoEiYHBYjxOvxIubvjn7DjYUHmBpoYmJLQZJsA7uDpbSsszs0f3tzvEfLq1afms563YzXNlVB/GX1Eu+D3CQzPo4e1ACiOxvS/XVKxJIlonJAkycsUbHfhVVuMDA8SB2ggZAAfwf6qrKokuSizIAgAGGbUCbuw2SZVlQJc3/VC217uTXXfcbWDLvak0gA+oqMcLMtJSJM1GpKqo65ZB77F938pPY5l2W1yzghCVL3CBlj/iLl7oyfVoA6DOpUqaoDhyCoklRSq3Vriyf5WP77EM/MKy0ASQgbwkmQeiDoqC7QAbyga8bYAMcSGB1K8h4p7/37a+mwlFlEaYkzCGR2BzsO+xvWStlyWW3ZbdhDXi+32tKfaS5M6YyC/zQcAH77pBKV/s3c/fOc0XXLz8VPWsUl+8mb4rdtR4PN6PegtabpqTD0jRGhkYkiAYgkL+mvlFtamEOKxV2QEojOIRIb7803l3JY++mrdY/RU6V07S2iVJl/VKHJywdoPBfqpxSr3gOlQ7DbvhBevQ4bej8//ajdTFEQ4HQSMFbW1P9mM/78+bb6kVcq2oT75vp4k1MK4fSNicsRELPENWOD47gYYEo4CYLzBpPnYkhaaR75DPMYQ5jigki/mb11fnrqbtn32pqQpAgIiIPEQl1msdwLkBX1f/92L4u/Js+L9uEv4oMMIQBg+5ZOOfGluQU/6flK5Bway7wFmJn725SJwB8aBmmni6c/v3TxYYA44gBEgTERRDwrwB3nRfp44gv0G07Ig2AeOZgdSngbjmkHPd+vjVOH60sBXRC70zwTgfQF6SXNv0/fgd/gM8QJIQOMUIeQ92hodAo6Ebon7Bu2CHYcTgSzoZnwovha+CX4H/A/0IgEWyEErGAFCLzkd9QzWgzuhv9J6Yc8xbbjFPiNuK5+H0EKWEFYT+RTPInXSL3UtCUQeoiGpW2io6l29GPMrwZy5hk5h1WAmuajWcXsq+x/+CwOf6ca1wj9zGvk/cfX8hfJVALjgupwmbhU5GjSC3SiKJECaJKUb1oRJwgThXniyvF/0mQErzEUpItmZW8h4ZKfaUx0lRpvrRWukq6jdz4HPY9a7AN3talN592hpgjF+ylu+eUNJcqsgkU9ifgMnaAy6LHKKnisjRRTlTLbuiV/Uo7ZYO2FcAyR+EJIuUYcc25c0/uHQqs+KnLMjQhHBIPJefSywxIoSymSnk5VVmoLrSrTt5N9LPBcjQ1npoMTRPzmfuJTxkRuIXoUZKwDLMcQJkozpWGymPVrJv3FvrZiMMMRDtmhbVGzOYX7DFgCJltOtZgQE50aBWXM5/LPk/CN2dePNylpGNSQ5kHsufkBipjzTAsJ+WsXjyldRDOe4+pnxA9jin3hPcRfhXKhZQ4I52RFJGdZZyoLCcduz/a/8Gr73n9PSzwMniKLByZc+nqSzPL9fAHglJZInqHpNqWLZXnimtKW8rPVDe093RGupt66/prBlPDPeOuST7dMXuI0EL/vHbDZ3MISwVsAgyQKXcpJTKrbJbL5ER+TE1p+TGw4xzT2azu4mgPycAx511SM0Il9olCkpbKyKaMyItun/hXa8zOWLaBbXIuns8BU8ISwzJwiCiZGttlBI/2HHZS2s9yGCoy+TLVtxdzV6tOANI3KgtT4ZBJSUxtN1wE0GlI7s4XxIs5zKBlVhlqBHb7Ko5Q3J4ropueZ58MiZoz2eAIDfVJBcSyZsFKWmaXyYecL83ONNRbWiYgIr2x5pwp9nsGcclezjLiCHHKwpjKKG3JaJFf3SX3FXoptuUolVU1S62pg4Y1Za0zbeuArvVhg3cZ1eOsJstpNWvnfLbXbm6f6TNOwFT7W6kvM5ENuShgEJWeG+0g6wQDH3bPMOkKdO1ipfqX2wHbbThskQDEo662oUaQicFdkXYlQcrSc8nsy6bJblupu/fVohu4AEsUtgPsI6cYAbFdl7Ql1SE5WiemiIgCK8z7FUMplutqZFIQwGCwYXoOfYbttLFM7vmMzNVGW5CLvXvGUXpzfuLDxBG745BTlS6kNBQGhOlAAECisb/MDPJRYpxP+qbFrJqn7NqDHxLj0yIcymbj6g3k0g5zmuaq18mT+Q6wfdweviMYQl3RTxB6xJHb9m4sWacXlIsKoXhD6bbyZS+0KrzGFxrFDifss/BrbRpsGT42WhivmRyY3jLrmD+12LHUCq/+MscK7uGOw+pxqTMzwZbAkbdTmalszKkS6ag0FcG95jRl2L5QF4tSVTYMCgRBEADBUL2g7wNwqGnQGDQ4TBb2mfbaMNlC+KEB+PjTxMBLvNKCvRkK1AEAjiVRggICffPkAlYzcmOmVYI8a7oWeOC8AoKCAAYLiBmz2wwGugRjoWi+AODOvFHxe0JXC/vELic2udL7bnkGSlMoIggCQupUQW0rMxxymusvowgdPBqki3pUZst8C3MYiTDGkP7LkH6E/gsxQjJz3Oae8p7CmBIfl0Z1SvpqNKX875KustfJZxSWxdKgyNO+fpRkI1rwPl/doBj9xXhs8l/Tcj6y7Pvkp3Z/tv+zw02Pc/of+IBcpQAS7UIvj0Gpoo+GdaiDWwbWlYhTXj3IHlhaK96tGeI7ia4wQ8A4AXBJGJITAFgMBhQjBsSKxQLJAEqVrCqurJqQA7/OKQ90hT0HniFXbMXF6D9lZnKmnhaKuWKjUM1Ux6C3OUFSJo4H1zFX5x8CJ8kbRT7RCk5gX2uEaJUIJfBoBoMVU7c9vHtG0AwwGL6rEYxEkfblIVSkNVP07vrZgYKGYva9WjvV2wAcO8RalEBhkVh0Ao0tZtYwG35bQXXGCIRfplnorsIzB4o4/ykFb+E7j2HDnsPdx98W5CR0Txjph39LuCPRiltoejWYDjKjPIryIYWR4oeUPqz8AZVHqh9WG6onmh0t8xCP8DD38xCvvelPGj02/qjJH0zfb/Yd8w9afJ4KsxzS/umzxz7/iS++6Muv+uoLvvmp77/nx89aiduU276ff+eX//ntK37/ir8f+PerHn7tcNHjFTofJl5uxAZAF6lCLClpAtOCorKsSoaZ1+EFBDEA4owKbGns7syLNvbZXXf9fxveRBYxRjMjiBxQsPtALOZK+SbYLm6OTwXDnGba32+XsBKLdJtHUp4qPlNaU36k0lRfsszuDZ0t3ed6LyUcglwzQhB1KurktBiykH0rDWPEG1ceTt3DDAUL7Rs9XBNNU4/lZEre5Xg92WBZAINCi0LBkSBKkZyk5ovVJkDgKR4Uk3Ejuovkyk8vSvADoT4hQhwiEShOUYWVmJipqhwKmixmsCLQNEk5o9o7pbJaloehPGMOLDT0xsN4WjJdVE79VFePZ+Vbwz7E7eC3BcvLBrRBxuiDhCBmiBvzcMo/vZl/mdzuV5WiekLNQwSZikXd/D17/9M/avDY8B9G2fiUSc/0jNm6+TmLR4hfTkb7g8+2fH7E90eseG1gtmi/XPP3XQ/nHbY8pmhG/iPhaLPeBL8QikqYE1dj7bwN4lgMNGGknbfoQ60B5dPVaGa8IowCgy1DA/mdWwADnyXccWXTOotKwEkbIjmhmwK3+CRuoKiIyXKkYvEYaE/WcaM7FkOKxIK1BB4Fj+59YsUK36/rYWoNnhMdjiFX4c4bvVsCFTdCNWRvtyY5kXosXRvkpkIEilzrzgb+taO+cVaJNGZYFttfYMAykL4o1ZO9QZ7IM1MBeuCYAksEksBS9WSImRtWqaj32+XZrsrCSYQoMbuGxW/KTZkIvy2C0PGApNrUeorkbOOE3ITcqQK6lRfqvPKY3R3YJ/RTvmBRi0cofDGzEGj4GIqVkSbWXmvtlG7y6/OJNsNyB4KmwMVROUAd3JvJhi/G4bME+TKxq/SUHVoPG5Egl341eGDCFimLkWvi3CCQQPTbdAlkk0tCK0lbLn6WFp3NBJ2H7tpZLACgASzQt6309tmoYcgYx/S6DbPLknrixjmaiYMFCZGGdmApMOLLGTHsAlcGQHN7CHbL8MTBEkwkz6U8lZGQ9UROnMwp7wklUUyUlmW/7LI6i3b1CIMmElHd6vPrPOOgytB6VnrWTgFx8amHQuSg8L6sDgu6OxQkyZkaZN2m5UaVDkTHyhyf0GhU0UKDpIVRdWK5hpIzAzKN8Uv2thHaSaxl4N0B4IwVJ4a8ig0Me3bzMfE7xiJMJr3smxQ7Hut69iXYGzB9ubsNuBbcbDVAaKyyIe9uAmJ6tpmDwJWDRqYF1lUyfFZH97o9lqmbpNXWwxHQh1sXdDuZioWU1FKb92GkSdRnVU55kVgmtwJRtt7eLae9Cuzq5DY9V4cJfa9TeedURp8MWAVYzMYA48bCSd+QbFIWLzvkgY0tcC8dexMTPTeVAx5wCZ2Hu9HWuGCmdOyC1eZYN9REn1InxIo8Qt/tglQi0ADXIOWcOiMU1BmEmKBdBDcEIFSDFK02tYzPQkgIIpF1AYBybf2SjEtD8+K8IQBDb5dhISkb48Oq/Y5mjtccDTFyBadoJgTqFXSjeMnoDSMgCH6aQpxD7xfIfkkkZ4v+93iAGHhGkXov+nt3XTups47D1LjlD6VS2J2TsjtyL6XCJgGbABpLoYGeCzBhoj0z7/PC6wV4PHg0DXILUuqQ+igldhVdGLR2TZ+ZAYobxKGmenmR/5OGvFC0gGj001BGUxANyp3So8YyGX4aMKI69koySmwkeKXFF5Qq/BjnvGVIETR/DHxQmcGuf1ZUNwOhxEh1GZhU5FqJJlvmpspp0kWFDH/nCE1sHIBOM43fzQnQw7vtjkTNK6xw/byQC5epJE4QNBabmNURZYhwFh9bGNg4uoGTD0BM9uCNdrUSclEvk34rNZDtkLNqYYTqJZs32Q1l15kG7xNqxDwANQ9qTahbi1UTzF6DQJa7Pq1DiOBoQUHBBwYcAQDkbjh1IFmkunPqAuYUvuYbDLhmvWN8IhSVMCMqzUmGXSUgU1BFap5236caxEl6ybjj2KkrJF/SUrch4IRjJZRLKMG2UjdskUdKq43HXPk5olDz0yXp13XvaA0IuInADD8XTLsUV0qRsEVQRffE7DqI+034DyIBRG5XV6xpZBEagbQsI8vercwNKYcKVkwrMZWxUqogtanUJ5oqral2WefOurS+44Ng9unYaDmerahIMluAILuO9Wgnf5MkmfARf0YwgShZQlELcjgJ1KGukgwaIhOs3CjzULqWIzaf6zo6NCsoEFDrKBpQDs629wmEiw52TGcHEXOmlnq9wlReO1Y6lM0Z3DmBSRyCwLAqcKlxaSK1wJ4JUcGWYDtBe0k6Cm7P1Z2LR1jYICIYWTKPPE6Bu4vVnc2NbkT+zZidW3vXdF022B9xqejxBf7RnD77pdoRa1YbUVsxOOwPwDnsGk5lUxmqOxGR0MEnh5JD9vvHhs8W71CcHa3A3A/56XfDhns7zonzXtRgsMhu81JZ9oCxPmaajC5HrvS3vrDZR6nTujG7qyVFNuAITv4jMbm0rs67a6QNsaTd/gRwDnIEMMzC/lf6tA2CGDFMZPjBIpB0XMkkk1iyyUZPEcXEUUEF8dRQg5FOnUx065HAuHFmlloqiTXWS+ago9I56YxcIIA+digP4JjDQnZf8BGJZgzEGMSn/m0OAu5cpohPnPkHSC92vwHMX4E9fCcXPpVVQIP4P9imDgWqpzHegIwCxN7YD2j+1que1TSQn5PlxiD3WniIAduC8ecP18oGm8zYaY8DDrvqjt+885/vOkVc1OeP+Uv+1hCUm/JTFMVQPJWm/q1i/IxaeN8DNKy3yRY77bbPIcdc95N7PnRA+rlnN+GUk/IuTK0K9s/xwftWW2m5xRaaa7apJptorNH+69mu7fI2aXfa7Ra5v/H++vvr7q+9v+b+1P2B++x7G/7Y+kfeH9mI8wACXpwWCf7NYqF7yvDa4Agk6rCmc2zTOcD9X0gilVnILa2sbRS2dvZKB0cnZxdXN3cPlafay9vH10+j9Q8IDAoOCQ0Lj4jURUXHxOrjDPFGU0KiOSk5JTUtPQM0NrW09Q6NLZ5Ysmzp8pVTk6tWr12zbv30xg2btmye2bZ9x7HirOzc4+XjRfkqnynN+7F50dn1ufM5ZQDg5AuseFGTCQBOvU+A2s/g7j3zBxaOHDy0Fex8CU5vnrpwEVT8joL6b11Ha1d3T2f/AOi7Nzq8a+9+ALy5BMBrEJASEoCPAHEfiHNA8wSWbtph22B5PRIMAmQg6GcPthU/OvtwS3+0X+4rBEEHgvRL7u3ePny3SXnwc5O7B3uJ4AnKzvvEb+/5SX/IHgRzvkpv99zh7rx3eEmbZz7MYQ/f/0ZvWsac/9Xds1aKUF+kyO7dvKaE8sZ4vd95U5aGG0YB1PsZdSMsMVGecafg03oyNvVhsRgJluDdJNu2U7hPUipl4MVG8tIp2etToAFnpr3y9xGwY8+d+aZqXSanzjRbtxkX5vq+IkCFrTqGAMYTqKomq7mKSrWaERLZRJLIJQqJABMZOD7ddnYnO7cDJEtCjgCHQdAKiqATDIKAYzTJJkkuAe4i2UgSyUUKkQAjGdiQvnptvRavndeAbFnYMeAoAFtgAXbA9Q6ApKAHqrKVVK4CPPWFhlt9A8c6juoaBkJRGMmNODLvKuNM8H++1c/C+lqTJh+/SdB68zwWeB3IIMKXBsUH6Qgbggj4al7GArpaO1sNYNAC1jZ50NHiAo6mjZoo4ueodPxuGvSaNQdZwI+R7XM3ubAjn+c2xccgDtGvba178t1vFMbmqeYGxf3evBk6BvDcPof2V8maUwsc5Ll5Rq4svLAWTqIjJ7MzxWgbGBmoHatFh2WYRcT1PIhhbu67b4IKtcNcTsZEw+R+gvh480IN/l7zGSrY7NwoXworbKJJcRMnZvVs4+8NQlKBuAghR/l4OMYKnRS0Gf6q9GtL7vjPWhaeVX6Xl2YgzgXhGpXnZkijAiiwjBEBRXMceMGsqDfQaYUVRUjOZhBBWHJlBWaQCaI48PML6OemueHA2PnN3/+ZeQ/kcr5sJ5wOCEMeNDB+xmqzZxVcJgfDahgpDLBuu6tte9YLyzybzRZN3t3jvwgQ/RyQ4CSCJs+Vx3EtZPqgJUoJsT85w+902xoLcIDlQpv8gr6APBBMKc2MdjiRQ+E4L9KRljbKwN8oz1Jzvw8y7cqLdrNBaB12/rXEVgSkXAgEUA8DiFYQViEQjwCzuG5afwkYftJVLAkFI2UQc/upjhpzDuQgsCs74vdfqOFtIPeY/uQxVqu8QuNAKbQjOjuAMvNiVkhN0FWiPw91PqlwVGERCgXPE/Yb2KS3dNOizUARKWy3FJksU4e0lAvX2MlTw1hmXZqwDqXM9WSt5nkcyRVdhaqg20hkKHLHLAQAFU0C4ttCN5ughCi+Ph/wYT567+UrjajH9tVjhiY7Q4uQkooj6MjB7GDR5Gb7icEJPpjYUF8/8FrWlqCS6/C9+tHpM1R3Ol8umuZN4RSxjIhLQRHEr7BQo6NYWmup8iUr+U5pVPJ+mgD0Id4ew6+YlHs67sIa8tgDW3vHoYUVHAQ2nW8sFGdS23slLSBaG2pWlcJxXR4vp2e5DyjJZllMC6hEwvkkLIYyY5jwMiGIzReC8jz7/wg5M7hgzl+QdEQURgrJlAWYMrXStpI2s0hABtWLWFVrHU6x6zF30wBiOO6PaolIthuTFlc3SiVWz5zzIrZQnFKYNJAeukJr25vvR3zbR7RGVMwyJxSRqc1av12z5ZTL1r9bZGInOsRdTynyHl/D6oTHjaSXEdHfxTKm9thpRmUj9xCxxoCLa730Y8jk2ivWCRNYvpkTNV7OplDADgrXGvPc7EGzdhyAn0YtROmwZRpdp223FLTJH0CGx2tgkBjHVlkAmcW1uHadf6F/Ia1GkGlFddV/ZICTJCObLU9l3vdmiAZ43IDmNVmNcMVbnXzRAMxCtHhYDdfzU5sajxIJ9Z9lAfGBmki4DljfGGgUAPj1CMGMJcfEjzWWaehyImJWA9rAHAQl8sNq/J8TlagAjbvVMPhmT/Ufusxb2Arc2du7vFic5DpUYZkHBZcA+LsZ5ykUzrbcZtyUKaX2gUgyJ0XLsHcFK3jp3HVsp55XGIedR1g+97hWCO8Z4+Ch4p4A6qvamyQS4aay2dDEAvH1LP7tDzk3DZiAiuKsvdReaVcVtd165kblS6a9Lk/Fm8zK/w0V5+dNLlHufhX4sr6pmJgJAouLw7fmhWAUARuhIEBb+atXM8d8nzltUw4WQWJTm5+4FnA5uy/rn4NtfhHJL9lSTLyBFFyBWSirhDeg22Fg6wPoTLttyfN5/cbozRyzHjRjYdVxJkIiVHcYzm6RC6tkhrVbmuEL8m0HuAT+tS3iGjTCWxFqtJbMsGZ0BtRHaB12Yn2LNa0G3ZSMTAjmyb2ulAQHvOpuCxHouboi3U2CVGmmwsghejYIfJEYhEYtlsRVUZb6YIRLINcZ2lI7Ux9vt57rZLpvrHgVCD/hP0bHyG0LXqdSMX6hRXVExnpjHkvKoxn7siWsZq2f68dbMqzUVIeTmd4DBlzEH/ky+IL88Q2sR2ccD2pvDfX5SP/v5J8XjLmCiIifxB8NVaLSs8TDxmpLvwECzzaKb/2fLjOAWfZfxJHZeMcVDDFMK65xpLa2NlOC7zWX6UMpbZ1WPjA/m2ld108Ou2Yo7Ddi23vCNVzvX6rHyRzHDyDyLRL4QPBnzJZivDnvNpWw7EQPt64OlIWnI6YMpDr8B0GfKqyyvcOE1MM6yPmOt8dstUzUq7AaXhc7Fq6siQQCB+PmlFXujKETwwqx6nRcUowFF0p8YfjzbzfcdAJXe4WNR+hakcmo1npNoJaH2CoLCrQaEz+6lb+yF7HMmmjpcqOidasyGYMbnXHXfR2x0G/PtW88srBS+uHdhz13y3aXL+yytzEGFVYwfIACaRdfiPgmKmmvL9y+QVCGjFo+t4YgPIGOaj3yjjf6PHmDWIKNkJIZELc0TE+abBopsC/Aj2Hg0ygo9SVhj615Pd+ieArB7k5mRYgKCChBrfwT8TrUGDtBzxxj7IPI57PBL22undV1tEkavhAbjdvfZs6kbFFtt4gjwNqZBK2H5KdDyYBvHwxWWFjndIz9wgyZbYWEfAF8Xkw/tzMs6Y45DgLcIhO+LDi0QunLTpp0rcb4p9+JThhJURzgSlP6EDi4MdJSK7s64WZ5Jar1Q/18Dq8/5SqXCr1VCnr/6SCWhokbF1+Nla9CvYOwnrjvTs6Lgkn/vhpW6Cofheoq1qMTadXC0OWzbN6ErFaVDURuS268r2KKmyUZJZIp/o0Z1t1dQnSwOZhigs5scfDDVPtY6VmIWaUW16+WiO3dvhvj5fx+reO0xfeWw4EdT7LP2VvAwUYN8yyX9/UaHvhDgDvMd4xCvBF057HcspRdtDWq9JSzvv1I17hvF3bVi2qG3t7ebdmmEBIyWSAgYULh+HNtN4xCxKvrvAKkFMbrrrRXrBGri2/l1IXf5SaJJMQ09Eh/9OA0llt+sNdp3wxPegeYVdVxq5o5lsnoCsBtGTdSoEoPbpnbGCkbqlTUAwqNTYBwfaqhpCTsRBETDOJa7nxJ79mwjGCV/7aIGOZd9EvERaXUZi+0ZzWsQb/C6uo0cK0v7k0kt9fJEFfieRS/u9cPYtZnvQNjyqkZcnEqJGNlefluXEODugmXj3PETKYd4lWXq5Fas8YgM7XJDbpDe1VNgj+OOhT8INFYcL8FbIP+QYNAM0O0cG2yRXEqag0FXcw+Iu7qvF2Sze3X2tYc3Il40gF6+/ajFOk1kWguOneSrdihpwdPJ5gQOHLYwpvatY4dRhW4rBaCpiVTJ2CGfp65nDnpZKAqEOnQ2o7cluk9ihepMeQ8E8BOphFHRQCZdT3IwRe4d8zqwK2yvRbGPv1yBHAtgJ9uf9SBlSDSu3q6dWKfhbi0eGnG+8morC+JHHpQWDiilAMxuLcVcu4bpKRU7Yyv3BDvMelmnaJRSdDGuGplY5vlGA+uOSx7MvrCu046dhl3RkzQR1yv8UpobC9co6Zys7nF7a/OoxIwxlBZcPbJ5TG1+d9zzDnRJD7XH8obAi00PXnDVqSSOJGNlHJQVjlVs/cjRqSRa86kcYRVXxjy9zpYtFqE1SO+FI6xCeKUrJQQizvAQjWxyYt01zgnE5Qcx0+J1kQrq/pi3thp8Xtd5i+BjDgAHjOw30zgtX02iHzWHHbr8kxMM9YOgEnwclkhl2Mc2hezRvEsiHNcMV43nPTcWkZX6FqNXbEI0e7eiJ67NMguAH2khsQ9fNi9Qwzgz/DhmRw3xtzFr86GMfaN82qQj4dDxPUThZrJ7Ex2oS199EvpxM09EkPcPyo3/avSqHgWkXx7EPw+do3K48hHQyEEneTvtErhMBYdSQWOeY0LROZUz0ec4td9/nXzYLVIlvgeGziQkm7PleErPlgcNZU/shdM1cD0l8y6mPdm3kYGB4GJOmwVV1jYR875iJ7jkeI4PdZ3lR9P2nvlFqLIH4clawpETtLkImMlUdS60FKwmkwKLcXeFzTp8oarxxFVbnQTff9Lx4P4NrZ5qGCISQwtC0vH62zcNZgbl/VtSbBwAQUiy6hRYEWn0jgq04dY99wMhCbAXdr+I4Gbh82AIrN6lYrkAOFYH7tOOAtBSU5v7EbSjCodKEk3ajN4NylYVyDf5VW4t3C64Xjyf+P5WCz6/bjOulkQnd2sqrPSW5Ii6mxb//64bXyQIsYptK2chUKnkbJSSIjAvDilT3vGqfLuvKxIe+f/hHatS1ViG6r777hlh2QITAN7wh22bpKTTGsrDZVMSUtMpjs1/61YuDEWhNdavSJ2F03/ZSkkyVaTz8kpHbghHVlyxliuFJM1FInnhLJgGkSDwjVivabFxIGSM1NPOrhbrpFm6Hqn0vJCHefhn8dLTlBMY/oTO1NjKloEscWmug52pcL0asDwytrXOMMQq6+0zVDSmmboR+knspNgWpru6cmmsCtoEnpuQUk/CuqpR47U1uk3HnWlveJKTyuhSHpKem56utWzN1YKFlMnAW4pCff077PLUWrEvlA+QC4sf2LP5GVDzmguHWHOo+YMkZn62ATG7yLG0ITE5NoLg5ZkSUpRclIENCqibgrkSEsOBRQ2P8+nT6spzUuYibKDaOE06Vaz6/nfYfLDVVjgxRKZ187vJthBzX8ygzE917popj3Z4/H+3KbNW0LY/2zxbtezogaIaTb2cQ3v54OjpoovblGBz3W6oNbi+8d1vtVQf/FnXMDKHGXxMhcWkCudUFL4ilPGzf4ccKyW4fosN4G8TQ+Vf+KwvoogCcBjYk24lhe8TMVYzkDGHdLGQR77bmP/JDZ5OuFV7YZBB49BX9y106aknEgry2JeaE/e5jXlWUNeFZ47HO85y9mGtxEO4ygL10RnXOFkzQpKL/zUHLF56jXAH2p9Gv1/1FfSIoo0Y2hfoJLe7jQi5/QgJGRGnBpU5EX0sC6NY73mku7CuM31dj2IXlZ5ZuH3abZUpSwlfBZrPlD6rsj2540jtC0bABoFxCKiMy1fNsmuTuugdMu9vZEeykq2IpF4McXjd4LnVdJC4vxNwuqinWKj6M92tbZmMn2ojJimhSY0r5YZ6MgTOY+Cdw2HkVf5GlN98fFqya5dLCBo6iOZlMUuIxUbYaujbBftRClJYjFlPDy9uYrl+sxaFzIdRW1zoNfQG6LajDExQBOncwk/itkgGjaguB4vgKiGVkWxkUhIo7TzP3YaWni9f6BkHh1iiV+MvULk0AkTKPV6EUsxLZ8kOQK1zjqetIEqrkLicczw4EEXxuBG0gLuOpy8kXQZdwJOATv1lEqxPJsm8BTVw0jxrAiDLRlNljdqP0fjWDpCCPcSjkXiySoU1+eGKL9urLAs58S0XXigwqJ/1mFvOFN00Qt4FlnAiGCumM7dil4gaPC1uOhSKIGvhRKdf+1Oxc2acLp0Le5f8O8qUIyaZNGqDNrAsN3Q6mAcZA9I9L8X4Wh6sMuBW/TMpvErZBSEoley6ZDlkPD+SE8nKHKc4X/RhILBw+QxYTVJiewe7wR1DGQ10jOk70mHQMNRcmidN79BpoBUVR6Q9Zs511z89gHSz9nvz8iqY4Y2D5F5Q8Ns0dqWfbscfb0yHA+Xs5SRzgmZ0V5WDFmn7yjCfqevm9sxbwoCVLygqHi2BFq0lIZE5mFeo5gMdIlVARC6LCdbuEeOBD2lf+WSb/sPuVOwlTzK3jwhuf1BFZZMJGv0m0DwAOVMOoJGJmblELbjxj6RssGdb+VzZz9tOekCx5BwBNPMj/9erj487IaGAchiJMDMUC2KL56oOCf/myMrv3AEXLnyjW9FiodJevB7N62VkcL17tsNiihvLItGDJYnU6HoZJSNBoGKFOdO9bszjufXmkJfh3is3EuIoZmOeX+JQyiRoJboBKlT40UyjBjSJupsI/PlhdMZBDik1APzWoNHbIPAQ6B+FEFPJfiC0dsShJbitI3F+nmmJ+mg0R+02xxD+g8iRWRmIMsMdfUHOUg0H0fRoECSYNJyVvm31TRY9LHTjsr2H7jrk7BpvYKKgFASNt31AZ1Ze5PtvGs3XhlOjtq8vOhM+e7cnx6F12Z6TwxruisSfe38vYgSc6aKUsuLvAy2bzL/ks0IwZBRLBtkPoEWOCRh/X3Jmc+tDgRnol7BCQjL286IDzaZXwJW9Ha608SKwvLSkprhwaRSrVZy+38ya8iqISU87PzH39KBNnWbR4vRyyenx6jBmiNVxsm2JIcMOzcXBNaFmZNi8EwLD3AJ93eVQM684T+9mp0lveZk0ErjyNNGIghbhrqPFcjQNPR8TgCEOvYeQmFvWPIeiVxuiUb5B7ywRZegBrTCFdBmLhTqMCzd5uPVTvtdJfL3eZfzHKIDZ40PYZKYqSp2SBCyCBJBjBSTbBPW93bHlGsJWiwExVKvy3D1SyksCMl4h0aXwUn2O+hrlEDA2+buZ6yC8f4KATtfuK0eFrkH7O0MVgSGlGYVDni1/pkUOpgWvbC4zSRhUepvkbQkS0meXUKMDf8dW725T78c8BOpELdJakaCs7uFdeyp5Z1yFgkpD1iRdRjq4j7/m5W6WDZI0oHo7bIMjlEdpAjq1HhkeMcdiDzUoQjebsW1G/cu+L3cLjQu1HmFacfu9nM0nwy3nXEkTWygyaovn+cYl8U9aTPcbtIvtZN22NvHFOtAPBEftYIO9KzU1CKVJiAopXb5ZHk0JASRH3CVUEy1ZmM+SRJj7eCKyJG8txJ1bTPwTdljuUcutKj0zGIFKxxt2+nWoHsvrQ/PSPQWuBMlNDb5o2tdQzQV5YCdwnUSy2oXzLGgF4ENCrA/3EEkfj13cHqTu8L798fEeRrayS/Pp6WmJA7r3Gk+p9fgkSrQotcgA79SeL20K9BTMrvLTX8BSVkmjEOkXr2Lm4eeYhEUIFqODfJ3WhhmpdFpS4N1zGJX5FjJRPCNQ3N8KdYwUO7IevH//N9Fji+qoY3SftRalg+8uhHklRti8M2iEK7i0TBg71MQGKVK8zeNakSQJVbf3WnPapBhmMmMaE4vVC4qVQZkcy2igz2WxpaqmPviOKEU3CtWWs4ptXNslmLxYkmRIcTPitiBJGApKTR5fkPX94URuiyQbwg+RxIqEmLBEvgXIboilr4/shj2Szy6nz4d4X3aCpeHDqWUkWME2aIQZdjmGxPpZU5zgnnesSNO+xNi49sUtdjsLOyFFIQvo4xpACYfVKgG1rgxyehpyikJpGdHt6cXJP92QFN2N0Imc1uWaqtZG35yjhoEXbPtpOmwVRrPyJ+G1jatqksmJot2gW7XN0lhNeky5fpFufFbksqXDH9NDnxp05ERpIg7l/xt13CfwWNVZv2SENMUQCH00GD/89QKUmmuzXIn04Y784vDnVvizaMVvq8LOnbuHApMsYsl+TdhGjXT11aDyMsroboTtk7Su1B99ZYCvADcDa8FgT5oy4yHSBQGUl/ySbVnAyb2Fxr+3JKH68XrMMRTaI9NSkiygUGZ12TDH4FDl4/zHm7w/7dBjUbZ7oUUH6rARC4WyJVkaQS6PBBFRow40Gy1nmlftXDCV1w+Rb/TjY0xZwIumHZU0ZgD7JGv9oR9Mz8E7F89dPzJ25mIHp/7v3IjYnVS256TDycbZwfqB1QGN11DLZd8vY4AnGeeifBLkcW30EGkNmGlwQPxKB51q5KOOpPaJeoWz7InSafF2C5bI263tJ52JQppMQamj2FOgf/fsapLbSD3MRs8+aD1cATDM7omrqbUv8IjtVv+fPh5niJxG+3fOj8JWH0C+tJZaZL2p4cZ3SOHLfDWuUuWVESGp2a+M3ZHqDDapFxdS1btVKVGKP8BXklxEBTBpHMSHFizFX4oD5G01+k6zIkvueGyFoOFF7yHpy0m80Dy8DS5h6FOKzV1JZRaGqr1g+nVXmR040lIPRJxkvKYi1uKaIyCzvqFVgdUxieHpxZVHmDC4+ZgYC2887MUUwnAQ4cu+s63IbuNqCt0KoO5Z8lGZqK2OX/rQXPfWGSGxgveqUBs3ePhBuuUWGDWfi+4Y4EAjrn6tm8PWtpUmcg6s2+1WT3Ky0saWVSkZ4s7JlY2Dm/bjplZ/ef0OmDSrsLXinxm4hl5PSuqP54aHw6NEkTrARsTPOc/Do1FUyDh3kEHQx0vgqHm/aOJ5yPt4Rrwc//F+gLT90TQyPukP8uv6J1qxn/Y15MeuGdRvXmiXJfj33zCiRGvV24cHfQryfaaaOemeMTkKKc+Go3HsrcQbMHSY9Blojn2NL7wEh4CwmPuVGQpPbTGIof4MNXnKFk67p+i3G8Zjq6Iz7EKojQ+KyNiV0e2wcRAT1INywzVYe+iMcdDwWJsDMvI3qgDew4mshIisTEcNwviiOhtqTyy3VQaFmLNjhGlc9JFMbZOUR4xq8rqknfpbHATnNSDmyMcUv1bYgKVAd453FpJjiwgukypB/hJx4Tor3gvfiyrCKOj3MX8EGWD84HviqJrA4axAg+Qufdz/V6J4MxScrF1rSnUL6H7jkPwmFbSGV15YLluQK5p0vclq1yNGH5W3W6A29knwVZJwk0k8yuPmDLfl5x0t2MBXRbErys8Zzwu+J41djkFmp4o6xwGfc+Cg2dtqG2hxMZ12ARW1BuxMjjLahV/LXf54fX8zDT8f8whi4wwTYZPIiGc3SNgRXcoBFo9NmkZb7m6Mz8y6Fqo4pCIE0gptJn4Mbi3CcQ0yNApVi5b3KBrRMDvXMLOqh3eCYfuf8X+QZZkV7YcPA7zSHCP08ZFO1vjYvx1JcWdkQ3O2uHV/nrRGzInIrVocmClps0yYlKEBtF+KxVljZamZYwnDhh4fNmr5P9zr4gJT6wDZ9sHlyy554VtFcYKg+0SMrpA+fwslrOAQbpXbb8Oz2r2COv0sUX6b9AbGrA9EkxjaElwn66WjF1tyxaDeZ5jPJNMY01k4ltYxHzxH5Q6Aid+FYyJJ0/uxZu3EZzcRY6A9x2ausOOd56S1gsjUbfvsC2EkdJ6EEJqh7HGRfQYdgmRDxNaJWRK8oh0MULb4U81oNmdQdhtTs7NEBoBqKtA9lyLIx4mcxV12ZRkXhQ2TnoW69cyGBM4QlJv7lnGVuVh0BsVjll3En2cjIYhO6Y3IREMbCtQRJ3GoHQUpCSWnx2Tgw/v4KD0WVGgVgSvNPnsZSCng37N9LO9uQ0To9Q0XXijt4ta4bQ5rdJTzw0ogJYT0iOecNyzLiZ43vLQuoaD4CtzYlQG/RMguXzr/mdf5WN6eGLjCvv+tJw2Q0oDIXh0UZPVY9/Q3lCPUhfBgaPMhJJkAwYM1kot0+9o+Fl+uYKmEu8oV2/PByf+5mLg8t76NebsmDyn3I54TaEmGPBcJHKTnDvuIlxMD4MZa8qO2ga7KTOnpIvic/0sv++5sDK4MRmbZkmoaF4SdEcdOeEgSBYooktsRzx5oOQCDeUdqs1+dc9biHsy1hmTFZydMOk9VplbF+roYJosN7HmHMK8hFr3FXxnwwAl7ADoQVId2rF04vv2R5VPSDRfXiyMSJUUzTqdSy+y8H1AR2WITjh3lLypQnBxBpQzi/R3KOQWLwlzOj8CvPiUJA2zZAV5I5LflC/6OSTIxUFvnfrLU3ZgDgmaxo3NKmxVl49Z9SdmqE7hdNHiNLFfxkK6xFuvFOOA5gr6mKteJCcWbnVGzyn/a7BVmnEdMA1mSglhNAXhrnHtlGZsB7ydYeaKXQcFWxSDTBnouIdU2d9jCx2hXLh9nqPq02mfQnoh3JANIL+JtrLm4B2gsZ1n9SEei8VIaF0/oD91JHtHYh9RFdYsLo4XgZ8fw+eLsgNUjvyjeCJf/BEMPQFBQSAAcRKdWFC8OcD7x60eS4K90iKOhWJsQ8Rke2Oqi6vEIkSmMHry9LR6zxtkRGwCCj6MLcxxcOCBpPis9SfFyPT+ei0iHrc0+EgYCMaYZGVe/sRsf0gUKoy0FBTsw3UzQBIUU06PNV/9S+HmWgBM7H1FSnmKFrp8mbYfoVkTw3VxNsOyLSAJdtholtSXj2yDjKEzu8BH1qiCL+CnMy+lWWiZDwibv64Ht3lUlq1NErIL0kVN4socWzCRvDsr2dxOehLiPqSMrBN2hgMMLJCYssCJfV8pc1AYYC2gQ1gERl8fr5z6sWXgpKk4qyOGgNcFLKv+Jgkwl6zST3hbxIJqITSGvFjKRcQgubTFlKJUu/SGiLQNJcayjiyf5Nl4nokV3u2ITKCK1QHJAVnqFtCwhNkELYhG5a/57zYPU1WSAOkwpjj3asX3LDVOpn56rq1Z51ZNqGJGBTPOs2O8e13ttAEfxVlgVYY1s51zilHFTGS+kZzyhp2xJsTJQlUaxwhffx62UfDF7EaxF8U41gO30V5OuMY2/IKRYWKfUwaUBkUplzjJuHaE6G8BFlN/uojOGBkmziUHn5KIWI8ElbuFDWWGCLym7b+Q1392UgADARql7WNUQENIiKVkTAg0ii2dOynLZzvaeUIN+Bpbg5TyC0eBYhgshaXcq02w8Y9g0a2xjAl348fEnX/ntnv/F8Zj+FBb9LIkmdm5uVQ9GBm7KZQWccelC+DudwoJPbxIrs55xFZPb6j/6kx6WrnM6a+V8+f4r4pmLHKOgpCq/81+RerCNHw09qHDdoapV75ERhU4M7SWL7xhIkHgSjt5OR0bQVKaxnUyk7svXRMQHrGaejKwm3Ex5OyGwOQwF7MKcG8judgl9B7/MttYnyXNgk6axq3MIWXTbL78dxtG3XpFcJD7kv6cpovOVM70e9+KjU46dS+w2RCqxHTgC3k+0a2mtJvJAQzBupZgG4dgT1M+Bz4JXUh58n1qGlCxKQynyYHqYNbeY1wLLiK9zW1ewBRRjDgdDRoFFgeswDcKGFnUiu14Lwr7+cLlVneT0CZI0srSMPn7+NqqEAd958QW8BKPtWB+EIfyHUOpibgUifnxT+KfAgVBYn6yUP+/mjz56oE/4tooJH958kj0GTbMhIqQaIDPDbyQISBQz0FNlHDUzTsAagKzL9OtlAJsnz1q1JpQbBdsw9hrgZfup8fOOpa6AW1iM88m1R6gsxUS5Bz5XzLjjCAoFq0MARfGZAxMKsknSK+WlejlKpe4FtEtkru1TuNuUZ3g1Q+6bmd6/p7pJulWnO9WCj/2PNeDZXLnQeJkMOwglkEUeaEh0FB1osZgFQ3ZZWRBDAS6BwMWhzGl/jTDYUjX3NRDI/E3aD8ry8BYaSckhtpuSRKsTgxzHrdhEOB0t8Q4m9W5USbPSE93MqE2qpIxkvTReodQvBaDynYI7tYrWiqyONF01jQngqdPdSmgXwqFJDJxZHC2MBNGd/Imsji2GggjdHsDghKvoRZ9Sbq7Km7pH3dKpABP/69h73WtgJMs9Tk/jiRIcYJGf4D+Hoji/PCoyJ3hkHQR7i2hGEF5DwE5oyR7qw53nm2PU6drpE1EqOqwpd/wks2xDGs0HuFe0qC0i2awOdEsF+vijmc5LtrACJ90vi1zs1XZ/jqlr/SMzfbHFaEeWHaNPRhtJzgSBDbhLN+fpDD7QCLnBcueCX6KnN7255ld/8zMgLmN/ejs4aZfNrff616X2bhjW+rW5a+JzGiBwCVGW6pLtmeFWtJRv9DjSUK3qJBnIeB5MjTCCvZJxcGPkBzUtkFKQaFJE6eg3SyGHXAkyx1iNk7HYEFeb+R5koQoPmYNk/j8fzi9JnmFSVpuAcf9SZyroVqcKdwvj3QH1ttvitcfcKn3aqP93H/9Nl5LlV3oAB6xi4YPkE/sxh+dXw1Hy6rndz7atazQL9Vpm1v8x4YuVDvsFSmYYQ62ddTk8530qgrOHezrmuh/FFieyNNCxcC5nsbRUAbCZ7aND/uQBg+sk1KNRWHeucVJ1fZ2AZRadZ3aw+sHsP8hOswfzjcQsKZQWDsiVEIg4pXKHxlx1NzHDzPfVyCgZUJCpSH8EzJmuSWCFINCX0OyYpe4I4kxGFAe12uY5SnQyLI+I6eGm4SGx4MnyxMSbTyzcOG0Hj1nZIcXDOxFOha7s4Wep197pqMD7Q9nhBmGM5mZzHl6upgiTITBaLdw/eh4xiO7hWjZagLgfYchAGTQmNQH6F8RR9SnKNU4xxkVnIM2E6FTrvmwA4qkocz4wLDUP2ts1oQ3YI7PomlMkCnPXn22XlMlq8XOmS6D1zDXqSikOpKrEEAe0HE2mbViMoIYVAAyT+Tp3OKMb5KOFXox3ea9VzqsBA7zOtuihXfomyOtVPmp3FnLu80zMu0a9Vq/ZS51G5zFxVaQUkAqBBEBkxBbTZcD+nEwW6w4j+nZjo/TYm7ogqrmY/NvlmqZsV+/dPuomikY36hSxdX9dueRX8KezjAOSGHIcMuoGNZ+gUqNoMVxff5eXLldTUC4+UWoxPEu9ItuTZtGBVDoboq1baKOq3ciMPmD/tOBRDnPHxoMeXIN2zk80FWskXCcDVpsjZv4ojT8wRUFCElAwr+JXRHs/R5IckUg4l8wrnSDTlnvwYWAlHqnmCaJiRzsGbrjz+m7MUZIuQWJu9kKQaqOxe4+DBWRs2CLQtA1ejmLrSQHI7FoVfLCX+D6NuuY48lVULmfStYqso8utgcog1tVVWMXDzXTP+PiPJQpygYOw/ROfi8IZRY9QmdLPhnLkLHwrqIa/0a0H4vCtVGcMXII+m/DrUqG4N9ZzCqsMPY6XlVyhKybOJq19TwxMae0VERK+miBhKhWQFUmNFFh58WCUJ2gx9LRDbeHQ6fOziL/zBBtsmBbSFHJdF7aTRpDvLIYoHSuCL0qm1Qar8Vsp4z/hiKSYnvHsVZd7szqqFR2cQ/f9qG6e1gTKweWgeCkARqOCp+olRhL39awSyY8XChXx3naX16V0Z1W/8N8+uZXQdYPByy46QyfkFbDVJgginqUq5UTB4J0OaleQa1WC4P8dOozZqRsIDtsZ0RnmpeX7m2UVh9mdyZ6zKLYoPOLfRGijjgqLj89RETN13V5sbqAKR+1wtcfnPmuGrYKz/D0wzcczrGh/S7isMwqEQtBbqsr24RZZ6AjSFxBbH5+gLtSG5tPXIxfigi2E1hgYPACQs9opGl0X1KapjPVEERPMvgFNK0rwHfHLdbkc1rL49/IIQD7FVwFXDCeDLMKTuODOGobKngCLFmTSviM20Da6my9hdS6DqeU8BnsAJYcn+sADcAz3nGZVyghTUcmVnUvj3alvJqLC7hS06xBEmznW8GOCCbG4q0WFZkZRsU5yaXs9icuKwnGy0WhUp3Y2ezSv6wvaDvF3xT6Df6ahz1uJgBWgDvmCpNWYo6bC0SN4yKpU5ilu5jnkOaEJ5nWcIPh4uzJTqDlmnhUhUv+mj7ZDjX+P0JF5Nr42JBdTCr7Bk8swCA1AGBPQCJTYeRreKT6TEzcBuEg8q20myngnjKD2rUn3d9+wB/DJczv0PbOOrk6OOXLVCjXj2Z/AIzKg1TVo70l/mtcEVfroSzZvejEvNzk8LTcgdqxjjqNNDhTGhZdJijtofPgQrECePoCSp0mWCrM2qgSnqGQsFG26rN/cMd3tknaL/R7cDF11fSVo+lpOhePvLTDElaVYBM6GKYfP+0cxtgTYhnIRCWeVx/w6XjHxEpY5wZ699SH6XXgQDBqdzVSe0WU4ZHdmoi5HWdPpYckJVBC+SGZ5urQ1GxysyE2V7LpKOQyiPYLmptSbFGniQ7IoP81GPDydsU92UDsRjQSDv1Vo1vp93wrGvFOJFLm9H+gxx0GF+bXu/Fqc3ayvTnbi8jMJFYdNNAE2pDI/y0a1nInMjYF2IB1/95KOWsCaigCy5GIF90lT5DFTUcz4BxuwWeI+BV80ga5MB2MTvM5xUyB0MAmBUvnsUSBrGc0WfQP2bVj3ALuBJ3M4xTzSZdxe+h23F0cPH5uEW4rTJdvIPH5FSJG+UGuaLLziT6Ux0rIUrERXv6IiXGlQiEN6NvY3ah/+HTszeNq7BECy/0nD1gvA87ggIg+g6dOq43R2iWEqZ5dlXgf/rr9bygMKujCmznhhsA9dZivospP5QDlfH3NSgblq8NsGbTg6Xxwdt8NOLecr2kOS4hwSGc+6MgIso3/wXxvKpWT9JmroEKELqEue5CuXyicOIygZ/eWgZjEYHZgav83ICxxcJBX4P8X/JFMcWlIACp81GFOUBiHQLl6B7h24qRExqfdFShUogMEKVSSWDaWWajEIh76MPb4WrjIgd5GrRRTbd3yrWP7SW4oUTYMStQxcJDcxY2igH9FNcun0DoQtkIb5xVoLraO47b7ZfaH663dBHYh7nYxBbZZkT6TZCga9g31ripOoBshir/wwtxErlbJyeqgHLuD4ODfN5bsua5Fx2uCN6cfv0U8gWyc8dZrDSjoOwx3HqZNroOkw98jybA8xEoZPaiURniIv+FrZiMkkvuC+VlyOswp7FExBKR+tL9vpwjXVoYrqVpqvSlIazd9bpDKw75lBCRCdwFGtyWSnL6uJgGqAwxQcFjKY9W4IDavTWaT4HQ/EsJt3HxcvvJrj+9s9YarCO6eWfwY5TTK47ARxzyw7MepDfP6Q2x50R5XIqt6INAKYgNcPapA7l2UEwoeXA75yj/MnEOS+ND0q7Pv6yC3uGbM2fyIQ88jhQ+VEUKyfsnv3CZGIPpr/ZFG3GTQwZCjvFuz3icREgmzcuJyNaQ/AyyDOktW6blHoZv3bgANaCC87ZbADS05drR4o0ICy+NdS/My/rEyzlUMXlnEDznJi3rb4ikIIIAnl4d2pZG8/19wsOeA/2Aa/H6f33/upPXyajOgBxTY7NMvaIcC9avycxmplxMo8DE+N+/Yf86+A/5xNZBbceTx8LtHpp4Dh6iksuItup9zvt5ZIuZLLwkNDzn7Cqtu7upRUsW74YF1Ypz8yQvi4lOCEm7QX1lf+PGZwJ8JM4t6f9YDpP7XsWs/yw6I6SHHvuiqpc8ssr+7cd3S143zd5jsZowlfikiRwCGOXBqrYgRRebwb6+KdT2laqeg1sHXLAF1AXkArW4ci3n6AN8sZBfYd1um2SI8wdrTvDzK2p/Z+jMr1aBxAy6e03KOhvPl5/iJL29pW8XP36h9yda73LzKzhHO7sMxt/QCe0/A5zoeduF5qPzfA1hG4HKerxb4Kdlyh6ODHLpNlg1rb7D0gcB+5m4R+yaJukRlBhv3UlkrrNU8WyDmNU/b2Stj13ISdxJwmPY6tp/B8z5HThMtx2e4xRl0Wmjw2bwpAeeWaCqQirO0VhotjSPAYeK0hnMFUA8tFRb4a9piCbjlQXZONGjmzTb8T3s5zQIkbdujtHaxM4K/v/JqMc1QIIDDbDnCUatnDacI6ai+fovNxLaK7AVnN+G4jrjvZD2iHpcqLleP8XINf79BkwlqnqvzkRHEYrHEBdZ5caY1tn2Q058FVLgnG6UidoUaKX7WQkiELqR00c23E3pgK2Z666Eff80Z6E2DxlrU9xDu+WcwkBoDgE3gMwhiWAZaXzAajeCEHoTA9QUkYTQozQVAow8EUwkc1fyD70qEEFfvf4m+jn1rp4pKXe3MxRIHSOZTcqi4bM7PdK4sC6zNXSY1of3WQxt73TNSlcqw+uf3TGT7puA2Ggc+6tYAO+84SLZPNpTQzmlb8IoGKg4xQGwLl7X+bXOIlZDPmWBJJHrFcV+J44AdPDjv4j21J9sMACuEU/LUDQ74z9tU4WFwuFaA9w8Iojqig/2g0IT0PNgyyK2MHcuuEjvgt8NlgHCUslGNyg0/HjiT64FQ2DdT2+cg/Hzo8kQhkwMPlVmmdMMBpYFAoACMlQoAEJXIocxOygObIh7tmLZtdF+M+UZKLti8Rawm0AQj4Nla9qKWEBW1pZ5pPX2UMiYdxceUU0Aw1wx/arMXlEbqj2eoeReP3XzZO91+yNAi/5qayiCBkxhWZBqiiJ0B3YNPrcyLag1uD0V2hAytiOFwZaFQtvV8NZR+lzDavydGemobhLuHuUpJ857WRE48m7dB5rW0xLTBSJqqbPww3yjTpPrUno+PpBxUFtubaW2idmKWoYYeoATAw9+Jvp3DOXEPAYA/bfdY2PGHth/M9/Qk82GoZMv6YWgwDNJYHiM5ZBCYHeUh88tWdALPYdjoQRG6rCaglyN+H3cVLtn14PA9cLUA1mhDa9AgITfkf5dbd+49ePTk2YtXb959QAwWhycQSWQKlUZnMFlsDtenL99+/PrzLyMrJ6+gqKSsoqqmrqGppa2jq6dvYGhkbGJqhot4oykh0ZyUnJKalp6xQbcey/QaMWS1Hwzqstiw5fqd0vetbabtcN62f2Vmjcm+6JZz9hw7cOjIrTedOPWfvHF3XFJz+4DCgqKS4tJ1yirKK6tqqmvr6hsbmlqaD1ivrbVdh0PuGrHHYT/x9LSM2Wu/eadNmHPGi/rMOOpY5JkwaomljlsdUaheLT0j9V0AAAA="

/***/ }),

/***/ "./node_modules/dompurify/dist/purify.js":
/*!***********************************************!*\
  !*** ./node_modules/dompurify/dist/purify.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/*! @license DOMPurify 3.4.5 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.4.5/LICENSE */

(function (global, factory) {
   true ? module.exports = factory() :
  undefined;
})(this, (function () { 'use strict';

  function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
    return n;
  }
  function _arrayWithHoles(r) {
    if (Array.isArray(r)) return r;
  }
  function _iterableToArrayLimit(r, l) {
    var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (null != t) {
      var e,
        n,
        i,
        u,
        a = [],
        f = true,
        o = false;
      try {
        if (i = (t = t.call(r)).next, 0 === l) ; else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
      } catch (r) {
        o = true, n = r;
      } finally {
        try {
          if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return;
        } finally {
          if (o) throw n;
        }
      }
      return a;
    }
  }
  function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function _slicedToArray(r, e) {
    return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
  }
  function _unsupportedIterableToArray(r, a) {
    if (r) {
      if ("string" == typeof r) return _arrayLikeToArray(r, a);
      var t = {}.toString.call(r).slice(8, -1);
      return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
  }

  const entries = Object.entries,
    setPrototypeOf = Object.setPrototypeOf,
    isFrozen = Object.isFrozen,
    getPrototypeOf = Object.getPrototypeOf,
    getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
  let freeze = Object.freeze,
    seal = Object.seal,
    create = Object.create; // eslint-disable-line import/no-mutable-exports
  let _ref = typeof Reflect !== 'undefined' && Reflect,
    apply = _ref.apply,
    construct = _ref.construct;
  if (!freeze) {
    freeze = function freeze(x) {
      return x;
    };
  }
  if (!seal) {
    seal = function seal(x) {
      return x;
    };
  }
  if (!apply) {
    apply = function apply(func, thisArg) {
      for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
        args[_key - 2] = arguments[_key];
      }
      return func.apply(thisArg, args);
    };
  }
  if (!construct) {
    construct = function construct(Func) {
      for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
        args[_key2 - 1] = arguments[_key2];
      }
      return new Func(...args);
    };
  }
  const arrayForEach = unapply(Array.prototype.forEach);
  const arrayLastIndexOf = unapply(Array.prototype.lastIndexOf);
  const arrayPop = unapply(Array.prototype.pop);
  const arrayPush = unapply(Array.prototype.push);
  const arraySplice = unapply(Array.prototype.splice);
  const arrayIsArray = Array.isArray;
  const stringToLowerCase = unapply(String.prototype.toLowerCase);
  const stringToString = unapply(String.prototype.toString);
  const stringMatch = unapply(String.prototype.match);
  const stringReplace = unapply(String.prototype.replace);
  const stringIndexOf = unapply(String.prototype.indexOf);
  const stringTrim = unapply(String.prototype.trim);
  const numberToString = unapply(Number.prototype.toString);
  const booleanToString = unapply(Boolean.prototype.toString);
  const bigintToString = typeof BigInt === 'undefined' ? null : unapply(BigInt.prototype.toString);
  const symbolToString = typeof Symbol === 'undefined' ? null : unapply(Symbol.prototype.toString);
  const objectHasOwnProperty = unapply(Object.prototype.hasOwnProperty);
  const objectToString = unapply(Object.prototype.toString);
  const regExpTest = unapply(RegExp.prototype.test);
  const typeErrorCreate = unconstruct(TypeError);
  /**
   * Creates a new function that calls the given function with a specified thisArg and arguments.
   *
   * @param func - The function to be wrapped and called.
   * @returns A new function that calls the given function with a specified thisArg and arguments.
   */
  function unapply(func) {
    return function (thisArg) {
      if (thisArg instanceof RegExp) {
        thisArg.lastIndex = 0;
      }
      for (var _len3 = arguments.length, args = new Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) {
        args[_key3 - 1] = arguments[_key3];
      }
      return apply(func, thisArg, args);
    };
  }
  /**
   * Creates a new function that constructs an instance of the given constructor function with the provided arguments.
   *
   * @param func - The constructor function to be wrapped and called.
   * @returns A new function that constructs an instance of the given constructor function with the provided arguments.
   */
  function unconstruct(Func) {
    return function () {
      for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
        args[_key4] = arguments[_key4];
      }
      return construct(Func, args);
    };
  }
  /**
   * Add properties to a lookup table
   *
   * @param set - The set to which elements will be added.
   * @param array - The array containing elements to be added to the set.
   * @param transformCaseFunc - An optional function to transform the case of each element before adding to the set.
   * @returns The modified set with added elements.
   */
  function addToSet(set, array) {
    let transformCaseFunc = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : stringToLowerCase;
    if (setPrototypeOf) {
      // Make 'in' and truthy checks like Boolean(set.constructor)
      // independent of any properties defined on Object.prototype.
      // Prevent prototype setters from intercepting set as a this value.
      setPrototypeOf(set, null);
    }
    if (!arrayIsArray(array)) {
      return set;
    }
    let l = array.length;
    while (l--) {
      let element = array[l];
      if (typeof element === 'string') {
        const lcElement = transformCaseFunc(element);
        if (lcElement !== element) {
          // Config presets (e.g. tags.js, attrs.js) are immutable.
          if (!isFrozen(array)) {
            array[l] = lcElement;
          }
          element = lcElement;
        }
      }
      set[element] = true;
    }
    return set;
  }
  /**
   * Clean up an array to harden against CSPP
   *
   * @param array - The array to be cleaned.
   * @returns The cleaned version of the array
   */
  function cleanArray(array) {
    for (let index = 0; index < array.length; index++) {
      const isPropertyExist = objectHasOwnProperty(array, index);
      if (!isPropertyExist) {
        array[index] = null;
      }
    }
    return array;
  }
  /**
   * Shallow clone an object
   *
   * @param object - The object to be cloned.
   * @returns A new object that copies the original.
   */
  function clone(object) {
    const newObject = create(null);
    for (const _ref2 of entries(object)) {
      var _ref3 = _slicedToArray(_ref2, 2);
      const property = _ref3[0];
      const value = _ref3[1];
      const isPropertyExist = objectHasOwnProperty(object, property);
      if (isPropertyExist) {
        if (arrayIsArray(value)) {
          newObject[property] = cleanArray(value);
        } else if (value && typeof value === 'object' && value.constructor === Object) {
          newObject[property] = clone(value);
        } else {
          newObject[property] = value;
        }
      }
    }
    return newObject;
  }
  /**
   * Convert non-node values into strings without depending on direct property access.
   *
   * @param value - The value to stringify.
   * @returns A string representation of the provided value.
   */
  function stringifyValue(value) {
    switch (typeof value) {
      case 'string':
        {
          return value;
        }
      case 'number':
        {
          return numberToString(value);
        }
      case 'boolean':
        {
          return booleanToString(value);
        }
      case 'bigint':
        {
          return bigintToString ? bigintToString(value) : '0';
        }
      case 'symbol':
        {
          return symbolToString ? symbolToString(value) : 'Symbol()';
        }
      case 'undefined':
        {
          return objectToString(value);
        }
      case 'function':
      case 'object':
        {
          if (value === null) {
            return objectToString(value);
          }
          const valueAsRecord = value;
          const valueToString = lookupGetter(valueAsRecord, 'toString');
          if (typeof valueToString === 'function') {
            const stringified = valueToString(valueAsRecord);
            return typeof stringified === 'string' ? stringified : objectToString(stringified);
          }
          return objectToString(value);
        }
      default:
        {
          return objectToString(value);
        }
    }
  }
  /**
   * This method automatically checks if the prop is function or getter and behaves accordingly.
   *
   * @param object - The object to look up the getter function in its prototype chain.
   * @param prop - The property name for which to find the getter function.
   * @returns The getter function found in the prototype chain or a fallback function.
   */
  function lookupGetter(object, prop) {
    while (object !== null) {
      const desc = getOwnPropertyDescriptor(object, prop);
      if (desc) {
        if (desc.get) {
          return unapply(desc.get);
        }
        if (typeof desc.value === 'function') {
          return unapply(desc.value);
        }
      }
      object = getPrototypeOf(object);
    }
    function fallbackValue() {
      return null;
    }
    return fallbackValue;
  }
  function isRegex(value) {
    try {
      regExpTest(value, '');
      return true;
    } catch (_unused) {
      return false;
    }
  }

  const html$1 = freeze(['a', 'abbr', 'acronym', 'address', 'area', 'article', 'aside', 'audio', 'b', 'bdi', 'bdo', 'big', 'blink', 'blockquote', 'body', 'br', 'button', 'canvas', 'caption', 'center', 'cite', 'code', 'col', 'colgroup', 'content', 'data', 'datalist', 'dd', 'decorator', 'del', 'details', 'dfn', 'dialog', 'dir', 'div', 'dl', 'dt', 'element', 'em', 'fieldset', 'figcaption', 'figure', 'font', 'footer', 'form', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'head', 'header', 'hgroup', 'hr', 'html', 'i', 'img', 'input', 'ins', 'kbd', 'label', 'legend', 'li', 'main', 'map', 'mark', 'marquee', 'menu', 'menuitem', 'meter', 'nav', 'nobr', 'ol', 'optgroup', 'option', 'output', 'p', 'picture', 'pre', 'progress', 'q', 'rp', 'rt', 'ruby', 's', 'samp', 'search', 'section', 'select', 'shadow', 'slot', 'small', 'source', 'spacer', 'span', 'strike', 'strong', 'style', 'sub', 'summary', 'sup', 'table', 'tbody', 'td', 'template', 'textarea', 'tfoot', 'th', 'thead', 'time', 'tr', 'track', 'tt', 'u', 'ul', 'var', 'video', 'wbr']);
  const svg$1 = freeze(['svg', 'a', 'altglyph', 'altglyphdef', 'altglyphitem', 'animatecolor', 'animatemotion', 'animatetransform', 'circle', 'clippath', 'defs', 'desc', 'ellipse', 'enterkeyhint', 'exportparts', 'filter', 'font', 'g', 'glyph', 'glyphref', 'hkern', 'image', 'inputmode', 'line', 'lineargradient', 'marker', 'mask', 'metadata', 'mpath', 'part', 'path', 'pattern', 'polygon', 'polyline', 'radialgradient', 'rect', 'stop', 'style', 'switch', 'symbol', 'text', 'textpath', 'title', 'tref', 'tspan', 'view', 'vkern']);
  const svgFilters = freeze(['feBlend', 'feColorMatrix', 'feComponentTransfer', 'feComposite', 'feConvolveMatrix', 'feDiffuseLighting', 'feDisplacementMap', 'feDistantLight', 'feDropShadow', 'feFlood', 'feFuncA', 'feFuncB', 'feFuncG', 'feFuncR', 'feGaussianBlur', 'feImage', 'feMerge', 'feMergeNode', 'feMorphology', 'feOffset', 'fePointLight', 'feSpecularLighting', 'feSpotLight', 'feTile', 'feTurbulence']);
  // List of SVG elements that are disallowed by default.
  // We still need to know them so that we can do namespace
  // checks properly in case one wants to add them to
  // allow-list.
  const svgDisallowed = freeze(['animate', 'color-profile', 'cursor', 'discard', 'font-face', 'font-face-format', 'font-face-name', 'font-face-src', 'font-face-uri', 'foreignobject', 'hatch', 'hatchpath', 'mesh', 'meshgradient', 'meshpatch', 'meshrow', 'missing-glyph', 'script', 'set', 'solidcolor', 'unknown', 'use']);
  const mathMl$1 = freeze(['math', 'menclose', 'merror', 'mfenced', 'mfrac', 'mglyph', 'mi', 'mlabeledtr', 'mmultiscripts', 'mn', 'mo', 'mover', 'mpadded', 'mphantom', 'mroot', 'mrow', 'ms', 'mspace', 'msqrt', 'mstyle', 'msub', 'msup', 'msubsup', 'mtable', 'mtd', 'mtext', 'mtr', 'munder', 'munderover', 'mprescripts']);
  // Similarly to SVG, we want to know all MathML elements,
  // even those that we disallow by default.
  const mathMlDisallowed = freeze(['maction', 'maligngroup', 'malignmark', 'mlongdiv', 'mscarries', 'mscarry', 'msgroup', 'mstack', 'msline', 'msrow', 'semantics', 'annotation', 'annotation-xml', 'mprescripts', 'none']);
  const text = freeze(['#text']);

  const html = freeze(['accept', 'action', 'align', 'alt', 'autocapitalize', 'autocomplete', 'autopictureinpicture', 'autoplay', 'background', 'bgcolor', 'border', 'capture', 'cellpadding', 'cellspacing', 'checked', 'cite', 'class', 'clear', 'color', 'cols', 'colspan', 'command', 'commandfor', 'controls', 'controlslist', 'coords', 'crossorigin', 'datetime', 'decoding', 'default', 'dir', 'disabled', 'disablepictureinpicture', 'disableremoteplayback', 'download', 'draggable', 'enctype', 'enterkeyhint', 'exportparts', 'face', 'for', 'headers', 'height', 'hidden', 'high', 'href', 'hreflang', 'id', 'inert', 'inputmode', 'integrity', 'ismap', 'kind', 'label', 'lang', 'list', 'loading', 'loop', 'low', 'max', 'maxlength', 'media', 'method', 'min', 'minlength', 'multiple', 'muted', 'name', 'nonce', 'noshade', 'novalidate', 'nowrap', 'open', 'optimum', 'part', 'pattern', 'placeholder', 'playsinline', 'popover', 'popovertarget', 'popovertargetaction', 'poster', 'preload', 'pubdate', 'radiogroup', 'readonly', 'rel', 'required', 'rev', 'reversed', 'role', 'rows', 'rowspan', 'spellcheck', 'scope', 'selected', 'shape', 'size', 'sizes', 'slot', 'span', 'srclang', 'start', 'src', 'srcset', 'step', 'style', 'summary', 'tabindex', 'title', 'translate', 'type', 'usemap', 'valign', 'value', 'width', 'wrap', 'xmlns']);
  const svg = freeze(['accent-height', 'accumulate', 'additive', 'alignment-baseline', 'amplitude', 'ascent', 'attributename', 'attributetype', 'azimuth', 'basefrequency', 'baseline-shift', 'begin', 'bias', 'by', 'class', 'clip', 'clippathunits', 'clip-path', 'clip-rule', 'color', 'color-interpolation', 'color-interpolation-filters', 'color-profile', 'color-rendering', 'cx', 'cy', 'd', 'dx', 'dy', 'diffuseconstant', 'direction', 'display', 'divisor', 'dur', 'edgemode', 'elevation', 'end', 'exponent', 'fill', 'fill-opacity', 'fill-rule', 'filter', 'filterunits', 'flood-color', 'flood-opacity', 'font-family', 'font-size', 'font-size-adjust', 'font-stretch', 'font-style', 'font-variant', 'font-weight', 'fx', 'fy', 'g1', 'g2', 'glyph-name', 'glyphref', 'gradientunits', 'gradienttransform', 'height', 'href', 'id', 'image-rendering', 'in', 'in2', 'intercept', 'k', 'k1', 'k2', 'k3', 'k4', 'kerning', 'keypoints', 'keysplines', 'keytimes', 'lang', 'lengthadjust', 'letter-spacing', 'kernelmatrix', 'kernelunitlength', 'lighting-color', 'local', 'marker-end', 'marker-mid', 'marker-start', 'markerheight', 'markerunits', 'markerwidth', 'maskcontentunits', 'maskunits', 'max', 'mask', 'mask-type', 'media', 'method', 'mode', 'min', 'name', 'numoctaves', 'offset', 'operator', 'opacity', 'order', 'orient', 'orientation', 'origin', 'overflow', 'paint-order', 'path', 'pathlength', 'patterncontentunits', 'patterntransform', 'patternunits', 'points', 'preservealpha', 'preserveaspectratio', 'primitiveunits', 'r', 'rx', 'ry', 'radius', 'refx', 'refy', 'repeatcount', 'repeatdur', 'restart', 'result', 'rotate', 'scale', 'seed', 'shape-rendering', 'slope', 'specularconstant', 'specularexponent', 'spreadmethod', 'startoffset', 'stddeviation', 'stitchtiles', 'stop-color', 'stop-opacity', 'stroke-dasharray', 'stroke-dashoffset', 'stroke-linecap', 'stroke-linejoin', 'stroke-miterlimit', 'stroke-opacity', 'stroke', 'stroke-width', 'style', 'surfacescale', 'systemlanguage', 'tabindex', 'tablevalues', 'targetx', 'targety', 'transform', 'transform-origin', 'text-anchor', 'text-decoration', 'text-rendering', 'textlength', 'type', 'u1', 'u2', 'unicode', 'values', 'viewbox', 'visibility', 'version', 'vert-adv-y', 'vert-origin-x', 'vert-origin-y', 'width', 'word-spacing', 'wrap', 'writing-mode', 'xchannelselector', 'ychannelselector', 'x', 'x1', 'x2', 'xmlns', 'y', 'y1', 'y2', 'z', 'zoomandpan']);
  const mathMl = freeze(['accent', 'accentunder', 'align', 'bevelled', 'close', 'columnalign', 'columnlines', 'columnspacing', 'columnspan', 'denomalign', 'depth', 'dir', 'display', 'displaystyle', 'encoding', 'fence', 'frame', 'height', 'href', 'id', 'largeop', 'length', 'linethickness', 'lquote', 'lspace', 'mathbackground', 'mathcolor', 'mathsize', 'mathvariant', 'maxsize', 'minsize', 'movablelimits', 'notation', 'numalign', 'open', 'rowalign', 'rowlines', 'rowspacing', 'rowspan', 'rspace', 'rquote', 'scriptlevel', 'scriptminsize', 'scriptsizemultiplier', 'selection', 'separator', 'separators', 'stretchy', 'subscriptshift', 'supscriptshift', 'symmetric', 'voffset', 'width', 'xmlns']);
  const xml = freeze(['xlink:href', 'xml:id', 'xlink:title', 'xml:space', 'xmlns:xlink']);

  const MUSTACHE_EXPR = seal(/{{[\w\W]*|^[\w\W]*}}/g);
  const ERB_EXPR = seal(/<%[\w\W]*|^[\w\W]*%>/g);
  const TMPLIT_EXPR = seal(/\${[\w\W]*/g);
  const DATA_ATTR = seal(/^data-[\-\w.\u00B7-\uFFFF]+$/); // eslint-disable-line no-useless-escape
  const ARIA_ATTR = seal(/^aria-[\-\w]+$/); // eslint-disable-line no-useless-escape
  const IS_ALLOWED_URI = seal(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i // eslint-disable-line no-useless-escape
  );
  const IS_SCRIPT_OR_DATA = seal(/^(?:\w+script|data):/i);
  const ATTR_WHITESPACE = seal(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g // eslint-disable-line no-control-regex
  );
  const DOCTYPE_NAME = seal(/^html$/i);
  const CUSTOM_ELEMENT = seal(/^[a-z][.\w]*(-[.\w]+)+$/i);

  /* eslint-disable @typescript-eslint/indent */
  // https://developer.mozilla.org/en-US/docs/Web/API/Node/nodeType
  const NODE_TYPE = {
    element: 1,
    text: 3,
    // Deprecated
    progressingInstruction: 7,
    comment: 8,
    document: 9};
  const getGlobal = function getGlobal() {
    return typeof window === 'undefined' ? null : window;
  };
  /**
   * Creates a no-op policy for internal use only.
   * Don't export this function outside this module!
   * @param trustedTypes The policy factory.
   * @param purifyHostElement The Script element used to load DOMPurify (to determine policy name suffix).
   * @return The policy created (or null, if Trusted Types
   * are not supported or creating the policy failed).
   */
  const _createTrustedTypesPolicy = function _createTrustedTypesPolicy(trustedTypes, purifyHostElement) {
    if (typeof trustedTypes !== 'object' || typeof trustedTypes.createPolicy !== 'function') {
      return null;
    }
    // Allow the callers to control the unique policy name
    // by adding a data-tt-policy-suffix to the script element with the DOMPurify.
    // Policy creation with duplicate names throws in Trusted Types.
    let suffix = null;
    const ATTR_NAME = 'data-tt-policy-suffix';
    if (purifyHostElement && purifyHostElement.hasAttribute(ATTR_NAME)) {
      suffix = purifyHostElement.getAttribute(ATTR_NAME);
    }
    const policyName = 'dompurify' + (suffix ? '#' + suffix : '');
    try {
      return trustedTypes.createPolicy(policyName, {
        createHTML(html) {
          return html;
        },
        createScriptURL(scriptUrl) {
          return scriptUrl;
        }
      });
    } catch (_) {
      // Policy creation failed (most likely another DOMPurify script has
      // already run). Skip creating the policy, as this will only cause errors
      // if TT are enforced.
      console.warn('TrustedTypes policy ' + policyName + ' could not be created.');
      return null;
    }
  };
  const _createHooksMap = function _createHooksMap() {
    return {
      afterSanitizeAttributes: [],
      afterSanitizeElements: [],
      afterSanitizeShadowDOM: [],
      beforeSanitizeAttributes: [],
      beforeSanitizeElements: [],
      beforeSanitizeShadowDOM: [],
      uponSanitizeAttribute: [],
      uponSanitizeElement: [],
      uponSanitizeShadowNode: []
    };
  };
  function createDOMPurify() {
    let window = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : getGlobal();
    const DOMPurify = root => createDOMPurify(root);
    DOMPurify.version = '3.4.5';
    DOMPurify.removed = [];
    if (!window || !window.document || window.document.nodeType !== NODE_TYPE.document || !window.Element) {
      // Not running in a browser, provide a factory function
      // so that you can pass your own Window
      DOMPurify.isSupported = false;
      return DOMPurify;
    }
    let document = window.document;
    const originalDocument = document;
    const currentScript = originalDocument.currentScript;
    const DocumentFragment = window.DocumentFragment,
      HTMLTemplateElement = window.HTMLTemplateElement,
      Node = window.Node,
      Element = window.Element,
      NodeFilter = window.NodeFilter,
      _window$NamedNodeMap = window.NamedNodeMap,
      NamedNodeMap = _window$NamedNodeMap === void 0 ? window.NamedNodeMap || window.MozNamedAttrMap : _window$NamedNodeMap,
      HTMLFormElement = window.HTMLFormElement,
      DOMParser = window.DOMParser,
      trustedTypes = window.trustedTypes;
    const ElementPrototype = Element.prototype;
    const cloneNode = lookupGetter(ElementPrototype, 'cloneNode');
    const remove = lookupGetter(ElementPrototype, 'remove');
    const getNextSibling = lookupGetter(ElementPrototype, 'nextSibling');
    const getChildNodes = lookupGetter(ElementPrototype, 'childNodes');
    const getParentNode = lookupGetter(ElementPrototype, 'parentNode');
    const getNodeType = Node && Node.prototype ? lookupGetter(Node.prototype, 'nodeType') : null;
    // As per issue #47, the web-components registry is inherited by a
    // new document created via createHTMLDocument. As per the spec
    // (http://w3c.github.io/webcomponents/spec/custom/#creating-and-passing-registries)
    // a new empty registry is used when creating a template contents owner
    // document, so we use that as our parent document to ensure nothing
    // is inherited.
    if (typeof HTMLTemplateElement === 'function') {
      const template = document.createElement('template');
      if (template.content && template.content.ownerDocument) {
        document = template.content.ownerDocument;
      }
    }
    let trustedTypesPolicy;
    let emptyHTML = '';
    const _document = document,
      implementation = _document.implementation,
      createNodeIterator = _document.createNodeIterator,
      createDocumentFragment = _document.createDocumentFragment,
      getElementsByTagName = _document.getElementsByTagName;
    const importNode = originalDocument.importNode;
    let hooks = _createHooksMap();
    /**
     * Expose whether this browser supports running the full DOMPurify.
     */
    DOMPurify.isSupported = typeof entries === 'function' && typeof getParentNode === 'function' && implementation && implementation.createHTMLDocument !== undefined;
    const MUSTACHE_EXPR$1 = MUSTACHE_EXPR,
      ERB_EXPR$1 = ERB_EXPR,
      TMPLIT_EXPR$1 = TMPLIT_EXPR,
      DATA_ATTR$1 = DATA_ATTR,
      ARIA_ATTR$1 = ARIA_ATTR,
      IS_SCRIPT_OR_DATA$1 = IS_SCRIPT_OR_DATA,
      ATTR_WHITESPACE$1 = ATTR_WHITESPACE,
      CUSTOM_ELEMENT$1 = CUSTOM_ELEMENT;
    let IS_ALLOWED_URI$1 = IS_ALLOWED_URI;
    /**
     * We consider the elements and attributes below to be safe. Ideally
     * don't add any new ones but feel free to remove unwanted ones.
     */
    /* allowed element names */
    let ALLOWED_TAGS = null;
    const DEFAULT_ALLOWED_TAGS = addToSet({}, [...html$1, ...svg$1, ...svgFilters, ...mathMl$1, ...text]);
    /* Allowed attribute names */
    let ALLOWED_ATTR = null;
    const DEFAULT_ALLOWED_ATTR = addToSet({}, [...html, ...svg, ...mathMl, ...xml]);
    /*
     * Configure how DOMPurify should handle custom elements and their attributes as well as customized built-in elements.
     * @property {RegExp|Function|null} tagNameCheck one of [null, regexPattern, predicate]. Default: `null` (disallow any custom elements)
     * @property {RegExp|Function|null} attributeNameCheck one of [null, regexPattern, predicate]. Default: `null` (disallow any attributes not on the allow list)
     * @property {boolean} allowCustomizedBuiltInElements allow custom elements derived from built-ins if they pass CUSTOM_ELEMENT_HANDLING.tagNameCheck. Default: `false`.
     */
    let CUSTOM_ELEMENT_HANDLING = Object.seal(create(null, {
      tagNameCheck: {
        writable: true,
        configurable: false,
        enumerable: true,
        value: null
      },
      attributeNameCheck: {
        writable: true,
        configurable: false,
        enumerable: true,
        value: null
      },
      allowCustomizedBuiltInElements: {
        writable: true,
        configurable: false,
        enumerable: true,
        value: false
      }
    }));
    /* Explicitly forbidden tags (overrides ALLOWED_TAGS/ADD_TAGS) */
    let FORBID_TAGS = null;
    /* Explicitly forbidden attributes (overrides ALLOWED_ATTR/ADD_ATTR) */
    let FORBID_ATTR = null;
    /* Config object to store ADD_TAGS/ADD_ATTR functions (when used as functions) */
    const EXTRA_ELEMENT_HANDLING = Object.seal(create(null, {
      tagCheck: {
        writable: true,
        configurable: false,
        enumerable: true,
        value: null
      },
      attributeCheck: {
        writable: true,
        configurable: false,
        enumerable: true,
        value: null
      }
    }));
    /* Decide if ARIA attributes are okay */
    let ALLOW_ARIA_ATTR = true;
    /* Decide if custom data attributes are okay */
    let ALLOW_DATA_ATTR = true;
    /* Decide if unknown protocols are okay */
    let ALLOW_UNKNOWN_PROTOCOLS = false;
    /* Decide if self-closing tags in attributes are allowed.
     * Usually removed due to a mXSS issue in jQuery 3.0 */
    let ALLOW_SELF_CLOSE_IN_ATTR = true;
    /* Output should be safe for common template engines.
     * This means, DOMPurify removes data attributes, mustaches and ERB
     */
    let SAFE_FOR_TEMPLATES = false;
    /* Output should be safe even for XML used within HTML and alike.
     * This means, DOMPurify removes comments when containing risky content.
     */
    let SAFE_FOR_XML = true;
    /* Decide if document with <html>... should be returned */
    let WHOLE_DOCUMENT = false;
    /* Track whether config is already set on this instance of DOMPurify. */
    let SET_CONFIG = false;
    /* Decide if all elements (e.g. style, script) must be children of
     * document.body. By default, browsers might move them to document.head */
    let FORCE_BODY = false;
    /* Decide if a DOM `HTMLBodyElement` should be returned, instead of a html
     * string (or a TrustedHTML object if Trusted Types are supported).
     * If `WHOLE_DOCUMENT` is enabled a `HTMLHtmlElement` will be returned instead
     */
    let RETURN_DOM = false;
    /* Decide if a DOM `DocumentFragment` should be returned, instead of a html
     * string  (or a TrustedHTML object if Trusted Types are supported) */
    let RETURN_DOM_FRAGMENT = false;
    /* Try to return a Trusted Type object instead of a string, return a string in
     * case Trusted Types are not supported  */
    let RETURN_TRUSTED_TYPE = false;
    /* Output should be free from DOM clobbering attacks?
     * This sanitizes markups named with colliding, clobberable built-in DOM APIs.
     */
    let SANITIZE_DOM = true;
    /* Achieve full DOM Clobbering protection by isolating the namespace of named
     * properties and JS variables, mitigating attacks that abuse the HTML/DOM spec rules.
     *
     * HTML/DOM spec rules that enable DOM Clobbering:
     *   - Named Access on Window (§7.3.3)
     *   - DOM Tree Accessors (§3.1.5)
     *   - Form Element Parent-Child Relations (§4.10.3)
     *   - Iframe srcdoc / Nested WindowProxies (§4.8.5)
     *   - HTMLCollection (§4.2.10.2)
     *
     * Namespace isolation is implemented by prefixing `id` and `name` attributes
     * with a constant string, i.e., `user-content-`
     */
    let SANITIZE_NAMED_PROPS = false;
    const SANITIZE_NAMED_PROPS_PREFIX = 'user-content-';
    /* Keep element content when removing element? */
    let KEEP_CONTENT = true;
    /* If a `Node` is passed to sanitize(), then performs sanitization in-place instead
     * of importing it into a new Document and returning a sanitized copy */
    let IN_PLACE = false;
    /* Allow usage of profiles like html, svg and mathMl */
    let USE_PROFILES = {};
    /* Tags to ignore content of when KEEP_CONTENT is true */
    let FORBID_CONTENTS = null;
    const DEFAULT_FORBID_CONTENTS = addToSet({}, ['annotation-xml', 'audio', 'colgroup', 'desc', 'foreignobject', 'head', 'iframe', 'math', 'mi', 'mn', 'mo', 'ms', 'mtext', 'noembed', 'noframes', 'noscript', 'plaintext', 'script', 'style', 'svg', 'template', 'thead', 'title', 'video', 'xmp']);
    /* Tags that are safe for data: URIs */
    let DATA_URI_TAGS = null;
    const DEFAULT_DATA_URI_TAGS = addToSet({}, ['audio', 'video', 'img', 'source', 'image', 'track']);
    /* Attributes safe for values like "javascript:" */
    let URI_SAFE_ATTRIBUTES = null;
    const DEFAULT_URI_SAFE_ATTRIBUTES = addToSet({}, ['alt', 'class', 'for', 'id', 'label', 'name', 'pattern', 'placeholder', 'role', 'summary', 'title', 'value', 'style', 'xmlns']);
    const MATHML_NAMESPACE = 'http://www.w3.org/1998/Math/MathML';
    const SVG_NAMESPACE = 'http://www.w3.org/2000/svg';
    const HTML_NAMESPACE = 'http://www.w3.org/1999/xhtml';
    /* Document namespace */
    let NAMESPACE = HTML_NAMESPACE;
    let IS_EMPTY_INPUT = false;
    /* Allowed XHTML+XML namespaces */
    let ALLOWED_NAMESPACES = null;
    const DEFAULT_ALLOWED_NAMESPACES = addToSet({}, [MATHML_NAMESPACE, SVG_NAMESPACE, HTML_NAMESPACE], stringToString);
    let MATHML_TEXT_INTEGRATION_POINTS = addToSet({}, ['mi', 'mo', 'mn', 'ms', 'mtext']);
    let HTML_INTEGRATION_POINTS = addToSet({}, ['annotation-xml']);
    // Certain elements are allowed in both SVG and HTML
    // namespace. We need to specify them explicitly
    // so that they don't get erroneously deleted from
    // HTML namespace.
    const COMMON_SVG_AND_HTML_ELEMENTS = addToSet({}, ['title', 'style', 'font', 'a', 'script']);
    /* Parsing of strict XHTML documents */
    let PARSER_MEDIA_TYPE = null;
    const SUPPORTED_PARSER_MEDIA_TYPES = ['application/xhtml+xml', 'text/html'];
    const DEFAULT_PARSER_MEDIA_TYPE = 'text/html';
    let transformCaseFunc = null;
    /* Keep a reference to config to pass to hooks */
    let CONFIG = null;
    /* Ideally, do not touch anything below this line */
    /* ______________________________________________ */
    const formElement = document.createElement('form');
    const isRegexOrFunction = function isRegexOrFunction(testValue) {
      return testValue instanceof RegExp || testValue instanceof Function;
    };
    /**
     * _parseConfig
     *
     * @param cfg optional config literal
     */
    // eslint-disable-next-line complexity
    const _parseConfig = function _parseConfig() {
      let cfg = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      if (CONFIG && CONFIG === cfg) {
        return;
      }
      /* Shield configuration object from tampering */
      if (!cfg || typeof cfg !== 'object') {
        cfg = {};
      }
      /* Shield configuration object from prototype pollution */
      cfg = clone(cfg);
      PARSER_MEDIA_TYPE =
      // eslint-disable-next-line unicorn/prefer-includes
      SUPPORTED_PARSER_MEDIA_TYPES.indexOf(cfg.PARSER_MEDIA_TYPE) === -1 ? DEFAULT_PARSER_MEDIA_TYPE : cfg.PARSER_MEDIA_TYPE;
      // HTML tags and attributes are not case-sensitive, converting to lowercase. Keeping XHTML as is.
      transformCaseFunc = PARSER_MEDIA_TYPE === 'application/xhtml+xml' ? stringToString : stringToLowerCase;
      /* Set configuration parameters */
      ALLOWED_TAGS = objectHasOwnProperty(cfg, 'ALLOWED_TAGS') && arrayIsArray(cfg.ALLOWED_TAGS) ? addToSet({}, cfg.ALLOWED_TAGS, transformCaseFunc) : DEFAULT_ALLOWED_TAGS;
      ALLOWED_ATTR = objectHasOwnProperty(cfg, 'ALLOWED_ATTR') && arrayIsArray(cfg.ALLOWED_ATTR) ? addToSet({}, cfg.ALLOWED_ATTR, transformCaseFunc) : DEFAULT_ALLOWED_ATTR;
      ALLOWED_NAMESPACES = objectHasOwnProperty(cfg, 'ALLOWED_NAMESPACES') && arrayIsArray(cfg.ALLOWED_NAMESPACES) ? addToSet({}, cfg.ALLOWED_NAMESPACES, stringToString) : DEFAULT_ALLOWED_NAMESPACES;
      URI_SAFE_ATTRIBUTES = objectHasOwnProperty(cfg, 'ADD_URI_SAFE_ATTR') && arrayIsArray(cfg.ADD_URI_SAFE_ATTR) ? addToSet(clone(DEFAULT_URI_SAFE_ATTRIBUTES), cfg.ADD_URI_SAFE_ATTR, transformCaseFunc) : DEFAULT_URI_SAFE_ATTRIBUTES;
      DATA_URI_TAGS = objectHasOwnProperty(cfg, 'ADD_DATA_URI_TAGS') && arrayIsArray(cfg.ADD_DATA_URI_TAGS) ? addToSet(clone(DEFAULT_DATA_URI_TAGS), cfg.ADD_DATA_URI_TAGS, transformCaseFunc) : DEFAULT_DATA_URI_TAGS;
      FORBID_CONTENTS = objectHasOwnProperty(cfg, 'FORBID_CONTENTS') && arrayIsArray(cfg.FORBID_CONTENTS) ? addToSet({}, cfg.FORBID_CONTENTS, transformCaseFunc) : DEFAULT_FORBID_CONTENTS;
      FORBID_TAGS = objectHasOwnProperty(cfg, 'FORBID_TAGS') && arrayIsArray(cfg.FORBID_TAGS) ? addToSet({}, cfg.FORBID_TAGS, transformCaseFunc) : clone({});
      FORBID_ATTR = objectHasOwnProperty(cfg, 'FORBID_ATTR') && arrayIsArray(cfg.FORBID_ATTR) ? addToSet({}, cfg.FORBID_ATTR, transformCaseFunc) : clone({});
      USE_PROFILES = objectHasOwnProperty(cfg, 'USE_PROFILES') ? cfg.USE_PROFILES && typeof cfg.USE_PROFILES === 'object' ? clone(cfg.USE_PROFILES) : cfg.USE_PROFILES : false;
      ALLOW_ARIA_ATTR = cfg.ALLOW_ARIA_ATTR !== false; // Default true
      ALLOW_DATA_ATTR = cfg.ALLOW_DATA_ATTR !== false; // Default true
      ALLOW_UNKNOWN_PROTOCOLS = cfg.ALLOW_UNKNOWN_PROTOCOLS || false; // Default false
      ALLOW_SELF_CLOSE_IN_ATTR = cfg.ALLOW_SELF_CLOSE_IN_ATTR !== false; // Default true
      SAFE_FOR_TEMPLATES = cfg.SAFE_FOR_TEMPLATES || false; // Default false
      SAFE_FOR_XML = cfg.SAFE_FOR_XML !== false; // Default true
      WHOLE_DOCUMENT = cfg.WHOLE_DOCUMENT || false; // Default false
      RETURN_DOM = cfg.RETURN_DOM || false; // Default false
      RETURN_DOM_FRAGMENT = cfg.RETURN_DOM_FRAGMENT || false; // Default false
      RETURN_TRUSTED_TYPE = cfg.RETURN_TRUSTED_TYPE || false; // Default false
      FORCE_BODY = cfg.FORCE_BODY || false; // Default false
      SANITIZE_DOM = cfg.SANITIZE_DOM !== false; // Default true
      SANITIZE_NAMED_PROPS = cfg.SANITIZE_NAMED_PROPS || false; // Default false
      KEEP_CONTENT = cfg.KEEP_CONTENT !== false; // Default true
      IN_PLACE = cfg.IN_PLACE || false; // Default false
      IS_ALLOWED_URI$1 = isRegex(cfg.ALLOWED_URI_REGEXP) ? cfg.ALLOWED_URI_REGEXP : IS_ALLOWED_URI; // Default regexp
      NAMESPACE = typeof cfg.NAMESPACE === 'string' ? cfg.NAMESPACE : HTML_NAMESPACE; // Default HTML namespace
      MATHML_TEXT_INTEGRATION_POINTS = objectHasOwnProperty(cfg, 'MATHML_TEXT_INTEGRATION_POINTS') && cfg.MATHML_TEXT_INTEGRATION_POINTS && typeof cfg.MATHML_TEXT_INTEGRATION_POINTS === 'object' ? clone(cfg.MATHML_TEXT_INTEGRATION_POINTS) : addToSet({}, ['mi', 'mo', 'mn', 'ms', 'mtext']); // Default built-in map
      HTML_INTEGRATION_POINTS = objectHasOwnProperty(cfg, 'HTML_INTEGRATION_POINTS') && cfg.HTML_INTEGRATION_POINTS && typeof cfg.HTML_INTEGRATION_POINTS === 'object' ? clone(cfg.HTML_INTEGRATION_POINTS) : addToSet({}, ['annotation-xml']); // Default built-in map
      const customElementHandling = objectHasOwnProperty(cfg, 'CUSTOM_ELEMENT_HANDLING') && cfg.CUSTOM_ELEMENT_HANDLING && typeof cfg.CUSTOM_ELEMENT_HANDLING === 'object' ? clone(cfg.CUSTOM_ELEMENT_HANDLING) : create(null);
      CUSTOM_ELEMENT_HANDLING = create(null);
      if (objectHasOwnProperty(customElementHandling, 'tagNameCheck') && isRegexOrFunction(customElementHandling.tagNameCheck)) {
        CUSTOM_ELEMENT_HANDLING.tagNameCheck = customElementHandling.tagNameCheck; // Default undefined
      }
      if (objectHasOwnProperty(customElementHandling, 'attributeNameCheck') && isRegexOrFunction(customElementHandling.attributeNameCheck)) {
        CUSTOM_ELEMENT_HANDLING.attributeNameCheck = customElementHandling.attributeNameCheck; // Default undefined
      }
      if (objectHasOwnProperty(customElementHandling, 'allowCustomizedBuiltInElements') && typeof customElementHandling.allowCustomizedBuiltInElements === 'boolean') {
        CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements = customElementHandling.allowCustomizedBuiltInElements; // Default undefined
      }
      if (SAFE_FOR_TEMPLATES) {
        ALLOW_DATA_ATTR = false;
      }
      if (RETURN_DOM_FRAGMENT) {
        RETURN_DOM = true;
      }
      /* Parse profile info */
      if (USE_PROFILES) {
        ALLOWED_TAGS = addToSet({}, text);
        ALLOWED_ATTR = create(null);
        if (USE_PROFILES.html === true) {
          addToSet(ALLOWED_TAGS, html$1);
          addToSet(ALLOWED_ATTR, html);
        }
        if (USE_PROFILES.svg === true) {
          addToSet(ALLOWED_TAGS, svg$1);
          addToSet(ALLOWED_ATTR, svg);
          addToSet(ALLOWED_ATTR, xml);
        }
        if (USE_PROFILES.svgFilters === true) {
          addToSet(ALLOWED_TAGS, svgFilters);
          addToSet(ALLOWED_ATTR, svg);
          addToSet(ALLOWED_ATTR, xml);
        }
        if (USE_PROFILES.mathMl === true) {
          addToSet(ALLOWED_TAGS, mathMl$1);
          addToSet(ALLOWED_ATTR, mathMl);
          addToSet(ALLOWED_ATTR, xml);
        }
      }
      /* Always reset function-based ADD_TAGS / ADD_ATTR checks to prevent
       * leaking across calls when switching from function to array config */
      EXTRA_ELEMENT_HANDLING.tagCheck = null;
      EXTRA_ELEMENT_HANDLING.attributeCheck = null;
      /* Merge configuration parameters */
      if (objectHasOwnProperty(cfg, 'ADD_TAGS')) {
        if (typeof cfg.ADD_TAGS === 'function') {
          EXTRA_ELEMENT_HANDLING.tagCheck = cfg.ADD_TAGS;
        } else if (arrayIsArray(cfg.ADD_TAGS)) {
          if (ALLOWED_TAGS === DEFAULT_ALLOWED_TAGS) {
            ALLOWED_TAGS = clone(ALLOWED_TAGS);
          }
          addToSet(ALLOWED_TAGS, cfg.ADD_TAGS, transformCaseFunc);
        }
      }
      if (objectHasOwnProperty(cfg, 'ADD_ATTR')) {
        if (typeof cfg.ADD_ATTR === 'function') {
          EXTRA_ELEMENT_HANDLING.attributeCheck = cfg.ADD_ATTR;
        } else if (arrayIsArray(cfg.ADD_ATTR)) {
          if (ALLOWED_ATTR === DEFAULT_ALLOWED_ATTR) {
            ALLOWED_ATTR = clone(ALLOWED_ATTR);
          }
          addToSet(ALLOWED_ATTR, cfg.ADD_ATTR, transformCaseFunc);
        }
      }
      if (objectHasOwnProperty(cfg, 'ADD_URI_SAFE_ATTR') && arrayIsArray(cfg.ADD_URI_SAFE_ATTR)) {
        addToSet(URI_SAFE_ATTRIBUTES, cfg.ADD_URI_SAFE_ATTR, transformCaseFunc);
      }
      if (objectHasOwnProperty(cfg, 'FORBID_CONTENTS') && arrayIsArray(cfg.FORBID_CONTENTS)) {
        if (FORBID_CONTENTS === DEFAULT_FORBID_CONTENTS) {
          FORBID_CONTENTS = clone(FORBID_CONTENTS);
        }
        addToSet(FORBID_CONTENTS, cfg.FORBID_CONTENTS, transformCaseFunc);
      }
      if (objectHasOwnProperty(cfg, 'ADD_FORBID_CONTENTS') && arrayIsArray(cfg.ADD_FORBID_CONTENTS)) {
        if (FORBID_CONTENTS === DEFAULT_FORBID_CONTENTS) {
          FORBID_CONTENTS = clone(FORBID_CONTENTS);
        }
        addToSet(FORBID_CONTENTS, cfg.ADD_FORBID_CONTENTS, transformCaseFunc);
      }
      /* Add #text in case KEEP_CONTENT is set to true */
      if (KEEP_CONTENT) {
        ALLOWED_TAGS['#text'] = true;
      }
      /* Add html, head and body to ALLOWED_TAGS in case WHOLE_DOCUMENT is true */
      if (WHOLE_DOCUMENT) {
        addToSet(ALLOWED_TAGS, ['html', 'head', 'body']);
      }
      /* Add tbody to ALLOWED_TAGS in case tables are permitted, see #286, #365 */
      if (ALLOWED_TAGS.table) {
        addToSet(ALLOWED_TAGS, ['tbody']);
        delete FORBID_TAGS.tbody;
      }
      if (cfg.TRUSTED_TYPES_POLICY) {
        if (typeof cfg.TRUSTED_TYPES_POLICY.createHTML !== 'function') {
          throw typeErrorCreate('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        }
        if (typeof cfg.TRUSTED_TYPES_POLICY.createScriptURL !== 'function') {
          throw typeErrorCreate('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        }
        // Overwrite existing TrustedTypes policy.
        trustedTypesPolicy = cfg.TRUSTED_TYPES_POLICY;
        // Sign local variables required by `sanitize`.
        emptyHTML = trustedTypesPolicy.createHTML('');
      } else {
        // Uninitialized policy, attempt to initialize the internal dompurify policy.
        if (trustedTypesPolicy === undefined) {
          trustedTypesPolicy = _createTrustedTypesPolicy(trustedTypes, currentScript);
        }
        // If creating the internal policy succeeded sign internal variables.
        if (trustedTypesPolicy !== null && typeof emptyHTML === 'string') {
          emptyHTML = trustedTypesPolicy.createHTML('');
        }
      }
      // Prevent further manipulation of configuration.
      // Not available in IE8, Safari 5, etc.
      if (freeze) {
        freeze(cfg);
      }
      CONFIG = cfg;
    };
    /* Keep track of all possible SVG and MathML tags
     * so that we can perform the namespace checks
     * correctly. */
    const ALL_SVG_TAGS = addToSet({}, [...svg$1, ...svgFilters, ...svgDisallowed]);
    const ALL_MATHML_TAGS = addToSet({}, [...mathMl$1, ...mathMlDisallowed]);
    /**
     * @param element a DOM element whose namespace is being checked
     * @returns Return false if the element has a
     *  namespace that a spec-compliant parser would never
     *  return. Return true otherwise.
     */
    const _checkValidNamespace = function _checkValidNamespace(element) {
      let parent = getParentNode(element);
      // In JSDOM, if we're inside shadow DOM, then parentNode
      // can be null. We just simulate parent in this case.
      if (!parent || !parent.tagName) {
        parent = {
          namespaceURI: NAMESPACE,
          tagName: 'template'
        };
      }
      const tagName = stringToLowerCase(element.tagName);
      const parentTagName = stringToLowerCase(parent.tagName);
      if (!ALLOWED_NAMESPACES[element.namespaceURI]) {
        return false;
      }
      if (element.namespaceURI === SVG_NAMESPACE) {
        // The only way to switch from HTML namespace to SVG
        // is via <svg>. If it happens via any other tag, then
        // it should be killed.
        if (parent.namespaceURI === HTML_NAMESPACE) {
          return tagName === 'svg';
        }
        // The only way to switch from MathML to SVG is via`
        // svg if parent is either <annotation-xml> or MathML
        // text integration points.
        if (parent.namespaceURI === MATHML_NAMESPACE) {
          return tagName === 'svg' && (parentTagName === 'annotation-xml' || MATHML_TEXT_INTEGRATION_POINTS[parentTagName]);
        }
        // We only allow elements that are defined in SVG
        // spec. All others are disallowed in SVG namespace.
        return Boolean(ALL_SVG_TAGS[tagName]);
      }
      if (element.namespaceURI === MATHML_NAMESPACE) {
        // The only way to switch from HTML namespace to MathML
        // is via <math>. If it happens via any other tag, then
        // it should be killed.
        if (parent.namespaceURI === HTML_NAMESPACE) {
          return tagName === 'math';
        }
        // The only way to switch from SVG to MathML is via
        // <math> and HTML integration points
        if (parent.namespaceURI === SVG_NAMESPACE) {
          return tagName === 'math' && HTML_INTEGRATION_POINTS[parentTagName];
        }
        // We only allow elements that are defined in MathML
        // spec. All others are disallowed in MathML namespace.
        return Boolean(ALL_MATHML_TAGS[tagName]);
      }
      if (element.namespaceURI === HTML_NAMESPACE) {
        // The only way to switch from SVG to HTML is via
        // HTML integration points, and from MathML to HTML
        // is via MathML text integration points
        if (parent.namespaceURI === SVG_NAMESPACE && !HTML_INTEGRATION_POINTS[parentTagName]) {
          return false;
        }
        if (parent.namespaceURI === MATHML_NAMESPACE && !MATHML_TEXT_INTEGRATION_POINTS[parentTagName]) {
          return false;
        }
        // We disallow tags that are specific for MathML
        // or SVG and should never appear in HTML namespace
        return !ALL_MATHML_TAGS[tagName] && (COMMON_SVG_AND_HTML_ELEMENTS[tagName] || !ALL_SVG_TAGS[tagName]);
      }
      // For XHTML and XML documents that support custom namespaces
      if (PARSER_MEDIA_TYPE === 'application/xhtml+xml' && ALLOWED_NAMESPACES[element.namespaceURI]) {
        return true;
      }
      // The code should never reach this place (this means
      // that the element somehow got namespace that is not
      // HTML, SVG, MathML or allowed via ALLOWED_NAMESPACES).
      // Return false just in case.
      return false;
    };
    /**
     * _forceRemove
     *
     * @param node a DOM node
     */
    const _forceRemove = function _forceRemove(node) {
      arrayPush(DOMPurify.removed, {
        element: node
      });
      try {
        // eslint-disable-next-line unicorn/prefer-dom-node-remove
        getParentNode(node).removeChild(node);
      } catch (_) {
        remove(node);
      }
    };
    /**
     * _removeAttribute
     *
     * @param name an Attribute name
     * @param element a DOM node
     */
    const _removeAttribute = function _removeAttribute(name, element) {
      try {
        arrayPush(DOMPurify.removed, {
          attribute: element.getAttributeNode(name),
          from: element
        });
      } catch (_) {
        arrayPush(DOMPurify.removed, {
          attribute: null,
          from: element
        });
      }
      element.removeAttribute(name);
      // We void attribute values for unremovable "is" attributes
      if (name === 'is') {
        if (RETURN_DOM || RETURN_DOM_FRAGMENT) {
          try {
            _forceRemove(element);
          } catch (_) {}
        } else {
          try {
            element.setAttribute(name, '');
          } catch (_) {}
        }
      }
    };
    /**
     * _initDocument
     *
     * @param dirty - a string of dirty markup
     * @return a DOM, filled with the dirty markup
     */
    const _initDocument = function _initDocument(dirty) {
      /* Create a HTML document */
      let doc = null;
      let leadingWhitespace = null;
      if (FORCE_BODY) {
        dirty = '<remove></remove>' + dirty;
      } else {
        /* If FORCE_BODY isn't used, leading whitespace needs to be preserved manually */
        const matches = stringMatch(dirty, /^[\r\n\t ]+/);
        leadingWhitespace = matches && matches[0];
      }
      if (PARSER_MEDIA_TYPE === 'application/xhtml+xml' && NAMESPACE === HTML_NAMESPACE) {
        // Root of XHTML doc must contain xmlns declaration (see https://www.w3.org/TR/xhtml1/normative.html#strict)
        dirty = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + dirty + '</body></html>';
      }
      const dirtyPayload = trustedTypesPolicy ? trustedTypesPolicy.createHTML(dirty) : dirty;
      /*
       * Use the DOMParser API by default, fallback later if needs be
       * DOMParser not work for svg when has multiple root element.
       */
      if (NAMESPACE === HTML_NAMESPACE) {
        try {
          doc = new DOMParser().parseFromString(dirtyPayload, PARSER_MEDIA_TYPE);
        } catch (_) {}
      }
      /* Use createHTMLDocument in case DOMParser is not available */
      if (!doc || !doc.documentElement) {
        doc = implementation.createDocument(NAMESPACE, 'template', null);
        try {
          doc.documentElement.innerHTML = IS_EMPTY_INPUT ? emptyHTML : dirtyPayload;
        } catch (_) {
          // Syntax error if dirtyPayload is invalid xml
        }
      }
      const body = doc.body || doc.documentElement;
      if (dirty && leadingWhitespace) {
        body.insertBefore(document.createTextNode(leadingWhitespace), body.childNodes[0] || null);
      }
      /* Work on whole document or just its body */
      if (NAMESPACE === HTML_NAMESPACE) {
        return getElementsByTagName.call(doc, WHOLE_DOCUMENT ? 'html' : 'body')[0];
      }
      return WHOLE_DOCUMENT ? doc.documentElement : body;
    };
    /**
     * Creates a NodeIterator object that you can use to traverse filtered lists of nodes or elements in a document.
     *
     * @param root The root element or node to start traversing on.
     * @return The created NodeIterator
     */
    const _createNodeIterator = function _createNodeIterator(root) {
      return createNodeIterator.call(root.ownerDocument || root, root,
      // eslint-disable-next-line no-bitwise
      NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_COMMENT | NodeFilter.SHOW_TEXT | NodeFilter.SHOW_PROCESSING_INSTRUCTION | NodeFilter.SHOW_CDATA_SECTION, null);
    };
    /**
     * Strip template-engine expressions ({{...}}, ${...}, <%...%>) from the
     * character data of an element subtree. Used as the final safety net for
     * SAFE_FOR_TEMPLATES on every DOM-returning code path so that expressions
     * which only form after text-node normalization (e.g. fragments split across
     * stripped elements) cannot survive into a template-evaluating framework.
     *
     * Walks text/comment/CDATA/processing-instruction nodes and mutates `.data`
     * in place rather than round-tripping through innerHTML. This preserves
     * descendant node references (important for IN_PLACE callers), avoids a
     * serialize/reparse cycle, and reads literal character data — which means
     * `<%...%>` in text content matches the ERB regex against its real bytes
     * instead of the HTML-entity-escaped form innerHTML would produce.
     *
     * Attribute values are not visited here; SAFE_FOR_TEMPLATES handling for
     * attributes is performed during the per-node `_sanitizeAttributes` pass.
     *
     * @param node The root element whose character data should be scrubbed.
     */
    const _scrubTemplateExpressions = function _scrubTemplateExpressions(node) {
      node.normalize();
      const walker = createNodeIterator.call(node.ownerDocument || node, node,
      // eslint-disable-next-line no-bitwise
      NodeFilter.SHOW_TEXT | NodeFilter.SHOW_COMMENT | NodeFilter.SHOW_CDATA_SECTION | NodeFilter.SHOW_PROCESSING_INSTRUCTION, null);
      let currentNode = walker.nextNode();
      while (currentNode) {
        let data = currentNode.data;
        arrayForEach([MUSTACHE_EXPR$1, ERB_EXPR$1, TMPLIT_EXPR$1], expr => {
          data = stringReplace(data, expr, ' ');
        });
        currentNode.data = data;
        currentNode = walker.nextNode();
      }
    };
    /**
     * _isClobbered
     *
     * @param element element to check for clobbering attacks
     * @return true if clobbered, false if safe
     */
    const _isClobbered = function _isClobbered(element) {
      return element instanceof HTMLFormElement && (typeof element.nodeName !== 'string' || typeof element.textContent !== 'string' || typeof element.removeChild !== 'function' || !(element.attributes instanceof NamedNodeMap) || typeof element.removeAttribute !== 'function' || typeof element.setAttribute !== 'function' || typeof element.namespaceURI !== 'string' || typeof element.insertBefore !== 'function' || typeof element.hasChildNodes !== 'function');
    };
    /**
     * Checks whether the given object is a DOM node, including nodes that
     * originate from a different window/realm (e.g. an iframe's
     * contentDocument). The previous `value instanceof Node` check was
     * realm-bound: nodes from a different window failed it, causing
     * sanitize() to silently stringify them and reset IN_PLACE to false,
     * returning the original node unsanitized. See GHSA-4w3q-35jp-p934.
     *
     * Implementation: call the cached `nodeType` getter from Node.prototype
     * directly on the value. This bypasses any clobbered instance property
     * (e.g. a child element named "nodeType") and works across realms
     * because the WebIDL `nodeType` getter reads an internal slot that
     * every real Node has, regardless of which window minted it.
     *
     * @param value object to check whether it's a DOM node
     * @return true if value is a DOM node from any realm
     */
    const _isNode = function _isNode(value) {
      if (!getNodeType || typeof value !== 'object' || value === null) {
        return false;
      }
      try {
        return typeof getNodeType(value) === 'number';
      } catch (_) {
        return false;
      }
    };
    function _executeHooks(hooks, currentNode, data) {
      arrayForEach(hooks, hook => {
        hook.call(DOMPurify, currentNode, data, CONFIG);
      });
    }
    /**
     * _sanitizeElements
     *
     * @protect nodeName
     * @protect textContent
     * @protect removeChild
     * @param currentNode to check for permission to exist
     * @return true if node was killed, false if left alive
     */
    const _sanitizeElements = function _sanitizeElements(currentNode) {
      let content = null;
      /* Execute a hook if present */
      _executeHooks(hooks.beforeSanitizeElements, currentNode, null);
      /* Check if element is clobbered or can clobber */
      if (_isClobbered(currentNode)) {
        _forceRemove(currentNode);
        return true;
      }
      /* Now let's check the element's type and name */
      const tagName = transformCaseFunc(currentNode.nodeName);
      /* Execute a hook if present */
      _executeHooks(hooks.uponSanitizeElement, currentNode, {
        tagName,
        allowedTags: ALLOWED_TAGS
      });
      /* Detect mXSS attempts abusing namespace confusion */
      if (SAFE_FOR_XML && currentNode.hasChildNodes() && !_isNode(currentNode.firstElementChild) && regExpTest(/<[/\w!]/g, currentNode.innerHTML) && regExpTest(/<[/\w!]/g, currentNode.textContent)) {
        _forceRemove(currentNode);
        return true;
      }
      /* Remove risky CSS construction leading to mXSS */
      if (SAFE_FOR_XML && currentNode.namespaceURI === HTML_NAMESPACE && tagName === 'style' && _isNode(currentNode.firstElementChild)) {
        _forceRemove(currentNode);
        return true;
      }
      /* Remove any occurrence of processing instructions */
      if (currentNode.nodeType === NODE_TYPE.progressingInstruction) {
        _forceRemove(currentNode);
        return true;
      }
      /* Remove any kind of possibly harmful comments */
      if (SAFE_FOR_XML && currentNode.nodeType === NODE_TYPE.comment && regExpTest(/<[/\w]/g, currentNode.data)) {
        _forceRemove(currentNode);
        return true;
      }
      /* Remove element if anything forbids its presence */
      if (FORBID_TAGS[tagName] || !(EXTRA_ELEMENT_HANDLING.tagCheck instanceof Function && EXTRA_ELEMENT_HANDLING.tagCheck(tagName)) && !ALLOWED_TAGS[tagName]) {
        /* Check if we have a custom element to handle */
        if (!FORBID_TAGS[tagName] && _isBasicCustomElement(tagName)) {
          if (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, tagName)) {
            return false;
          }
          if (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(tagName)) {
            return false;
          }
        }
        /* Keep content except for bad-listed elements */
        if (KEEP_CONTENT && !FORBID_CONTENTS[tagName]) {
          const parentNode = getParentNode(currentNode) || currentNode.parentNode;
          const childNodes = getChildNodes(currentNode) || currentNode.childNodes;
          if (childNodes && parentNode) {
            const childCount = childNodes.length;
            for (let i = childCount - 1; i >= 0; --i) {
              const childClone = cloneNode(childNodes[i], true);
              parentNode.insertBefore(childClone, getNextSibling(currentNode));
            }
          }
        }
        _forceRemove(currentNode);
        return true;
      }
      /* Check whether element has a valid namespace */
      if (currentNode instanceof Element && !_checkValidNamespace(currentNode)) {
        _forceRemove(currentNode);
        return true;
      }
      /* Make sure that older browsers don't get fallback-tag mXSS */
      if ((tagName === 'noscript' || tagName === 'noembed' || tagName === 'noframes') && regExpTest(/<\/no(script|embed|frames)/i, currentNode.innerHTML)) {
        _forceRemove(currentNode);
        return true;
      }
      /* Sanitize element content to be template-safe */
      if (SAFE_FOR_TEMPLATES && currentNode.nodeType === NODE_TYPE.text) {
        /* Get the element's text content */
        content = currentNode.textContent;
        arrayForEach([MUSTACHE_EXPR$1, ERB_EXPR$1, TMPLIT_EXPR$1], expr => {
          content = stringReplace(content, expr, ' ');
        });
        if (currentNode.textContent !== content) {
          arrayPush(DOMPurify.removed, {
            element: currentNode.cloneNode()
          });
          currentNode.textContent = content;
        }
      }
      /* Execute a hook if present */
      _executeHooks(hooks.afterSanitizeElements, currentNode, null);
      return false;
    };
    /**
     * _isValidAttribute
     *
     * @param lcTag Lowercase tag name of containing element.
     * @param lcName Lowercase attribute name.
     * @param value Attribute value.
     * @return Returns true if `value` is valid, otherwise false.
     */
    // eslint-disable-next-line complexity
    const _isValidAttribute = function _isValidAttribute(lcTag, lcName, value) {
      /* FORBID_ATTR must always win, even if ADD_ATTR predicate would allow it */
      if (FORBID_ATTR[lcName]) {
        return false;
      }
      /* Make sure attribute cannot clobber */
      if (SANITIZE_DOM && (lcName === 'id' || lcName === 'name') && (value in document || value in formElement)) {
        return false;
      }
      const nameIsPermitted = ALLOWED_ATTR[lcName] || EXTRA_ELEMENT_HANDLING.attributeCheck instanceof Function && EXTRA_ELEMENT_HANDLING.attributeCheck(lcName, lcTag);
      /* Allow valid data-* attributes: At least one character after "-"
          (https://html.spec.whatwg.org/multipage/dom.html#embedding-custom-non-visible-data-with-the-data-*-attributes)
          XML-compatible (https://html.spec.whatwg.org/multipage/infrastructure.html#xml-compatible and http://www.w3.org/TR/xml/#d0e804)
          We don't need to check the value; it's always URI safe. */
      if (ALLOW_DATA_ATTR && !FORBID_ATTR[lcName] && regExpTest(DATA_ATTR$1, lcName)) ; else if (ALLOW_ARIA_ATTR && regExpTest(ARIA_ATTR$1, lcName)) ; else if (!nameIsPermitted || FORBID_ATTR[lcName]) {
        if (
        // First condition does a very basic check if a) it's basically a valid custom element tagname AND
        // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
        // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
        _isBasicCustomElement(lcTag) && (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, lcTag) || CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(lcTag)) && (CUSTOM_ELEMENT_HANDLING.attributeNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.attributeNameCheck, lcName) || CUSTOM_ELEMENT_HANDLING.attributeNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.attributeNameCheck(lcName, lcTag)) ||
        // Alternative, second condition checks if it's an `is`-attribute, AND
        // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
        lcName === 'is' && CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements && (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, value) || CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(value))) ; else {
          return false;
        }
        /* Check value is safe. First, is attr inert? If so, is safe */
      } else if (URI_SAFE_ATTRIBUTES[lcName]) ; else if (regExpTest(IS_ALLOWED_URI$1, stringReplace(value, ATTR_WHITESPACE$1, ''))) ; else if ((lcName === 'src' || lcName === 'xlink:href' || lcName === 'href') && lcTag !== 'script' && stringIndexOf(value, 'data:') === 0 && DATA_URI_TAGS[lcTag]) ; else if (ALLOW_UNKNOWN_PROTOCOLS && !regExpTest(IS_SCRIPT_OR_DATA$1, stringReplace(value, ATTR_WHITESPACE$1, ''))) ; else if (value) {
        return false;
      } else ;
      return true;
    };
    /* Names the HTML spec reserves from valid-custom-element-name; these must
     * never be treated as basic custom elements even when a permissive
     * CUSTOM_ELEMENT_HANDLING.tagNameCheck is configured. */
    const RESERVED_CUSTOM_ELEMENT_NAMES = addToSet({}, ['annotation-xml', 'color-profile', 'font-face', 'font-face-format', 'font-face-name', 'font-face-src', 'font-face-uri', 'missing-glyph']);
    /**
     * _isBasicCustomElement
     * checks if at least one dash is included in tagName, and it's not the first char
     * for more sophisticated checking see https://github.com/sindresorhus/validate-element-name
     *
     * @param tagName name of the tag of the node to sanitize
     * @returns Returns true if the tag name meets the basic criteria for a custom element, otherwise false.
     */
    const _isBasicCustomElement = function _isBasicCustomElement(tagName) {
      return !RESERVED_CUSTOM_ELEMENT_NAMES[stringToLowerCase(tagName)] && regExpTest(CUSTOM_ELEMENT$1, tagName);
    };
    /**
     * _sanitizeAttributes
     *
     * @protect attributes
     * @protect nodeName
     * @protect removeAttribute
     * @protect setAttribute
     *
     * @param currentNode to sanitize
     */
    const _sanitizeAttributes = function _sanitizeAttributes(currentNode) {
      /* Execute a hook if present */
      _executeHooks(hooks.beforeSanitizeAttributes, currentNode, null);
      const attributes = currentNode.attributes;
      /* Check if we have attributes; if not we might have a text node */
      if (!attributes || _isClobbered(currentNode)) {
        return;
      }
      const hookEvent = {
        attrName: '',
        attrValue: '',
        keepAttr: true,
        allowedAttributes: ALLOWED_ATTR,
        forceKeepAttr: undefined
      };
      let l = attributes.length;
      /* Go backwards over all attributes; safely remove bad ones */
      while (l--) {
        const attr = attributes[l];
        const name = attr.name,
          namespaceURI = attr.namespaceURI,
          attrValue = attr.value;
        const lcName = transformCaseFunc(name);
        const initValue = attrValue;
        let value = name === 'value' ? initValue : stringTrim(initValue);
        /* Execute a hook if present */
        hookEvent.attrName = lcName;
        hookEvent.attrValue = value;
        hookEvent.keepAttr = true;
        hookEvent.forceKeepAttr = undefined; // Allows developers to see this is a property they can set
        _executeHooks(hooks.uponSanitizeAttribute, currentNode, hookEvent);
        value = hookEvent.attrValue;
        /* Full DOM Clobbering protection via namespace isolation,
         * Prefix id and name attributes with `user-content-`
         */
        if (SANITIZE_NAMED_PROPS && (lcName === 'id' || lcName === 'name') && stringIndexOf(value, SANITIZE_NAMED_PROPS_PREFIX) !== 0) {
          // Remove the attribute with this value
          _removeAttribute(name, currentNode);
          // Prefix the value and later re-create the attribute with the sanitized value
          value = SANITIZE_NAMED_PROPS_PREFIX + value;
        }
        // Else: already prefixed, leave the attribute alone — the prefix is
        // itself the clobbering protection, and re-applying it is incorrect.
        /* Work around a security issue with comments inside attributes */
        if (SAFE_FOR_XML && regExpTest(/((--!?|])>)|<\/(style|script|title|xmp|textarea|noscript|iframe|noembed|noframes)/i, value)) {
          _removeAttribute(name, currentNode);
          continue;
        }
        /* Make sure we cannot easily use animated hrefs, even if animations are allowed */
        if (lcName === 'attributename' && stringMatch(value, 'href')) {
          _removeAttribute(name, currentNode);
          continue;
        }
        /* Did the hooks approve of the attribute? */
        if (hookEvent.forceKeepAttr) {
          continue;
        }
        /* Did the hooks approve of the attribute? */
        if (!hookEvent.keepAttr) {
          _removeAttribute(name, currentNode);
          continue;
        }
        /* Work around a security issue in jQuery 3.0 */
        if (!ALLOW_SELF_CLOSE_IN_ATTR && regExpTest(/\/>/i, value)) {
          _removeAttribute(name, currentNode);
          continue;
        }
        /* Sanitize attribute content to be template-safe */
        if (SAFE_FOR_TEMPLATES) {
          arrayForEach([MUSTACHE_EXPR$1, ERB_EXPR$1, TMPLIT_EXPR$1], expr => {
            value = stringReplace(value, expr, ' ');
          });
        }
        /* Is `value` valid for this attribute? */
        const lcTag = transformCaseFunc(currentNode.nodeName);
        if (!_isValidAttribute(lcTag, lcName, value)) {
          _removeAttribute(name, currentNode);
          continue;
        }
        /* Handle attributes that require Trusted Types */
        if (trustedTypesPolicy && typeof trustedTypes === 'object' && typeof trustedTypes.getAttributeType === 'function') {
          if (namespaceURI) ; else {
            switch (trustedTypes.getAttributeType(lcTag, lcName)) {
              case 'TrustedHTML':
                {
                  value = trustedTypesPolicy.createHTML(value);
                  break;
                }
              case 'TrustedScriptURL':
                {
                  value = trustedTypesPolicy.createScriptURL(value);
                  break;
                }
            }
          }
        }
        /* Handle invalid data-* attribute set by try-catching it */
        if (value !== initValue) {
          try {
            if (namespaceURI) {
              currentNode.setAttributeNS(namespaceURI, name, value);
            } else {
              /* Fallback to setAttribute() for browser-unrecognized namespaces e.g. "x-schema". */
              currentNode.setAttribute(name, value);
            }
            if (_isClobbered(currentNode)) {
              _forceRemove(currentNode);
            } else {
              arrayPop(DOMPurify.removed);
            }
          } catch (_) {
            _removeAttribute(name, currentNode);
          }
        }
      }
      /* Execute a hook if present */
      _executeHooks(hooks.afterSanitizeAttributes, currentNode, null);
    };
    /**
     * _sanitizeShadowDOM
     *
     * @param fragment to iterate over recursively
     */
    const _sanitizeShadowDOM2 = function _sanitizeShadowDOM(fragment) {
      let shadowNode = null;
      const shadowIterator = _createNodeIterator(fragment);
      /* Execute a hook if present */
      _executeHooks(hooks.beforeSanitizeShadowDOM, fragment, null);
      while (shadowNode = shadowIterator.nextNode()) {
        /* Execute a hook if present */
        _executeHooks(hooks.uponSanitizeShadowNode, shadowNode, null);
        /* Sanitize tags and elements */
        _sanitizeElements(shadowNode);
        /* Check attributes next */
        _sanitizeAttributes(shadowNode);
        /* Deep shadow DOM detected */
        if (shadowNode.content instanceof DocumentFragment) {
          _sanitizeShadowDOM2(shadowNode.content);
        }
      }
      /* Execute a hook if present */
      _executeHooks(hooks.afterSanitizeShadowDOM, fragment, null);
    };
    /**
     * _sanitizeAttachedShadowRoots
     *
     * Walks `root` and feeds every attached shadow root we encounter into
     * the existing _sanitizeShadowDOM pipeline. The default node iterator
     * does not descend into shadow trees, so nodes inside an attached
     * shadow root would otherwise be skipped entirely.
     *
     * Two real input paths put attached shadow roots in front of us:
     *   1. IN_PLACE on a DOM node that already has shadow roots attached.
     *   2. DOM-node input where importNode(dirty, true) deep-clones the
     *      shadow root because it was created with `clonable: true`.
     *
     * This pass runs once, up front, so the main iteration loop (and the
     * existing _sanitizeShadowDOM template-content recursion) stay
     * untouched — string-input paths are not affected.
     *
     * @param root the subtree root to walk for attached shadow roots
     */
    const _sanitizeAttachedShadowRoots2 = function _sanitizeAttachedShadowRoots(root) {
      if (root.nodeType === NODE_TYPE.element && root.shadowRoot instanceof DocumentFragment) {
        const sr = root.shadowRoot;
        // Recurse first so that nested shadow roots are reached even if
        // _sanitizeShadowDOM removes hosts at this level.
        _sanitizeAttachedShadowRoots2(sr);
        _sanitizeShadowDOM2(sr);
      }
      // Snapshot children before recursing. Sanitization of one subtree
      // (e.g. via an uponSanitizeShadowNode hook) may detach siblings,
      // and naive nextSibling traversal would silently skip the rest of
      // the list once a node is detached.
      const childNodes = root.childNodes;
      if (!childNodes) {
        return;
      }
      const snapshot = [];
      arrayForEach(childNodes, child => {
        arrayPush(snapshot, child);
      });
      for (const child of snapshot) {
        _sanitizeAttachedShadowRoots2(child);
      }
    };
    // eslint-disable-next-line complexity
    DOMPurify.sanitize = function (dirty) {
      let cfg = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      let body = null;
      let importedNode = null;
      let currentNode = null;
      let returnNode = null;
      /* Make sure we have a string to sanitize.
        DO NOT return early, as this will return the wrong type if
        the user has requested a DOM object rather than a string */
      IS_EMPTY_INPUT = !dirty;
      if (IS_EMPTY_INPUT) {
        dirty = '<!-->';
      }
      /* Stringify, in case dirty is an object */
      if (typeof dirty !== 'string' && !_isNode(dirty)) {
        dirty = stringifyValue(dirty);
        if (typeof dirty !== 'string') {
          throw typeErrorCreate('dirty is not a string, aborting');
        }
      }
      /* Return dirty HTML if DOMPurify cannot run */
      if (!DOMPurify.isSupported) {
        return dirty;
      }
      /* Assign config vars */
      if (!SET_CONFIG) {
        _parseConfig(cfg);
      }
      /* Clean up removed elements */
      DOMPurify.removed = [];
      /* Check if dirty is correctly typed for IN_PLACE */
      if (typeof dirty === 'string') {
        IN_PLACE = false;
      }
      if (IN_PLACE) {
        /* Do some early pre-sanitization to avoid unsafe root nodes */
        const nn = dirty.nodeName;
        if (typeof nn === 'string') {
          const tagName = transformCaseFunc(nn);
          if (!ALLOWED_TAGS[tagName] || FORBID_TAGS[tagName]) {
            throw typeErrorCreate('root node is forbidden and cannot be sanitized in-place');
          }
        }
        /* Sanitize attached shadow roots before the main iterator runs.
           The iterator does not descend into shadow trees. */
        _sanitizeAttachedShadowRoots2(dirty);
      } else if (_isNode(dirty)) {
        /* If dirty is a DOM element, append to an empty document to avoid
           elements being stripped by the parser */
        body = _initDocument('<!---->');
        importedNode = body.ownerDocument.importNode(dirty, true);
        if (importedNode.nodeType === NODE_TYPE.element && importedNode.nodeName === 'BODY') {
          /* Node is already a body, use as is */
          body = importedNode;
        } else if (importedNode.nodeName === 'HTML') {
          body = importedNode;
        } else {
          // eslint-disable-next-line unicorn/prefer-dom-node-append
          body.appendChild(importedNode);
        }
        /* Clonable shadow roots are deep-cloned by importNode(); sanitize
           them before the main iterator runs, since the iterator does not
           descend into shadow trees. */
        _sanitizeAttachedShadowRoots2(importedNode);
      } else {
        /* Exit directly if we have nothing to do */
        if (!RETURN_DOM && !SAFE_FOR_TEMPLATES && !WHOLE_DOCUMENT &&
        // eslint-disable-next-line unicorn/prefer-includes
        dirty.indexOf('<') === -1) {
          return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? trustedTypesPolicy.createHTML(dirty) : dirty;
        }
        /* Initialize the document to work on */
        body = _initDocument(dirty);
        /* Check we have a DOM node from the data */
        if (!body) {
          return RETURN_DOM ? null : RETURN_TRUSTED_TYPE ? emptyHTML : '';
        }
      }
      /* Remove first element node (ours) if FORCE_BODY is set */
      if (body && FORCE_BODY) {
        _forceRemove(body.firstChild);
      }
      /* Get node iterator */
      const nodeIterator = _createNodeIterator(IN_PLACE ? dirty : body);
      /* Now start iterating over the created document */
      while (currentNode = nodeIterator.nextNode()) {
        /* Sanitize tags and elements */
        _sanitizeElements(currentNode);
        /* Check attributes next */
        _sanitizeAttributes(currentNode);
        /* Shadow DOM detected, sanitize it */
        if (currentNode.content instanceof DocumentFragment) {
          _sanitizeShadowDOM2(currentNode.content);
        }
      }
      /* If we sanitized `dirty` in-place, return it. */
      if (IN_PLACE) {
        if (SAFE_FOR_TEMPLATES) {
          _scrubTemplateExpressions(dirty);
        }
        return dirty;
      }
      /* Return sanitized string or DOM */
      if (RETURN_DOM) {
        if (SAFE_FOR_TEMPLATES) {
          _scrubTemplateExpressions(body);
        }
        if (RETURN_DOM_FRAGMENT) {
          returnNode = createDocumentFragment.call(body.ownerDocument);
          while (body.firstChild) {
            // eslint-disable-next-line unicorn/prefer-dom-node-append
            returnNode.appendChild(body.firstChild);
          }
        } else {
          returnNode = body;
        }
        if (ALLOWED_ATTR.shadowroot || ALLOWED_ATTR.shadowrootmode) {
          /*
            AdoptNode() is not used because internal state is not reset
            (e.g. the past names map of a HTMLFormElement), this is safe
            in theory but we would rather not risk another attack vector.
            The state that is cloned by importNode() is explicitly defined
            by the specs.
          */
          returnNode = importNode.call(originalDocument, returnNode, true);
        }
        return returnNode;
      }
      let serializedHTML = WHOLE_DOCUMENT ? body.outerHTML : body.innerHTML;
      /* Serialize doctype if allowed */
      if (WHOLE_DOCUMENT && ALLOWED_TAGS['!doctype'] && body.ownerDocument && body.ownerDocument.doctype && body.ownerDocument.doctype.name && regExpTest(DOCTYPE_NAME, body.ownerDocument.doctype.name)) {
        serializedHTML = '<!DOCTYPE ' + body.ownerDocument.doctype.name + '>\n' + serializedHTML;
      }
      /* Sanitize final string template-safe */
      if (SAFE_FOR_TEMPLATES) {
        arrayForEach([MUSTACHE_EXPR$1, ERB_EXPR$1, TMPLIT_EXPR$1], expr => {
          serializedHTML = stringReplace(serializedHTML, expr, ' ');
        });
      }
      return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? trustedTypesPolicy.createHTML(serializedHTML) : serializedHTML;
    };
    DOMPurify.setConfig = function () {
      let cfg = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      _parseConfig(cfg);
      SET_CONFIG = true;
    };
    DOMPurify.clearConfig = function () {
      CONFIG = null;
      SET_CONFIG = false;
    };
    DOMPurify.isValidAttribute = function (tag, attr, value) {
      /* Initialize shared config vars if necessary. */
      if (!CONFIG) {
        _parseConfig({});
      }
      const lcTag = transformCaseFunc(tag);
      const lcName = transformCaseFunc(attr);
      return _isValidAttribute(lcTag, lcName, value);
    };
    DOMPurify.addHook = function (entryPoint, hookFunction) {
      if (typeof hookFunction !== 'function') {
        return;
      }
      arrayPush(hooks[entryPoint], hookFunction);
    };
    DOMPurify.removeHook = function (entryPoint, hookFunction) {
      if (hookFunction !== undefined) {
        const index = arrayLastIndexOf(hooks[entryPoint], hookFunction);
        return index === -1 ? undefined : arraySplice(hooks[entryPoint], index, 1)[0];
      }
      return arrayPop(hooks[entryPoint]);
    };
    DOMPurify.removeHooks = function (entryPoint) {
      hooks[entryPoint] = [];
    };
    DOMPurify.removeAllHooks = function () {
      hooks = _createHooksMap();
    };
    return DOMPurify;
  }
  var purify = createDOMPurify();

  return purify;

}));
//# sourceMappingURL=purify.js.map


/***/ }),

/***/ "./node_modules/scratch-render-fonts/src/index.js":
/*!********************************************************!*\
  !*** ./node_modules/scratch-render-fonts/src/index.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


// Synchronously load TTF fonts.
// First, have Webpack load their data as Base 64 strings.
var FONTS = void 0;

var getFonts = function getFonts() {
    if (FONTS) return FONTS;
    /* eslint-disable global-require */
    FONTS = {
        'Sans Serif': __webpack_require__(/*! base64-loader!./NotoSans-Medium.woff2 */ "./node_modules/base64-loader/index.js!./node_modules/scratch-render-fonts/src/NotoSans-Medium.woff2"),
        'Serif': __webpack_require__(/*! base64-loader!./SourceSerifPro-Regular.woff2 */ "./node_modules/base64-loader/index.js!./node_modules/scratch-render-fonts/src/SourceSerifPro-Regular.woff2"),
        'Handwriting': __webpack_require__(/*! base64-loader!./handlee-regular.woff2 */ "./node_modules/base64-loader/index.js!./node_modules/scratch-render-fonts/src/handlee-regular.woff2"),
        'Marker': __webpack_require__(/*! base64-loader!./Knewave.woff2 */ "./node_modules/base64-loader/index.js!./node_modules/scratch-render-fonts/src/Knewave.woff2"),
        'Curly': __webpack_require__(/*! base64-loader!./Griffy-Regular.woff2 */ "./node_modules/base64-loader/index.js!./node_modules/scratch-render-fonts/src/Griffy-Regular.woff2"),
        'Pixel': __webpack_require__(/*! base64-loader!./Grand9K-Pixel.woff2 */ "./node_modules/base64-loader/index.js!./node_modules/scratch-render-fonts/src/Grand9K-Pixel.woff2")
    };
    /* eslint-enable global-require */

    // For each Base 64 string,
    // 1. Replace each with a usable @font-face tag that points to a Data URI.
    // 2. Inject the font into a style on `document.body`, so measurements
    //    can be accurately taken in SvgRenderer._transformMeasurements.
    for (var fontName in FONTS) {
        var fontData = FONTS[fontName];
        FONTS[fontName] = '@font-face {' + ('font-family: "' + fontName + '";src: url("data:font/woff2;base64,' + fontData + '");}');
    }

    if (!document.getElementById('scratch-font-styles')) {
        var css = '';
        for (var _fontName in FONTS) {
            css += FONTS[_fontName];
        }

        var documentStyleTag = document.createElement('style');
        documentStyleTag.id = 'scratch-font-styles';
        documentStyleTag.textContent = css;
        document.body.insertBefore(documentStyleTag, document.body.firstChild);
    }

    return FONTS;
};

module.exports = getFonts;

/***/ }),

/***/ "./node_modules/transformation-matrix/build-umd/transformation-matrix.min.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/transformation-matrix/build-umd/transformation-matrix.min.js ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

!function(r,n){ true?module.exports=n():undefined}(window,function(){return function(r){var n={};function t(e){if(n[e])return n[e].exports;var o=n[e]={i:e,l:!1,exports:{}};return r[e].call(o.exports,o,o.exports,t),o.l=!0,o.exports}return t.m=r,t.c=n,t.d=function(r,n,e){t.o(r,n)||Object.defineProperty(r,n,{enumerable:!0,get:e})},t.r=function(r){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(r,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(r,"__esModule",{value:!0})},t.t=function(r,n){if(1&n&&(r=t(r)),8&n)return r;if(4&n&&"object"==typeof r&&r&&r.__esModule)return r;var e=Object.create(null);if(t.r(e),Object.defineProperty(e,"default",{enumerable:!0,value:r}),2&n&&"string"!=typeof r)for(var o in r)t.d(e,o,function(n){return r[n]}.bind(null,o));return e},t.n=function(r){var n=r&&r.__esModule?function(){return r.default}:function(){return r};return t.d(n,"a",n),n},t.o=function(r,n){return Object.prototype.hasOwnProperty.call(r,n)},t.p="",t(t.s=0)}([function(r,n,t){"use strict";function e(r,n){return Array.isArray(n)?[r.a*n[0]+r.c*n[1]+r.e,r.b*n[0]+r.d*n[1]+r.f]:{x:r.a*n.x+r.c*n.y+r.e,y:r.b*n.x+r.d*n.y+r.f}}function o(r,n){return n.map(function(n){return e(r,n)})}function u(r){return{a:parseFloat(r.a),b:parseFloat(r.b),c:parseFloat(r.c),d:parseFloat(r.d),e:parseFloat(r.e),f:parseFloat(r.f)}}t.r(n);var a=/^matrix\(\s*([0-9_+-.e]+)\s*,\s*([0-9_+-.e]+)\s*,\s*([0-9_+-.e]+)\s*,\s*([0-9_+-.e]+)\s*,\s*([0-9_+-.e]+)\s*,\s*([0-9_+-.e]+)\s*\)$/i;function i(r){var n=r.match(a);if(null===n||n.length<7)throw new Error("'"+r+"' is not a matrix");return{a:parseFloat(n[1]),b:parseFloat(n[2]),c:parseFloat(n[3]),d:parseFloat(n[4]),e:parseFloat(n[5]),f:parseFloat(n[6])}}function f(){return{a:1,c:0,e:0,b:0,d:1,f:0}}function c(r){var n=r.a,t=r.b,e=r.c,o=r.d,u=r.e,a=r.f,i=n*o-t*e;return{a:o/i,b:t/-i,c:e/-i,d:n/i,e:(o*u-e*a)/-i,f:(t*u-n*a)/i}}var d="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(r){return typeof r}:function(r){return r&&"function"==typeof Symbol&&r.constructor===Symbol&&r!==Symbol.prototype?"symbol":typeof r},s=function(r){return"number"==typeof r&&!isNaN(r)&&isFinite(r)},l=function(r){return null!=r&&"object"===(void 0===r?"undefined":d(r))};function p(r){return l(r)&&r.hasOwnProperty("a")&&s(r.a)&&r.hasOwnProperty("b")&&s(r.b)&&r.hasOwnProperty("c")&&s(r.c)&&r.hasOwnProperty("d")&&s(r.d)&&r.hasOwnProperty("e")&&s(r.e)&&r.hasOwnProperty("f")&&s(r.f)}function y(r){return void 0===r}function b(r){return{a:1,c:0,e:r,b:0,d:1,f:arguments.length>1&&void 0!==arguments[1]?arguments[1]:0}}function v(){for(var r=arguments.length,n=Array(r),t=0;t<r;t++)n[t]=arguments[t];var e=function(r,n){return{a:r.a*n.a+r.c*n.b,c:r.a*n.c+r.c*n.d,e:r.a*n.e+r.c*n.f+r.e,b:r.b*n.a+r.d*n.b,d:r.b*n.c+r.d*n.d,f:r.b*n.e+r.d*n.f+r.f}};switch((n=Array.isArray(n[0])?n[0]:n).length){case 0:throw new Error("no matrices provided");case 1:return n[0];case 2:return e(n[0],n[1]);default:var o=function(r){return Array.isArray(r)?r:Array.from(r)}(n),u=o[0],a=o[1],i=o.slice(2),f=e(u,a);return v.apply(void 0,[f].concat(function(r){if(Array.isArray(r)){for(var n=0,t=Array(r.length);n<r.length;n++)t[n]=r[n];return t}return Array.from(r)}(i)))}}function m(){return v.apply(void 0,arguments)}var h=Math.cos,x=Math.sin,g=Math.PI;function w(r,n,t){var e=h(r),o=x(r),u={a:e,c:-o,e:0,b:o,d:e,f:0};return y(n)||y(t)?u:v([b(n,t),u,b(-n,-t)])}function P(r){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:void 0,t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:void 0;return w(r*g/180,n,t)}function S(r){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:void 0;return y(n)&&(n=r),{a:r,c:0,e:0,b:0,d:n,f:0}}function O(r,n){return{a:1,c:r,e:0,b:n,d:1,f:0}}var A=Math.tan;function F(r,n){return{a:1,c:A(r),e:0,b:A(n),d:1,f:0}}function M(r,n){return F(r*Math.PI/180,n*Math.PI/180)}function j(r){return T(r)}function _(r){return T(r)}function T(r){return"matrix("+r.a+","+r.b+","+r.c+","+r.d+","+r.e+","+r.f+")"}t.d(n,"applyToPoint",function(){return e}),t.d(n,"applyToPoints",function(){return o}),t.d(n,"fromObject",function(){return u}),t.d(n,"fromString",function(){return i}),t.d(n,"identity",function(){return f}),t.d(n,"inverse",function(){return c}),t.d(n,"isAffineMatrix",function(){return p}),t.d(n,"rotate",function(){return w}),t.d(n,"rotateDEG",function(){return P}),t.d(n,"scale",function(){return S}),t.d(n,"shear",function(){return O}),t.d(n,"skew",function(){return F}),t.d(n,"skewDEG",function(){return M}),t.d(n,"toCSS",function(){return j}),t.d(n,"toSVG",function(){return _}),t.d(n,"toString",function(){return T}),t.d(n,"transform",function(){return v}),t.d(n,"compose",function(){return m}),t.d(n,"translate",function(){return b})}])});
//# sourceMappingURL=transformation-matrix.min.js.map

/***/ }),

/***/ "./src/bitmap-adapter.js":
/*!*******************************!*\
  !*** ./src/bitmap-adapter.js ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var base64js = __webpack_require__(/*! base64-js */ "./node_modules/base64-js/index.js");

/**
 * Adapts Scratch 2.0 bitmaps for use in scratch 3.0
 */

var BitmapAdapter = function () {
    /**
     * @param {?function} makeImage HTML image constructor. Tests can provide this.
     * @param {?function} makeCanvas HTML canvas constructor. Tests can provide this.
     */
    function BitmapAdapter(makeImage, makeCanvas) {
        _classCallCheck(this, BitmapAdapter);

        this._makeImage = makeImage ? makeImage : function () {
            return new Image();
        };
        this._makeCanvas = makeCanvas ? makeCanvas : function () {
            return document.createElement('canvas');
        };
        this.stageWidth = 480;
        this.stageHeight = 360;
    }

    _createClass(BitmapAdapter, [{
        key: 'setStageSize',
        value: function setStageSize(width, height) {
            this.stageWidth = width;
            this.stageHeight = height;
        }

        /**
         * Return a canvas with the resized version of the given image, done using nearest-neighbor interpolation
         * @param {CanvasImageSource} image The image to resize
         * @param {int} newWidth The desired post-resize width of the image
         * @param {int} newHeight The desired post-resize height of the image
         * @returns {HTMLCanvasElement} A canvas with the resized image drawn on it.
         */

    }, {
        key: 'resize',
        value: function resize(image, newWidth, newHeight) {
            // We want to always resize using nearest-neighbor interpolation. However, canvas implementations are free to
            // use linear interpolation (or other "smooth" interpolation methods) when downscaling:
            // https://bugzilla.mozilla.org/show_bug.cgi?id=1360415
            // It seems we can get around this by resizing in two steps: first width, then height. This will always result
            // in nearest-neighbor interpolation, even when downscaling.
            var stretchWidthCanvas = this._makeCanvas();
            stretchWidthCanvas.width = newWidth;
            stretchWidthCanvas.height = image.height;
            var context = stretchWidthCanvas.getContext('2d');
            context.imageSmoothingEnabled = false;
            context.drawImage(image, 0, 0, stretchWidthCanvas.width, stretchWidthCanvas.height);
            var stretchHeightCanvas = this._makeCanvas();
            stretchHeightCanvas.width = newWidth;
            stretchHeightCanvas.height = newHeight;
            context = stretchHeightCanvas.getContext('2d');
            context.imageSmoothingEnabled = false;
            context.drawImage(stretchWidthCanvas, 0, 0, stretchHeightCanvas.width, stretchHeightCanvas.height);
            return stretchHeightCanvas;
        }

        /**
         * Scratch 2.0 had resolution 1 and 2 bitmaps. All bitmaps in Scratch 3.0 are equivalent
         * to resolution 2 bitmaps. Therefore, converting a resolution 1 bitmap means doubling
         * it in width and height.
         * @param {!string} dataURI Base 64 encoded image data of the bitmap
         * @param {!function} callback Node-style callback that returns updated dataURI if conversion succeeded
         */

    }, {
        key: 'convertResolution1Bitmap',
        value: function convertResolution1Bitmap(dataURI, callback) {
            var _this = this;

            var image = this._makeImage();
            image.src = dataURI;
            image.onload = function () {
                callback(null, _this.resize(image, image.width * 2, image.height * 2).toDataURL());
            };
            image.onerror = function () {
                callback('Image load failed');
            };
        }

        /**
         * Given width/height of an uploaded item, return width/height the image will be resized
         * to in Scratch 3.0
         * @param {!number} oldWidth original width
         * @param {!number} oldHeight original height
         * @return {object} Array of new width, new height
         */

    }, {
        key: 'getResizedWidthHeight',
        value: function getResizedWidthHeight(oldWidth, oldHeight) {
            var STAGE_WIDTH = this.stageWidth;
            var STAGE_HEIGHT = this.stageHeight;
            var STAGE_RATIO = STAGE_WIDTH / STAGE_HEIGHT;

            // If both dimensions are smaller than or equal to corresponding stage dimension,
            // double both dimensions
            if (oldWidth <= STAGE_WIDTH && oldHeight <= STAGE_HEIGHT) {
                return { width: oldWidth * 2, height: oldHeight * 2 };
            }

            // If neither dimension is larger than 2x corresponding stage dimension,
            // this is an in-between image, return it as is
            if (oldWidth <= STAGE_WIDTH * 2 && oldHeight <= STAGE_HEIGHT * 2) {
                return { width: oldWidth, height: oldHeight };
            }

            var imageRatio = oldWidth / oldHeight;
            // Otherwise, figure out how to resize
            if (imageRatio >= STAGE_RATIO) {
                // Wide Image
                return { width: STAGE_WIDTH * 2, height: STAGE_WIDTH * 2 / imageRatio };
            }
            // In this case we have either:
            // - A wide image, but not with as big a ratio between width and height,
            // making it so that fitting the width to double stage size would leave
            // the height too big to fit in double the stage height
            // - A square image that's still larger than the double at least
            // one of the stage dimensions, so pick the smaller of the two dimensions (to fit)
            // - A tall image
            // In any of these cases, resize the image to fit the height to double the stage height
            return { width: STAGE_HEIGHT * 2 * imageRatio, height: STAGE_HEIGHT * 2 };
        }

        /**
         * Given bitmap data, resize as necessary.
         * @param {ArrayBuffer | string} fileData Base 64 encoded image data of the bitmap
         * @param {string} fileType The MIME type of this file
         * @returns {Promise} Resolves to resized image data Uint8Array
         */

    }, {
        key: 'importBitmap',
        value: function importBitmap(fileData, fileType) {
            var _this2 = this;

            var dataURI = fileData;
            if (fileData instanceof ArrayBuffer) {
                dataURI = this.convertBinaryToDataURI(fileData, fileType);
            }
            return new Promise(function (resolve, reject) {
                var image = _this2._makeImage();
                image.src = dataURI;
                image.onload = function () {
                    var newSize = _this2.getResizedWidthHeight(image.width, image.height);
                    var resizedDataURI = _this2.resize(image, newSize.width, newSize.height).toDataURL();
                    resolve(_this2.convertDataURIToBinary(resizedDataURI));
                };
                image.onerror = function () {
                    // TODO: reject with an Error (breaking API change!)
                    // eslint-disable-next-line prefer-promise-reject-errors
                    reject('Image load failed');
                };
            });
        }

        // TODO consolidate with scratch-vm/src/util/base64-util.js
        // From https://gist.github.com/borismus/1032746

    }, {
        key: 'convertDataURIToBinary',
        value: function convertDataURIToBinary(dataURI) {
            var BASE64_MARKER = ';base64,';
            var base64Index = dataURI.indexOf(BASE64_MARKER) + BASE64_MARKER.length;
            var base64 = dataURI.substring(base64Index);
            var raw = window.atob(base64);
            var rawLength = raw.length;
            var array = new Uint8Array(new ArrayBuffer(rawLength));

            for (var i = 0; i < rawLength; i++) {
                array[i] = raw.charCodeAt(i);
            }
            return array;
        }
    }, {
        key: 'convertBinaryToDataURI',
        value: function convertBinaryToDataURI(arrayBuffer, contentType) {
            return 'data:' + contentType + ';base64,' + base64js.fromByteArray(new Uint8Array(arrayBuffer));
        }
    }]);

    return BitmapAdapter;
}();

module.exports = BitmapAdapter;

/***/ }),

/***/ "./src/fixup-svg-string.js":
/*!*********************************!*\
  !*** ./src/fixup-svg-string.js ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Fixup svg string prior to parsing.
 * @param {!string} svgString String of the svg to fix.
 * @returns {!string} fixed svg that should be parseable.
 */
module.exports = function (svgString) {
    // Add root svg namespace if it does not exist.
    var svgAttrs = svgString.match(/<svg [^>]*>/);
    if (svgAttrs && svgAttrs[0].indexOf('xmlns=') === -1) {
        svgString = svgString.replace('<svg ', '<svg xmlns="http://www.w3.org/2000/svg" ');
    }

    // There are some SVGs from Illustrator that use undeclared entities.
    // Just replace those entities with fake namespace references to prevent
    // DOMParser from crashing
    if (svgAttrs && svgAttrs[0].indexOf('&ns_') !== -1 && svgString.indexOf('<!DOCTYPE') === -1) {
        svgString = svgString.replace(svgAttrs[0], svgAttrs[0].replace(/&ns_[^;]+;/g, 'http://ns.adobe.com/Extensibility/1.0/'));
    }

    // Some SVGs exported from Photoshop have been found to have an invalid mime type
    // Chrome and Safari won't render these SVGs, so we correct it here
    if (svgString.includes('data:img/png')) {
        svgString = svgString.replace(
        // capture entire image tag with xlink:href=and the quote - dont capture data: bit
        /(<image[^>]+?xlink:href=["'])data:img\/png/g,
        // use the captured <image ..... xlink:href=" then append the right data uri mime type
        function ($0, $1) {
            return $1 + 'data:image/png';
        });
    }

    // Some SVGs from Inkscape attempt to bind a prefix to a reserved namespace name.
    // This will cause SVG parsing to fail, so replace these with a dummy namespace name.
    // This namespace name is only valid for "xml", and if we bind "xmlns:xml" to the dummy namespace,
    // parsing will fail yet again, so exclude "xmlns:xml" declarations.
    var xmlnsRegex = /(<[^>]+?xmlns:(?!xml=)[^ ]+=)"http:\/\/www.w3.org\/XML\/1998\/namespace"/g;
    if (svgString.match(xmlnsRegex) !== null) {
        svgString = svgString.replace(
        // capture the entire attribute
        xmlnsRegex,
        // use the captured attribute name; replace only the URL
        function ($0, $1) {
            return $1 + '"http://dummy.namespace"';
        });
    }

    // Strip `svg:` prefix (sometimes added by Inkscape) from all tags. They interfere with DOMPurify (prefixed tag
    // names are not recognized) and the paint editor.
    // This matches opening and closing tags--the capture group captures the slash if it exists, and it is reinserted
    // in the replacement text.
    svgString = svgString.replace(/<(\/?)\s*svg:/g, '<$1');

    // The <metadata> element is not needed for rendering and sometimes contains
    // unparseable garbage from Illustrator :( Empty out the contents.
    // Note: [\s\S] matches everything including newlines, which .* does not
    svgString = svgString.replace(/<metadata>[\s\S]*<\/metadata>/, '<metadata></metadata>');

    // Empty script tags and javascript executing
    svgString = svgString.replace(/<script[\s\S]*>[\s\S]*<\/script>/, '<script></script>');

    return svgString;
};

/***/ }),

/***/ "./src/font-converter.js":
/*!*******************************!*\
  !*** ./src/font-converter.js ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * @fileOverview Convert 2.0 fonts to 3.0 fonts.
 */

/**
 * Given an SVG, replace Scratch 2.0 fonts with new 3.0 fonts. Add defaults where there are none.
 * @param {SVGElement} svgTag The SVG dom object
 * @return {void}
 */
var convertFonts = function convertFonts(svgTag) {
    // Collect all text elements into a list.
    var textElements = [];
    var collectText = function collectText(domElement) {
        if (domElement.localName === 'text') {
            textElements.push(domElement);
        }
        for (var i = 0; i < domElement.childNodes.length; i++) {
            collectText(domElement.childNodes[i]);
        }
    };
    collectText(svgTag);
    // If there's an old font-family, switch to the new one.
    var _iteratorNormalCompletion = true;
    var _didIteratorError = false;
    var _iteratorError = undefined;

    try {
        for (var _iterator = textElements[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
            var textElement = _step.value;

            // If there's no font-family provided, provide one.
            if (!textElement.getAttribute('font-family') || textElement.getAttribute('font-family') === 'Helvetica') {
                textElement.setAttribute('font-family', 'Sans Serif');
            } else if (textElement.getAttribute('font-family') === 'Mystery') {
                textElement.setAttribute('font-family', 'Curly');
            } else if (textElement.getAttribute('font-family') === 'Gloria') {
                textElement.setAttribute('font-family', 'Handwriting');
            } else if (textElement.getAttribute('font-family') === 'Donegal') {
                textElement.setAttribute('font-family', 'Serif');
            }
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally {
        try {
            if (!_iteratorNormalCompletion && _iterator.return) {
                _iterator.return();
            }
        } finally {
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
};

module.exports = convertFonts;

/***/ }),

/***/ "./src/font-inliner.js":
/*!*****************************!*\
  !*** ./src/font-inliner.js ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

/**
 * @fileOverview Import bitmap data into Scratch 3.0, resizing image as necessary.
 */
var getFonts = __webpack_require__(/*! scratch-render-fonts */ "./node_modules/scratch-render-fonts/src/index.js");

var xmlEscape = function xmlEscape(str) {
    return str.replace(/[<>&'"]/g, function (c) {
        switch (c) {
            case '<':
                return '&lt;';
            case '>':
                return '&gt;';
            case '&':
                return '&amp;';
            case '\'':
                return '&apos;';
            case '"':
                return '&quot;';
        }
    });
};

/**
 * Given SVG data, inline the fonts. This allows them to be rendered correctly when set
 * as the source of an HTMLImageElement. Here is a note from tmickel:
 *   // Inject fonts that are needed.
 *   // It would be nice if there were another way to get the SVG-in-canvas
 *   // to render the correct font family, but I couldn't find any other way.
 *   // Other things I tried:
 *   // Just injecting the font-family into the document: no effect.
 *   // External stylesheet linked to by SVG: no effect.
 *   // Using a <link> or <style>@import</style> to link to font-family
 *   // injected into the document: no effect.
 * @param {string} svgString The string representation of the svg to modify
 * @param {object} [customFontFaces] Object mapping custom font families to @font-face statements.
 * @return {string} The svg with any needed fonts inlined
 */
var inlineSvgFonts = function inlineSvgFonts(svgString) {
    var customFontFaces = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    // Make it clear that this function only operates on strings.
    // If we don't explicitly throw this here, the function silently fails.
    if (typeof svgString !== 'string') {
        throw new Error('SVG to be inlined is not a string');
    }

    var FONTS = {};
    if (customFontFaces && (typeof customFontFaces === 'undefined' ? 'undefined' : _typeof(customFontFaces)) === 'object') {
        // The fonts in the document will be XML escaped
        var _iteratorNormalCompletion = true;
        var _didIteratorError = false;
        var _iteratorError = undefined;

        try {
            for (var _iterator = Object.entries(customFontFaces)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                var _ref = _step.value;

                var _ref2 = _slicedToArray(_ref, 2);

                var families = _ref2[0];
                var style = _ref2[1];

                FONTS[xmlEscape(families)] = style;
            }
        } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
        } finally {
            try {
                if (!_iteratorNormalCompletion && _iterator.return) {
                    _iterator.return();
                }
            } finally {
                if (_didIteratorError) {
                    throw _iteratorError;
                }
            }
        }
    }
    try {
        // We already know these don't need to be XML escaped
        Object.assign(FONTS, getFonts());
    } catch (e) {}
    // getFonts fails in tests because it uses some webpack tricks. This is safe to ignore.


    // Collect fonts that need injection.
    var fontsNeeded = new Set();
    var fontRegex = /font-family="([^"]*)"/g;
    var matches = fontRegex.exec(svgString);
    while (matches) {
        fontsNeeded.add(matches[1]);
        matches = fontRegex.exec(svgString);
    }
    if (fontsNeeded.size > 0) {
        var str = '<defs><style>';
        var _iteratorNormalCompletion2 = true;
        var _didIteratorError2 = false;
        var _iteratorError2 = undefined;

        try {
            for (var _iterator2 = fontsNeeded[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
                var font = _step2.value;

                if (Object.prototype.hasOwnProperty.call(FONTS, font)) {
                    str += '' + FONTS[font];
                }
            }
        } catch (err) {
            _didIteratorError2 = true;
            _iteratorError2 = err;
        } finally {
            try {
                if (!_iteratorNormalCompletion2 && _iterator2.return) {
                    _iterator2.return();
                }
            } finally {
                if (_didIteratorError2) {
                    throw _iteratorError2;
                }
            }
        }

        str += '</style></defs>';
        svgString = svgString.replace(/<svg[^>]*>/, '$&' + str);
        return svgString;
    }
    return svgString;
};

module.exports = inlineSvgFonts;

/***/ }),

/***/ "./src/index.js":
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var SVGRenderer = __webpack_require__(/*! ./svg-renderer */ "./src/svg-renderer.js");
var BitmapAdapter = __webpack_require__(/*! ./bitmap-adapter */ "./src/bitmap-adapter.js");
var inlineSvgFonts = __webpack_require__(/*! ./font-inliner */ "./src/font-inliner.js");
var loadSvgString = __webpack_require__(/*! ./load-svg-string */ "./src/load-svg-string.js");
var sanitizeSvg = __webpack_require__(/*! ./sanitize-svg */ "./src/sanitize-svg.js");
var serializeSvgToString = __webpack_require__(/*! ./serialize-svg-to-string */ "./src/serialize-svg-to-string.js");
var SvgElement = __webpack_require__(/*! ./svg-element */ "./src/svg-element.js");
var convertFonts = __webpack_require__(/*! ./font-converter */ "./src/font-converter.js");
var fixForVanilla = __webpack_require__(/*! ./tw-fix-for-vanilla */ "./src/tw-fix-for-vanilla.js");
var DOMPurify = __webpack_require__(/*! dompurify */ "./node_modules/dompurify/dist/purify.js");
// /**
//  * Export for NPM & Node.js
//  * @type {RenderWebGL}
//  */
module.exports = {
    BitmapAdapter: BitmapAdapter,
    convertFonts: convertFonts,
    inlineSvgFonts: inlineSvgFonts,
    loadSvgString: loadSvgString,
    sanitizeSvg: sanitizeSvg,
    serializeSvgToString: serializeSvgToString,
    SvgElement: SvgElement,
    SVGRenderer: SVGRenderer,
    fixForVanilla: fixForVanilla,
    DOMPurify: DOMPurify
};

/***/ }),

/***/ "./src/load-svg-string.js":
/*!********************************!*\
  !*** ./src/load-svg-string.js ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var DOMPurify = __webpack_require__(/*! dompurify */ "./node_modules/dompurify/dist/purify.js");
var SvgElement = __webpack_require__(/*! ./svg-element */ "./src/svg-element.js");
var convertFonts = __webpack_require__(/*! ./font-converter */ "./src/font-converter.js");
var fixupSvgString = __webpack_require__(/*! ./fixup-svg-string */ "./src/fixup-svg-string.js");
var transformStrokeWidths = __webpack_require__(/*! ./transform-applier */ "./src/transform-applier.js");
var getSandbox = __webpack_require__(/*! ./tw-svg-sandbox */ "./src/tw-svg-sandbox.js");

/**
 * @param {SVGElement} svgTag the tag to search within
 * @param {string} [tagName] svg tag to search for (or collect all elements if not given)
 * @return {Array} a list of elements with the given tagname
 */
var collectElements = function collectElements(svgTag, tagName) {
    var elts = [];
    var collectElementsInner = function collectElementsInner(domElement) {
        if ((domElement.localName === tagName || typeof tagName === 'undefined') && domElement.getAttribute) {
            elts.push(domElement);
        }
        for (var i = 0; i < domElement.childNodes.length; i++) {
            collectElementsInner(domElement.childNodes[i]);
        }
    };
    collectElementsInner(svgTag);
    return elts;
};

/**
 * Fix SVGs to comply with SVG spec. Scratch 2 defaults to x2 = 0 when x2 is missing, but
 * SVG defaults to x2 = 1 when missing.
 * @param {SVGSVGElement} svgTag the SVG tag to apply the transformation to
 */
var transformGradients = function transformGradients(svgTag) {
    var linearGradientElements = collectElements(svgTag, 'linearGradient');

    // For each gradient element, supply x2 if necessary.
    var _iteratorNormalCompletion = true;
    var _didIteratorError = false;
    var _iteratorError = undefined;

    try {
        for (var _iterator = linearGradientElements[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
            var gradientElement = _step.value;

            if (!gradientElement.getAttribute('x2')) {
                gradientElement.setAttribute('x2', '0');
            }
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally {
        try {
            if (!_iteratorNormalCompletion && _iterator.return) {
                _iterator.return();
            }
        } finally {
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
};

/**
 * Fix SVGs to match appearance in Scratch 2, which used nearest neighbor scaling for bitmaps
 * within SVGs.
 * @param {SVGSVGElement} svgTag the SVG tag to apply the transformation to
 */
var transformImages = function transformImages(svgTag) {
    var imageElements = collectElements(svgTag, 'image');

    // For each image element, set image rendering to pixelated
    var pixelatedImages = 'image-rendering: optimizespeed; image-rendering: pixelated;';
    var _iteratorNormalCompletion2 = true;
    var _didIteratorError2 = false;
    var _iteratorError2 = undefined;

    try {
        for (var _iterator2 = imageElements[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
            var elt = _step2.value;

            if (elt.getAttribute('style')) {
                elt.setAttribute('style', pixelatedImages + ' ' + elt.getAttribute('style'));
            } else {
                elt.setAttribute('style', pixelatedImages);
            }
        }
    } catch (err) {
        _didIteratorError2 = true;
        _iteratorError2 = err;
    } finally {
        try {
            if (!_iteratorNormalCompletion2 && _iterator2.return) {
                _iterator2.return();
            }
        } finally {
            if (_didIteratorError2) {
                throw _iteratorError2;
            }
        }
    }
};

/**
 * Transforms an SVG's text elements for Scratch 2.0 quirks.
 * These quirks include:
 * 1. `x` and `y` properties are removed/ignored.
 * 2. Alignment is set to `text-before-edge`.
 * 3. Line-breaks are converted to explicit <tspan> elements.
 * 4. Any required fonts are injected.
 * @param {SVGSVGElement} svgTag the SVG tag to apply the transformation to
 */
var transformText = function transformText(svgTag) {
    // Collect all text elements into a list.
    var textElements = [];
    var collectText = function collectText(domElement) {
        if (domElement.localName === 'text') {
            textElements.push(domElement);
        }
        for (var i = 0; i < domElement.childNodes.length; i++) {
            collectText(domElement.childNodes[i]);
        }
    };
    collectText(svgTag);
    convertFonts(svgTag);
    // For each text element, apply quirks.
    var _iteratorNormalCompletion3 = true;
    var _didIteratorError3 = false;
    var _iteratorError3 = undefined;

    try {
        for (var _iterator3 = textElements[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
            var textElement = _step3.value;

            // Remove x and y attributes - they are not used in Scratch.
            textElement.removeAttribute('x');
            textElement.removeAttribute('y');
            // Set text-before-edge alignment:
            // Scratch renders all text like this.
            textElement.setAttribute('alignment-baseline', 'text-before-edge');
            textElement.setAttribute('xml:space', 'preserve');
            // If there's no font size provided, provide one.
            if (!textElement.getAttribute('font-size')) {
                textElement.setAttribute('font-size', '18');
            }
            var text = textElement.textContent;

            // Fix line breaks in text, which are not natively supported by SVG.
            // Only fix if text does not have child tspans.
            // @todo this will not work for font sizes with units such as em, percent
            // However, text made in scratch 2 should only ever export size 22 font.
            var fontSize = parseFloat(textElement.getAttribute('font-size'));
            var tx = 2;
            var ty = 0;
            var spacing = 1.2;
            // Try to match the position and spacing of Scratch 2.0's fonts.
            // Different fonts seem to use different line spacing.
            // Scratch 2 always uses alignment-baseline=text-before-edge
            // However, most SVG readers don't support this attribute
            // or don't support it alongside use of tspan, so the translations
            // here are to make up for that.
            if (textElement.getAttribute('font-family') === 'Handwriting') {
                spacing = 2;
                ty = -11 * fontSize / 22;
            } else if (textElement.getAttribute('font-family') === 'Scratch') {
                spacing = 0.89;
                ty = -3 * fontSize / 22;
            } else if (textElement.getAttribute('font-family') === 'Curly') {
                spacing = 1.38;
                ty = -6 * fontSize / 22;
            } else if (textElement.getAttribute('font-family') === 'Marker') {
                spacing = 1.45;
                ty = -6 * fontSize / 22;
            } else if (textElement.getAttribute('font-family') === 'Sans Serif') {
                spacing = 1.13;
                ty = -3 * fontSize / 22;
            } else if (textElement.getAttribute('font-family') === 'Serif') {
                spacing = 1.25;
                ty = -4 * fontSize / 22;
            }

            if (textElement.transform.baseVal.numberOfItems === 0) {
                var transform = svgTag.createSVGTransform();
                textElement.transform.baseVal.appendItem(transform);
            }

            // Right multiply matrix by a translation of (tx, ty)
            var mtx = textElement.transform.baseVal.getItem(0).matrix;
            mtx.e += mtx.a * tx + mtx.c * ty;
            mtx.f += mtx.b * tx + mtx.d * ty;

            if (text && textElement.childElementCount === 0) {
                textElement.textContent = '';
                var lines = text.split('\n');
                text = '';
                var _iteratorNormalCompletion4 = true;
                var _didIteratorError4 = false;
                var _iteratorError4 = undefined;

                try {
                    for (var _iterator4 = lines[Symbol.iterator](), _step4; !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
                        var line = _step4.value;

                        var tspanNode = SvgElement.create('tspan');
                        tspanNode.setAttribute('x', '0');
                        tspanNode.setAttribute('style', 'white-space: pre');
                        tspanNode.setAttribute('dy', spacing + 'em');
                        tspanNode.textContent = line ? line : ' ';
                        textElement.appendChild(tspanNode);
                    }
                } catch (err) {
                    _didIteratorError4 = true;
                    _iteratorError4 = err;
                } finally {
                    try {
                        if (!_iteratorNormalCompletion4 && _iterator4.return) {
                            _iterator4.return();
                        }
                    } finally {
                        if (_didIteratorError4) {
                            throw _iteratorError4;
                        }
                    }
                }
            }
        }
    } catch (err) {
        _didIteratorError3 = true;
        _iteratorError3 = err;
    } finally {
        try {
            if (!_iteratorNormalCompletion3 && _iterator3.return) {
                _iterator3.return();
            }
        } finally {
            if (_didIteratorError3) {
                throw _iteratorError3;
            }
        }
    }
};

/**
 * Find the largest stroke width in the svg. If a shape has no
 * `stroke` property, it has a stroke-width of 0. If it has a `stroke`,
 * it is by default a stroke-width of 1.
 * This is used to enlarge the computed bounding box, which doesn't take
 * stroke width into account.
 * @param {SVGSVGElement} rootNode The root SVG node to traverse.
 * @return {number} The largest stroke width in the SVG.
 */
var findLargestStrokeWidth = function findLargestStrokeWidth(rootNode) {
    var largestStrokeWidth = 0;
    var collectStrokeWidths = function collectStrokeWidths(domElement) {
        if (domElement.getAttribute) {
            if (domElement.getAttribute('stroke')) {
                largestStrokeWidth = Math.max(largestStrokeWidth, 1);
            }
            if (domElement.getAttribute('stroke-width')) {
                largestStrokeWidth = Math.max(largestStrokeWidth, Number(domElement.getAttribute('stroke-width')) || 0);
            }
        }
        for (var i = 0; i < domElement.childNodes.length; i++) {
            collectStrokeWidths(domElement.childNodes[i]);
        }
    };
    collectStrokeWidths(rootNode);
    return largestStrokeWidth;
};

/**
 * Transform the measurements of the SVG.
 * In Scratch 2.0, SVGs are drawn without respect to the width,
 * height, and viewBox attribute on the tag. The exporter
 * does output these properties - but they appear to be incorrect often.
 * To address the incorrect measurements, we append the DOM to the
 * document, and then use SVG's native `getBBox` to find the real
 * drawn dimensions. This ensures things drawn in negative dimensions,
 * outside the given viewBox, etc., are all eventually drawn to the canvas.
 * I tried to do this several other ways: stripping the width/height/viewBox
 * attributes and then drawing (Firefox won't draw anything),
 * or inflating them and then measuring a canvas. But this seems to be
 * a natural and performant way.
 * @param {SVGSVGElement} svgTag the SVG tag to apply the transformation to
 */
var transformMeasurements = function transformMeasurements(svgTag) {
    var sandbox = getSandbox();

    // Append the SVG dom to the document.
    // This allows us to use `getBBox` on the page,
    // which returns the full bounding-box of all drawn SVG
    // elements, similar to how Scratch 2.0 did measurement.
    var svgSpot = document.createElement('span');
    // Since we're adding user-provided SVG to document.body,
    // sanitizing is required. This should not affect bounding box calculation.
    // outerHTML is attribute of Element (and not HTMLElement), so use it instead of
    // calling serializer or toString()
    // NOTE: svgTag remains untouched!
    var rawValue = svgTag.outerHTML;
    var sanitizedValue = DOMPurify.sanitize(rawValue, {
        // Use SVG profile (no HTML elements)
        USE_PROFILES: { svg: true },
        // Remove some tags that Scratch does not use.
        FORBID_TAGS: ['a', 'audio', 'canvas', 'video'],
        // Allow data URI in image tags (e.g. SVGs converted from bitmap)
        ADD_DATA_URI_TAGS: ['image']
    });
    var bbox = void 0;
    try {
        // Insert sanitized value.
        svgSpot.innerHTML = sanitizedValue;
        sandbox.appendChild(svgSpot);
        // Take the bounding box. We have to get elements via svgSpot
        // because we added it via innerHTML.
        bbox = svgSpot.children[0].getBBox();
    } finally {
        // Always destroy the element, even if, for example, getBBox throws.
        sandbox.removeChild(svgSpot);
    }

    // Enlarge the bbox from the largest found stroke width
    // This may have false-positives, but at least the bbox will always
    // contain the full graphic including strokes.
    // If the width or height is zero however, don't enlarge since
    // they won't have a stroke width that needs to be enlarged.
    var halfStrokeWidth = void 0;
    if (bbox.width === 0 || bbox.height === 0) {
        halfStrokeWidth = 0;
    } else {
        halfStrokeWidth = findLargestStrokeWidth(svgTag) / 2;
    }
    var width = bbox.width + halfStrokeWidth * 2;
    var height = bbox.height + halfStrokeWidth * 2;
    var x = bbox.x - halfStrokeWidth;
    var y = bbox.y - halfStrokeWidth;

    // Set the correct measurements on the SVG tag
    svgTag.setAttribute('width', width);
    svgTag.setAttribute('height', height);
    svgTag.setAttribute('viewBox', x + ' ' + y + ' ' + width + ' ' + height);
};

/**
 * Find all instances of a URL-referenced `stroke` in the svg. In 2.0, all gradient strokes
 * have a round `stroke-linejoin` and `stroke-linecap`... for some reason.
 * @param {SVGSVGElement} svgTag the SVG tag to apply the transformation to
 */
var setGradientStrokeRoundedness = function setGradientStrokeRoundedness(svgTag) {
    var elements = collectElements(svgTag);

    var _iteratorNormalCompletion5 = true;
    var _didIteratorError5 = false;
    var _iteratorError5 = undefined;

    try {
        for (var _iterator5 = elements[Symbol.iterator](), _step5; !(_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done); _iteratorNormalCompletion5 = true) {
            var elt = _step5.value;

            if (!elt.style) continue;
            var stroke = elt.style.stroke || elt.getAttribute('stroke');
            if (stroke && stroke.match(/^url\(#.*\)$/)) {
                elt.style['stroke-linejoin'] = 'round';
                elt.style['stroke-linecap'] = 'round';
            }
        }
    } catch (err) {
        _didIteratorError5 = true;
        _iteratorError5 = err;
    } finally {
        try {
            if (!_iteratorNormalCompletion5 && _iterator5.return) {
                _iterator5.return();
            }
        } finally {
            if (_didIteratorError5) {
                throw _iteratorError5;
            }
        }
    }
};

/**
 * In-place, convert passed SVG to something consistent that will be rendered the way we want them to be.
 * @param {SVGSvgElement} svgTag root SVG node to operate upon
 * @param {boolean} [fromVersion2] True if we should perform conversion from version 2 to version 3 svg.
 */
var normalizeSvg = function normalizeSvg(svgTag, fromVersion2) {
    if (fromVersion2) {
        // Fix gradients. Scratch 2 exports no x2 when x2 = 0, but
        // SVG default is that x2 is 1. This must be done before
        // transformStrokeWidths since transformStrokeWidths affects
        // gradients.
        transformGradients(svgTag);
    }
    transformStrokeWidths(svgTag, window);
    transformImages(svgTag);
    if (fromVersion2) {
        // Transform all text elements.
        transformText(svgTag);
        // Transform measurements.
        transformMeasurements(svgTag);
        // Fix stroke roundedness.
        setGradientStrokeRoundedness(svgTag);
    } else if (!svgTag.getAttribute('viewBox')) {
        // Renderer expects a view box.
        transformMeasurements(svgTag);
    } else if (!svgTag.getAttribute('width') || !svgTag.getAttribute('height')) {
        svgTag.setAttribute('width', svgTag.viewBox.baseVal.width);
        svgTag.setAttribute('height', svgTag.viewBox.baseVal.height);
    }
};

/**
 * Load an SVG string and normalize it. All the steps before drawing/measuring.
 * Currently, this will normalize stroke widths (see transform-applier.js) and render all embedded images pixelated.
 * The returned SVG will be guaranteed to always have a `width`, `height` and `viewBox`.
 * In addition, if the `fromVersion2` parameter is `true`, several "quirks-mode" transformations will be applied which
 * mimic Scratch 2.0's SVG rendering.
 * @param {!string} svgString String of SVG data to draw in quirks-mode.
 * @param {boolean} [fromVersion2] True if we should perform conversion from version 2 to version 3 svg.
 * @return {SVGSVGElement} The normalized SVG element.
 */
var loadSvgString = function loadSvgString(svgString, fromVersion2) {
    // Parse string into SVG XML.
    var parser = new DOMParser();
    svgString = fixupSvgString(svgString);
    var svgDom = parser.parseFromString(svgString, 'text/xml');
    if (svgDom.childNodes.length < 1 || svgDom.documentElement.localName !== 'svg') {
        throw new Error('Document does not appear to be SVG.');
    }
    var svgTag = svgDom.documentElement;
    normalizeSvg(svgTag, fromVersion2);
    return svgTag;
};

module.exports = loadSvgString;

/***/ }),

/***/ "./src/sanitize-svg.js":
/*!*****************************!*\
  !*** ./src/sanitize-svg.js ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * @fileOverview Sanitize the content of an SVG aggressively, to make it as safe
 * as possible
 */
var fixupSvgString = __webpack_require__(/*! ./fixup-svg-string */ "./src/fixup-svg-string.js");
var DOMPurify = __webpack_require__(/*! dompurify */ "./node_modules/dompurify/dist/purify.js");

var sanitizeSvg = {};

/**
 * Load an SVG Uint8Array of bytes and "sanitize" it
 * @param {!Uint8Array} rawData unsanitized SVG daata
 * @return {Uint8Array} sanitized SVG data
 */
sanitizeSvg.sanitizeByteStream = function (rawData) {
    var decoder = new TextDecoder();
    var encoder = new TextEncoder();
    var sanitizedText = sanitizeSvg.sanitizeSvgText(decoder.decode(rawData));
    return encoder.encode(sanitizedText);
};

// TW: Don't remove extra metadata tag: <!--rotationCenter:10,10-->
// Using literal HTML comments tokens will cause this script to be very hard to inline in
// a <script> element, so we'll instead do this terrible hack which the minifier probably
// won't be able to optimize away.
var HTML_COMMENT_START = '<!' + '-'.repeat(2);
var HTML_COMMENT_END = '-'.repeat(2) + '>';
var extraMetadataRegex = new RegExp(HTML_COMMENT_START + 'rotationCenter:(-?[\\d\\.]+):(-?[\\d\\.]+)' + HTML_COMMENT_END + '$');

/**
 * Load an SVG string and "sanitize" it. This is more aggressive than the handling in
 * fixup-svg-string.js, and thus more risky; there are known examples of SVGs that
 * it will clobber. We use DOMPurify's svg profile, which restricts many types of tag.
 * @param {!string} rawSvgText unsanitized SVG string
 * @return {string} sanitized SVG text
 */
sanitizeSvg.sanitizeSvgText = function (rawSvgText) {
    var sanitizedText = DOMPurify.sanitize(rawSvgText, {
        USE_PROFILES: { svg: true }
    });

    // Remove partial XML comment that is sometimes left in the HTML
    var badTag = sanitizedText.indexOf(']&gt;');
    if (badTag >= 0) {
        sanitizedText = sanitizedText.substring(5, sanitizedText.length);
    }

    // also use our custom fixup rules
    sanitizedText = fixupSvgString(sanitizedText);

    // TW: don't remove extra metadata comment
    var extraMetadataMatch = rawSvgText.match(extraMetadataRegex);
    if (extraMetadataMatch) {
        sanitizedText += extraMetadataMatch[0];
    }

    return sanitizedText;
};

module.exports = sanitizeSvg;

/***/ }),

/***/ "./src/serialize-svg-to-string.js":
/*!****************************************!*\
  !*** ./src/serialize-svg-to-string.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var inlineSvgFonts = __webpack_require__(/*! ./font-inliner */ "./src/font-inliner.js");

/**
 * Serialize a given SVG DOM to a string.
 * @param {SVGSVGElement} svgTag The SVG element to serialize.
 * @param {boolean|object} [injectFonts] True if fonts should be included in the SVG as
 *     base64 data. Use an object to specify custom fonts.
 * @returns {string} String representing current SVG data.
 */
var serializeSvgToString = function serializeSvgToString(svgTag, injectFonts) {
    var serializer = new XMLSerializer();
    var string = serializer.serializeToString(svgTag);
    if (injectFonts) {
        string = inlineSvgFonts(string, injectFonts);
    }
    return string;
};

module.exports = serializeSvgToString;

/***/ }),

/***/ "./src/svg-element.js":
/*!****************************!*\
  !*** ./src/svg-element.js ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/* Adapted from
 * Paper.js - The Swiss Army Knife of Vector Graphics Scripting.
 * http://paperjs.org/
 *
 * Copyright (c) 2011 - 2016, Juerg Lehni & Jonathan Puckey
 * http://scratchdisk.com/ & http://jonathanpuckey.com/
 *
 * Distributed under the MIT license. See LICENSE file for details.
 *
 * All rights reserved.
 */

/**
 * @name SvgElement
 * @namespace
 * @private
 */
var SvgElement = function () {
    function SvgElement() {
        _classCallCheck(this, SvgElement);
    }

    _createClass(SvgElement, null, [{
        key: 'attributeNamespace',


        // Mapping of attribute names to required namespaces:
        value: function attributeNamespace() {
            return {
                'href': SvgElement.xlink,
                'xlink': SvgElement.xmlns,
                // Only the xmlns attribute needs the trailing slash. See #984
                'xmlns': SvgElement.xmlns + '/',
                // IE needs the xmlns namespace when setting 'xmlns:xlink'. See #984
                'xmlns:xlink': SvgElement.xmlns + '/'
            };
        }
    }, {
        key: 'create',
        value: function create(tag, attributes, formatter) {
            return SvgElement.set(document.createElementNS(SvgElement.svg, tag), attributes, formatter);
        }
    }, {
        key: 'get',
        value: function get(node, name) {
            var namespace = SvgElement.attributeNamespace[name];
            var value = namespace ? node.getAttributeNS(namespace, name) : node.getAttribute(name);
            return value === 'null' ? null : value;
        }
    }, {
        key: 'set',
        value: function set(node, attributes, formatter) {
            for (var name in attributes) {
                var value = attributes[name];
                var namespace = SvgElement.attributeNamespace[name];
                if (typeof value === 'number' && formatter) {
                    value = formatter.number(value);
                }
                if (namespace) {
                    node.setAttributeNS(namespace, name, value);
                } else {
                    node.setAttribute(name, value);
                }
            }
            return node;
        }
    }, {
        key: 'svg',

        // SVG related namespaces
        get: function get() {
            return 'http://www.w3.org/2000/svg';
        }
    }, {
        key: 'xmlns',
        get: function get() {
            return 'http://www.w3.org/2000/xmlns';
        }
    }, {
        key: 'xlink',
        get: function get() {
            return 'http://www.w3.org/1999/xlink';
        }
    }]);

    return SvgElement;
}();

module.exports = SvgElement;

/***/ }),

/***/ "./src/svg-renderer.js":
/*!*****************************!*\
  !*** ./src/svg-renderer.js ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var loadSvgString = __webpack_require__(/*! ./load-svg-string */ "./src/load-svg-string.js");
var serializeSvgToString = __webpack_require__(/*! ./serialize-svg-to-string */ "./src/serialize-svg-to-string.js");

/**
 * Main quirks-mode SVG rendering code.
 * @deprecated Call into individual methods exported from this library instead.
 */

var SvgRenderer = function () {
  /**
   * Create a quirks-mode SVG renderer for a particular canvas.
   * @param {HTMLCanvasElement} [canvas] An optional canvas element to draw to. If this is not provided, the renderer
   * will create a new canvas.
   * @constructor
   */
  function SvgRenderer(canvas) {
    _classCallCheck(this, SvgRenderer);

    /**
     * The canvas that this SVG renderer will render to.
     * @type {HTMLCanvasElement}
     * @private
     */
    this._canvas = canvas || document.createElement('canvas');
    this._context = this._canvas.getContext('2d');

    /**
     * A measured SVG "viewbox"
     * @typedef {object} SvgRenderer#SvgMeasurements
     * @property {number} x - The left edge of the SVG viewbox.
     * @property {number} y - The top edge of the SVG viewbox.
     * @property {number} width - The width of the SVG viewbox.
     * @property {number} height - The height of the SVG viewbox.
     */

    /**
     * The measurement box of the currently loaded SVG.
     * @type {SvgRenderer#SvgMeasurements}
     * @private
     */
    this._measurements = { x: 0, y: 0, width: 0, height: 0 };

    /**
     * The `<img>` element with the contents of the currently loaded SVG.
     * @type {?HTMLImageElement}
     * @private
     */
    this._cachedImage = null;

    /**
     * True if this renderer's current SVG is loaded and can be rendered to the canvas.
     * @type {boolean}
     */
    this.loaded = false;
  }

  /**
   * @returns {!HTMLCanvasElement} this renderer's target canvas.
   */


  _createClass(SvgRenderer, [{
    key: 'loadString',


    /**
     * Load an SVG string and normalize it. All the steps before drawing/measuring.
     * @param {!string} svgString String of SVG data to draw in quirks-mode.
     * @param {?boolean} fromVersion2 True if we should perform conversion from
     *     version 2 to version 3 svg.
     */
    value: function loadString(svgString, fromVersion2) {
      // New svg string invalidates the cached image
      this._cachedImage = null;
      var svgTag = loadSvgString(svgString, fromVersion2);

      this._svgTag = svgTag;
      this._measurements = {
        width: svgTag.viewBox.baseVal.width,
        height: svgTag.viewBox.baseVal.height,
        x: svgTag.viewBox.baseVal.x,
        y: svgTag.viewBox.baseVal.y
      };
    }

    /**
     * Load an SVG string, normalize it, and prepare it for (synchronous) rendering.
     * @param {!string} svgString String of SVG data to draw in quirks-mode.
     * @param {?boolean} fromVersion2 True if we should perform conversion from version 2 to version 3 svg.
     * @param {Function} [onFinish] - An optional callback to call when the SVG is loaded and can be rendered.
     */

  }, {
    key: 'loadSVG',
    value: function loadSVG(svgString, fromVersion2, onFinish) {
      this.loadString(svgString, fromVersion2);
      this._createSVGImage(onFinish);
    }

    /**
     * Creates an <img> element for the currently loaded SVG string, then calls the callback once it's loaded.
     * @param {Function} [onFinish] - An optional callback to call when the <img> has loaded.
     */

  }, {
    key: '_createSVGImage',
    value: function _createSVGImage(onFinish) {
      var _this = this;

      if (this._cachedImage === null) this._cachedImage = new Image();
      var img = this._cachedImage;

      img.onload = function () {
        _this.loaded = true;
        if (onFinish) onFinish();
      };
      var svgText = this.toString(true /* shouldInjectFonts */);
      img.src = 'data:image/svg+xml;utf8,' + encodeURIComponent(svgText);
      this.loaded = false;
    }

    /**
     * Serialize the active SVG DOM to a string.
     * @param {?boolean} shouldInjectFonts True if fonts should be included in the SVG as
     *     base64 data.
     * @returns {string} String representing current SVG data.
     * @deprecated Use the standalone `serializeSvgToString` export instead.
     */

  }, {
    key: 'toString',
    value: function toString(shouldInjectFonts) {
      return serializeSvgToString(this._svgTag, shouldInjectFonts);
    }

    /**
     * Synchronously draw the loaded SVG to this renderer's `canvas`.
     * @param {number} [scale] - Optionally, also scale the image by this factor.
     */

  }, {
    key: 'draw',
    value: function draw(scale) {
      if (!this.loaded) throw new Error('SVG image has not finished loading');
      this._drawFromImage(scale);
    }

    /**
     * Draw to the canvas from a loaded image element.
     * @param {number} [scale] - Optionally, also scale the image by this factor.
     **/

  }, {
    key: '_drawFromImage',
    value: function _drawFromImage(scale) {
      if (this._cachedImage === null) return;

      var ratio = Number.isFinite(scale) ? scale : 1;
      var bbox = this._measurements;
      this._canvas.width = bbox.width * ratio;
      this._canvas.height = bbox.height * ratio;
      // Even if the canvas at the current scale has a nonzero size, the image's dimensions are floored pre-scaling.
      // e.g. if an image has a width of 0.4 and is being rendered at 3x scale, the canvas will have a width of 1, but
      // the image's width will be rounded down to 0 on some browsers (Firefox) prior to being drawn at that scale.
      if (this._canvas.width <= 0 || this._canvas.height <= 0 || this._cachedImage.naturalWidth <= 0 || this._cachedImage.naturalHeight <= 0) return;
      this._context.clearRect(0, 0, this._canvas.width, this._canvas.height);
      this._context.setTransform(ratio, 0, 0, ratio, 0, 0);
      this._context.drawImage(this._cachedImage, 0, 0);
    }
  }, {
    key: 'canvas',
    get: function get() {
      return this._canvas;
    }

    /**
     * @return {Array<number>} the natural size, in Scratch units, of this SVG.
     */

  }, {
    key: 'size',
    get: function get() {
      return [this._measurements.width, this._measurements.height];
    }

    /**
     * @return {Array<number>} the offset (upper left corner) of the SVG's view box.
     */

  }, {
    key: 'viewOffset',
    get: function get() {
      return [this._measurements.x, this._measurements.y];
    }
  }]);

  return SvgRenderer;
}();

module.exports = SvgRenderer;

/***/ }),

/***/ "./src/transform-applier.js":
/*!**********************************!*\
  !*** ./src/transform-applier.js ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var Matrix = __webpack_require__(/*! transformation-matrix */ "./node_modules/transformation-matrix/build-umd/transformation-matrix.min.js");
var SvgElement = __webpack_require__(/*! ./svg-element */ "./src/svg-element.js");
var log = __webpack_require__(/*! ./util/log */ "./src/util/log.js");

/**
 * @fileOverview Apply transforms to match stroke width appearance in 2.0 and 3.0
 */

var roundTo4Places = function roundTo4Places(num) {
    return Math.round(num * 1e4) / 1e4;
};

// Adapted from paper.js's Path.applyTransform
var _parseTransform = function _parseTransform(domElement) {
    var matrix = Matrix.identity();
    var string = domElement.attributes && domElement.attributes.transform && domElement.attributes.transform.value;
    if (!string) return matrix;
    // https://www.w3.org/TR/SVG/types.html#DataTypeTransformList
    // Parse SVG transform string. First we split at /)\s*/, to separate
    // commands
    var transforms = string.split(/\)\s*/g);
    var _iteratorNormalCompletion = true;
    var _didIteratorError = false;
    var _iteratorError = undefined;

    try {
        for (var _iterator = transforms[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
            var transform = _step.value;

            if (!transform) break;
            // Command come before the '(', values after
            var parts = transform.split(/\(\s*/);
            var command = parts[0].trim();
            var v = parts[1].split(/[\s,]+/g);
            // Convert values to floats
            for (var j = 0; j < v.length; j++) {
                v[j] = parseFloat(v[j]);
            }
            switch (command) {
                case 'matrix':
                    matrix = Matrix.compose(matrix, { a: v[0], b: v[1], c: v[2], d: v[3], e: v[4], f: v[5] });
                    break;
                case 'rotate':
                    matrix = Matrix.compose(matrix, Matrix.rotateDEG(v[0], v[1] || 0, v[2] || 0));
                    break;
                case 'translate':
                    matrix = Matrix.compose(matrix, Matrix.translate(v[0], v[1] || 0));
                    break;
                case 'scale':
                    matrix = Matrix.compose(matrix, Matrix.scale(v[0], v[1] || v[0]));
                    break;
                case 'skewX':
                    matrix = Matrix.compose(matrix, Matrix.skewDEG(v[0], 0));
                    break;
                case 'skewY':
                    matrix = Matrix.compose(matrix, Matrix.skewDEG(0, v[0]));
                    break;
                default:
                    log.error('Couldn\'t parse: ' + command);
            }
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally {
        try {
            if (!_iteratorNormalCompletion && _iterator.return) {
                _iterator.return();
            }
        } finally {
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }

    return matrix;
};

// Adapted from paper.js's Matrix.decompose
// Given a matrix, return the x and y scale factors of the matrix
var _getScaleFactor = function _getScaleFactor(matrix) {
    var a = matrix.a;
    var b = matrix.b;
    var c = matrix.c;
    var d = matrix.d;
    var det = a * d - b * c;

    if (a !== 0 || b !== 0) {
        var r = Math.sqrt(a * a + b * b);
        return { x: r, y: det / r };
    }
    if (c !== 0 || d !== 0) {
        var s = Math.sqrt(c * c + d * d);
        return { x: det / s, y: s };
    }
    // a = b = c = d = 0
    return { x: 0, y: 0 };
};

// Returns null if matrix is not invertible. Otherwise returns given ellipse
// transformed by transform, an object {radiusX, radiusY, rotation}.
var _calculateTransformedEllipse = function _calculateTransformedEllipse(radiusX, radiusY, theta, transform) {
    theta = -theta * Math.PI / 180;
    var a = transform.a;
    var b = -transform.c;
    var c = -transform.b;
    var d = transform.d;
    // Since other parameters determine the translation of the ellipse in SVG, we do not need to worry
    // about what e and f are.
    var det = a * d - b * c;
    // Non-invertible matrix
    if (det === 0) return null;

    // rotA, rotB, and rotC represent Ax^2 + Bxy + Cy^2 = 1 coefficients for a rotated ellipse formula
    var sinT = Math.sin(theta);
    var cosT = Math.cos(theta);
    var sin2T = Math.sin(2 * theta);
    var rotA = cosT * cosT / radiusX / radiusX + sinT * sinT / radiusY / radiusY;
    var rotB = sin2T / radiusX / radiusX - sin2T / radiusY / radiusY;
    var rotC = sinT * sinT / radiusX / radiusX + cosT * cosT / radiusY / radiusY;

    // Calculate the ellipse formula of the transformed ellipse
    // A, B, and C represent Ax^2 + Bxy + Cy^2 = 1 / det / det coefficients in a transformed ellipse formula
    // scaled by inverse det squared (to preserve accuracy)
    var A = rotA * d * d - rotB * d * c + rotC * c * c;
    var B = -2 * rotA * b * d + rotB * a * d + rotB * b * c - 2 * rotC * a * c;
    var C = rotA * b * b - rotB * a * b + rotC * a * a;

    // Derive new radii and theta from the transformed ellipse formula
    var newRadiusXOverDet = Math.sqrt(2) * Math.sqrt((A + C - Math.sqrt(A * A + B * B - 2 * A * C + C * C)) / (-B * B + 4 * A * C));
    var newRadiusYOverDet = 1 / Math.sqrt(A + C - 1 / newRadiusXOverDet / newRadiusXOverDet);
    var temp = (A - 1 / newRadiusXOverDet / newRadiusXOverDet) / (1 / newRadiusYOverDet / newRadiusYOverDet - 1 / newRadiusXOverDet / newRadiusXOverDet);
    if (temp < 0 && Math.abs(temp) < 1e-8) temp = 0; // Fix floating point issue
    temp = Math.sqrt(temp);
    if (Math.abs(1 - temp) < 1e-8) temp = 1; // Fix floating point issue
    // Solve for which of the two possible thetas is correct
    var newTheta = Math.asin(temp);
    temp = B / (1 / newRadiusXOverDet / newRadiusXOverDet - 1 / newRadiusYOverDet / newRadiusYOverDet);
    var newTheta2 = -newTheta;
    if (Math.abs(Math.sin(2 * newTheta2) - temp) < Math.abs(Math.sin(2 * newTheta) - temp)) {
        newTheta = newTheta2;
    }

    return {
        radiusX: newRadiusXOverDet * det,
        radiusY: newRadiusYOverDet * det,
        rotation: -newTheta * 180 / Math.PI
    };
};

// Adapted from paper.js's PathItem.setPathData
var _transformPath = function _transformPath(pathString, transform) {
    if (!transform || Matrix.toString(transform) === Matrix.toString(Matrix.identity())) return pathString;
    // First split the path data into parts of command-coordinates pairs
    // Commands are any of these characters: mzlhvcsqta
    var parts = pathString && pathString.match(/[mlhvcsqtaz][^mlhvcsqtaz]*/ig);
    var coords = void 0;
    var relative = false;
    var previous = void 0;
    var control = void 0;
    var current = { x: 0, y: 0 };
    var start = { x: 0, y: 0 };
    var result = '';

    var getCoord = function getCoord(index, coord) {
        var val = +coords[index];
        if (relative) {
            val += current[coord];
        }
        return val;
    };

    var getPoint = function getPoint(index) {
        return { x: getCoord(index, 'x'), y: getCoord(index + 1, 'y') };
    };

    // Returns the transformed point as a string
    var getString = function getString(point) {
        var transformed = Matrix.applyToPoint(transform, point);
        return roundTo4Places(transformed.x) + ' ' + roundTo4Places(transformed.y) + ' ';
    };

    for (var i = 0, l = parts && parts.length; i < l; i++) {
        var part = parts[i];
        var command = part[0];
        var lower = command.toLowerCase();
        // Match all coordinate values
        coords = part.match(/[+-]?(?:\d*\.\d+|\d+\.?)(?:[eE][+-]?\d+)?/g);
        var length = coords && coords.length;
        relative = command === lower;
        // Fix issues with z in the middle of SVG path data, not followed by
        // a m command, see paper.js#413:
        if (previous === 'z' && !/[mz]/.test(lower)) {
            result += 'M ' + current.x + ' ' + current.y + ' ';
        }
        switch (lower) {
            case 'm': // Move to
            case 'l':
                // Line to
                {
                    var move = lower === 'm';
                    for (var j = 0; j < length; j += 2) {
                        result += move ? 'M ' : 'L ';
                        current = getPoint(j);
                        result += getString(current);
                        if (move) {
                            start = current;
                            move = false;
                        }
                    }
                    control = current;
                    break;
                }
            case 'h': // Horizontal line
            case 'v':
                // Vertical line
                {
                    var coord = lower === 'h' ? 'x' : 'y';
                    current = { x: current.x, y: current.y }; // Clone as we're going to modify it.
                    for (var _j = 0; _j < length; _j++) {
                        current[coord] = getCoord(_j, coord);
                        result += 'L ' + getString(current);
                    }
                    control = current;
                    break;
                }
            case 'c':
                // Cubic Bezier curve
                for (var _j2 = 0; _j2 < length; _j2 += 6) {
                    var handle1 = getPoint(_j2);
                    control = getPoint(_j2 + 2);
                    current = getPoint(_j2 + 4);
                    result += 'C ' + getString(handle1) + getString(control) + getString(current);
                }
                break;
            case 's':
                // Smooth cubic Bezier curve
                for (var _j3 = 0; _j3 < length; _j3 += 4) {
                    var _handle = /[cs]/.test(previous) ? { x: current.x * 2 - control.x, y: current.y * 2 - control.y } : current;
                    control = getPoint(_j3);
                    current = getPoint(_j3 + 2);

                    result += 'C ' + getString(_handle) + getString(control) + getString(current);
                    previous = lower;
                }
                break;
            case 'q':
                // Quadratic Bezier curve
                for (var _j4 = 0; _j4 < length; _j4 += 4) {
                    control = getPoint(_j4);
                    current = getPoint(_j4 + 2);
                    result += 'Q ' + getString(control) + getString(current);
                }
                break;
            case 't':
                // Smooth quadratic Bezier curve
                for (var _j5 = 0; _j5 < length; _j5 += 2) {
                    control = /[qt]/.test(previous) ? { x: current.x * 2 - control.x, y: current.y * 2 - control.y } : current;
                    current = getPoint(_j5);

                    result += 'Q ' + getString(control) + getString(current);
                    previous = lower;
                }
                break;
            case 'a':
                // Elliptical arc curve
                for (var _j6 = 0; _j6 < length; _j6 += 7) {
                    current = getPoint(_j6 + 5);
                    var rx = +coords[_j6];
                    var ry = +coords[_j6 + 1];
                    var rotation = +coords[_j6 + 2];
                    var largeArcFlag = +coords[_j6 + 3];
                    var clockwiseFlag = +coords[_j6 + 4];
                    var newEllipse = _calculateTransformedEllipse(rx, ry, rotation, transform);
                    var matrixScale = _getScaleFactor(transform);
                    if (newEllipse) {
                        if (matrixScale.x > 0 && matrixScale.y < 0 || matrixScale.x < 0 && matrixScale.y > 0) {
                            clockwiseFlag = clockwiseFlag ^ 1;
                        }
                        result += 'A ' + roundTo4Places(Math.abs(newEllipse.radiusX)) + ' ' + (roundTo4Places(Math.abs(newEllipse.radiusY)) + ' ') + (roundTo4Places(newEllipse.rotation) + ' ' + largeArcFlag + ' ') + (clockwiseFlag + ' ' + getString(current));
                    } else {
                        result += 'L ' + getString(current);
                    }
                }
                break;
            case 'z':
                // Close path
                result += 'Z ';
                // Correctly handle relative m commands, see paper.js#1101:
                current = start;
                break;
        }
        previous = lower;
    }
    return result;
};

var GRAPHICS_ELEMENTS = ['circle', 'ellipse', 'image', 'line', 'path', 'polygon', 'polyline', 'rect', 'text', 'use'];
var CONTAINER_ELEMENTS = ['a', 'defs', 'g', 'marker', 'glyph', 'missing-glyph', 'pattern', 'svg', 'switch', 'symbol'];
var _isContainerElement = function _isContainerElement(element) {
    return element.tagName && CONTAINER_ELEMENTS.includes(element.tagName.toLowerCase());
};
var _isGraphicsElement = function _isGraphicsElement(element) {
    return element.tagName && GRAPHICS_ELEMENTS.includes(element.tagName.toLowerCase());
};
var _isPathWithTransformAndStroke = function _isPathWithTransformAndStroke(element, strokeWidth) {
    if (!element.attributes) return false;
    strokeWidth = element.attributes['stroke-width'] ? Number(element.attributes['stroke-width'].value) : Number(strokeWidth);
    return strokeWidth && element.tagName && element.tagName.toLowerCase() === 'path' && element.attributes.d && element.attributes.d.value;
};
var _quadraticMean = function _quadraticMean(a, b) {
    return Math.sqrt((a * a + b * b) / 2);
};

var _createGradient = function _createGradient(gradientId, svgTag, bbox, matrix) {
    // Adapted from Paper.js's SvgImport.getValue
    var getValue = function getValue(node, name, isString, allowNull, allowPercent, defaultValue) {
        // Interpret value as number. Never return NaN, but 0 instead.
        // If the value is a sequence of numbers, parseFloat will
        // return the first occurring number, which is enough for now.
        var value = SvgElement.get(node, name);
        var res = void 0;
        if (value === null) {
            if (defaultValue) {
                res = defaultValue;
                if (/%\s*$/.test(res)) {
                    value = defaultValue;
                    res = parseFloat(value);
                }
            } else if (allowNull) {
                res = null;
            } else if (isString) {
                res = '';
            } else {
                res = 0;
            }
        } else if (isString) {
            res = value;
        } else {
            res = parseFloat(value);
        }
        // Support for dimensions in percentage of the root size. If root-size
        // is not set (e.g. during <defs>), just scale the percentage value to
        // 0..1, as required by gradients with gradientUnits="objectBoundingBox"
        if (/%\s*$/.test(value)) {
            var size = allowPercent ? 1 : bbox[/x|^width/.test(name) ? 'width' : 'height'];
            return res / 100 * size;
        }
        return res;
    };
    var getPoint = function getPoint(node, x, y, allowNull, allowPercent, defaultX, defaultY) {
        x = getValue(node, x || 'x', false, allowNull, allowPercent, defaultX);
        y = getValue(node, y || 'y', false, allowNull, allowPercent, defaultY);
        return allowNull && (x === null || y === null) ? null : { x: x, y: y };
    };

    var defs = svgTag.getElementsByTagName('defs');
    if (defs.length === 0) {
        defs = SvgElement.create('defs');
        svgTag.appendChild(defs);
    } else {
        defs = defs[0];
    }

    // Clone the old gradient. We'll make a new one, since the gradient might be reused elsewhere
    // with different transform matrix
    var oldGradient = svgTag.getElementById(gradientId);
    if (!oldGradient) return;

    var radial = oldGradient.tagName.toLowerCase() === 'radialgradient';
    var newGradient = svgTag.getElementById(gradientId).cloneNode(true /* deep */);

    // Give the new gradient a new ID
    var matrixString = Matrix.toString(matrix);
    matrixString = matrixString.substring(8, matrixString.length - 1);
    var newGradientId = gradientId + '-' + matrixString;
    newGradient.setAttribute('id', newGradientId);

    // This gradient already exists and was transformed before. Just reuse the already-transformed one.
    if (svgTag.getElementById(newGradientId)) {
        // This is the same code as in the end of the function, but I don't feel like wrapping the next 80 lines
        // in an `if (!svgTag.getElementById(newGradientId))` block
        return 'url(#' + newGradientId + ')';
    }

    var scaleToBounds = getValue(newGradient, 'gradientUnits', true) !== 'userSpaceOnUse';
    var origin = void 0;
    var destination = void 0;
    var radius = void 0;
    var focal = void 0;
    if (radial) {
        origin = getPoint(newGradient, 'cx', 'cy', false, scaleToBounds, '50%', '50%');
        radius = getValue(newGradient, 'r', false, false, scaleToBounds, '50%');
        focal = getPoint(newGradient, 'fx', 'fy', true, scaleToBounds);
    } else {
        origin = getPoint(newGradient, 'x1', 'y1', false, scaleToBounds);
        destination = getPoint(newGradient, 'x2', 'y2', false, scaleToBounds, '1');
        if (origin.x === destination.x && origin.y === destination.y) {
            // If it's degenerate, use the color of the last stop, as described by
            // https://www.w3.org/TR/SVG/pservers.html#LinearGradientNotes
            var stops = newGradient.getElementsByTagName('stop');
            if (!stops.length || !stops[stops.length - 1].attributes || !stops[stops.length - 1].attributes['stop-color']) {
                return null;
            }
            return stops[stops.length - 1].attributes['stop-color'].value;
        }
    }

    // Transform points
    // Emulate SVG's gradientUnits="objectBoundingBox"
    if (scaleToBounds) {
        var boundsMatrix = Matrix.compose(Matrix.translate(bbox.x, bbox.y), Matrix.scale(bbox.width, bbox.height));
        origin = Matrix.applyToPoint(boundsMatrix, origin);
        if (destination) destination = Matrix.applyToPoint(boundsMatrix, destination);
        if (radius) {
            radius = _quadraticMean(bbox.width, bbox.height) * radius;
        }
        if (focal) focal = Matrix.applyToPoint(boundsMatrix, focal);
    }

    if (radial) {
        origin = Matrix.applyToPoint(matrix, origin);
        var matrixScale = _getScaleFactor(matrix);
        radius = _quadraticMean(matrixScale.x, matrixScale.y) * radius;
        if (focal) focal = Matrix.applyToPoint(matrix, focal);
    } else {
        var dot = function dot(a, b) {
            return a.x * b.x + a.y * b.y;
        };
        var multiply = function multiply(coefficient, v) {
            return { x: coefficient * v.x, y: coefficient * v.y };
        };
        var add = function add(a, b) {
            return { x: a.x + b.x, y: a.y + b.y };
        };
        var subtract = function subtract(a, b) {
            return { x: a.x - b.x, y: a.y - b.y };
        };

        // The line through origin and gradientPerpendicular is the line at which the gradient starts
        var gradientPerpendicular = Math.abs(origin.x - destination.x) < 1e-8 ? add(origin, { x: 1, y: (origin.x - destination.x) / (destination.y - origin.y) }) : add(origin, { x: (destination.y - origin.y) / (origin.x - destination.x), y: 1 });

        // Transform points
        gradientPerpendicular = Matrix.applyToPoint(matrix, gradientPerpendicular);
        origin = Matrix.applyToPoint(matrix, origin);
        destination = Matrix.applyToPoint(matrix, destination);

        // Calculate the direction that the gradient has changed to
        var originToPerpendicular = subtract(gradientPerpendicular, origin);
        var originToDestination = subtract(destination, origin);
        var gradientDirection = Math.abs(originToPerpendicular.x) < 1e-8 ? { x: 1, y: -originToPerpendicular.x / originToPerpendicular.y } : { x: -originToPerpendicular.y / originToPerpendicular.x, y: 1 };

        // Set the destination so that the gradient moves in the correct direction, by projecting the destination vector
        // onto the gradient direction vector
        var projectionCoeff = dot(originToDestination, gradientDirection) / dot(gradientDirection, gradientDirection);
        var projection = multiply(projectionCoeff, gradientDirection);
        destination = { x: origin.x + projection.x, y: origin.y + projection.y };
    }

    // Put values back into svg
    if (radial) {
        newGradient.setAttribute('cx', roundTo4Places(origin.x));
        newGradient.setAttribute('cy', roundTo4Places(origin.y));
        newGradient.setAttribute('r', roundTo4Places(radius));
        if (focal) {
            newGradient.setAttribute('fx', roundTo4Places(focal.x));
            newGradient.setAttribute('fy', roundTo4Places(focal.y));
        }
    } else {
        newGradient.setAttribute('x1', roundTo4Places(origin.x));
        newGradient.setAttribute('y1', roundTo4Places(origin.y));
        newGradient.setAttribute('x2', roundTo4Places(destination.x));
        newGradient.setAttribute('y2', roundTo4Places(destination.y));
    }
    newGradient.setAttribute('gradientUnits', 'userSpaceOnUse');
    defs.appendChild(newGradient);

    return 'url(#' + newGradientId + ')';
};

// Adapted from paper.js's SvgImport.getDefinition
var _parseUrl = function _parseUrl(value, windowRef) {
    // When url() comes from a style property, '#'' seems to be missing on
    // WebKit. We also get variations of quotes or no quotes, single or
    // double, so handle it all with one regular expression:
    var match = value && value.match(/\((?:["'#]*)([^"')]+)/);
    var name = match && match[1];
    var res = name && windowRef ?
    // This is required by Firefox, which can produce absolute
    // urls for local gradients, see paperjs#1001:
    name.replace(windowRef.location.href.split('#')[0] + '#', '') : name;
    return res;
};

/** @type {Record<string, DOMRect>} */
var pathBBoxCache = Object.create(null);
/** @type {HTMLElement} */
var svgSpotOuter = null;
/** @type {SVGSVGElement} */
var svgSpotSVG = null;
/** @type {SVGPathElement} */
var svgSpotPath = null;

/**
 * @param {SVGPathElement} element The SVG <path> element
 * @param {Window} windowRef Window object
 * @returns {DOMRect} Bounding box
 */
var getPathBBox = function getPathBBox(element, windowRef) {
    var d = element.attributes.d.value;
    if (Object.prototype.hasOwnProperty.call(pathBBoxCache, d)) {
        return pathBBoxCache[d];
    }

    // Re-use the elements when we can. Repeatededly appending and removing elements
    // can cause performance problems with browser extensions that heavily use
    // MutationObserver.
    if (!svgSpotOuter) {
        var doc = windowRef.document;
        svgSpotOuter = doc.createElement('span');
        svgSpotSVG = doc.createElementNS(SvgElement.svg, 'svg');
        svgSpotPath = doc.createElementNS(SvgElement.svg, 'path');

        // Our test element needs to be in the document and not display: none
        // when we call getBBox().
        svgSpotOuter.className = 'scratch-svg-renderer-bbox';
        svgSpotOuter.style.visibility = 'hidden';
        svgSpotOuter.style.position = 'absolute';
        svgSpotOuter.style.top = '-10000px';
        svgSpotOuter.style.left = '-10000px';
        svgSpotOuter.ariaHidden = true;

        svgSpotSVG.appendChild(svgSpotPath);
        svgSpotOuter.appendChild(svgSpotSVG);
        document.body.appendChild(svgSpotOuter);
    }

    svgSpotPath.setAttribute('d', d);
    var bbox = svgSpotSVG.getBBox();
    pathBBoxCache[d] = bbox;
    return bbox;
};

/**
 * Scratch 2.0 displays stroke widths in a "normalized" way, that is,
 * if a shape with a stroke width has a transform applied, it will be
 * rendered with a stroke that is the same width all the way around,
 * instead of stretched looking.
 *
 * The vector paint editor also prefers to normalize the stroke width,
 * rather than keep track of transforms at the group level, as this
 * simplifies editing (e.g. stroke width 3 always means the same thickness)
 *
 * This function performs that normalization process, pushing transforms
 * on groups down to the leaf level and averaging out the stroke width
 * around the shapes. Note that this doens't just change stroke widths, it
 * changes path data and attributes throughout the SVG.
 *
 * @param {SVGElement} svgTag The SVG dom object
 * @param {Window} windowRef The window to use. Need to pass in for
 *     tests to work, as they get angry at even the mention of window.
 * @param {object} bboxForTesting The bounds to use. Need to pass in for
 *     tests only, because getBBox doesn't work in Node. This should
 *     be the bounds of the svgTag without including stroke width or transforms.
 * @return {void}
 */
var transformStrokeWidths = function transformStrokeWidths(svgTag, windowRef, bboxForTesting) {
    var inherited = Matrix.identity();

    var applyTransforms = function applyTransforms(element, matrix, strokeWidth, fill, stroke) {
        if (_isContainerElement(element)) {
            // Push fills and stroke width down to leaves
            if (element.attributes['stroke-width']) {
                strokeWidth = element.attributes['stroke-width'].value;
            }
            if (element.attributes) {
                if (element.attributes.fill) fill = element.attributes.fill.value;
                if (element.attributes.stroke) stroke = element.attributes.stroke.value;
            }

            // If any child nodes don't take attributes, leave the attributes
            // at the parent level.
            for (var i = 0; i < element.childNodes.length; i++) {
                applyTransforms(element.childNodes[i], Matrix.compose(matrix, _parseTransform(element)), strokeWidth, fill, stroke);
            }
            element.removeAttribute('transform');
            element.removeAttribute('stroke-width');
            element.removeAttribute('fill');
            element.removeAttribute('stroke');
        } else if (_isPathWithTransformAndStroke(element, strokeWidth)) {
            if (element.attributes['stroke-width']) {
                strokeWidth = element.attributes['stroke-width'].value;
            }
            if (element.attributes.fill) fill = element.attributes.fill.value;
            if (element.attributes.stroke) stroke = element.attributes.stroke.value;
            matrix = Matrix.compose(matrix, _parseTransform(element));
            if (Matrix.toString(matrix) === Matrix.toString(Matrix.identity())) {
                element.removeAttribute('transform');
                element.setAttribute('stroke-width', strokeWidth);
                if (fill) element.setAttribute('fill', fill);
                if (stroke) element.setAttribute('stroke', stroke);
                return;
            }

            // Transform gradient
            var fillGradientId = _parseUrl(fill, windowRef);
            var strokeGradientId = _parseUrl(stroke, windowRef);

            if (fillGradientId || strokeGradientId) {
                // Need path bounds to transform gradient
                var bbox = bboxForTesting || getPathBBox(element, windowRef);

                if (fillGradientId) {
                    var newFillRef = _createGradient(fillGradientId, svgTag, bbox, matrix);
                    if (newFillRef) fill = newFillRef;
                }

                if (strokeGradientId) {
                    var newStrokeRef = _createGradient(strokeGradientId, svgTag, bbox, matrix);
                    if (newStrokeRef) stroke = newStrokeRef;
                }
            }

            // Transform path data
            element.setAttribute('d', _transformPath(element.attributes.d.value, matrix));
            element.removeAttribute('transform');

            // Transform stroke width
            var matrixScale = _getScaleFactor(matrix);
            element.setAttribute('stroke-width', _quadraticMean(matrixScale.x, matrixScale.y) * strokeWidth);
            if (fill) element.setAttribute('fill', fill);
            if (stroke) element.setAttribute('stroke', stroke);
        } else if (_isGraphicsElement(element)) {
            // Push stroke width, fill, and stroke down to leaves
            if (strokeWidth && !element.attributes['stroke-width']) {
                element.setAttribute('stroke-width', strokeWidth);
            }
            if (fill && !element.attributes.fill) {
                element.setAttribute('fill', fill);
            }
            if (stroke && !element.attributes.stroke) {
                element.setAttribute('stroke', stroke);
            }

            // Push transform down to leaves
            matrix = Matrix.compose(matrix, _parseTransform(element));
            if (Matrix.toString(matrix) === Matrix.toString(Matrix.identity())) {
                element.removeAttribute('transform');
            } else {
                element.setAttribute('transform', Matrix.toString(matrix));
            }
        }
    };
    applyTransforms(svgTag, inherited, 1 /* default SVG stroke width */);
};

module.exports = transformStrokeWidths;

/***/ }),

/***/ "./src/tw-fix-for-vanilla.js":
/*!***********************************!*\
  !*** ./src/tw-fix-for-vanilla.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * If an SVG has width and height set to 100%, as some tools like Affinity Designer
 * output, then vanilla scratch-svg-renderer will fail to draw anything on the stage.
 * Based on: https://github.com/ScratchAddons/ScratchAddons/pull/748
 * Upstream bug: https://github.com/scratchfoundation/scratch-svg-renderer/issues/124
 * Example: https://scratch.mit.edu/projects/447085841/
 * @param {SVGSVGElement} svgTag <svg> element, modified in-place.
 * @returns {boolean} True if a change was made.
 */
var removeWidthAndHeight100Percent = function removeWidthAndHeight100Percent(svgTag) {
    if (svgTag.getAttribute('width') === '100%' && svgTag.getAttribute('height') === '100%') {
        svgTag.removeAttribute('width');
        svgTag.removeAttribute('height');
        return true;
    }
    return false;
};

/**
 * The paper.js used by vanilla doesn't handle rounded <rect> properly when they have only rx/ry
 * set instead of both. While this is fixed in our paper.js fork, to ensure the project looks
 * correct if someone imports the project into vanilla, we'll add the missing attribute.
 * Upstream bug: https://github.com/paperjs/paper.js/issues/1863
 * @param {SVGSVGElement} svgTag <svg> element, modified in-place.
 * @returns {boolean} True if a change was made.
 */
var workaroundPaperRoundedRectangleBug = function workaroundPaperRoundedRectangleBug(svgTag) {
    var changed = false;

    /**
     * @param {SVGElement} element SVG element, modified in-place.
     */
    var recurse = function recurse(element) {
        if (element.tagName === 'rect') {
            if (element.hasAttribute('rx') && !element.hasAttribute('ry')) {
                changed = true;
                element.setAttribute('ry', element.getAttribute('rx'));
            } else if (element.hasAttribute('ry') && !element.hasAttribute('rx')) {
                changed = true;
                element.setAttribute('rx', element.getAttribute('ry'));
            }
        }

        var childNodes = element.childNodes;
        if (childNodes) {
            for (var i = 0; i < childNodes.length; i++) {
                recurse(childNodes[i]);
            }
        }
    };

    recurse(svgTag);
    return changed;
};

/**
 * Applies fixes to an SVG to improve how it will behave in vanilla Scratch.
 * Unlike the regular loadSvgString(), this should be called once when the SVG
 * is first imported instead of each time the SVG loads.
 * @param {Uint8Array} rawData Raw SVG bytes
 * @returns {Uint8Array} Fixed SVG bytes. Could be the same object as `rawData`
 */
var fixForVanilla = function fixForVanilla(rawData) {
    var decoded = new TextDecoder().decode(rawData);
    var svgDom = new DOMParser().parseFromString(decoded, 'image/svg+xml');
    var svgTag = svgDom.documentElement;

    var changed = false;
    // To avoid short-circuiting, call the function on the left side of the ||
    changed = removeWidthAndHeight100Percent(svgTag) || changed;
    changed = workaroundPaperRoundedRectangleBug(svgTag) || changed;

    if (changed) {
        var svgText = new XMLSerializer().serializeToString(svgDom);
        return new TextEncoder().encode(svgText);
    }

    // No reason to serialize and re-encode
    return rawData;
};

module.exports = fixForVanilla;

/***/ }),

/***/ "./src/tw-svg-sandbox.js":
/*!*******************************!*\
  !*** ./src/tw-svg-sandbox.js ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/** @type {HTMLIFrameElement|null} */
var iframe = null;

/**
 * @returns {HTMLElement} Safe place to insert possibly dangerous SVG.
 */
var getSandbox = function getSandbox() {
    if (!iframe) {
        iframe = document.createElement('iframe');
        iframe.className = 'scratch-svg-renderer-sandbox';

        // iframe must be same-origin so we can append elements into it directly.
        // By not including allow-scripts, the page itself won't be able to run anything, though
        // we can still access it.
        iframe.sandbox = 'allow-same-origin';

        // If iframe has display: none then Firefox and Chrome will stub certain SVG APIs. Using this alternative
        // approach to hiding the iframe ensures that it will behave more closely to how it would if the SVG was
        // in the regular DOM. (eg. getBBox() would always return 0x0)
        iframe.style.position = 'absolute';
        iframe.style.top = '-10000px';
        iframe.style.left = '-10000px';
        iframe.style.width = '0';
        iframe.style.height = '0';
        iframe.style.opacity = '0';
        iframe.style.visibility = 'hidden';
        iframe.style.pointerEvents = 'none';
        iframe.tabIndex = -1;
        iframe.ariaHidden = true;
        document.body.appendChild(iframe);

        // Use <meta> with a strict CSP so that the elements inside the iframe can't make any requests.
        // Code execution is already blocked by the sandbox attribute but it's also blocked here for an extra layer.
        // It would be better to use srcdoc instead of document.write(), but srcdoc would make us wait until the load
        // event so we would have to become async.
        iframe.contentDocument.open();
        /* eslint-disable max-len */
        iframe.contentDocument.write('\n        <!DOCTYPE html>\n        <html>\n            <head>\n                <meta charset="utf-8">\n                <meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\' data:; font-src data:; img-src data:">\n            </head>\n            <body></body>\n        </html>\n        ');
        /* eslint-enable max-len */
        iframe.contentDocument.close();
    }

    return iframe.contentDocument.body;
};

module.exports = getSandbox;

/***/ }),

/***/ "./src/util/log.js":
/*!*************************!*\
  !*** ./src/util/log.js ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var nanolog = __webpack_require__(/*! @turbowarp/nanolog */ "./node_modules/@turbowarp/nanolog/index.js");
nanolog.enable();

module.exports = nanolog('scratch-svg-render');

/***/ })

/******/ });
});
//# sourceMappingURL=scratch-svg-renderer.js.map